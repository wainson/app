
//公共方法
class Util{
        //初始化
        static init(){
            navigator.getUserMedia = navigator.getUserMedia ||
                                     navigator.webkitGetUserMedia ||
                                     navigator.mozGetUserMedia ||
                                     navigator.msGetUserMedia;

            window.AudioContext = window.AudioContext ||
                                  window.webkitAudioContext;
        }
        //日志
        static log(...args){
            console.log.apply(console,args);
        }
    };
    
/*
   let recorder = new Recorder({
       sampleRate: 44100, //采样频率，默认为44100Hz(标准MP3采样率)
       bitRate: 128, //比特率，默认为128kbps(标准MP3质量)
       success: function(){ //成功回调函数
           document.getElementById("recStart").disabled = false;
       },
       error: function(msg){ //失败回调函数
           alert(msg);
       },
       fix: function(msg){ //不支持H5录音回调函数
           alert(msg);
       }
   });
  */
class Recorder{
  
  constructor(config){
    //if(config === undefined) return undefined;
    if( typeof(this.support()) == undefined ){
        alert('当前浏览器不支持录音功能');
        return undefined;
    }
  
    this.context = undefined;
    this.microphone = undefined; //媒体流音频源
    this.processor = undefined; //js音频处理器
    this.successCallback = undefined;
    this.errorCallback = undefined;

    this.realTimeWorker = new Worker('recWorker.js'); //开启后台线程;
    
    navigator.getUserMedia({
        audio: true //配置对象
    },this.success,this.error);

  }
  
  support = ()=>{
    navigator.getUserMedia = navigator.getUserMedia ||
                                 navigator.webkitGetUserMedia ||
                                 navigator.mozGetUserMedia ||
                                 navigator.msGetUserMedia;
    window.AudioContext = window.AudioContext ||
                              window.webkitAudioContext;
    return navigator.getUserMedia;
  }
  
  //开始录音
  start = ()=>{
      if(this.processor && this.microphone){
          this.microphone.connect(this.processor);
          this.processor.connect(this.context.destination);
          Util.log('开始录音');
      }
  };
  
  //结束录音
  stop = ()=>{
      if(this.processor && this.microphone){
          this.microphone.disconnect();
          this.processor.disconnect();
          Util.log('录音结束v2.0');
      }
  };
  
  //获取blob格式录音文件
  getBlob = (onSuccess, onError)=>{
      this.successCallback = onSuccess;
      this.errorCallback = onError;
      this.realTimeWorker.postMessage({ cmd: 'finish' });
  }; 
  
  success = (stream)=>{ //成功回调
      this.context = new AudioContext();
      this.microphone = this.context.createMediaStreamSource(stream); //媒体流音频源
      this.processor = this.context.createScriptProcessor(16384,1,1); //js音频处理器
 
      this.processor.onaudioprocess = (event)=>{
          //监听音频录制过程
          Util.log('encode');
          let array = event.inputBuffer.getChannelData(0);
          this.realTimeWorker.postMessage({ cmd: 'encode', buf: array });
      };
      //let realTimeWorker = 
      this.realTimeWorker.onmessage = (e)=>{ //主线程监听后台线程，实时通信
          switch(e.data.cmd){
              case 'init':
                  Util.log('初始化成功');
                  //alert('初始化成功');
                  /*if(config.success){
                      config.success();
                  }*/
                  break;
              case 'end':
                  if(this.successCallback){
                      var blob = new Blob(e.data.buf, { type: 'audio/mp3' });
                      this.successCallback(blob);
                      Util.log('MP3大小：' + blob.size + '%cB', 'color:#0000EE');
                  }
                  break;
              case 'error':
                  Util.log('错误信息：' + e.data.error);
                  if(this.errorCallback){
                      this.errorCallback(e.data.error);
                  }
                  break;
              default:
                  Util.log('未知信息：' + e.data);
          }
      };

      this.realTimeWorker.postMessage({
              cmd: 'init',
              config: {
                  sampleRate: 44100,
                  bitRate: 128
              }
      });

  }
        
  error = (error)=>{ //失败回调
      var msg;
      switch(error.code || error.name){
          case 'PermissionDeniedError':
          case 'PERMISSION_DENIED':
          case 'NotAllowedError':
              msg = '用户拒绝访问麦克风';
              break;
          case 'NOT_SUPPORTED_ERROR':
          case 'NotSupportedError':
              msg = '浏览器不支持麦克风';
              break;
          case 'MANDATORY_UNSATISFIED_ERROR':
          case 'MandatoryUnsatisfiedError':
              msg = '找不到麦克风设备';
              break;
          default:
              msg = '无法打开麦克风，异常信息:' + (error.code || error.name);
              break;
      }
      Util.log(msg);
      /*if(config.error){
          config.error(msg);
      }*/
  }

};


export { Recorder }