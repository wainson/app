var gumStream; //stream from getUserMedia()
var recorder; //MediaRecorder object
var chunks = []; //Array of chunks of audio data from the browser
var extension;

$(document).on('mousedown', '#counterRec', function(e) {

    $("#counterAlert").remove();

    let text = $(this).attr("data-alert");

    let div = com({
        t: "div",
        i: "recVoice",
        c: "abs list_col jcfs aifs btn btn-group",
        h: com({
                t: "div",
                i: "recVoiceBtns",
                c: "rel list_row btn btn-group",
                h: com({ t: "button", i: "recStart", c: "recBtns btn btn-default", h: "start" }) +
                    com({ t: "button", i: "recStop", c: "recBtns btn btn-default", h: "stop" }) +
                    com({ t: "button", i: "recPlay", c: "recBtns btn btn-default", h: "play" }) +
                    com({ t: "button", i: "recClose", c: "recBtns btn btn-default", h: "close" })
            }) +
            com({ t: "div", i: "recVoiceAudio", c: "rel list_col jcfs aic", h: "" })
    });

    $("#paper").append(div);

    let cx = $("#counter").position().left;
    let cy = $("#counter").position().top;
    let h = $("#counter").outerHeight();
    set_position("recVoice", cx, cy + h + 5);
    $("#recVoice").css("z-index", 50);



    // true on chrome, false on firefox
    console.log("audio/webm:" + MediaRecorder.isTypeSupported('audio/webm;codecs=opus'));
    // false on chrome, true on firefox
    console.log("audio/ogg:" + MediaRecorder.isTypeSupported('audio/ogg;codecs=opus'));

    // if (recorder.isTypeSupported('audio/webm;codecs=opus')){
    //     extension="webm";
    // }else{
    //     extension="ogg"
    // }



    //toggleRecording();

    // recorder = new Recorder({
    //     sampleRate: 44100, //采样频率，默认为44100Hz(标准MP3采样率)
    //     bitRate: 128, //比特率，默认为128kbps(标准MP3质量)
    //     success: function(){ //成功回调函数
    //         document.getElementById("recStart").disabled = false;
    //     },
    //     error: function(msg){ //失败回调函数
    //         alert(msg);
    //     },
    //     fix: function(msg){ //不支持H5录音回调函数
    //         alert(msg);
    //     }
    // });






});

function stopRecording() {
    console.log("stopButton clicked");

    //disable the stop button, enable the record too allow for new recordings


    let recordButton = document.getElementById("recStart");
    let stopButton = document.getElementById("recStop");
    let pauseButton = document.getElementById("recPlay");


    stopButton.disabled = true;
    recordButton.disabled = false;
    pauseButton.disabled = true;

    //reset button just in case the recording is stopped while paused
    pauseButton.innerHTML = "Pause";

    //tell the recorder to stop the recording
    recorder.stop();

    //stop microphone access
    gumStream.getAudioTracks()[0].stop();


    //const blob = new Blob(chunks, { t: 'audio/'+extension, bitsPerSecond:128000});
    //createDownloadLink(blob)


}

function startRecording() {
    console.log("recordButton clicked");


    //add_div_pop(extension);

    /*
        Simple constraints object, for more advanced audio features see
        https://addpipe.com/blog/audio-constraints-getusermedia/
    */

    var constraints = { audio: true }

    /*
       Disable the record button until we get a success or fail from getUserMedia()
   */


    let recordButton = document.getElementById("recStart");
    let stopButton = document.getElementById("recStop");
    let pauseButton = document.getElementById("recPlay");
    recordButton.enable = false;
    stopButton.enable = true;
    pauseButton.disabled = false;

    /*
        We're using the standard promise based getUserMedia()
        https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
    */

    navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
        console.log("getUserMedia() success, stream created, initializing MediaRecorder");

        /*  assign to gumStream for later use  */
        gumStream = stream;

        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
            extension = "webm";
        } else {
            extension = "ogg"
        }

        //extension="ogg";


        var options = {
            audioBitsPerSecond: 128000,
            videoBitsPerSecond: 128000,

            mimeType: 'audio/' + extension + ';codecs=opus'
        }

        //bitsPerSecond:        128000,
        //update the format
        //document.getElementById("formats").innerHTML='Sample rate: 48kHz, MIME: audio/'+extension+';codecs=opus';

        /*
            Create the MediaRecorder object
        */
        recorder = new MediaRecorder(stream, options);




        //when data becomes available add it to our attay of audio data
        recorder.ondataavailable = function(e) {
            console.log("recorder.ondataavailable:" + e.data);

            console.log("recorder.audioBitsPerSecond:" + recorder.audioBitsPerSecond);
            console.log("recorder.videoBitsPerSecond:" + recorder.videoBitsPerSecond);
            //console.log ("recorder.bitsPerSecond:"+recorder.bitsPerSecond);
            // add stream data to chunks
            chunks.push(e.data);
            // if recorder is 'inactive' then recording has finished
            if (recorder.state === 'inactive') {
                // convert stream data chunks to a 'webm' audio format as a blob
                const blob = new Blob(chunks, { t: 'audio/' + extension, bitsPerSecond: 128000 });
                createDownloadLink(blob)
            }
        };

        recorder.onerror = function(e) {
            console.log(e.error);
            add_div_pop(e.error);
        };

        //start recording using 1 second chunks
        //Chrome and Firefox will record one long chunk if you do not specify the chunck length
        recorder.start(1000);

        //recorder.start();
    }).catch(function(err) {
        //enable the record button if getUserMedia() fails
        recordButton.disabled = false;
        stopButton.disabled = true;
        pauseButton.disabled = true;

        add_div_pop(err);

    });
}

function createDownloadLink(blob) {

    var url = URL.createObjectURL(blob);
    var au = document.createElement('audio');
    var li = document.createElement('li');
    var link = document.createElement('a');

    //add controls to the <audio> element
    au.controls = true;
    au.src = url;

    //link the a element to the blob
    link.href = url;
    link.download = new Date().toISOString() + '.' + extension;
    link.innerHTML = link.download;

    //add the new audio and a elements to the li element
    li.appendChild(au);
    li.appendChild(link);

    //add the li element to the ordered list
    //recordingsList.appendChild(li);

    $("#recVoiceAudio").append(li);



}

var recorder, gumStream;
// var recordButton = document.getElementById("recordButton");
// recordButton.addEventListener("click", toggleRecording);

function toggleRecording() {
    if (recorder && recorder.state == "recording") {
        recorder.stop();
        gumStream.getAudioTracks()[0].stop();
    } else {
        navigator.mediaDevices.getUserMedia({
            audio: true
        }).then(function(stream) {

            let div = com({
                t: "div",
                i: "recVoice",
                c: "abs list_col jcfs aifs btn btn-group",
                h: com({
                        t: "div",
                        i: "recVoiceBtns",
                        c: "rel list_row btn btn-group",
                        h: com({ t: "button", i: "recStart", c: "recBtns btn btn-default", h: "start" }) +
                            com({ t: "button", i: "recStop", c: "recBtns btn btn-default", h: "stop" }) +
                            com({ t: "button", i: "recPlay", c: "recBtns btn btn-default", h: "play" }) +
                            com({ t: "button", i: "recClose", c: "recBtns btn btn-default", h: "close" })
                    }) +
                    com({ t: "div", i: "recVoiceAudio", c: "rel list_col jcfs aic", h: "" })
            });


            let cx = $("#counter").position().left;
            let cy = $("#counter").position().top;

            let h = $("#counter").outerHeight();
            set_position("recVoice", cx, cy + h + 5);

            $("#recVoice").css("z-index", 50);

            $("#paper").append(div);

            gumStream = stream;
            recorder = new MediaRecorder(stream);
            recorder.ondataavailable = function(e) {
                var url = URL.createObjectURL(e.data);
                var preview = document.createElement('audio');
                preview.controls = true;
                preview.src = url;
                $("#recVoiceAudio").append(preview);
            };
            recorder.start();
        }).catch(function(result) {
            add_div_pop(result);
        });
    }
}

$(document).on('mousedown', '.recBtns', function(e) {

    let id = $(this).attr("id");

    if (id === "recStart") {


        startRecording();

        return;


        document.getElementById("recStop").disabled = false;
        document.getElementById("recStart").disabled = true;
        var audio = document.querySelectorAll('audio');
        for (var i = 0; i < audio.length; i++) {
            if (!audio[i].paused) {
                audio[i].pause();
            }
        }
        recorder.start();

    } else if (id === "recStop") {

        //recorder.state = 'inactive';
        //recorder.stop();

        stopRecording();

        return;

        document.getElementById("recStop").disabled = true;
        document.getElementById("recStart").disabled = false;
        recorder.stop();
        recorder.getBlob(function(blob) {
            var audio = document.createElement('audio');

            audio.src = URL.createObjectURL(blob);
            audio.controls = true;
            $("#recVoice").append(audio);
        });
    } else if (id === "recPlay") {

    } else if (id === "recClose") {
        $("#recVoice").remove();
    }

});
