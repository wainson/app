
//@ajs
class Ajs{
    constructor(){
        this.doc = document;
        if(self.$lg == undefined){
            //new Log();
        }
    }
    
    //#valid
    valid   =   (obj)=>{
        if(obj == undefined || obj == null){
          return 0;
        }
        return 1;
    }
    
    //#invalid
    inValid =   (obj)=>{
        if(this.valid(obj)==0){
          return 1;
        }
        return 0;
    }
    
    
    
    //#docu
    docu    =   {
        ds      :   ()=>{
            return this;
        },
        domain  :   ()=>{
            return document.domain;
        },
        url     :   ()=>{
            return document.URL;
        },
        uri     :   (...args)=>{
            if(args.length == 0)return document.documentURI;
            if(args.length > 0 && args[0].length > 0) {
                document.documentURI = args[0];
                return this;
            }
            
        },
        
        gbid    :   (id)=>{
            //
            return document.getElementById(id);
        },
        gbcl    :   (clazz)=>{
            return document.getElementsByClassName(clazz);
        },
        gbna    :   (name)=>{
            return document.getElementsByTagName(anyStr);
        },
        gbtg    :   (tag)=>{
            return document.getElementsByTagName(tag);
        },
        query   :   (anyStr)=>{
            return document.querySelector(anyStr);
        },
        queryAll:   (anyStr)=>{
            return document.querySelectorAll(anyStr);
        },
        
        /*
        //img-{07}.jpg
        //img-0160.jpg
        //querySetId('#div1 .img','img-','.jpg',0,160,4,'0');
        querySetId : (queStr,modStr,step=1,padChar='0')=>{
            let str    = modStr.toString();
            let hasNum = str.includes('{');
            let bit = 0;
            if(hasNum){
                let mch = str.match(/([.\.]+)\{(\d+)\}([.\.]*)/ig);
                if(mch){
                    let zeros = mch[1].toString();
                    let len = zeros.length;
                }
            }
            let elms = document.querySelectorAll('.tbox .icon');
            let i = numStart;
            for(let elm of elms){
                let ii = numPad > 0 ? i.toString().padStart(numPad,numPadStr) : i;
                elm.setAttribute('id',`${id}${ii}${idEnd}`);
                i++;
            }
              
        },*/
        
        title   :   (...args)=>{
            if(args.length == 0) return document.title;
            if(args.length > 0 && args[0].length > 0) {
                document.title = args[0];
                return this;
            }
        },
        head    :   ()=>{
            return document.head;
        },
        body    :   ()=>{
            return document.body;
        },
        rs      :   ()=>{
            return document.readyState;
        },
        ref     :   ()=>{
            return document.referrer;
        },
        exe     :   {
            copy    : (anyData,showUi=false)=>{
                let rst = document.execCommand("copy",showUi,anyData);
                
                return this;
            },
            cut    : ()=>{
                document.execCommand("cut");
                return this;
            },
            paste    : ()=>{
                document.execCommand("paste");
                return this;
            },
            selectAll    : ()=>{
                document.execCommand("selectAll");
                return this;
            },
            fullScr    : (anyStr,full=1)=>{
                let e = this.doc.query(anyStr);
                if(this.inValid(e)) return this;
                if (full==1 && document.fullscreenEnabled) {
                    e.requestFullscreen();
                    return this;
                }
                if (full==0 && document.exitFullscreen) {
                    e.exitFullscreen();
                }
                return this;
            },
        },
        cre     :   {
            ds      :   (  )=>{
                return this;
            },
            eve     :   {
                mouse   : ()=>{
                    let x = document.createEvent("MouseEvent");
                        //x.initMouseEvent("mouseover", true, true, self, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                    //document.getElementById("myDiv").dispatchEvent(x);
                },
            },
            fgm     :   ()=>{
                return document.createDocumentFragment();
            },
            comm    :   (obj,comm)=>{
                let c = document.createComment(comm);
                obj.appendChild(c);
            },
            elm     :   (tag,id,cl)=>{
                let e = document.createElement(tag);
                this.elm.idcl(id,cl,e);
                return e;
            },
            att     :   (key,val='')=>{
                let att = document.createAttribute(key);
                    if(val.length > 0)att.value = val;
                return att;
            },
            
        },
        celm    :   (...args)=>{
            return this.docu.cre.elm(...args);
        },
        zidx    :   {
            max     :   ()=>{
                let max_idx = 0;
                let tags = this.docu.queryAll('body *');

                for(let tag of tags){
                    let idx = tag.style.zIndex;
                    if(idx == '')idx = 0;
                    else if(parseInt(idx) > max_idx)
                        max_idx = idx;
                }
                return max_idx;
            },
        },
    }
    
    //#got
    got     =   {
        type    :   (obj)=>{
            //let jstr = JSON.stringify( obj.toString() );// ;JSON.stringify(`${obj}`);
            let jstr = JSON.stringify(`${obj}`);
            let str  = jstr.replace(/[\[\]]+/g,'');
            let arr  = jstr.match(/([a-z]+)\s*([a-zA-Z]*)/i);
                //if(arr == 0){ return 0;};
                //
                //
            if(Array.isArray(arr)){
                if(arr.length == 3){
                    return arr[2];
                }else if(arr.length == 2){
                    return arr[1];
                }else if(arr.length == 1){
                    return arr[0];
                }
            }
            return str;
        },
        
    }
    
    elm     =   {
            //#id
        id      :   (str,target)=>{
            try{
                if(typeof str == 'string' && str.length > 0){
                    target.setAttribute("id",str);
                }
            }catch(err){
                $lg('200::Ajs::id:49',err.message);
            }
            return target;
        },
        
        //#cl
        cl      :   (str,tar)=>{
            if(typeof str == 'string' && str.length > 0){
              tar.setAttribute("class",str);
            }
            return tar;
        },
        //#cl
        html    :   (str,tar)=>{
            if(typeof str == 'string' && str.length > 0){
              tar.innerHTML = str;
            }
            return tar;
        },
        
        //#idcl
        idcl    :   (id,cl,tar)=>{
            this.elm.id(id,tar);
            this.elm.cl(cl,tar);
            return this;
        },
    
    }
    //#bug
    bug     =   (err,argu,pos,...args)=>{
        let msg =  ( err.message == undefined ? err : err.message )  + '\n';
            msg += pos + '\n';
            msg += `args:\n${JSON.stringify(argu)}\n`;
        alert(msg);
    }
    
    clone0   =   (origin)=>{
        
        let originProto = Object.getPrototypeOf(origin);
        return Object.assign(Object.create(originProto),origin);
    }
    
    /* Shallow clone an object */
    static clone(object) {
      var newObject = Object.create(null);
    
      var property = void 0;
      for (property in object) {
        if (Reflect.apply(Object.hasOwnProperty, object, [property])) {
          newObject[property] = object[property];
        }
      }
    
      return newObject;
    }
    
    
    static objType(obj){
    //let jstr = JSON.stringify( obj.toString() );// ;JSON.stringify(`${obj}`);
    let jstr = JSON.stringify(`${obj}`);
    let str  = jstr.replace(/[\[\]]+/g,'');
    let arr  = jstr.match(/([a-z]+)\s*([a-zA-Z]*)/i);
        //if(arr == 0){ return 0;};
        //
        //
    if(Array.isArray(arr)){
        if(arr.length == 3){
            return arr[2];
        }else if(arr.length == 2){
            return arr[1];
        }else if(arr.length == 1){
            return arr[0];
        }
    }
    return str;
  }
    
    //#type(ajs)
    static type(any){
        if(Array.isArray(any)) return 'array';
        else return typeof(any);
    }
    /*
    static type(obj){
        const arr = ['undefined','function','symbol','NaN','boolean','object','array','number','string','null'];
        let rst  = undefined;
        let item = arr.pop();
        const ask = () =>{
            item = arr.pop();
            rst  = typeof(obj) == item ? item : 
                      item == undefined ? undefined : ask(); 
            return rst;
        }
        try{
            rst = Array.isArray(obj) ? 'array' : 
                      typeof(obj) == item ? item : 
                          ask() ;
            return rst;
        }catch(err){
            alert('267::Ajs::type>error:\n'+err.message);
            return 'error';
        }
    }
    */
    
    static runAll  =   (obj,except=['all'])=>{
        
        let fs = Reflect.ownKeys(obj);
        //
        for(let f of fs){
            if( except.includes(f) )continue;
            let oo = Reflect.get(obj,f);
            if(typeof(oo) == 'function'){
                oo();
            }else if(typeof(oo) == 'object'){
                Ajs.runAll(oo);
            }
        }
        return this;
    }
    
}

class Doc{
    constructor(){
        
    }
   
    static api    =   {
        ds      :   ()=>{
            return Doc;
        },
        domain  :   ()=>{
            return document.domain;
        },
        url     :   ()=>{
            return document.URL;
        },
        uri     :   (...args)=>{
            if(args.length == 0)return document.documentURI;
            if(args.length > 0 && args[0].length > 0) {
                document.documentURI = args[0];
                return Doc;
            }
            
        },
        
        
        cspv    :   (obj,ppt)=>{
            return self.getComputedStyle(obj)
                         .getPropertyValue(ppt);

        },
        gbid    :   (id)=>{
            //$lg('Ajs::gbid::47::id',id);
            return document.getElementById(id);
        },
        gbcl    :   (clazz)=>{
            return document.getElementsByClassName(clazz);
        },
        gbna    :   (name)=>{
            return document.getElementsByTagName(anyStr);
        },
        gbtg    :   (tag)=>{
            return document.getElementsByTagName(tag);
        },
        query   :   (anyStr)=>{
            return document.querySelector(anyStr);
        },
        queryAll:   (anyStr)=>{
            return document.querySelectorAll(anyStr);
        },
        
        title   :   (...args)=>{
            if(args.length == 0) return document.title;
            if(args.length > 0 && args[0].length > 0) {
                document.title = args[0];
                return Doc;
            }
        },
        head    :   ()=>{
            return document.head;
        },
        body    :   ()=>{
            return document.body;
        },
        rs      :   ()=>{
            return document.readyState;
        },
        ref     :   ()=>{
            return document.referrer;
        },
        exe     :   {
            copy    : ()=>{
                document.execCommand("copy");
                return Doc;
            },
            cut    : ()=>{
                document.execCommand("cut");
                return Doc;
            },
            paste    : ()=>{
                document.execCommand("paste");
                return Doc;
            },
            selectAll    : ()=>{
                document.execCommand("selectAll");
                return Doc;
            },
            fullScr    : (anyStr,full=1)=>{
                let e = Doc.api.query(anyStr);
                if(Doc.inValid(e)) return Doc;
                if (full==1 && document.fullscreenEnabled) {
                    e.requestFullscreen();
                    return Doc;
                }
                if (full==0 && document.exitFullscreen) {
                    e.exitFullscreen();
                }
                return Doc;
            },
        },
        cre     :   {
            ds      :   (  )=>{
                return Doc;
            },
            eve     :   {
                mouse   : ()=>{
                    let x = document.createEvent("MouseEvent");
                        //x.initMouseEvent("mouseover", true, true, self, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                    //document.getElementById("myDiv").dispatchEvent(x);
                },
            },
            fgm     :   ()=>{
                return document.createDocumentFragment();
            },
            comm    :   (obj,comm)=>{
                let c = document.createComment(comm);
                obj.appendChild(c);
            },
            elm     :   (tag,id='',cl='',html='',eveArr=null)=>{
                let e = document.createElement(tag);
                if(id   !== '') e.setAttribute('id',id);
                if(cl   !== '') e.setAttribute('class',cl);
                if(html !== '') e.innerHTML = html;
                if(eveArr == null)return e;
                for(let obj of eveArr){
                    e.setAttribute(`on${obj.name}`,obj.callback);
                }
                e.setAttribute('data-ajs-idx',Html.didx);
                Html.didx++;
                return e;
            },
            att     :   (key,val='')=>{
                let att = document.createAttribute(key);
                    if(val.length > 0)att.value = val;
                return att;
            },
            
        },
        celm    :   (...args)=>{
            return Doc.api.cre.elm(...args);
        },
        zidx    :   {
            max     :   ()=>{
                let max_idx = 0;
                let tags = Doc.api.queryAll('body *');

                for(let tag of tags){
                    let idx = tag.style.zIndex;
                    if(idx == '')idx = 0;
                    else if(parseInt(idx) > max_idx)
                        max_idx = idx;
                }
                return max_idx;
            },
        },
    }
    
    static add    = (tag,id='',cl='',html='',eveArr=null)=>{
        let e = Doc.api.celm(tag,id,cl,html,eveArr);
        document.appendChild(e);
    }
    
    static bindEvent = (docElm,eventArr)=>{
        if(eventArr == null) return;
        
        for(let obj of eventArr){
            let event = obj.event;
            let callback = obj.callback;
            let pfix = event.startsWith('on') ? '' : 'on';
            Reflect.set(docElm,`${pfix}${event}`,callback);
        }
        
        return docElm;
        
    }
    
    static has = (anyStr)=>{
      if(document.querySelector(anyStr)) return true;
      else return false;
    }
    
}

//@html
/**
 * 
 * 
 * version 2.0   2023.06.08  
 *      改用createDocumentFragment()向document插入元素
 **/ 
class Html extends Ajs{
  
  constructor(){
      super();
      if(self.$lg == undefined){
          new Log();
      }
      
      
      if(Html.instId == undefined){
          Html.instId = 0;
      }else{
          Html.instId++;
      }
      
      this.instId = Html.instId;
      
      if(Html.didx == undefined){
          //Html.didx = 0;
          this._html.autoDefine();
          let idxs = document.querySelectorAll[`*[data-ajs-idx]`];
          if(idxs == undefined || idxs.length == 0) Html.didx = 0
          else Html.didx = idxs.length;
          
      }else{
          Html.didx++;
      }
      
      this.object = undefined;
      this.topObject  = undefined;
      this.stepTopMode = 0;
      //TopObjectArray
      this.toa = [];
      this.frags = this._html.obj.frags();
      
      self.$$ = this.$$;
      self.$h = this;
      
  
  }
  
  //#step
  step(val=0){
      this.stepTopMode = val;
      return this;
  }
  
  
  
  //#_setAtt
  _setAtt(prop,val){
      if(this.object == null || this.object == undefined){return alert('Html::_setAtt:this.object == null');};
      try{
          let types = Ajs.objType(this.object);
          //alert(JSON.stringify(typeArr));
          if(types == 'DocumentFragment' && this.lastExec == 'dom'){
              let tobj = this.frags[this.fidx-1].top;
                if(tobj == null){alert('html::_setAtt:125:\n tobj == null'); return this;};
              tobj.setAttribute(prop,val);
          }else if(types.match(/HTML/i)){
              this.object.setAttribute(prop,val);
          }else{
              alert('html::_setAtt:130:\n setAttribute fail');
              return this;
          }
      }catch(err){
          let msg =  'Html::_setAtt:134:\n'+err.message +'\n';
              msg +=  JSON.stringify(`${this.object}`) + '\n';
          alert(msg);
      }
      return this;
  }
  

  
  //#wh
  wh(width,height){
    if(this.object == undefined) return this;
    if(this.object == null) return this;
    this.object.setAttribute('width',width)
    this.object.setAttribute('height',height)
    return this;
  }
  
  //#alt
  alt(pos,msg){
    let p = pos.split('.');
    let ss = '';
    for(let s of p){
      ss += s + ' > ';
    }
    ss += '\n'+msg;
    return $lg('Html::alt',ss);
  }
 
  
  //#id
  id(str,tar=this.object){
    try{
      if(typeof str == 'string' && str.length > 0){
        tar.setAttribute("id",str);
        this.lastId = str;
      }
    }catch(err){
      this.msg(err.toString());
      let num = document.all.length;
      this.msg(num.toString());
      let obj1 = document.all[document.all.length-1];
      let htm = obj1.tagName;
      this.msg(htm);
    }
    return this;
  }
  
  //#data
  data(name,id){
    this.object.setAttribute('data-ajs-'+name,id);
    return this;
  }
  
  //#cl
  cl(str,tar=this.object){
    if(str != undefined && str.length > 0){
      tar.setAttribute("class",str);
    }
    return this;
  }


  //#dom()
  //#dom(html)
  dom(anyStr=null){
    
    
    //let rst = document.querySelector(anyStr);
    
    //
   //let obj = document.getElementById(args[0]);

    //if(this.inValid(rst)){
      
        //alert("Html::dom:724:\n querySelector's result: null\nyour input:dom("+anyStr+')');
      
    //}else {
        //let DocObj = rst.length > 1 ? rst : rst[0];
        let DocObj = anyStr == null ? null : document.querySelector(anyStr);
        //.length > 1 ? rst : rst[0];
        //
        this.frags.addFrag(this._html.obj.frag(anyStr,DocObj));
        this.topObject = this.frags.lastFrag();
        
        
        this.object = this.frags.lastFrag().top;
      
        /*this.frags[this.fidx] = this.ofrag(args[0],obj);
        this.topObject = this.frags[this.fidx].frag;
        this.fidx++;*/
        
        /*
        (this.frags).push(this.ofrag(args[0],obj))
        this.topObject = this.frags[(this.frags).length-1].frag;
        this.fidx++;
        this.object = this.topObject;
        */
    //}
    //this.lastExec = 'dom';
    //this.exeStack.push('dom');
    //$lg('html:246:_showFrags:');
    //this._showFrags();
    return this;
    
  }
  
  //#top(html)
  top(...args){
    //this._showFrags();
    
    if(args.length == 0){
      //$lg('688::args.length == 0');
      this.topObject = this.object;
      
    
    }else{
      let tobj = undefined;
      //topObject.type == 'frag';
      if(this.topObject == undefined){
          //$lg('703::this.topObject == undefined');
      }else if(this.topObject.type == undefined){
          //$lg('696::this.topObject.type == undefined');
      }else if(this.topObject.type == 'frag'){
          //$lg('698::this.topObject.type == frag');
          tobj = this.topObject.query(args[0]);
      }else{
          
      }
      //let tobj = this.__fgQuery(`*[data-ajs-idx='${Html.didx-1}']`);
        
      if(this.valid(tobj)){
          this.topObject = tobj
      }else{
          //$lg('707::tobj==null,tobj,args::bgo',tobj,args);
          //alert('716::tobj = undefined;');
      }
    } 
    return this;
  }
  
  //#as
  as(...args){
      //$lg('691::n',n);
      if(args.length === 0){
        this.toa[0] = this.object;
        //$lg('729::args.length === 0');
        return this;
      }
      if(typeof(args[0]) !== 'number')alert('730::must be number');
      else this.toa[args[0]] = this.object;
      return this;
  }
  
  grab(n){
      if(n == undefined) {
          alert('739::must input a number');
          return this;
      }
      if(typeof(n) !== 'number') {
          alert('743::must be a number');
          return this;
      }
      
      this.object = this.toa[n];
      return this;
  }
  
  
  //#ok
  ok(){
      //$lg('734::ok::before::readyState::bgb',document.readyState);
      this.frags.out();
      this._html.reset();
      //$lg('737::ok::finish::bgb',Log.now());
            
      return this;
  }

  pack(){
    let bag = this.frags.pack();
    this._html.reset();
    return bag;
  }

  $$ = (...args)=>{
    return this.obj(...args);
  }
  
 //#obj
  obj(...args){
    if(args.length > 1){
        //if(args[1] == 1 || args[1] == 'all')
        //this.object = document.querySelectorAll(args[0]);
    }
    this.object = document.querySelector(args[0]);
    //
    if(this.valid(this.object)==0){
      alert('html::obj::678::this.object==null\ninput:'+args[0]);
    }
    return this;
  }
  
  //#query(html)
  query(anyStr,callback){
      //$lg('782::query');
      let docElm = this.frags.lastFrag().query(anyStr);
      if(docElm){
        //$lg('785::docElm is true');
        callback(docElm);
      }
      return this;
  }
  
 //#getObject
  getObject(tar){
       
    let obj = document.querySelector(tar);
    if(obj == null){obj = ()=>{alert('Html::getObject:obj==null');}}
    return obj;
    /*if(typeof tar === 'string'){
      if(tar.charAt(0)==='#'){
        obj = this._getById(tar.slice(1));
        
      }else if(tar.charAt(0) == '.'){
        obj = document.getElementsByClassName(tar.slice(1));
        if(obj != null){ obj = obj[0]; }
      
      }else if(this._getById(tar)!=null){
        obj = this._getById(tar);
      
      }else if(this.isTag(tar)){
        obj = document.getElementsByTagName(tar);
        
        if(obj != NULL && obj != undefined){ 
          obj = obj[0]; 
        }
      }
    }else if(typeof tar === 'object'){
      obj = tar;
    }*/
    return obj;
  }
  
  //#text
  text(cont,a=0){
    if(cont.length == 0)return this;
    if(this.object != undefined){
      this.object.innerText = cont;
    }else{
        let msg = 'ajs::html::text:665:\n';
            msg += 'this.object == undefined\n'
            msg += `your input:text(${cont},...)\n`;
        alert(msg);
    }
    return this;
  }
  
  inrHtml(html,e){
      if(html.length>0){
          if(html.match(/\&[a-zA-Z]{2,10}/g)){
            html = html.replace('"','');
            //html = &#8801;
          }
          e.innerHTML = html;
      }
      return this;
  }
  
  //#classList
  classList = {
    valid : (obj)=>{
        if(obj == null ){
            let msg =  'html::classList:497\n';
                msg += 'obj == null';
            alert(msg);
            return 0;
        }
        return 1;
    },
    arr : ()=>{
        //alert(this.object.class);
        if( this.object.className == undefined){
            //
            return [];
        } 
        //
        return this.object.className.split(' ');
    },
    add : (className)=>{
        let valid = this.classList.valid;
            if(valid(this.object) == 0 ){return this;}
        let arr = this.classList.arr();
        //
            //if(arr == null){ alert('html::classList.add:516:arr == null') ; return this ; };
        if(arr.includes(className) == 0){
            arr.push(className);
            this._setAtt('class',arr.join(' '));
            //this.object.setAttribute('class',arr.join(' '));
        };
        return this;
    },
    del : (className)=>{
        let valid = this.classList.valid;
            if(valid(this.object) == 0 ){
                return this;
            }
        let arr = this.classList.arr();
            if(arr == null){
                /*alert('html::classList.add:516:arr == null') ; */ 
                return this ;
            };
        let idx = arr.indexOf(className);
            if(idx == -1) {
                return this;
            }
        arr.splice(idx,1);
        this._setAtt('class',arr.join(' '));
        //this.object.setAttribute('class',arr.join(' '));
        return this;
    },
    remove : (...args)=>{
        return this.classList.del(...args);
    },
  }
  
  //#clist
  clist = this.classList;
  
  //#attr
  attr(name,prop){
    let mrst = name.match(/style\.([a-zA-Z]+)/i);
    if(mrst && mrst[1]){
        Reflect.set(this.object.style,mrst[1],prop);
    }else{
        this.object.setAttribute(name,prop);
    }
    return this;
  }
  
  disable(...args){
      if(args.length == 0)args[0] = 1;
      this.at.disabled(...args);
      return this;
  }
  
  data(fix,val){
    this.object.setAttribute('data-ajs-'+fix,val);
    return this;
  }

  role(val){
    this.attr(prop,val);
    return this;
  }
  
  ar = {
    base : (prop,val)=>{
              this.attr(prop,val);
              return this;
            },
    live : (val)=>{return this.ar.base('aria-live',val);},
    atom : (val)=>{return this.ar.base('aria-atomic',val);},
    live : (val)=>{return this.ar.base('aria-live',val);},
    label : (val)=>{return this.ar.base('aria-label',val);},
    hidden : (val='')=>{return this.ar.base('aria-hidden',val);},
  }
  
  //#meta
  meta = {
    base    : (prop,value,cont="")=>{
                let e = document.createElement( "meta" );
                    e.setAttribute( prop, value );
                    if(cont.length>0)e.setAttribute( "content", cont );
                this._html.fgAdd(e);
                return this.meta;
               },

    nocache : ()=>{ this.meta.base("http-equiv",'pragma',       "no-cache")
                             .base("http-equiv",'cache-control',"no-cache")
                   return this.meta ;
              },
    charset : (cont='utf-8')=>{return this.meta.base("charset",cont,"");},
    type    : (cont='text/html')=>{return this.meta.base("http-equiv","content-type",cont);},//
    eventSource   : (cont='text/event-stream')=>{return this.meta.base("http-equiv","content-type",cont);},//
    lang    : (cont='zh-cn')=>{return this.meta.base("http-equiv","Content-Language",cont);},
    viewport: (cont='1.0',max='1.0',adj='no')=>{
                
                let text = `width=device-width, initial-scale='${cont}',maximum-scale=${max}, user-scalable=${adj},shrink-to-fit=no`;
                return this.meta.base("http-equiv","viewport",text);
               },
    expires : (cont='')=>{return this.meta.base("http-equiv","expires",  cont);},
    refresh : (cont)=>{return this.meta.base("http-equiv","refresh",     cont);},
    cookie  : (cont)=>{return this.meta.base("http-equiv","set-cookie",  cont);},
    author  : (cont)=>{return this.meta.base("name","author",  cont);},
    description  : (cont)=>{return this.meta.base("name","description", cont);},
    keywords     : (cont)=>{return this.meta.base("name","keywords",    cont);},
    generator    : (cont)=>{return this.meta.base("name","generator",   cont);},
    revised      : (cont)=>{return this.meta.base("name","revised",     cont);},
    others       : (cont)=>{return this.meta.base("name","others",      cont);},
    ds           : ()=>{return this;}
  }
  
  
  input = {
    base    : (type,...args)=>{
                  return this._html.handle.tag('input',`ty:${type}`,...args);
               },
    button   : (...args)=>{return this.input.base('button',  ...args);},
    checkbox : (...args)=>{return this.input.base('checkbox',...args);},
    file     : (...args)=>{return this.input.base('file',    ...args);},
    password : (...args)=>{return this.input.base('password',...args);},
    radio    : (...args)=>{return this.input.base('radio',   ...args);},
    text     : (...args)=>{return this.input.base('text',    ...args);},
    reset    : (...args)=>{return this.input.base('reset',   ...args);},
    submit   : (...args)=>{return this.input.base('submit',  ...args);},
    range    : (...args)=>{return this.input.base('range',   ...args);},
  }
  
  
  btn = {
    base    : (id,cl,type)=>{
                let e = document.createElement( "button" );
                    e.setAttribute( "type", type );
                this.addIdClass(id,cl);
                this._html.fgAdd(e);
                return this;
               },
    button   : (id,cl,type='button')=>{return this.btn.base(id,cl,"button");},
    reset    : (id,cl,type)=>{return this.btn.base(id,cl,"reset");},
    submit   : (id,cl,type)=>{return this.btn.base(id,cl,"submit");}
  }

  //#add(html)
  add = {
    base    : (tagName,id='',cl='')=>{
                let e = this.docu.celm(tagName);
                this.elm.idcl(id,cl,e);
                this._html.fgAdd(e);
                return this;
              },
    div     : (id='',cl='')=>{return this.base('div',     id,cl);},
    table   : (id='',cl='')=>{return this.base('table',   id,cl);},
    canvas  : (id='',cl='')=>{return this.base('canvas',  id,cl);},
    a       : (id='',cl='')=>{return this.base('a',       id,cl);},
    p       : (id='',cl='')=>{return this.base('p',       id,cl);},
    ul      : (id='',cl='')=>{return this.base('ul',      id,cl);},
    ol      : (id='',cl='')=>{return this.base('ol',      id,cl);},
    li      : (id='',cl='')=>{return this.base('li',      id,cl);},
    audio   : (id='',cl='')=>{return this.base('audio',   id,cl);},
    video   : (id='',cl='')=>{return this.base('video',   id,cl);},
    option  : (id='',cl='')=>{return this.base('option',  id,cl);},
    select  : (id='',cl='')=>{return this.base('select',  id,cl);},
    td      : (id='',cl='')=>{return this.base('td',      id,cl);},
    th      : (id='',cl='')=>{return this.base('th',      id,cl);},
    tr      : (id='',cl='')=>{return this.base('tr',      id,cl);},
    img     : (id='',cl='')=>{return this.base('img',     id,cl);},
    article : (id='',cl='')=>{return this.base('article', id,cl);},
    
    ds      : ()=>{ return this; },
    
         
  }
  
  //#copy(html)
  copy(...args){
      if(this.object == null || this.topObject == null){
          let msg  = 'Html::copy::1058\n';
              msg += 'this.object or topObject == null\n';
              msg += `input: copy(${[...args].join(',')})\n`;
          alert(msg);
      }
      if(args.length == 1 && typeof args[0] == 'number'){
          let obj = this.object;
          let ope = this.object.parentElement;
          let [tag,id,cl] = [obj.nodeName, obj.id, obj.className];
          //this.dom('#'+this.topObject.id);
          let stepVal = this.stepTopMode;
          this.step(0);
          for(let i = 0 ; i < args[0] ; i++){
              //Reflect.get(this.add,'base')(tag.toLowerCase(),id,cl);
              let newObj = obj.cloneNode(true);
                  newObj.setAttribute('data-ajs-idx',Html.didx);
                  Html.didx++;
              ope.appendChild(newObj);
          }
          this.step(stepVal);
          //this.ok();
      }else if( args.length     == 2 ){
            let [a1,a2]  = [...args];
            let type = {
                a1 : typeof a1,
                a2 : typeof a2,
            }
            if(type.a1  == 'number'){
                if(type.a2  == 'string'){
                    if(a2 == 'complex' || a2 == 'cpx'){
                        return this.copyComplex.conf.num(a1);
                    }else{
                        
                    }
                }else if(type.a2  == 'object'){
                }
            }else if(type.a1  == 'string'){
                
            }
      }
      return this;
  }
  
  copyComplex = {
      para : {
          num  : 0,
          id   : '',
          cl   : '',
          cid  : '',
          ccl  : '',
          into : this.topObject,
          tar  : this.object,
      },
      conf : {
          num  : (val)=>{this.copyComplex.para.num = val;    return this.copyComplex.conf;},
          id   : (val)=>{this.copyComplex.para.id  = val;    return this.copyComplex.conf;},
          cl   : (val)=>{this.copyComplex.para.cl  = val;    return this.copyComplex.conf;},
          cid  : (val)=>{this.copyComplex.para.cid = val;    return this.copyComplex.conf;},
          ccl  : (val)=>{this.copyComplex.para.ccl = val;    return this.copyComplex.conf;},
          into : (anyStr)=>{this.copyComplex.para.into = anyStr;    return this.copyComplex.conf;},
          done : ()=>{ return this.copyComplex.exec },
      },
      exec : ()=>{
          //new fgm
          //this.object.cloneNode
          //reset id,cl,...attr
          //fgm.appendChild
          //topObject.appendChild(fgm)
          return this;
      },
      ds : ()=>{
          return this;
      }
  }
  
  copyCpx = this.copyComplex;


  clone(...args) {
      let [i,who,num] = [-1,null,null];
      const f = (a,n) =>{
          if(n == 1) return a.charAt(0);
          else if(n > 1)return a.slice(0,n-1);
      } 
      
      for(let a of args){
          i++;
          let t = Ajs.type(a);
                if( t === 'number'){
                    if( i === 0){
                        if(a)who = this.toa[a];
                    }else if( i === 1){
                        if(a)num = a;
                    }
          }else if( t === 'string'){
              let [f1,f2] = [f(a,1),(a,2)];
          }else;
      }
      
      if(who && num){
          let parent = who.parentNode;
          if(parent){
              for(let i = 0; i<num; i++){
                  let newNode = who.cloneNode(true);
                      this._html.setIdx(newNode);
                  parent.appendChild(newNode);
              }
          }
      }
      return this;
  }


  into(...args){
    
    
    return this.to(...args);
  }

  
  //#controls
  controls(val='controls'){
      this._setAtt('controls',val);
      return this;
  }
  
  //#src
  src(url){
      this._setAtt('src',url);
      return this;
  }

  aria(val){
    this.object.setAttribute('aria',val);
    return this;
  }

  //#docType
  docType(){
    this.getObject('html').prepend('<!DOCTYPE html>');
    return this;
  }
  
  //#demo
  demo(tit=''){
      //document.doctype = 'html5';
      this.dom('head')
          .title(`!${tit}`)
          .meta .charset()
                .viewport()
                .nocache()
                .expires().ds()
          .ok();
    return this;   
  }

    //#att
    at = {
      base      : (prop,val)=>{
                  try{
                    this.object.setAttribute(prop,val);
                  }catch(err){
                    this.msg(err.toString());
                  }
                    return this.at;
                  },
      id        : (str)=>{return this.at.base('id',          str)},
      class     : (str)=>{return this.at.base('class',       str)},
      name      : (str)=>{return this.at.base('name',        str)},
      style     : (str)=>{return this.at.base('style',       str)},
      
      title     : (str)=>{return this.at.base('title',       str)},
      lang      : (str)=>{return this.at.base('lang',        str)},
      type      : (str)=>{return this.at.base('type',        str)},
      alt       : (str)=>{return this.at.base('alt',        str)},
      
      min       : (num)=>{return this.at.base('min',       num)},
      max       : (num)=>{return this.at.base('max',       num)},
      value     : (str)=>{return this.at.base('value',       str)},
      rows      : (str)=>{return this.at.base('rows',        str)},
      cols      : (str)=>{return this.at.base('cols',        str)},
      tabindex  : (num)=>{return this.at.base('tabindex',    num)},
      draggable : (bool)=>{return this.at.base('draggable',  bool)},
      disabled  : (bool)=>{return this.at.base('disabled',   bool)},
      readonly  : (bool)=>{return this.at.base('readOnly',   bool)},
      width     :  (num)=>{return this.at.base('width',      num)},
      height    :  (num)=>{return this.at.base('height',     num)},
      src       :  (str)=>{return this.at.base('src',        str)},
      controls  :  (str)=>{return this.at.base('controls',   str)},
      
      ds        :  ()=>{return this;}
      
    }
    
    //#on
    on = {
      //self 事件属性
      afterprint        : (callback,mode=1,event='afterprint')=>{return this._html.eve(callback,event,mode);},
      beforeprint       : (callback,mode=1,event='beforeprint')=>{return this._html.eve(callback,event,mode);},
      beforeload        : (callback,mode=1,event='beforeload')=>{return this._html.eve(callback,event,mode);},
      blur              : (callback,mode=1,event='blur')=>{return this._html.eve(callback,event,mode);},
      error             : (callback,mode=1,event='error')=>{return this._html.eve(callback,event,mode);},
      focus             : (callback,mode=1,event='focus')=>{return this._html.eve(callback,event,mode);},
      haschange         : (callback,mode=1,event='haschange')=>{return this._html.eve(callback,event,mode);},
      load              : (callback,mode=1,event='load')=>{/*$lg('ajs::html::on::1405::onload');*/return this.eve(callback,event,mode);},
      message           : (callback,mode=1,event='message')=>{return this._html.eve(callback,event,mode);},
      offline           : (callback,mode=1,event='offline')=>{return this._html.eve(callback,event,mode);},
      line              : (callback,mode=1,event='line')=>{return this._html.eve(callback,event,mode);},
      pagehide          : (callback,mode=1,event='pagehide')=>{return this._html.eve(callback,event,mode);},
      pageshow          : (callback,mode=1,event='pageshow')=>{return this._html.eve(callback,event,mode);},
      popstate          : (callback,mode=1,event='popstate')=>{return this._html.eve(callback,event,mode);},
      redo              : (callback,mode=1,event='redo')=>{return this._html.eve(callback,event,mode);},
      resize            : (callback,mode=1,event='resize')=>{return this._html.eve(callback,event,mode);},
      storage           : (callback,mode=1,event='storage')=>{return this._html.eve(callback,event,mode);},
      undo              : (callback,mode=1,event='undo')=>{return this._html.eve(callback,event,mode);},
      unload            : (callback,mode=1,event='unload')=>{return this._html.eve(callback,event,mode);},
      
      //表单事件
      blur              : (callback,mode=1,event='blur')=>{return this._html.eve(callback,event,mode);},
      change            : (callback,mode=1,event='change')=>{return this._html.eve(callback,event,mode);},
      ctextmenu         : (callback,mode=1,event='ctextmenu')=>{return this._html.eve(callback,event,mode);},
      focus             : (callback,mode=1,event='focus')=>{return this._html.eve(callback,event,mode);},
      formchange        : (callback,mode=1,event='formchange')=>{return this._html.eve(callback,event,mode);},
      forminput         : (callback,mode=1,event='forminput')=>{return this._html.eve(callback,event,mode);},
      input             : (callback,mode=1,event='input')=>{return this._html.eve(callback,event,mode);},
      invalid           : (callback,mode=1,event='invalid')=>{return this._html.eve(callback,event,mode);},
      reset             : (callback,mode=1,event='reset')=>{return this._html.eve(callback,event,mode);},
      select            : (callback,mode=1,event='select')=>{return this._html.eve(callback,event,mode);},
      submit            : (callback,mode=1,event='submit')=>{return this._html.eve(callback,event,mode);},
      
      //键盘事件
      keydown           : (callback,mode=1,event='keydown')=>{return this._html.eve(callback,event,mode);},
      keypress          : (callback,mode=1,event='keypress')=>{return this._html.eve(callback,event,mode);},
      keyup             : (callback,mode=1,event='keyup')=>{return this._html.eve(callback,event,mode);},
      
      //鼠标事件
      click             : (callback,mode=1,event='click')=>{return this._html.eve(callback,event,mode);},
      dblClick          : (callback,mode=1,event='dblclick')=>{return this._html.eve(callback,event,mode);},
      drag              : (callback,mode=1,event='drag')=>{return this._html.eve(callback,event,mode);},
      dragEnd           : (callback,mode=1,event='dragend')=>{return this._html.eve(callback,event,mode);},
      dragEnter         : (callback,mode=1,event='dragenter')=>{return this._html.eve(callback,event,mode);},
      dragLeave         : (callback,mode=1,event='dragleave')=>{return this._html.eve(callback,event,mode);},
      dragOver          : (callback,mode=1,event='dragover')=>{return this._html.eve(callback,event,mode);},
      dragStart         : (callback,mode=1,event='dragstart')=>{return this._html.eve(callback,event,mode);},
      drop              : (callback,mode=1,event='drop')=>{return this._html.eve(callback,event,mode);},
      mouseDown         : (callback,mode=1,event='mousedown')=>{return this._html.eve(callback,event,mode);},
      mouseMove         : (callback,mode=1,event='mousemove')=>{return this._html.eve(callback,event,mode);},
      mouseOut          : (callback,mode=1,event='mouseout')=>{return this._html.eve(callback,event,mode);},
      mouseOver         : (callback,mode=1,event='mouseover')=>{return this._html.eve(callback,event,mode);},
      mouseUp           : (callback,mode=1,event='mouseup')=>{return this._html.eve(callback,event,mode);},
      mouseWheel        : (callback,mode=1,event='mousewheel')=>{return this._html.eve(callback,event,mode);},
      scroll            : (callback,mode=1,event='scroll')=>{return this._html.eve(callback,event,mode);},
      
      // 多媒体事件
      abort             : (callback,mode=1,event='abort')=>{return this._html.eve(callback,event,mode);},
      canPlay           : (callback,mode=1,event='canplay')=>{return this._html.eve(callback,event,mode);},
      canPlayThrough    : (callback,mode=1,event='canplaythrough')=>{return this._html.eve(callback,event,mode);},
      duratiChange      : (callback,mode=1,event='duratichange')=>{return this._html.eve(callback,event,mode);},
      emptied           : (callback,mode=1,event='emptied')=>{return this._html.eve(callback,event,mode);},
      ended             : (callback,mode=1,event='ended')=>{return this._html.eve(callback,event,mode);},
      error             : (callback,mode=1,event='error')=>{return this._html.eve(callback,event,mode);},
      loadedData        : (callback,mode=1,event='loadeddata')=>{return this._html.eve(callback,event,mode);},
      loadedMetaData    : (callback,mode=1,event='loadedmetadata')=>{return this._html.eve(callback,event,mode);},
      loadStart         : (callback,mode=1,event='loadstart')=>{return this._html.eve(callback,event,mode);},
      pause             : (callback,mode=1,event='pause')=>{return this._html.eve(callback,event,mode);},
      play              : (callback,mode=1,event='pause')=>{return this._html.eve(callback,event,mode);},
      playing           : (callback,mode=1,event='playing')=>{return this._html.eve(callback,event,mode);},
      progress          : (callback,mode=1,event='progress')=>{return this._html.eve(callback,event,mode);},
      rateChange        : (callback,mode=1,event='ratechange')=>{return this._html.eve(callback,event,mode);},
      readystateChange  : (callback,mode=1,event='readystatechange')=>{return this._html.eve(callback,event,mode);},
      seeked            : (callback,mode=1,event='seeked')=>{return this._html.eve(callback,event,mode);},
      seeking           : (callback,mode=1,event='seeking')=>{return this._html.eve(callback,event,mode);},
      stalled           : (callback,mode=1,event='stalled')=>{return this._html.eve(callback,event,mode);},
      suspEnd           : (callback,mode=1,event='suspend')=>{return this._html.eve(callback,event,mode);},
      timeUpdate        : (callback,mode=1,event='timeupdate')=>{return this._html.eve(callback,event,mode);},
      volumeChange      : (callback,mode=1,event='volumechange')=>{return this._html.eve(callback,event,mode);},
      waiting           : (callback,mode=1,event='waiting')=>{return this._html.eve(callback,event,mode);},
      
      //动画事件
      aniStart          : (callback,mode=1,event='animationstart')=>{return this._html.eve(callback,event,mode);},
      aniEnd            : (callback,mode=1,event='animationend')=>{return this._html.eve(callback,event,mode);},
      aniEnd_Wk         : (callback,mode=1,event='webkitAnimationEnd')=>{return this._html.eve(callback,event,mode);},
      aniIter           : (callback,mode=1,event='animationiteration')=>{return this._html.eve(callback,event,mode);},
      
  
    }

    //#_html(html)
    _html   =   {
      
        tags : {
            all      : [
                'a',
                'abbr',
                'address',
                
                'area',
                'article',
                'aside',
                'audio',
                'b',
                'base',
                'bdi',
                'bdo',
                'blockquote',
                'body',
                'br',
                'button',
                'canvas',
                'caption',
                'cite',
                'code',
                'col',
                'colgroup',
                //'data',
                'datalist',
                'dd',
                'del',
                'details',
                'dfn',
                'dialog',
                'div',
                'dl',
                'dt',
                'em',
                'embed',
                'fieldset',
                'figcaption',
                'figure',
                'footer',
                'form',
                'h1',
                'h2',
                'h3',
                'h4',
                'h5',
                'h6',
                'head',
                'header',
                'hr',
                'html',
                'i',
                'iframe',
                'img',
                //'input',
                'ins',
                'kbd',
                'label',
                'legend',
                'li',
                'link',
                'main',
                'map',
                'mark',
                //'meta',
                'meter',
                'nav',
                'noscript',
                //'object',
                'ol',
                'optgroup',
                'option',
                'output',
                'p',
                'param',
                'picture',
                'pre',
                'progress',
                'q',
                'rp',
                'rt',
                'ruby',
                's',
                'samp',
                'script',
                'section',
                'select',
                'small',
                'source',
                'span',
                'strong',
                'style',
                'sub',
                'summary',
                'sup',
                'svg',
                'table',
                'tbody',
                'td',
                'template',
                'textarea',
                'tfoot',
                'th',
                'thead',
                'time',
                'title',
                'tr',
                'track',
                'u',
                'ul',
                'var',
                'video',
                'wbr'],
            basic    : [
                'doctype',
                'html',
                'head',
                'title',
                'body',
                'hn',
                'p',
                'br',
                'hr',
                'comment',
            ],
            format   : [
                'abbr',
                'address',
                'b',
                'bdi',
                'bdo',
                'blockquote',
                'cite',
                'code',
                'del',
                'dfn',
                'em',
                'i',
                'ins',
                'kbd',
                'mark',
                'meter',
                'pre',
                'progress',
                'q',
                'rp',
                'rt',
                'ruby',
                's',
                'samp',
                'small',
                'strong',
                'sub',
                'sup',
                'template',
                'time',
                'u',
                'var',
                'wbr',
            ],
            form     : [
                'form',
                'input',
                'textarea',
                'button',
                'select',
                'optgroup',
                'option',
                'label',
                'fieldset',
                'legend',
                'datalist',
                'output',
            ],
            frame    : [
                'iframe',
            ],
            image    : [
                'img',
                'map',
                'area',
                'canvas',
                'figcaption',
                'figure',
                'picture',
                'svg',
            ],
            avd      : [
                'audio',
                'source',
                'track',
                'video',
            ],
            link     : [
                'a',
                'link',
                'nav',
            ],
            list     : [
                'ul',
                'ol',
                'li',
                'dl',
                'dt',
                'dd',
            ],
            table    : [
                'table',
                'caption',
                'th',
                'tr',
                'td',
                'thead',
                'tbody',
                'tfoot',
                'col',
                'colgroup',
            ],
            style    : [
                'style',
                'div',
                'span',
                'header',
                'footer',
                'main',
                'section',
                'article',
                'aside',
                'details',
                'dialog',
                'summary',
                'data',
            ],
            meta     : [
                'head',
                'meta',
                'base',
            ],
            program  : [
                'script',
                'noscript',
                'embed',
                'object',
                'param',
            ],
        },
        
        attrs : {
          
            input  : [
                'autocomplete',
                'autofocus',
                'form',
                'formaction',
                'formenctype',
                'formmethod',
                'formnovalidate',
                'formtarget',
                'height',
                'width',
                'list',
                'min',
                'max',
                'multiple',
                'pattern',
                'placeholder',
                'required',
                'range',
                'step'
            ],
          
        },
        
        //##obj(html)
        obj  : {
            //##frags
            frags : (...args)=>{
            
                let fgs = {
                    type : 'frags',
                    arr   : [],
                    addFrag   : function(frag){
                        this.arr.push(frag);
                    },
                    lastFrag  : function(){
                        //return frag
                        return this.arr[this.arr.length-1];
                    },
                    query : function(anyStr){
                        let DocObj = null;
                        for(let frag of this.arr){
                          DocObj = frag.query(anyStr);
                          if(DocObj) return DocObj;
                        }
                        return DocObj;
                    },
                    out   : function(){
                        //$lg('1553::frags.out()::start::bgb',Log.now());
                        let fgm = document.createDocumentFragment();
                        //let pack = 0;
                        
                        for(let frag of this.arr){
                            
                            if(frag.top == null){
                              fgm.appendChild(frag.pack());
                            }else{
                              frag.out();
                            }
                        }
                        
                        return fgm;
                        
                        //$lg('1558::frags.out()::finish::bgb',Log.now());
       
                    },
                    pack  : function(){
                        //$lg('1553::frags.out()::start::bgb',Log.now());
                        let fgm = document.createDocumentFragment();
                        for(let frag of this.arr){
                            fgm.appendChild(frag.pack());
                        }
                        
                        return fgm;
                        //$lg('1558::frags.out()::finish::bgb',Log.now());
       
                    },
                    
                }
                return fgs;
            },
            //##frag
            frag  : (anyStr,topDocElm)=>{
                let dcdf = document.createDocumentFragment();
                let ofg = {
                    from  : `dom('${anyStr}')`,
                    type  : 'frag',
                    que   : anyStr,
                    top   : topDocElm,
                    fgm   : dcdf,
                    elms  : [], //DocElm
                    
                    //top(anyStr)
                    query  : function(anyStr){
                        $lg(`1655::query('${anyStr}')`);
                        let find = (elm,didx)=>{
                            
                            if(elm.getAttribute('data-ajs-idx') == didx){
                                //$lg('1655::elm was found');
                                return elm;
                            }else if(elm.childElementCount > 0){
                                for(let child of elm.childNodes){
                                    let tar = find(child,didx);
                                    if(tar) return tar;
                                }
                            }
                            //$lg('1662::elm was not found');
                            return null;
                        }
                        let cloneFgm = this.fgm.cloneNode(true);      
                        for(let DocElm of this.elms){
                            cloneFgm.appendChild(DocElm);
                        }
                        //$lg('1653::anyStr',anyStr);
                        let docObj = cloneFgm.querySelectorAll(anyStr);
                        $lg('1676::docObj.length',docObj.length);
                        if(docObj){
                            //$lg('1657',docObj[0].outerHTML);
                            let didx = docObj[0].getAttribute('data-ajs-idx');
                            //$lg('1663::didx',didx);
                            for(let elm of this.elms){
                              //$lg('1665::elm',elm.outerHTML);
                              let tar = find(elm,didx);
                              if(tar) {
                                  $lg('1680::elm was found',tar.getAttribute('data-ajs-idx'));
                                  return tar;
                              }
                              /*if(elm.getAttribute('data-ajs-idx') == didx){
                                  $lg('1667::didx',didx);
                                  return elm;
                              }
                              */
                            }
                            return null;
                        }else{
                            let msg  = '2074:\n';
                                msg += '在当前的fgm中找不到你指定的内容:\n';
                                msg += `your input : '${anyStr}'`;
                            alert(msg);
                        }
                    },  

                    lastElm  : function(){
                        return this.elms[this.elms.length-1];
                    },
                    addElm   : function(DocElm){
                        this.elms.push(DocElm);
                    },
                    out      : function(){
                        //$lg('1605::frag.out()::start::bgb',Log.now());
       
                        
                        for(let DocElm of this.elms){
                            this.fgm.appendChild(DocElm);
                        }
                        if(Array.isArray(this.top)){
                            for(let t of this.top){
                                t.appendChild(this.fgm);
                            }
                        }else{
                            //$lg(`1616::${this.que}.appendChild::before::bgo`,Log.now());
                            this.top.appendChild(this.fgm);
                            //$lg(`1618::${this.que}.appendChild::finish::bgo`,Log.now());
                         
                        }
                        
                        //$lg('1622::frag.out()::finish::bgb',Log.now());
       
                     
                    },
                    pack     : function(){
                        //$lg('1605::frag.out()::start::bgb',Log.now());
       
                        
                        for(let DocElm of this.elms){
                            this.fgm.appendChild(DocElm);
                        }
                        return this.fgm;

                    },
                }
            
                return ofg;
            },
            
        },
        
        //##handler
        handle    :   {
          
            tag  : (tag,...args)=>{
                
                let e = this.docu.celm(tag);
                let ppts = [];
                let [i,id,cl,ht,tobj,eveArr,add] = [-1,'','','',null,null,this._html.fgAdd];
                let [src,type] = [null,null];
                ppts.push({src},{type});
                const f = (a,n) =>{
                    if(n == 1) return a.charAt(0);
                    else if(n > 1)return a.slice(0,n-1);
                }
                
                for(let a of args){
                    
                    i++;
                    const t = Ajs.type(a);
                    if      ( t === 'string' ){
                        const [f1,f2,f3] = [f(a,1), f(a,2), f(a,3)];
                        
                        if     (f1 == '#'  ) {
                          id = a.slice(1);
                          if(id === 'hcw'){
                            //$lg('1704::hcw::args.length',args.length,...args);
                          }
                        }
                        else if(f1 == '.'  ) {
                          cl = a.slice(1);
                          //
                        }
                        else if(f1 == '!'  ) {
                          ht = a.slice(1);
                          //
                        }
                        else if(f2 == 'i:' ) id = a.slice(2);
                        else if(f3 == 'id:') id = a.slice(3);
                        else if(f2 == 'c:' ) cl = a.slice(2);
                        else if(f3 == 'cl:') cl = a.slice(3);
                        else if(f2 == 'h:' ) ht = a.slice(2);
                        else if(f3 == 'ht:') ht = a.slice(3);
                       //else if(f2 == 't:' ) text = a.slice(2);
                        else if(f2 == 's:' ) src  = a.slice(2);
                        else if(f2 == 't:') type  = a.slice(2);
                        else if(f3 == 'ty:') type  = a.slice(3);
                        
                        else{
                          if(tag === 'a'){
                            e = this._html.handle.a(e,...args);
                
                          }else{
                                 if(i  ==  0  ) {cl = a;}
                            else if(i  ==  1  ) {id = a;}
                            else if(i  ==  2  ) {ht = a;}
                          }
                        };
                    }else if( t === 'array'  ){
                        //eventArr
                        eveArr = a;
                    }else if( t === 'number' ){
                        //$lg('1610::number::a',a);
                        let iid = a;
                        add = (docElm)=>{
                            (this.toa[iid]).appendChild(docElm);
                            this.object = (this.toa[iid]).lastChild;
                            //$lg('1615::this.object::bgo',this.object);
                            //$lg('1616::innerHtml:',(this.toa[iid]).innerHTML);
                        }
                    }else if( t === 'null' ){
                        //$lg(`1376::t === 'null'`);
                        add = (docElm)=>{
                            (this.toa[0]).appendChild(docElm);
                            this.object = (this.toa[0]).lastChild;
                        }
                    }else{
                    }
                }
                
                
                    
                this.elm.idcl(id,cl,e);
                this.elm.html(ht,e);
                
                ppts.forEach((obj)=>{
                  if(obj.keys != null){
                    (obj.keys).forEach((key)=>{
                      if(obj[key])Reflect.set(e,obj[key],val);})
                  }
                });
                if(eveArr) e = Doc.bindEvent(e,eveArr);
                
                e.setAttribute('data-ajs-idx',Html.didx);
                Html.didx++;
                    
                add(e);
                
                return this;
            },
            
            a    : (docElm,...args)=>{
                let [i,hr,ht,tg] = [-1,null,null,null];
                const f = (a,n) =>{
                    if(n == 1) return a.charAt(0);
                    else if(n > 1)return a.slice(0,n-1);
                } 
                for(let a of args){
                    i++;
                    let t = Ajs.type(a);
                    if      ( t === 'string' ){
                        const [f1,f2,f3,f4,f5] = [f(a,1), f(a,3), f(a,4), f(a,5), f(a,6)];
                        //$lg('1852::bgb',a,f1,f2,f3,f5,f6);
                             if(f1 == '_'  ) tg  = a;
                        else if(f2 == 'u:' ) hr  = a.slice(2);
                        else if(f2 == './' ) hr  = a.slice(2);
                        else if(f3 == '../') hr  = a.slice(3);
                        else if(f3 == 'hr:') hr  = a.slice(3);
                        else if(f4 == 'http')  hr = a;
                        else if(f5 == 'https') hr = a;
                        else if(i  ==  0  ) hr  = a;
                        else if(i  ==  1  ) tg  = a;
                        else if(i  ==  2  ) ht  = a;
                        else;
                    }else;
                }
                if(hr) docElm.setAttribute('href',hr);
                if(tg) docElm.setAttribute('target',tg);
                if(ht) docElm.innerHTML = ht;
                return docElm;
            },
            
            attr : ()=>{
              
            },
            
        },
        
        fgAdd     :   (it)=>{
    
            it.setAttribute('data-ajs-idx',Html.didx);

            if(this.topObject != undefined && it != undefined){
                
                let t = this.topObject.type;
                if( t == undefined ) {
                    //DocElm
                    $log.lgg(`'${this.topObject.innerHTML}'`);
                    $log.lgg(`'${this.topObject.id}'`);
                    
                    this.topObject.appendChild(it);
                    //this.object = it;
                    this.object = this.topObject.lastChild;
                }else if( t == 'frags') {
                    
            
                }else if( t == 'frag') { 
                    
                    this.topObject.addElm(it);
                    this.object = this.topObject.lastElm();
                    
                }
              
                if(this.inValid(this.object)){
                    //this.badMsg('fgAdd');
                    //
                }
              
                if(this.stepTopMode){
                    this.topObject = this.object;
                }
              
            }else{
                //alert('1698.fgAdd:\nthis.topObject == undefined || it == undefined');
            }
            Html.didx++;
            this.lastExec = 'fgAdd';
            return this;
        },
        
        //#eve
        eve       :   (callback,event,mode)=>{
      
            if(mode == 1){
                this.object.addEventListener( event, callback, false );
            }else{
                Reflect.set(this.object,`on${event}`,callback);
                //
                //
            }
            return this;
          
        },
        
        //#reset
        reset     :   ()=>{
            this.frags      = this._html.obj.frags();
            this.topObject  = undefined;
            this.object     = undefined;
            this.toa        = [];
            Html.didx++;
            return this;
        },
  
        setIdx    :   (docNode)=>{
            if(!docNode){
                alert(`1900::docNode can't be null`);
                return this;
            }
            docNode.setAttribute('data-ajs-idx',Html.didx);
            Html.didx++;
            let all = docNode.querySelectorAll('*');
            for(let a of all){
                a.setAttribute('data-ajs-idx',Html.didx);
                Html.didx++;
            }
            return this;
        },
  
        //##autoDefine
        autoDefine :  ()=>{
            
            let tags = this._html.tags.all;
            for(let tag of tags ){
                Reflect.defineProperty(Html.prototype,tag,{
                    name  : tag,
                    value : function(...args){
                        return this._html.handle.tag(tag,...args);
                    },
                    enumerable : true,
                })
            }
        }
        
    }

}



//@ui
class Ui extends Html{ 
    
    constructor(prefix = 'ajs-ui'){
        super();
        this.h  = new Html();
        this.cs = new Css();
        this.p;
        this.prefix = prefix;
        if(self.$lg == undefined){
            new Log();
        }
        
    }
    
    slider      = class{
        constructor(){
            if(self.readyStateChangeList == undefined){
                self.readyStateChangeList = [];
                document.onreadystatechange = ()=>{
                    //if(document.readyState == 'complete'){
                        for(let fn of self.readyStateChangeList){
                            if(fn)fn();
                        }
                    //}
                }
            }
            this.para = {
                into  : 'body',
                open  : undefined,
                tit   : '',
                pos   : 'L',//L,R,M
                min   : '0px',
                max   : '100%',
                pfix  : 'ajs',
                id    : 'ajs-slider',
                cl    : 'ajs-slider',
                bg    : 'yellow',
                bord  : 0,
                level : 12,
                opc   : 0.9,
                time  : 0.4,
                fsize : 10,
                id_   : 'ajs-slider',
                cl_   : 'ajs-slider',
                name  : 'slider',
            }
        }
        conf    = {
            into   : (anyStr)=>{this.para.into = anyStr; return this.conf;},
            open   : (anyStr)=>{this.para.open = anyStr; return this.conf;},
            openby : (anyStr)=>{this.para.open = anyStr; return this.conf;},
            min    : (strVal)=>{this.para.min  = strVal; return this.conf;},
            max    : (strVal)=>{this.para.max  = strVal; return this.conf;},
            id     : (strVal)=>{this.para.id   = strVal; return this.conf;},
            cl     : (strVal)=>{this.para.cl   = strVal; return this.conf;},
            pos    : (strVal)=>{this.para.pos  = strVal; return this.conf;},
            title  : (strVal)=>{this.para.tit  = strVal; return this.conf;},
            border : (strVal)=>{this.para.bord = strVal; return this.conf;},
            bg     : (strVal)=>{this.para.bg   = strVal; return this.conf;},
            opc    : (val)=>{   this.para.opc  = val;    return this.conf;},
            level  : (val)=>{   this.para.level = val;   return this.conf;},
            time   : (val)=>{   this.para.time  = val;   return this.conf;},
            fsize  : (val)=>{   this.para.fsize = val;   return this.conf;},
            //upid   : ()=>{let p = this.para;p.id = p.id == '' ? `${p.pfix}-${p.name}` : `${p.id}`;},
            //upcl   : ()=>{let p = this.para;p.cl = p.cl == '' ? `${p.pfix}-${p.name}` : `${p.cl}`;},
            done   : ()=>{return this.done();},
            ds     : ()=>{return this;},
        }
        into    = (anyStr)=>{
            return this.conf.into(anyStr);
        }
        done    = ()=>{
            //$lg(`1879::ui.slider.done() start::bgg`);
            return new Promise((res)=>{
                let id = this.para.id;
                /*self.readyStateChangeList.push(()=>{
                    if(document.readyState !== 'complete')return;
                    $lg(`1883::document.readyState == completeid,id::bgg`,id);
                    if(document.querySelector(`#${id}`)){
                        $lg(`1885::#${id} exists::bgg`,Log.now());
                        res();
                    }
                });*/
                let p = this.para;
                this.html(p.into);
                this.css.all();
                this.event.setup(p.open);
                res();
            });
        }
        html    = ()=>{
            let p  = this.para;
            let id = `${p.id}`;
            let cl = `${p.cl}`;
            let h  = new Html();
            //h.demo('test-ui-slider')
            h.dom(p.into)
                .div(cl,id).top()
                    .div(`.${cl}-caption`).as(1)
                        .div(`.${cl}-title`,`!${p.tit}`,1)
                        .div(`.${cl}-close`,`!\u22A0`,1)
                    .div(`#${id}-content`,`.${cl}-content`)
             .ok();
            return this;
        }
        css     = {
            slider  : ()=>{
          
                let p  = this.para;
                let id = `${p.id}`;
                let cl = `${p.cl}`;
                let cs = new Css();
                let bg  = cs.rgba.get(`${p.bg}`,`${p.level}`,`${p.opc}`);
                let bor = cs.rgba.get(`${p.bg}`,0,1);
                let ppt = this.fn.tsiPPT(p.pos);
                cs.style(['cssAjs','cssUi','cssSlider'])
                  .style('cssSlider_').slt(`#${id}`)
                    .f.fix().ds()
                    .flex.col.p(8)
                    .a.wh('0','100%')
                      .bg(bg)
                      .mar('6px')
                      .bor(`${p.bord} solid ${bor}`)
                      .tsi(`${ppt} ${p.time}s ease`)
                      .fnt.size(`${p.fsize}vmin`);
                if('L' == p.pos.toUpperCase()) cs.a.tl('0',  '0');
                if('R' == p.pos.toUpperCase()) cs.a.tr('0',  '0');
                cs.ok();
            },
            caption : ()=>{
                let p  = this.para;
                let id = `${p.id}`;
                let cl = `${p.cl}`;
                let cs = new Css();
                cs.dom(`#cssSlider`)
                  .style('cssCaption').slt(`.${cl}-caption`)
                    //.f.rel().ds()
                    //.flex.row.p(46)
                    .a.wh('100%','auto')
                      .pad('6px')
                      .dsp.no()
                      .pos.sti()
                    .ds()
                    .ok();
            },
            title   : ()=>{
                let p  = this.para;
                let id = `${p.id}`;
                let cl = `${p.cl}`;
                let cs = new Css();
                cs.dom(`#cssSlider`)
                  .style('css_Title').slt(`.${cl}-title`)
                    .f.rel().tac().ds()
                    //.flex.row.p(5)
                    .a.wh('100%','auto').top('20px').rig('20px')
                      .pad('3px')
                      
                    .ds()
                    .ok();
            },
            close   : ()=>{
                let p  = this.para;
                let id = `${p.id}`;
                let cl = `${p.cl}`;
                let cs = new Css();
                let bg  = cs.rgba.get(`${p.bg}`,`${p.level}`,`${p.opc}`);
                cs.dom('#cssSlider')
                  .style('css_Close').slt(`.${cl}-close`)
                      .f.abs().ds()
                      .flex.col.p(5)
                      .a.wh('70px','70px').top('20px').rig('20px')
                        .mar('20px')
                        .pad('2px')
                        .bor('3px solid white')
                        .bg( bg )
                        .clr('black')
                        .fnt.size('10vmin')
                        .ds()
                  .ok();
            },
            content : ()=>{
                let p  = this.para;
                let id = `${p.id}`;
                let cl = `${p.cl}`;
                let cs = new Css();
                cs.dom(`#cssSlider`)
                  .style('cssContent').slt(`.${cl}-content`)
                    .f.rel().ds()
                    .flex.col.p(8)
                    .a.wh('100%','auto')
                    .vis.no()
                    .ds()
                    .ok();
            },
            all     : ()=>{
                let fs = Reflect.ownKeys(this.css);
                //
                for(let f of fs){
                    if(f == 'all')continue;
                    Reflect.get(this.css,f)();
                }
                //this.app.css.body().box();
                return this;
            },
        }
        event   = {
            open  : (e)=>{
                return new Promise((res)=>{
                    let p = this.para;
                    let id = `${p.id}`;
                    let cl = `${p.cl}`;
                    let sld = Doc.api.query(`#${id}`);
                        this.fn.setVal(sld.style,p.max);
                    //h.docu.query(`#${p.id} .${p.cl}-close`).style.visibility = 'visible';
                      
                    let tit = Doc.api.query(`#${id} .${cl}-caption`);
                        tit.style.display = 'block';
                        
                    let cont = Doc.api.query(`#${id} .${cl}-content`);
                        cont.style.visibility = 'visible';
                        
                    res();
                })
            },
            close : (e)=>{
                return new Promise((res)=>{
                    let p = this.para;
                    let id = `${p.id}`;
                    let cl = `${p.cl}`;
                    let sld = Doc.api.query(`#${id}`);
                    this.fn.setVal(sld.style,p.min);
                    
                    let tit = Doc.api.query(`#${id} .${cl}-caption`);
                        tit.style.display = 'none';
                    
                    let cont = Doc.api.query(`#${id} .${cl}-content`);
                        cont.style.visibility = 'hidden';
                        
                    res();
                })
            },
            setup : ()=>{
                //$lg('1918::event.setup::bgg');
                let p = this.para;
                let id = `${p.id}`;
                let cl = `${p.cl}`;
                let h = new Html()
                let sld = h.docu.query(`#${id}`);
                //$lg('1924::sld::bgo',sld);
                this.fn.setVal(sld,p.min);
                //$lg('1926::after::setVal');
                let open = document.querySelector(p.open);
                    //$lg('1927::p.open,open',p.open,open);
                    open.onclick = this.event.open;
                    
                let close = document.querySelector(`#${id} .${cl}-close`);
                    close.addEventListener('click',this.event.close);

                return this;
            },
        }
        fn      = {
            tsiPPT : (pos)=>{
                let d = {
                   L : 'width',
                   R : 'width',
                   M : 'height'
                }
                return Reflect.get(d,pos.toUpperCase());
            },
            
            setVal : (obj,val,ppt=null)=>{
                    let p = this.para;
                    if(!ppt)ppt = this.fn.tsiPPT(p.pos);
                    //$lg('2026::ppt',ppt);
                    Reflect.set(obj,ppt,val);
            },
        }
    }
    
    fileEx       = class{
        constructor(){
            if(self.readyStateChangeList == undefined){
                self.readyStateChangeList = [];
                document.onreadystatechange = ()=>{
                    //if(document.readyState == 'complete'){
                        for(let fn of self.readyStateChangeList){
                            if(fn)fn();
                        }
                    //}
                }
            }else{
                //self.AjsStateChangeList
                
            }
            this.pars = {
                into    : 'body',
                openBy  : null,
                dsp     : 'no',
                id      : 'ajs-fileEx',
                pfix    : 'ajs-fileEx',
                closeBy : '.ajs-fileEx-close',
                addr    : '',
            };
            this.pidx = -1;
            //this.pdat = [];
        }
        conf   = {
            id      : (str/*querySelector no#*/)=>{
                this.pars.id = str;
                return this.conf;
            },
            pfix    : (str/*querySelector no#*/)=>{
                this.pars.id = str;
                return this.conf;
            },
            into    : (anyStr/*querySelector*/)=>{
                this.pars.into = anyStr;
                return this.conf;
            },
            dsp     : (anyStr/*yes|no*/)=>{
                this.pars.dsp = anyStr;
                return this.conf;
            },
            openBy  : (anyStr/*querySelector*/)=>{
                this.pars.openBy = anyStr;
                return this.conf;
            },
            closeBy : (anyStr/*querySelector*/)=>{
                this.pars.closeBy = anyStr;
                return this.conf;
            },
            addr    : (str/*handler.php*/)=>{
                this.pars.addr = str;
                return this.conf;
            },
            done    : (...args)=>{
                return this.done(...args);
            },
        }
        into   = (anyStr)=>{
            return this.conf.into(anyStr);
        }
        done   = (...args)=>{
            //$lg('2088::ui::fileEx::done:start',Log.now());
            let str = `#${this.pars.id}`;
            //$lg(' 2090::ui::fileEx::id',str,Log.now());
          
            return new Promise((res)=>{
                //$lg('2093::ui::fileEx::Promise::bgy','before::onreadystatechange','document.readyState:',document.readyState);
                  
                self.readyStateChangeList.push(()=>{
                    if(document.readyState !== 'complete')return;
                    $lg('2109::fileEx::done::bgy',document.readyState,str,Log.now());
                    if(document.querySelector(str)){
                        $lg('2111::fileEx::done::resolve::bgg',str+' exists',Log.now());
                        res();
                    }else{
                        $lg('2114::fileEx::done::not resolve::bgo',str+' not exists',Log.now());
                    }
                })
                /*
                document.onreadystatechange = ()=>{
                    if(document.readyState == 'complete'){
                        $lg('2097::fileEx::done::bgy',document.readyState,str,Log.now());
                        if(document.querySelector(str)){
                            $lg('2099::fileEx::done::resolve::bgg',str+' exists',Log.now());
                            res();
                        }else{
                            $lg('2083::fileEx::done::not resolve::bgo',str+' not exists',Log.now());
                        }
                    }
                }*/
                this.css.all();
                this.htm.frame();
                this.event.all();
                this.page.start.init();
                //$lg('2108::ui::fileEx::Promise end::bgy');
               
            })
        }
        htm    = {
            frame : (res)=>{
                $lg('2096::frame() start::bgb',Log.now());
                let p = this.pars;
                let h = new Html();
                    h.dom('body')
                        .div(`#${p.id}`).top()
                            .div('.menu rel row-46').as(1)
                                .div('.m1 row-5',1).as(11)
                                    .span('.folder icon',`!\u2630`,11)
                                .div('.lbox',1)
                                .div('.m3 col-5',1).as(13)
                                    .span('.close icon','!\u2612',13)
                            .div('.path rel row-46').as(2)
                                .div('.pbox row-4',2)
                                .div('.btn row-5',`!\u25bc`,2)
                            .div('.list rel col-7040').as(3)
                            .div('.tool rel col-7040').as(4)
                                .div('.tline-1 row-46',4).as(14)
                                    .div('.tbox row-4050',14).as(24)
                                        .span('.icon',24).copy(7)
                                    .span('.btn row-46',`!\u25b2`,14)
                                .div('.tline-2 tbox row-4050',4).as(34)
                                    .span('.icon',34).copy(7)
                        .ok();      
                        $lg('2096::frame() finish::bgb',Log.now());
                return this;
            },
            addListItem : ()=>{
              
            },
        }
        css    = {
            frame   : ()=>{
              try{
                //$lg('2149::css::frame()::bgg');
                let cs = new Css();
                cs.style(['cssAjs','cssUi','cssFileEx'])
                  .slt('#fileEx')
                      .f.abs().blk().ds()
                      .flex.col.p(8)
                      .a.wh('98%','99%')
                        .tl('0','0')
                        .bg('white')
                        .bor('6px solid white')
                        .tsi('width height 0.5s ease');
                      if(this.pars.dsp == 'yes')cs.a.vis.yes();
                      if(this.pars.dsp == 'no' )cs.a.vis.no();
                cs.ok();
                return this.css;
              }catch(e){
                //$lg('2164::err::bgo',e.message);
              }
                
            },
            menu    : ()=>{
                //$lg('2164::css::menu()::bgg');
              try{
                let cs = new Css();
                cs.dom('#cssFileEx')
                  .style(['cssMenu','css_menu'])
                      .slt('.menu')
                          .a.wh('99%','100px')
                            .bor('6px solid red').ds()
                      .slt('.m1')
                          .a.wh('7.5%','99%').ds()
                      .slt('.lbox')
                          .a.wh('85%','99%')
                            .mar('6px').pad('6px')
                            .ovfl.x.scl()
                            .ds()
                      .slt('.m3')
                          .a.wh('7.5%','99%').ds()
                      .slt('.label')
                          .a.wh('auto','99%')
                            .mar('6px').pad('6px')
                            .bord.rad('10px').aa()
                            .fnt.size('4vmin').ds()
                      .slt('.fnew')
                          .a.marg.rig('20px').ds()
                      .ok();
                return this.css;
              }catch(e){
                  $lg('2270::err',e.message);
              }
            },
            path    : ()=>{
              try{
                let cs = new Css();
                cs.dom('#cssFileEx')
                    .style('cssPath')
                        .slt('.path')
                            .a.wh('99%','100px')
                              .bor('6px solid yellow').ds()
                        .slt('.pbox')
                            .a.wh('90%','70px')
                              .ovfl.x.scl()
                              .flx.wrap.yes().aa()
                              .bor('3px solid red').ds()
                        .slt('.pathCell')
                            .a.mar('6px').pad('6px')
                              .bor('1px solid black')
                              .fnt.size('4vmin').aa()
                              .bord.rad('6px').ds()
                        .slt('.spcode')
                              .a.fnt.size('4vmin').aa()
                              .ds()
                            .ok();
                return this.css;
              }catch(e){
                $lg('2282::bgo',e.message);
              }
            },
            list    : ()=>{
                let cs = new Css();
                cs.dom('#cssFileEx')
                    .style('cssList')
                        .slt('.list')
                            .a.wh('99%','76%')
                              .bor('6px solid blue')
                              .ovf.scl()
                              .ds()
                            .ok();
                return this.css;
            },
            tool    : ()=>{
                let cs = new Css();
                cs.dom('#cssFileEx')
                  .style(['cssTool','css_tool'])
                      .slt('.tool')
                          .a.wh('99%','100px')
                            .bor('6px solid green').ds()
                  .style('css_line')
                      .slt('.tline-1')
                      .slt('.tline-2')
                          .a.vis.no().ds()
                      .slt('.tbox')
                          .a.wh('90%','70px')
                            .ovfl.x.scl()
                            .flx.wrap.yes().aa()
                            .bor('3px solid red').ds()
                      .ok();
                return this.css;
            },
            flex    : ()=>{
                let cs = new Css();
                cs.dom('#cssFileEx')
                  .style('cssFlex')
                  .slt('.col-4')
                      .flex.col.p(4).ds()
                  .slt('.col-5')
                      .flex.col.p(5).ds()
                  .slt('.row-4')
                      .flex.row.p(4).ds()
                  .slt('.row-5')
                      .flex.row.p(5).ds()
                  .slt('.row-46')
                      .flex.row.p(46).ds()
                  .slt('.row-4050')
                      .flex.row.p(4050).ds()
                  .slt('.row-7080')
                      .flex.row.p(7080).ds()
                  .slt('.col-7040')
                      .flex.row.p(7040).ds()
                  .ok();
                return this.css;
            },
            page    : ()=>{
               //$lg('2246::css::other()::bgg');
                let p = this.pars;
                let cs = new Css();
                cs.dom('#cssFileEx')
                  .style('cssPage')
                    .slt('.page')
                        .a.wh('98%','98%')
                          .mar('10px')
                          .pad('10px')
                          .bord.rad('20px').aa()
                          .bor('6px solid red')
                          .ovf.scl()
                          .ds()
                    .slt('.hidden')
                        .a.dsp.no().ds()
                    .slt('.folder,.file')
                        .a.fnt.size('4vmin').aa()
                          .mar('6px')
                          .bg('yellow')
                          .clr('black')
                          .ds()
                    .slt('.file')
                        .a.bg('lightblue').ds() 
                    .slt('.pitem')
                        .a.wh('99%','100px')
                          .mar('3px').pad('3px')
                          .bor('6px solid black').ds()
                    .slt('.iname')
                        .f.tal().ds()
                        .a.fnt.size('4vmin').aa()
                          .wh('99%','99%')
                          .ds()
                    .slt('.btn-root')
                        .f.tac().ds()
                        .a.wh('40%','150px')
                          .mar('20px')
                          .bor('1px solid black')
                          .bord.rad('20px').aa()
                          .bg('white')
                          .fnt.size('8vmin')
                          .ds()
                    .ok();
                return this.css;
            },
            other   : ()=>{
               $lg('2246::css::other()::bgg');
              try{
                let p = this.pars;
                let cs = new Css();
                cs.dom('#cssFileEx')
                  .style('cssOther')
                    .slt('.icon')
                        .f.tac().ds()
                        .a.wh('80px','80px')
                          .fnt.size('6vmin').ds()
                    .slt(`#${p.id} .menu .m3 .close`)
                        .a.fnt.size('7vmin').aa()
                          .padd.bot('16px').ds()
                          //.bor('3px solid red').ds()
                    .slt('.btn')
                        .a.wh('70px','70px')
                          .padd.bot('10px').aa()
                          .fnt.size('6vmin').aa()
                          //.tsf(cs.fn.rotz('270deg'))
                          .bor('3px solid green').ds()
                    .slt('.rel')
                        .f.rel().ds()
                    .ok();
                    $lg('2588::css::other()::finish::bgg');
                return this.css;
              }catch(e){
                $lg('2591::err',e.message);
                  //throw new Error("break",{cause: e});
              }
            },
            all     : ()=>{
                //$lg('2262::css::all::bgg');
                Ajs.runAll(this.css,['all']);
                return this;
            },
        }
        event  = {
            init  : ()=>{
                //$lg('2355::event.init');
                this.fn.hide();
                return this;
            },
            open  : ()=>{
                //$lg('2360::event.open');
                
                let p  = this.pars;
                if(p.openBy == null || p.openBy == '')return;
                let obj = document.querySelector(`#${p.openBy}`);
                    obj.addEventListener('click',(e)=>{
                        this.fn.open();
                    })
            },
            close : ()=>{
                //$lg('2370::event.close');
                let p  = this.pars;
                let obj = document.querySelector(`#${p.id} .m3 .close`);
                    obj.addEventListener('click',(e)=>{
                        //$lg('2366::addEventListener');
                        this.fn.hide();
                    })
            },
            all   : ()=>{
                //$lg('2371::event.all');
                Ajs.runAll(this.event,['all']);
                return this;
            },
            
        }
        fn     = {
            getIdx : ()=>{
              
            },
            show   : ()=>{
                let p  = this.pars;
                let fe = document.querySelector(`#${p.id}`);
                    //fe.style.display = 'flex';
                    fe.style.backgroundColor = 'white';
                    fe.style.visibility = 'visible';
                    fe.style.width = '99%';
                    fe.style.height = '99%';
                return this;
            },
            hide   : ()=>{
                //$lg('2387::fn.hide');
                let p  = this.pars;
                let fe = document.querySelector(`#${p.id}`);
                    //fe.style.display = 'none';
                    fe.style.backgroundColor = 'transparent';
                    fe.style.visibility = 'hidden';
                    fe.style.width = '0%';
                    fe.style.height = '0%';
                return this;
            },
            listFolder : (path)=>{
                //$lg('85::listFolder,path',path);
                let p = this.pars;
                let addr = p.addr;
                let data = {path : path};
                let xhr = new Xhr(addr);
                    xhr.ask('folder__list',data)
                       .rsp((data)=>{
                          $lg('86::dat::bgg',data);
                          let obj = JSON.parse(data);
                          let rst = obj.da.rst;
                          let dat = obj.da.dat;
                          let path  = dat.path;
                          let items = dat.items;
                          //$lg(`2464::path:${path}::bgb`);
                          //this.path.add(path);
                          this.page.add(path,items);
                          /*
                          for(let item of items){
                              let type = item.type;
                              $lg(`${item.name}${(type == 2 ? '::bgy' : '')}`);
                          }*/
                       },(err)=>{
                          $lg('88::err::bgo',err);
                       })
                
                return this.fn;
            },
            
            
        }
        page   = {
            
            start  : {
                init : ()=>{
                    this.page.start.htm();
                    /*this.page.start.event.inside_click('/storage/emulated/0/')
                                         .sdcard_click('/storage/A8FA-F85F/');
                                         */
                    return this;
                },
                htm  : ()=>{
                    let p = this.pars;
                    let id = p.id;
                    let h = new Html();
                    h.dom(`#${id} .list`)
                      .div(`.page rel row-7080`).top()
                        .button('#rInside','.btn-root rel','!内部存储')
                            .on.click(this.page.start.event.inside_click)
                        .button('#rSdcard', '.btn-root rel','!sd卡')
                            .on.click(this.page.start.event.sdcard_click)
                        .ok();
                },
                event : {
                    inside_click : ()=>{
                        //this.path.add(spath);
                        let path = "\/storage\/emulated\/0";
                        this.fn.listFolder(path);
                    },
                    sdcard_click : ()=>{
                        let path = "\/storage\/A8FA-F85F";
                        //this.path.add(path);
                        this.fn.listFolder(path);
                    },
                }
            },
            
            add : (path,arrs)=>{
                let p = this.pars;
                let id = p.id;
                let h = new Html();
                this.pidx++;
                h.dom(`#${id} .list`)
                  .div(`.page rel col-7040`).top()
                      .data('ajs-pidx',this.pidx);
                for(let arr of arrs){
                  
                    if(arr[0] == 0)continue;
                    let type = arr[0];
                    let name = arr[1];
                    
                    let f1 = type == 2 ? 'folder' : `file`;
                    
                    h.div(`.pitem row-4`).as(1)
                        .span(`.${f1}`,`!${f1}`,1)
                        .span(`.iname`,`!${name}`,1)
                            .data('type',type)
                            .on.click(this.page.item_click);
                  
                }
                this.page.hideAll();
                h.ok();
                this.label.add(this.pidx,path);
                this.path.add(path);
            },
            
            item_click : (e)=>{
                $lg('2580::item_click');
                let p = this.pars;
                let pbox = document.querySelector(`#${p.id} .pbox`);
                let path = pbox.getAttribute('data-ajs-path');
                let tar  = e.target;
                let text = tar.innerText;
                let type = tar.getAttribute('data-ajs-type');
                $lg('2587::type',type);
                if(type == '2' && text.length > 0){
                    $lg('2590::path',path);
                    this.fn.listFolder(path+'/'+text);
                }
                return this;
            },
            
            hideAll : ()=>{
                let pgs = document.querySelectorAll('.page');
                for(let p of pgs){
                    p.classList.add('hidden');
                }
                return this;
            },
            
        }
        path   = {
          
            add : (pathStr)=>{
                //$lg('2513::pathStr',pathStr);
                let arr = pathStr.toString().split('/');
                //$lg('2514::arr',arr);
                let p   = this.pars;
                let docPath = document.querySelector(`#${p.id} .pbox`);
                    docPath.innerHTML = '';
                let h = new Html();
                    h.dom(`#${p.id} .pbox`)
                          .data('path',pathStr);
                let [i,j] = [-1,0];
                //let slaCode = '/'.toString().charCodeAt(0);
                let spc = String.fromCharCode(0x2023);//0x2023//27a1,203a
                let uri = '';
                for(let s of arr){
                    //let scode = s.toString().charCodeAt(0);
                    //$lg(`2529::code:'${scode},${slaCode}'::bgo`);
                    //if(scode === slaCode) s = String.fromCharCode(0xbb);//0x2023
                    i++;
                    uri += '/'.repeat(j) + s;
                    j=1;
                    h.span(`#pathCell${i}`,`.pathCell`,`!${s}`)
                          .data('uri',uri).on.click(this.path.cell_click)
                      .span('.spcode',`!${spc}`);
                }
                h.ok();
            },
            
            cell_click : (e)=>{
                let tar = e.target;
                let uri = tar.getAttribute('data-ajs-uri');
                this.fn.listFolder(uri);
            },
            
        }
        label  = {
            add  : (pidx,path)=>{
              
            },
            click : ()=>{
              
            },
        }
    }
    
    grid         = class{
    
      para  =   {
          into  : '#box',
          size  : '20px',
          color : new Css().rgba.yellow(1,0.6),
      }
      conf  =   {
          into  :   (anyStr)=> {
              this.para.into = anyStr;
              return this.conf;
          },
          size  :   (str)=>{
              this.para.size = str;
              return this.conf;
          },
          color :   (str)=>{
              this.para.color = str;
              return this.conf;
          },
          ds    :   ()=>{
              return this;
          },
      }
      html  =   ()=>{
          let p = this.para;
          let h = new Html();
          h.dom(this.para.into).step(1)
                .div('gridBox','grid-box')
                    .div('gridLayerX','grid-layer grid-layer-x').top().step(0)
                        .div('','grid-line-x').copy(58).top('#gridBox')
                    .div('gridLayerY','grid-layer grid-layer-y').top()
                        .div('','grid-line-y').copy(36)
            .ok();
            return this;
      }
      css   =   {
          box     :   ()=>{
              let p = this.para;
              let cs = new Css()
              cs.style(['cssGrid','cssGrid_Box'])
                .slt('.grid-box')
                .f.rel().ds()
                .a.tl(0,0)
                  .wh('100%','100%')
                  .bgd.tsp()
                  .bor('6px solid '+p.color)
                  .ds()
                .ok();
              return this.css;
          },
          layer   :   ()=>{
              let cs = new Css()
              cs.style(['cssGrid','cssGrid_Layer'])
                .slt('.grid-layer')
                    .f.rel().ds()
                    .a.tl(0,0)
                      .wh('100%','100%')
                      .bgd.tsp()
                    .ds()
                .slt('.grid-layer-x')
                    .flex.col.p(8)
                    //.a.bor('6px solid yellowgreen')
                    .a.flx.wrap.yes().ds()
                .slt('.grid-layer-y')
                    .f.abs().ds()
                    .flex.row.p(4)
                    //.a.bor('6px solid fuchsia')
                    .a.flx.wrap.yes().ds()
                .ok();
              return this.css;
          },
          lineX   :   ()=>{
              let p = this.para;
              
              let cs = new Css()
              let up = cs.docu.gbid('gridLayerX')
              let upch = parseInt(up.clientHeight);
              //alert('178::upch::'+upch);
              cs.style(['cssGrid','cssGrid_LineX'])
                .slt('.grid-line-x')
                    .f.rel().ds()
                    .a.bord.bot.val('1px solid '+p.color).aa()
                      .bgd.tsp()
                      .wh('100%',p.size)
                      .tl(0,0)
                      .ds()
                .ok();
              return this.css;
          },
          lineY   :   ()=>{
              let p = this.para;
              let color = p.color;
              let cs = new Css()
              let up = cs.docu.gbid('gridLayerX')
              let upcw = parseInt(up.clientWidth);
              //alert('195::upcw::'+upcw);
             
              cs.style(['cssGrid','cssGrid_LineY'])
                .slt('.grid-line-y')
                    .f.rel().ds()
                    .a.bord.rig.val('1px solid '+p.color).aa()
                      .bgd.tsp()
                      .wh(p.size,'100%')
                      .ds()
                .ok();
              return this.css;
          },
          all     :   ()=>{
            //(new Css).runAll(this.css,['all']);
            this.css.box()
                    .layer()
                    .lineX()
                    .lineY();
                    
            return this;
          },
      }
      add   =   ()=>{
          //super.runAll(this,['para','conf','add']);
          this.html().css.all();
          return this;
      }
      ds    =   ()=>{
          return this;
      }
      
    }
    
    panel        = class{
    
      para  =   {
          into   : 'body',
          width  : '80%',
          height : '80%',
          color  : 'black',
          rad    : '20px',
          bg     : 'white',
          pfix   : 'ajs',
      }
      conf  =   {
          into  :   (anyStr)=> {
              this.para.into = anyStr;
              return this.conf;
          },
          size  :   (str)=>{
              this.para.size = str;
              return this.conf;
          },
          color :   (str)=>{
              this.para.color = str;
              return this.conf;
          },
          ds    :   ()=>{
              return this;
          },
      }
      html  =   ()=>{
          let p  = this.para;
          let id = p.pfix+'Panel';
          let cl = p.pfix+'-panel';
          let h  = new Html();
          h.dom(this.para.into)
                .div(id+'Box',cl+'frame').top()
                    .div(id,cl)
            .ok();
            return this;
      }
      css   =   {
          box     :   ()=>{
              let p = this.para;
              let cs = new Css()
              cs.style(['cssGrid','cssGrid_Box'])
                .slt('.grid-box')
                .f.rel().ds()
                .a.tl(0,0)
                  .wh('100%','100%')
                  .bgd.tsp()
                  .bor('6px solid '+p.color)
                  .ds()
                .ok();
              return this.css;
          },
          layer   :   ()=>{
              let cs = new Css()
              cs.style(['cssGrid','cssGrid_Layer'])
                .slt('.grid-layer')
                    .f.rel().ds()
                    .a.tl(0,0)
                      .wh('100%','100%')
                      .bgd.tsp()
                    .ds()
                .slt('.grid-layer-x')
                    .flex.col.p(8)
                    //.a.bor('6px solid yellowgreen')
                    .a.flx.wrap.yes().ds()
                .slt('.grid-layer-y')
                    .f.abs().ds()
                    .flex.row.p(4)
                    //.a.bor('6px solid fuchsia')
                    .a.flx.wrap.yes().ds()
                .ok();
              return this.css;
          },
          lineX   :   ()=>{
              let p = this.para;
              
              let cs = new Css()
              let up = cs.docu.gbid('gridLayerX')
              let upch = parseInt(up.clientHeight);
              //alert('178::upch::'+upch);
              cs.style(['cssGrid','cssGrid_LineX'])
                .slt('.grid-line-x')
                    .f.rel().ds()
                    .a.bord.bot.val('1px solid '+p.color).aa()
                      .bgd.tsp()
                      .wh('100%',p.size)
                      .tl(0,0)
                      .ds()
                .ok();
              return this.css;
          },
          lineY   :   ()=>{
              let p = this.para;
              let color = p.color;
              let cs = new Css()
              let up = cs.docu.gbid('gridLayerX')
              let upcw = parseInt(up.clientWidth);
              //alert('195::upcw::'+upcw);
             
              cs.style(['cssGrid','cssGrid_LineY'])
                .slt('.grid-line-y')
                    .f.rel().ds()
                    .a.bord.rig.val('1px solid '+p.color).aa()
                      .bgd.tsp()
                      .wh(p.size,'100%')
                      .ds()
                .ok();
              return this.css;
          },
          all     :   ()=>{
            //Ajs.runAll(this.css,['all']);
            this.css.box()
                    .layer()
                    .lineX()
                    .lineY();
                    
            return this;
          },
      }
      add   =   ()=>{
          //super.runAll(this,['para','conf','add']);
          this.html().css.all();
          return this;
      }
      ds    =   ()=>{
          return this;
      }
      
    }
  
    pixelWall    = class{
    
      para  =   {
          into  : '#box',
          size  : '20px',
          rad   : '0px',
          color : new Css().rgba.yellow(1,0.6),
          pfix  : 'pixelWall',
      }
      conf  =   {
          into  :   (anyStr)=> {
              this.para.into = anyStr;
              return this.conf;
          },
          size  :   (str)=>{
              this.para.size = str;
              return this.conf;
          },
          color :   (str)=>{
              this.para.color = str;
              return this.conf;
          },
          ds    :   ()=>{
              return this;
          },
      }
      html  =   ()=>{
          let p = this.para;
          let h = new Htm();
          h.dom(this.para.into).step(1)
                .div('pixelWall','pixelWall')
                    .div('','pixelWall-line').top().step(0)
                        .div('','pixelWall-cell').copy(58)
                    .copy(10,'.pixelWall-line')
                        .into('#pixelWall')
                        .done()
            .ok();
            return this;
      }
      css   =   {
          box     :   ()=>{
              let p = this.para;
              let cs = new Css()
              cs.style(['cssGridBlock','cssGridBlock_Box'])
                .slt('.grid-block-box')
                .f.rel().ds()
                .a.tl(0,0)
                  .wh('100%','100%')
                  .bgd.tsp()
                  .bor('6px solid '+p.color)
                  .ds()
                .ok();
              return this.css;
          },
          layer   :   ()=>{
              let cs = new Css()
              cs.style(['cssGrid','cssGrid_Layer'])
                .slt('.grid-block-layer')
                    .f.rel().ds()
                    .a.tl(0,0)
                      .wh('100%','100%')
                      .bgd.tsp()
                    .ds()
                .slt('.grid-block-layer-x')
                    .flex.col.p(8)
                    //.a.bor('6px solid yellowgreen')
                    .a.flx.wrap.yes().ds()
                .slt('.grid-block-layer-y')
                    .f.abs().ds()
                    .flex.row.p(4)
                    //.a.bor('6px solid fuchsia')
                    .a.flx.wrap.yes().ds()
                .ok();
              return this.css;
          },
          lineX   :   ()=>{
              let p = this.para;
              
              let cs = new Css()
              let up = cs.docu.gbid('gridLayerX')
              let upch = parseInt(up.clientHeight);
              //alert('178::upch::'+upch);
              cs.style(['cssGrid','cssGrid_LineX'])
                .slt('.grid-block-line-x')
                    .f.rel().ds()
                    .a.bord.bot.val('1px solid '+p.color).aa()
                      .bgd.tsp()
                      .wh('100%',p.size)
                      .tl(0,0)
                      .ds()
                .ok();
              return this.css;
          },
          lineY   :   ()=>{
              let p = this.para;
              let color = p.color;
              let cs = new Css()
              let up = cs.docu.gbid('gridLayerX')
              let upcw = parseInt(up.clientWidth);
              //alert('195::upcw::'+upcw);
             
              cs.style(['cssGrid','cssGrid_LineY'])
                .slt('.grid-block-line-y')
                    .f.rel().ds()
                    .a.bord.rig.val('1px solid '+p.color).aa()
                      .bgd.tsp()
                      .wh(p.size,'100%')
                      .ds()
                .ok();
              return this.css;
          },
          all     :   ()=>{
            //(new Css).runAll(this.css,['all']);
            this.css.box()
                    .layer()
                    .lineX()
                    .lineY();
                    
            return this;
          },
      }
      add   =   ()=>{
          //super.runAll(this,['para','conf','add']);
          this.html().css.all();
          return this;
      }
      ds    =   ()=>{
          return this;
      }
      
    }
    
    table        = class{
        
        constructor(arr = null){
            this.data = arr;
            this.pars = {
                
            }
        }
        
        done = ()=>{
            //$lg('3229::ui.table.done');
            this.css();
            this.htm();
            return this;
        }
        
        css = ()=>{
          
            let cs = new Css();
            cs.style(['cssAjs','cssUi','cssTable','css_Table'])
              .slt('.ajs-table,.ajs-tr,.ajs-th,.ajs-td')
                .a.clr('white').ds()
                  .fontSize('3vmin')
                  .overflow('scroll')
                  .border('2px solid white')
                  .margin('6px')
                  .padding('3px')
                .ok();
            return this;
          
        }
        
        htm = ()=>{
            //$lg('3235::ui.table.htm');
            let h = new Html();
            h.dom('#box')
              .table('.ajs-table').top()
                  .tr('.ajs-tr').as(0);
            let keys = Reflect.ownKeys(this.data[0]);
            for(let key of keys){
                h.th('.ajs-th',`!${key}`,0);
            }
            for(let obj of this.data){
                h.tr('.ajs-tr').as(0);
                for(let key of keys){
                    let val = Reflect.get(obj,key);
                    //$lg('3248::k,v::bgg',`${key}:${val}`);
                    h.td('.ajs-td',`!${val}`,0);
                }
            }
            h.ok();
            
            return this;
            
        }
        
        
    }
    
    range        = class{
      
        constructor(){
          
            this.pars = {
              
                into  : 'body',
                id    : 'ajs-range',
                cl    : 'ajs-range',
                min   : 0,
                max   : 100,
                val   : 50,
                w     : '96%',
                h     : '16px',
                opc   : 0.7,
                bg    : 'gray',
            }
          
        }
        conf  = {
            into  : (anyStr = 'body')=>{ this.pars.into = anyStr; return this.conf; },
            id    : ( val = 'ajs-range')=>{ this.pars.id = val; return this.conf; },
            cl    : ( val = 'ajs-range')=>{ this.pars.cl = val; return this.conf; },
            min   : ( val = 0)=>{ this.pars.min = val; return this.conf; },
            max   : ( val = 100)=>{ this.pars.max = val; return this.conf; },
            val   : ( val = 50)=>{ this.pars.val = val; return this.conf; },
            w     : ( val = '96%')=>{ this.pars.w = val; return this.conf; },
            h     : ( val = '70px')=>{ this.pars.h = val; return this.conf; },
            bg   : ( val = 'white')=>{ this.pars.bg = val; return this.conf; },
            opc   : ( val = 0.7)=>{ this.pars.opc = val; return this.conf; },
            done  : ()=>{ return this.done();},
        }
        into  = (anyStr='body')=>{
            //$lg('3319::into',anyStr);
            this.pars.into = anyStr;
            return this.conf;
        }
        done  = ()=>{
            //$lg('3324::done');
            this.css.range();
            this.htm();
            return this;
        }
        htm   = ()=>{
            //$lg('3330::htm');
            let p = this.pars;
            let h = new Html();
            h.dom(p.into)
                .input.range(`#${p.id}`,`.${p.cl}`)
                    .at.type('range')
                       .min(p.min)
                       .max(p.max)
                       .value(p.val)
                       .ds()
            .ok();
            return this;
          
        }
        css   = {
          
            range : ()=>{
                let p = this.pars;
                let cs = new Css();
                cs.style(['cssAjs','cssUi','cssRange','css_Range'])
                    .slt(`#${p.id}`)
                        .appearance('none')
                        .width(`${p.w}`)
                        .height(`${p.h}`)
                        .outline('none')
                        .opacity(`${p.opc}`)
                        .background(`${p.bg}`)
                        .color('white')
                        .transition('opacity .2s')
                        .border_radius('10px')
                        .font_size('4vmin')
                        .margin('10px')
                    .slt(`#${p.id}::-webkit-slider-thumb`) 
                        .appearance('none')
                        .width(`60px`)
                        .height('60px')
                        .border_radius('50%')
                        .background('#4CAF50')
                        .font_size('4vmin')
                        .color('white')
                        .cursor('pointer')
                        
                  .ok();
                return this;
            },
          
        }
        event = {
            oninput : ()=>{
                let p = this.pars;
                let rge = document.getElementById(`${p.id}`);
                    rge.oninput = (e)=>{
                        //e.target.
                    }
                
            }
        }
      
    }
    
    range2       = class{
      
        constructor(){
          
            this.pars = {
              
                into  : 'body',
                id    : 'ajs-range2',
                cl    : 'ajs-range2',
                min   : 0,
                max   : 100,
                val   : 50,
                w     : '96%',
                h     : '16px',
                opc   : 0.7,
                bg    : 'gray',
                bg1   : 'orange',
                bg2   : 'yellow',
                c1   : 'white',
                c2   : 'black',
                t1   : 'A',
                t2   : 'B',
                callback  : {
                  p1 : {
                    click : null,
                    start : null,
                    move  : null,
                    end   : null,
                  },
                  p2 : {
                    click : null,
                    start : null,
                    move  : null,
                    end   : null,
                  },
                },
                single : 0,
            }
          
        }
        conf  = {
            into  : (anyStr = 'body')=>{ this.pars.into = anyStr; return this.conf; },
            id    : ( val = 'ajs-range2')=>{ this.pars.id = val; return this.conf; },
            cl    : ( val = 'ajs-range2')=>{ this.pars.cl = val; return this.conf; },
            min   : ( val = 0)=>{ this.pars.min = val; return this.conf; },
            max   : ( val = 100)=>{ this.pars.max = val; return this.conf; },
            val   : ( val = 50)=>{ this.pars.val = val; return this.conf; },
            w     : ( val = '96%')=>{ this.pars.w = val; return this.conf; },
            h     : ( val = '70px')=>{ this.pars.h = val; return this.conf; },
            opc   : ( val = 0.7)=>{ this.pars.opc = val; return this.conf; },
            bg   : ( val = 'gray')=>{ this.pars.bg = val; return this.conf; },
            bg1   : ( val = 'orange')=>{ this.pars.bg1 = val; return this.conf; },
            bg2   : ( val = 'yellow')=>{ this.pars.bg2 = val; return this.conf; },
            c1   : ( val = 'white')=>{ this.pars.c1 = val; return this.conf; },
            c2   : ( val = 'black')=>{ this.pars.c2 = val; return this.conf; },
            t1   : ( val = 'A')=>{ this.pars.t1 = val; return this.conf; },
            t2   : ( val = 'B')=>{ this.pars.t2 = val; return this.conf; },
            bgc1   : ( val = 'orange white')=>{ 
                let arr = val.split(' ');
                this.pars.bg1 = arr[0];
                this.pars.c1 = arr[1];
                return this.conf; 
            },
            bgc2   : ( val = 'yellow black')=>{ 
                let arr = val.split(' ');
                this.pars.bg2 = arr[0];
                this.pars.c2 = arr[1];
                return this.conf; 
            },
            single   : ( val = 1)=>{ this.pars.single = val; return this.conf; },
            callback : {
              p1 : (a=null,b=null,c=null)=>{
                this.pars.callback.p1.start = a;
                this.pars.callback.p1.move  = b;
                this.pars.callback.p1.end   = c;
                return this.conf;
              },
              p2 : (a=null,b=null,c=null)=>{
                this.pars.callback.p2.start = a;
                this.pars.callback.p2.move  = b;
                this.pars.callback.p2.end   = c;
                return this.conf;
              },
              p1click : (a)=>{
                this.pars.callback.p1.click = a;
                return this.conf;
              },
              p2click : (a)=>{
                this.pars.callback.p2.click = a;
                return this.conf;
              },
            },
            
            done  : ()=>{ return this.done();},
        }
        into  = (anyStr='body')=>{
            //$lg('3319::into',anyStr);
            this.pars.into = anyStr;
            return this.conf;
        }
        done  = ()=>{
            //$lg('3324::done');
            this.css.all();
            this.htm();
            this.event.setup();
            return this;
        }
        htm   = ()=>{
            //$lg('3330::htm');
            let p = this.pars;
            let h = new Html();
            h.dom(p.into)
                .div(`#${p.id}`,`.${p.cl} range2`).top()
                    .div(`.range2-bg`)
                    .div(`.range2-pbox`).as(1)
                        .div(`.range2-point point1`,`!${p.t1}`,1)
                            .data('min','0')
                            .data('max','100')
                            .data('val','25');
                  if(this.pars.single == 1){h.ok();return this;}
                  h.div(`.range2-pbox`).as(2)
                        .div(`.range2-point point2`,`!${p.t2}`,2)
                            .data('min','0')
                            .data('max','100')
                            .data('val','75');
                    
                 h.ok();
            return this;
        }
        css   = {
          
            common : ()=>{
                let p = this.pars;
                let cs = new Css();
                cs.style(['cssAjs','cssUi','cssRange2',`css_${p.cl}`])
                    .slt(`.${p.cl}`)
                        .flex.row.p(5)
                        .a.bgd.tsp()
                          .bord.rad('10px').aa()
                          .pad('10px')
                          .mar('10px')
                          .bor('1px solid white')
                          .ds()
                    .slt(`.${p.cl} .range2-bg`) 
                        .f.abs().blk().ds()
                        .a.wh('96%','20px')
                          .padd.top('10px').aa()
                          .bord.rad('10px').ds()
                    .slt(`.${p.cl} .range2-point`) 
                        .f.abs().blk().tac().ds()
                        .a.wh(`66px`,'60px')
                          .bord.rad('50%').aa()
                          .padd.top('10px').aa()
                          .fnt.size('4vmin').aa()
                          .clr('white')
                          .bor('3px solid black')
                          .ds()
                    .slt(`.${p.cl} .range2-pbox`) 
                          .f.abs().ds()
                          .flex.col.cc()
                          .a.wh('60px','98%').tl(0,0)
                            //.bg( cs.rgba.blue(6,0.6) )
                            .bgd.tsp()
                            .ovfl.x.vis()
                            .bor('0px solid green')
                            .ds()
                  .ok();
                return this;
            },
          
            inst : ()=>{
                let p = this.pars;
                let cs = new Css();
                cs.style(['cssAjs','cssUi','cssRange2',`css_${p.id}`])
                    .slt(`#${p.id}`)
                        .a.wh(`${p.w}`,`60px`)
                          .ds()
                    .slt(`#${p.id} .range2-bg`) 
                        .a.wh('96%','20px')
                          .bg(`${p.bg}`)
                          .ds()
                    .slt(`#${p.id} .range2-point`) 
                        .a.wh(`66px`,'60px')
                          .ds()
                    .slt(`#${p.id} .range2-pbox`) 
                          .a.wh('60px','98%').tl(0,0)
                            .ds()
                    .slt(`#${p.id} .point1`) 
                        .a.bg(`${p.bg1}`)
                          .clr(`${p.c1}`)
                          .l('50px')
                          .ds()
                    .slt(`#${p.id} .point2`) 
                        .a.bg(`${p.bg2}`)
                          .clr(`${p.c2}`)
                          .l('150px')
                          .ds()
                  .ok();
                return this;
            },
            /*range2 : ()=>{
                let p = this.pars;
                let cs = new Css();
                cs.style(['cssAjs','cssUi','cssRange2',`css_${p.id}`])
                    .slt(`#${p.id}`)
                        .flex.row.p(5)
                        .a.wh(`${p.w}`,`60px`)
                          .bgd.tsp()
                          .bord.rad('10px').aa()
                          .pad('10px')
                          .mar('10px')
                          .bor('1px solid white')
                          .ds()
                    .slt(`#${p.id} .range2-bg`) 
                        .f.abs().blk().ds()
                        .a.wh('96%','20px')
                          //.tl('0','0')
                          .padd.top('10px').aa()
                          .bg(`${p.bg}`)
                          .bord.rad('10px').ds()
                    .slt(`#${p.id} .range2-point`) 
                        .f.abs().blk().tac().ds()
                        .a.wh(`66px`,'60px')
                          //.tl(`16px`,`${p.val}%`)
                          .bord.rad('50%').aa()
                          .padd.top('10px').aa()
                          //.bg('#4CAF50')
                          .fnt.size('4vmin').aa()
                          .clr('white')
                          .bor('3px solid black')
                          .ds()
                    .slt(`#${p.id} .range2-pbox`) 
                          .f.abs().ds()
                          .flex.col.cc()
                          .a.wh('60px','98%').tl(0,0)
                            //.bg( cs.rgba.blue(6,0.6) )
                            .bgd.tsp()
                            .ovfl.x.vis()
                            .bor('0px solid green')
                            .ds()
                    .slt(`#${p.id} .point1`) 
                        .a.bg(`${p.bg1}`)
                          .clr(`${p.c1}`)
                          .l('50px')
                          .ds()
                    .slt(`#${p.id} .point2`) 
                        .a.bg(`${p.bg2}`)
                          .clr(`${p.c2}`)
                          .l('150px')
                          .ds()
                    .slt(`.point-sel`) 
                        .a.bor(`6px solid ${cs.rgba.white(9)}`)
                          .bg(cs.rgba.white(6))
                          .clr(cs.rgba.white(9))
                          .ds()
                  .ok();
                return this;
            },*/
            all : ()=>{
              Ajs.runAll(this.css);
              return this;
            },
        }
        event = {
          click : ()=>{
              let clk = (e)=>{
                //$lg('3509::point1 clicked');
                  e.stopPropagation();
                
                let t = e.type;
                    
                    
                //$lg('3584::e.type::bgy',e.type);
                let x = null;
                    x = e.clientX;
                //let y = e.touches[0].clientY;
    
                let ds = e.target;
                    
                let p = 'p2';
                if(ds.className.indexOf('point1')>=0) p = 'p1';
                
                let obj = Reflect.get(this.pars.callback,p);
                let callback = Reflect.get(obj,t);
                    if(callback)callback(ds,t,p,x);
              
                return this;
              }
              let p1 = Doc.api.query(`.range2 .point1`);
              let p2 = Doc.api.query(`.range2 .point2`);
                  p1.addEventListener('click',clk,false);
                  p2.addEventListener('click',clk,false);
              return this;
          },
          touch : {
            
            all : ()=>{
                let p = this.pars;
                let sme = (e)=>{
                  
                    e.stopPropagation();
                    
                    let t = e.type;
                        t = t.replace('touch','');
                        
                    //$lg('3584::e.type::bgy',e.type);
                    let x = null;
                    if(e.type == 'touchmove'){ 
                      x = e.touches[0].pageX;
                      //screenX,clientX,pageX,radiusX
                      
                      /*let ppt = Reflect.getPrototypeOf(e.touches[0]);
                      let keys = Reflect.ownKeys(ppt);
                      if(keys)$lg('3632',...keys);*/
                    }
                    //let y = e.touches[0].clientY;
                    
                    let ds = e.target;
                        ds.style.left = x+`px`;
                        //ds.style.top  = y+`px`;
                    //$lg('3525::className',ds.className);
                    
                    //$lg('3592::event type',t);
                    let p = 'p2';
                    if(ds.className.indexOf('point1')>=0) p = 'p1';
                    
                    let obj = Reflect.get(this.pars.callback,p);
                    let callback = Reflect.get(obj,t);
                        if(callback)callback(ds,t,p,x);
                  
                    return this;
                }
                let p1 = Doc.api.query(`#${p.id} .point1`);
                    p1.addEventListener('touchstart',sme,false);
                    p1.addEventListener('touchmove',sme,false);
                    p1.addEventListener('touchend',sme,false);
                if(this.pars.single == 1) return this;
                let p2 = Doc.api.query(`#${p.id} .point2`);
                    p2.addEventListener('touchstart',sme,false);
                    p2.addEventListener('touchmove',sme,false);
                    p2.addEventListener('touchend',sme,false);
                
            },
            
          },
          updatePos : (pc,num)=>{
            let p = this.pars;
            let point = Doc.api.query(`#${p.id} .point${num}`);
            //$lg('3676::point',point.className);
            let rg2 = point.parentNode.parentNode;
            //$lg('3678::rg2.classList',rg2.classList);
            let width = Doc.api.cspv(rg2,'width');
            //$lg('3680::rg2.width,pc',width,pc);
           
            let wid = parseFloat(width.replace('px',''));
            //let width = rg2.style.width;
            //let width = gp.style.clientWidth;
            point.style.left = wid * pc + 'px';
            
            //$lg('3674::point.style.left',point.style.left);
            
          },
          setup : ()=>{
              this.event.click();
              this.event.touch.all();
          },
        }
        
    }
}

/**
 * frags[...frag]
 *      dom:frag : DocumentFragment
 *          style:style
 *            slt: sltor 
 *            kf : keyframes
 *                  pc : pcent
 */ 
//@css
class Css extends Ajs{
  
  constructor(){
    super();
    //return new Promise((res)=>{
        //this.pfix = pfix;
        //new Log();
        //$lg('3295::constructor::start',Log.now());
        Css.counter.instance ++;
        if(Css.counter.instance == 1){
          this._css.autorun();
        }
        
        if(Css.cidx == undefined){
            //Html.didx = 0;
            let cidx = document.querySelectorAll[`style[data-ajs-cidx]`];
            if(cidx == undefined || cidx.length == 0) Css.cidx = 0
            else Css.cidx = cidx.length;
            
        }else{
            Css.cidx++;
        }
        
        this.lastExec = undefined;
        
        this.object    = undefined;
        this.topObject = undefined;
        this.styleObject = undefined;
        this.frags = this._css.obj.frags();
        this.dom('head');
        //$lg('3317::cs::constructor end',Log.now());
        /*res();
    })*/
    
  }
  
  static counter = {
    instance : 0,
  }
  
  //#dom(css)
  dom(...args){
    //$lg(`dom(${args[0]})`);    
    let obj = this.docu.query(args[0]);

    if(this.inValid(obj)){
        obj = this.docu.query('head');
        //$lg(`2764:${args[0]} not exists::bgo`,`change to:dom('head')`,`input:${args[0]}`);
      
    }else {
      
        /*this.frags[this.fidx] = this.ofrag(args[0],obj);
        this.topObject = this.frags[this.fidx].frag;
        this.fidx++;*/
        
        this.frags.add(this._css.obj.frag(args[0],obj));
        this.topObject = this.frags.last();
        this.fidx++;
        this.object = this.topObject.top;
    }
    this.lastExec = 'dom';
    //this.exeStack.push('dom');
    //$lg('html:246:_showFrags:');
    //this._showFrags();
    return this;
    
  }
  
  //#boss(css)
  boss(...args){
    if(args.length == 0){
        this.topObject = this.styleObject;
    }else{
        //obj_style
        //args[0] =  this.pfix + args[0];
        
        this.topObject = this.frags.last().query(args[0]);
        //$lg('css::1498::this.topObject.id',this.topObject.id);
    }
    if(this.topObject == null){
        let msg =  'Css::boss:1507:\n';
            msg += 'this.topObject == null\n';
            msg += `your input is : boss( "${args[0]}" )\n`;
            msg += `are you mean  : boss( "${args[0].replace('#','')}" ) ?\n`;
        alert(msg);
    };
    return this;
  }
  
  //#style(css)
  style(id,clazz='',append=0){
    //$lg('2803::css::style::id::bgb',id);
    let oid = id;
    if(Array.isArray(id)){
        let count = -1;
        for(let iid of id){
            count++;
            //$lg('ajs::css::style::1514::isArray',id)
            //oid = this.pfix + iid;
            oid = iid;
            let chk = this.docu.gbid(oid);
            if(chk){
                //$lg(`this.dom('#'+${iid});`);
                if(count == id.length-1) return this;
                this.dom('#'+iid);
                continue;
            }
            //dom('head')
            //style(['CssAjs','cssApp','cssBody'])
            //this.frags.last()  = frag
            //this.topObject.add = frag.add
            //#1.topObject == document.head
            //#2.topObject == DocStyle
            //#3.topObject == obj_frag
            //#4.topObject == obj_style
            //$lg('css::1524::this.topObject.type',this.topObject.type);
            if(this.topObject.type == undefined){
                //#1,#2 head,style appendChild style
                this.topObject.appendChild(this.docu.celm('style',oid,clazz));
                this.styleObject = this.topObject.querySelector('#'+oid);
                this.topObject = this.styleObject;
            }else if(this.topObject.type == 'frag'){
                //#3.topObject == obj_frag
                this.topObject.add(this._css.obj.style(oid,clazz));
                this.styleObject = this.topObject.last();
                this.topObject = this.styleObject;
            }else if(this.topObject.type == 'style'){
                //#4.topObject == obj_style
                this.topObject.add_child(this._css.obj.style(oid,clazz));
                this.styleObject = this.topObject.last_child();
                this.topObject = this.styleObject;
            }
        
        }
      
    }else if(typeof id == 'string'){
      //$lg(`css:1544:typeof id == 'string'`);
      //$lg(`css:4028:id ==`,id);
      if(Doc.has(`#${id}`))return this;
      oid =  id;
      //$lg('css:1544:this.topObject.type',this.topObject.type);
      if(this.topObject.type == undefined){
          //#1,#2 head,style appendChild style
          this.topObject.appendChild(this.docu.celm('style',oid,clazz));
          this.styleObject = this.topObject.querySelector('#'+oid);
      }else if(this.topObject.type == 'frag'){
          //#3.topObject == obj_frag
          this.topObject.add(this._css.obj.style(oid,clazz));
          this.styleObject = this.topObject.last();
      }else if(this.topObject.type == 'style'){
          //#4.topObject == obj_style
          //$lg('css::1557::this.topObject.sty.id',this.topObject.sty.id);
          this.topObject.add_child(this._css.obj.style(oid,clazz));
          this.styleObject = this.topObject.last_child();
      }
      //$lg('css:4045:this.topObject.type',this.topObject.type);
    
      //this.topObject = this._gbid(oid);
    }
    //this.object = this.docu.gbid(oid);
    //alert(typeof this.object);
    return this;
  }

  //#slt(css)
  slt(...args){
      //$lg(`2879::slt(${anyStr})`);
      let len = args.length;
      
      if(len == 0){
        
          return alert('Ajs::css::3572\n至少需要1个参数');
        
      }
      
      
      let a1 = args[0];
      let a2 = len < 2 ?   undefined : args[1];
      
      //$lg('3576::slt::len',len,typeof(a1));
      
      
      
      //slt('body')
      if( typeof(a1) === 'string' ){
          //$lg('3762::args',...args);
          this.styleObject.add_slt(this._css.obj.sltor(a1));
          this.object = this.styleObject.last_slt();
          /*
          if(len == 2){
            $lg('3582::slt::args',...args,this.object.type);
          }*/
          
      }
      
      //slt('body',{})
      if( typeof(a2) === 'object' && Array.isArray(a2) === false ){
          let obj = a2;
          Reflect.ownKeys(obj).forEach((key)=>{
              if(typeof(obj[key]) != undefined){
                  let val = obj[key];
                  this._css.val_key(val,key);
              }
          })
      }
          
      
      return this;
  }

  //#kfs(css keyframes)
  kf(name,webkit=''){
      let kf = this._css.obj.kf(name,webkit);
      //$lg('1563:this.topObject.type',this.topObject.type);
      this.styleObject.add_kf(kf);
      //this.styleObject = this.styleObject.last_kf();
      //this.object = this.topObject.last();
      this.object = undefined;
      return this;
  }
  
  //#pc(css percent %)
  pc(num){
      let pct = this._css.obj.pcent(num);
      //$lg('1574::this.topObject.type',this.topObject.type);
      //this.topObject = keyframes
      //this.styleObject.add(pct);
      this.styleObject.last_kf().add(pct);
      this.object = this.styleObject.last_kf().last();
      return this;
  }
  
  //#_ok
  ok(){
    this.frags.out();
    this._css.reset();
    return this;
  }
  
  //#abbr
  a = {
      w    : (val)=>{ this._css.val_key( val,  'width' );  return  this.a ; },
      wh   : (w,h=w)=>{ this._css.val_key( w,    'width' );  this._css.val_key( h,  'height' ); return  this.a ; },
      tl   : (t,l=t)=>{ this._css.val_key( t,    'top'   );  this._css.val_key( l,  'left'   ); return  this.a ; },
      tr   : (t,r=t)=>{ this._css.val_key( t,    'top'   );  this._css.val_key( r,  'right'  ); return  this.a ; },
      bl   : (b,l=b)=>{ this._css.val_key( b,    'bottom' ); this._css.val_key( l,  'left'   ); return  this.a ; },
      h    : (val)=>{ this._css.val_key( val,  'height');  return  this.a ; },
      t    : (val)=>{ this._css.val_key( val,  'top'   );  return  this.a ; },
      l    : (val)=>{ this._css.val_key( val,  'left'  );  return  this.a ; },
      r    : (val)=>{ this._css.val_key( val,  'right'  );  return  this.a ; },
      b    : (val)=>{ this._css.val_key( val,  'bottom'  );  return  this.a ; },
      rig  : (val)=>{ this._css.val_key( val,  'right'  ); return  this.a ; },
      top  : (val)=>{ this._css.val_key( val,  'top'  ); return  this.a ; },
      bot  : (val)=>{ this._css.val_key( val,  'bottom'  ); return  this.a ; },
      lef  : (val)=>{ this._css.val_key( val,  'left'  ); return  this.a ; },
      dsp  : {
          inl : {
              box  : ()=>{this._css.val_key(  this._css.spread( 'inl','box' ), 'display' );  return  this.a ; },
              flx  : ()=>{this._css.val_key(  this._css.spread( 'inl','flx' ), 'display' );  return  this.a ; },
              flxb : ()=>{this._css.val_key(  this._css.spread( 'inl','flxb'), 'display' );  return  this.a ; },
              blk  : ()=>{this._css.val_key(  this._css.spread( 'inl','blk' ), 'display' );  return  this.a ; },
              tbl  : ()=>{this._css.val_key(  this._css.spread( 'inl','tbl' ), 'display' );  return  this.a ; },
              aa   : ()=>{ return  this.dsp ; },
              ds   : ()=>{ return  this ; },
          },
          tbl    : {
              grp  : {
                  col  : ()=>{this._css.val_key(  this._css.spread( 'tbl','col','grp' ), 'display' );  return this.a ; },
                  foo  : ()=>{this._css.val_key(  this._css.spread( 'tbl','foo','grp' ), 'display' );  return this.a ; },
                  hea  : ()=>{this._css.val_key(  this._css.spread( 'tbl','hea','grp' ), 'display' );  return this.a ; },
                  row  : ()=>{this._css.val_key(  this._css.spread( 'tbl','row','grp' ), 'display' );  return this.a ; },
              },
              cap  : ()=>{this._css.val_key(  this._css.spread( 'tbl','cap' ), 'display' );  return this.a ; },
              row  : ()=>{this._css.val_key(  this._css.spread( 'tbl','row' ), 'display' );  return this.a ; },
              col  : ()=>{this._css.val_key(  this._css.spread( 'tbl','col' ), 'display' );  return  this ; },
              cell : ()=>{this._css.val_key(  this._css.spread( 'tbl','cell'), 'display' );  return  this ; },
          },
          flx    : ()=>{this._css.val_key(  this._css.spread( 'flx' ),    'display' );  return  this.a ; },
          box    : ()=>{this._css.val_key(  this._css.spread( 'box' ),    'display' );  return  this.a ; },
          flxb   : ()=>{this._css.val_key(  this._css.spread( 'flxb' ),   'display' );  return  this.a ; },
          rin    : ()=>{this._css.val_key(  this._css.spread( 'rin' ),    'display' );  return  this.a ; },
          inline : ()=>{this._css.val_key(  this._css.spread( 'inline' ), 'display' );  return  this.a ; },
          grid   : ()=>{this._css.val_key(  this._css.spread( 'grid' ),   'display' );  return  this.a ; },
          blk    : ()=>{this._css.val_key(  'block',   'display' );  return  this.a ; },
          no     : ()=>{this._css.val_key(  'none',    'display' );  return  this.a ; },
          ds     : ()=>{ return  this ; },
      },
      ani  : (val)=>{ this._css.val_key( val,  'animation'  );  return  this.a ; },
      anim : {
          name  : (val)=>{ this._css.val_key( val,  'animation-name'  );                return  this.a ; },
          dur   : (val)=>{ this._css.val_key( val,  'animation-duration'  );            return  this.a ; },
          tf    : (val)=>{ this._css.val_key( val,  'animation-timing-function'  );     return  this.a ; },
          dla   : (val)=>{ this._css.val_key( val,  'animation-delay'  );               return  this.a ; },
          ic    : (val)=>{ this._css.val_key( val,  'animation-iteration-count'  );     return  this.a ; },
          dir   : (val)=>{ this._css.val_key( val,  'animation-direction'  );           return  this.a ; },
          fm    : (val)=>{ this._css.val_key( val,   'animation-fill-mode' );           return  this.a ; },
          fmo   : {
              no    : (val)=>{ this._css.val_key( 'none',      'animation-fill-mode'  ); return  this.a ; },
              fw    : (val)=>{ this._css.val_key( 'forwards',  'animation-fill-mode'  ); return  this.a ; },
              bw    : (val)=>{ this._css.val_key( 'backwards', 'animation-fill-mode'  ); return  this.a ; },
              bo    : (val)=>{ this._css.val_key( 'both',      'animation-fill-mode'  ); return  this.a ; },
              ff   : ()=>{ return  this.f ; },
              ds   : ()=>{ return  this ; },
          },
          ps    : (val)=>{ this._css.val_key( val,   'animation-play-state'  );          return  this.a ; },
          pso   : {
              run   : (val)=>{ this._css.val_key( 'running',  'animation-play-state'  ); return  this.a ; },
              pau   : (val)=>{ this._css.val_key( 'paused',   'animation-play-state'  ); return  this.a ; },
              ff   : ()=>{ return  this.f ; },
              ds   : ()=>{ return  this ; },
          },
          ff   : ()=>{ return  this.f ; },
          ds   : ()=>{ return  this ; },
      },
      fnt  : {
          fml  :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','fml'  ));    return  this.a.fnt ; },
          kern :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','kern' ));    return  this.a.fnt ; },
          size :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','size' ));    return  this.a.fnt ; },
          sdj  :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','siz','adj'));return  this.a.fnt ; },  
          stc  :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','stc'  ));    return  this.a.fnt ; }, 
          sty  :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','sty'  ));    return  this.a.fnt ; },
          style :(val)=>{  return  this.a.fnt.sty(val) ; },
          var  :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','var'  ));    return  this.a.fnt ; },
          wei  :(val)=>{ this._css.val_key( val,  this._css.spread( 'fnt','wei'  ));    return  this.a.fnt ; },
          aa   : ()=>{ return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      flx  : {
          bas  :(val)=>{ this._css.val_key(  val, this._css.spread( 'flx','bas'  ) );  return  this.a.flx ; },
          dir  :{
              row   : ()=>{ this._css.val_key( this._css.spread( 'row' ), this._css.spread( 'flx','dir' ) );  return  this.a.flx ; },
              col   : ()=>{ this._css.val_key( this._css.spread( 'col' ), this._css.spread( 'flx','dir' ) );  return  this.a.flx ; },
              init  : ()=>{ this._css.val_key( this._css.spread( 'init'), this._css.spread( 'flx','dir' ) );  return  this.a.flx ; },
              inh   : ()=>{ this._css.val_key( this._css.spread( 'inh' ), this._css.spread( 'flx','dir' ) );  return  this.a.flx ; },
              rv    : ()=>{ this._css.val_key( this._css.spread( 'rrvs' ), this._css.spread( 'flx','dir' ) );  return  this.a.flx ; },
              cv    : ()=>{ this._css.val_key( this._css.spread( 'crvs' ), this._css.spread( 'flx','dir' ) );  return  this.a.flx ; },
              aa : ()=>{ return  this.a ; },
              ds : ()=>{ return  this ; },
          }, 
          shr  :(val)=>{ this._css.val_key( val, this._css.spread( 'flx','shr'  ) );  return  this.a.flx ; },
          flow :(val)=>{ this._css.val_key( val, this._css.spread( 'flx','flow' ) );  return  this.a.flx ; },
          grow :(val)=>{ this._css.val_key( val, this._css.spread( 'flx','grow' ) );  return  this.a.flx ; },
          wrap  :{
              yes    : ()=>{ this._css.val_key( this._css.spread( 'wrap' ), this._css.spread( 'flx','wrap' ) );  return  this.a.flx; },
              no     : ()=>{ this._css.val_key( this._css.spread( 'nwr'  ), this._css.spread( 'flx','wrap' ) );  return  this.a.flx; },
              inh    : ()=>{ this._css.val_key( this._css.spread( 'inh'  ), this._css.spread( 'flx','wrap' ) );  return  this.a.flx; },
              init   : ()=>{ this._css.val_key( this._css.spread( 'init' ), this._css.spread( 'flx','wrap' ) );  return  this.a.flx; },
              wrvs   : ()=>{ this._css.val_key( this._css.spread( 'wrap','rvs' ), this._css.spread( 'flx','wrap' ) );  return  this.a.flx; },
              aa     : ()=>{ return  this.a ; },
              ds     : ()=>{ return  this ; },
          },
          //wrp  : this.a.flx.wrap,
          aa  : ()=>{ return  this.a ; },
          ds  : ()=>{ return  this ; },
      },
      box  : {
          size : {
              cont  : ()=>{ this._css.val_key( 'content-box',  'box-sizing' );    return  this.a ; },
              bord  : ()=>{ this._css.val_key( 'border-box',   'box-sizing' );    return  this.a ; },
              inh   : ()=>{ this._css.val_key( 'inherit',   'box-sizing' );    return  this.a ; },
          },
          shad  : (val)=>{ this._css.val_key( val,  'box-shadow' );    return  this.a ; },
         
      },
      jc   : {
          c    :()=>{ this._css.val_key( this._css.spread( 'ctr' ),          this._css.spread( 'jc' ));  return  this.a ; },
          fs   :()=>{ this._css.val_key( this._css.spread( 'flx','start' ),  this._css.spread( 'jc' ));  return  this.a ; },
          fe   :()=>{ this._css.val_key( this._css.spread( 'flx','end' ),    this._css.spread( 'jc' ));  return  this.a ; },
          sa   :()=>{ this._css.val_key( this._css.spread( 'spa','aro' ),    this._css.spread( 'jc' ));  return  this.a ; },
          sb   :()=>{ this._css.val_key( this._css.spread( 'spa','bet' ),    this._css.spread( 'jc' ));  return  this.a ; },
          init :()=>{ this._css.val_key( this._css.spread( 'init' ),         this._css.spread( 'jc' ));  return  this.a ; },
          inh  :()=>{ this._css.val_key( this._css.spread( 'inh' ),          this._css.spread( 'jc' ));  return  this.a ; },
          ds   :()=>{ return  this ; },
      },
      ac   : {
          s    : ()=>{ this._css.val_key( this._css.spread( 'stc' ),          this._css.spread( 'ac' ));  return  this.a ; },
          c    : ()=>{ this._css.val_key( this._css.spread( 'ctr' ),          this._css.spread( 'ac' ));  return  this.a ; },
          fs   : ()=>{ this._css.val_key( this._css.spread( 'flx','start' ),  this._css.spread( 'ac' ));  return  this.a ; },
          fe   : ()=>{ this._css.val_key( this._css.spread( 'flx','end' ),    this._css.spread( 'ac' ));  return  this.a ; },
          sa   : ()=>{ this._css.val_key( this._css.spread( 'spa','aro' ),    this._css.spread( 'ac' ));  return  this.a ; },
          sb   : ()=>{ this._css.val_key( this._css.spread( 'spa','bet' ),    this._css.spread( 'ac' ));  return  this.a ; },
          init : ()=>{ this._css.val_key( this._css.spread( 'init' ),         this._css.spread( 'ac' ));  return  this.a ; },
          inh  : ()=>{ this._css.val_key( this._css.spread( 'inh' ),          this._css.spread( 'ac' ));  return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      ai   : {
          s    : ()=>{ this._css.val_key( this._css.spread( 'stc' ),          this._css.spread( 'ai' ));  return  this.a ; },
          c    : ()=>{ this._css.val_key( this._css.spread( 'ctr' ),          this._css.spread( 'ai' ));  return  this.a ; },
          fs   : ()=>{ this._css.val_key( this._css.spread( 'flx','start' ),  this._css.spread( 'ai' ));  return  this.a ; },
          fe   : ()=>{ this._css.val_key( this._css.spread( 'flx','end' ),    this._css.spread( 'ai' ));  return  this.a ; },
          sa   : ()=>{ this._css.val_key( this._css.spread( 'spa','aro' ),    this._css.spread( 'ai' ));  return  this.a ; },
          sb   : ()=>{ this._css.val_key( this._css.spread( 'spa','bet' ),    this._css.spread( 'ai' ));  return  this.a ; },
          init : ()=>{ this._css.val_key( this._css.spread( 'init' ),         this._css.spread( 'ai' ));  return  this.a ; },
          inh  : ()=>{ this._css.val_key( this._css.spread( 'inh' ),          this._css.spread( 'ai' ));  return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      as   : {
          auto : ()=>{ this._css.val_key( this._css.spread( 'aut' ),          this._css.spread( 'as' ));  return  this.a ; },
          s    : ()=>{ this._css.val_key( this._css.spread( 'stc' ),          this._css.spread( 'as' ));  return  this.a ; },
          c    : ()=>{ this._css.val_key( this._css.spread( 'ctr' ),          this._css.spread( 'as' ));  return  this.a ; },
          fs   : ()=>{ this._css.val_key( this._css.spread( 'flx','start' ),  this._css.spread( 'as' ));  return  this.a ; },
          fe   : ()=>{ this._css.val_key( this._css.spread( 'flx','end' ),    this._css.spread( 'as' ));  return  this.a ; },
          bl   : ()=>{ this._css.val_key( this._css.spread( 'bl' ),           this._css.spread( 'as' ));  return  this.a ; },
          init : ()=>{ this._css.val_key( this._css.spread( 'init' ),         this._css.spread( 'as' ));  return  this.a ; },
          inh  : ()=>{ this._css.val_key( this._css.spread( 'inh' ),          this._css.spread( 'as' ));  return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      
      line  : {
          hei  : (val)=>{    this._css.val_key(  val, 'line-height' );  return  this.a.line ; },
      
          aa   : ()=>{ return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      col  : {
          cnt   : {
              auto  :()=>{    this._css.val_key(  this._css.spread( 'auto' ), this._css.spread( 'col','cnt' ) );  return  this.a.col ; },
              init  :()=>{    this._css.val_key(  this._css.spread( 'init' ), this._css.spread( 'col','cnt' ) );  return  this.a.col ; },
              inh   :()=>{    this._css.val_key(  this._css.spread( 'inh' ),    this._css.spread( 'col','cnt' ) );  return  this.a.col ; },
              val   : ()=>{ this._css.val_key(  val, this._css.spread( 'col','cnt' ) );  return  this.a ; },
          },
          fill  : {
              bal  :()=>{    this._css.val_key(  this._css.spread( 'bal' ), this._css.spread( 'col','fill' ) );  return  this.a ; },
              init  :()=>{    this._css.val_key(  this._css.spread( 'init' ), this._css.spread( 'col' ) );  return  this.a ; },
              inh   :()=>{    this._css.val_key(  this._css.spread( 'inh' ),    this._css.spread( 'col' ) );  return  this.a ; },
              val   :(val)=>{ this._css.val_key(  val, this._css.spread( 'col' ) );  return  this.a ; },
              
          },
          aa   : ()=>{ return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      
      grid : {
          auto : {
              auto  : ()=>{ this._css.val_key( this._css.spread( 'auto' ),       this._css.spread( 'grid','auto' ) );  return  this.a.grid ; },
              max   : ()=>{ this._css.val_key( this._css.spread( 'max','cont' ), this._css.spread( 'grid','auto' ) );  return  this.a.grid ; },
              min   : ()=>{ this._css.val_key( this._css.spread( 'min','cont' ), this._css.spread( 'grid','auto' ) );  return  this.a.grid ; },
              mm    : ()=>{ this._css.val_key( this._css.spread( 'minmax' ),     this._css.spread( 'grid','auto' ) );  return  this.a.grid ; },
              fix   : ()=>{ this._css.val_key( this._css.spread( 'fix','cont' ), this._css.spread( 'grid','auto' ) );  return  this.a.grid ; },
              val   : (val)=>{ this._css.val_key( val,                         this._css.spread( 'grid','auto' ) );  return  this.a.grid ; },
          },
          col  : {
              start : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','col','start' ) );  return  this.a.grid ; },
              end   : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','col','end' ) );    return  this.a.grid ; },
              gap   : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','col','gap' ) );    return  this.a.grid ; },
              val   : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','col' ) );          return  this.a.grid ; },
          },
          row  : {
              start : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','row','start' ) );  return  this.a.grid ; },
              end   : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','row','end' ) );    return  this.a.grid ; },
              gap   : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','row','gap' ) );    return  this.a.grid ; },
              val   : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','row' ) );          return  this.a.grid ; },
          },
          temp : {
              areas : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','temp','areas' ) );  return  this.a.grid ; },
              rows  : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','temp','rows' ) );    return  this.a.grid ; },
              cols  : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','temp','cols' ) );    return  this.a.grid ; },
              val   : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','temp' ) );          return  this.a.grid ; },
          },
          area : {
              rs  : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','area','' ) );  return  this.a.grid ; },
              re  : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','area','rows' ) );    return  this.a.grid ; },
              cs  : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','area','cols' ) );    return  this.a.grid ; },
              ce  : (val)=>{ this._css.val_key( val, this._css.spread( 'grid','area' ) );          return  this.a.grid ; },
              aa   : ()=>{ return  this.a ; },
              ds   : ()=>{ return  this ; },
          },
          aa   : ()=>{ return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      
      bg   : (val)=>{ this._css.val_key( val,  this._css.spread( 'bg' ));  return  this.a ; },
      bgd  : {
          att  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','att' ));  return  this.a.bgd ; },
          bld  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','bld' ));  return  this.a.bgd ; },
          clip :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','clip'));  return  this.a.bgd ; },
          clr  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','clr' ));  return  this.a.bgd ; },
          img  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','img' ));  return  this.a.bgd ; },
          ori  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','ori' ));  return  this.a.bgd ; },
          pos  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','pos' ));  return  this.a.bgd ; },
          rep  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','rep' ));  return  this.a.bgd ; },
          siz  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bg','siz' ));  return  this.a.bgd ; },  
          tsp  : ()=>{ this._css.val_key( 'transparent',  'background' );  return  this.a ; },  
          ccl  : ()=>{ this._css.val_key( 'currentColor', 'background' );  return  this.a ; },  
          aa   : ()=>{ return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      
      bor  : (val)=>{ this._css.val_key( val,  this._css.spread( 'bor' ));  return  this.a ; },
      bord : {
          top : {
              clr : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','top','clr' ));  return  this.a.bord.top ; },
              sty : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','top','sty' ));  return  this.a.bord.top ; },
              wid : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','top','wid' ));  return  this.a.bord.top ; },
              val : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','top' ));  return  this.a.bord ; },
              rad : {
                  lef : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','top','lef','rad' ));  return  this.a.bord.top.rad ; },
                  rig : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','top','rig','rad' ));  return  this.a.bord.top.rad ; },
                  aa  : ()=>{ return  this.a ; },
                  ds  : ()=>{ return  this ; },
              },
              aa  : ()=>{ return  this.a ; },
              ds: ()=>{ return  this ; },
          },
          bot : {
              clr : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','bot','clr' ));  return  this.a.bord.bot ; },
              sty : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','bot','sty' ));  return  this.a.bord.bot ; },
              wid : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','bot','wid' ));  return  this.a.bord.bot ; },
              rad : {
                  lef : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','bot','lef','rad' ));  return  this.a.bord.bot.rad ; },
                  rig : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','bot','rig','rad' ));  return  this.a.bord.bot.rad ; },
                  up  : ()=>{ return  this.bot ; },
                  aa  : ()=>{ return  this.a ; },
                  ds  : ()=>{ return  this ; },
              },
              val : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','bot' ));  return  this.a.bord ; },
              aa  : ()=>{this.a},
              ds: ()=>{ return  this ; },
          },
          lef : {
              clr : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','lef','clr' ));  return  this.a.bord.lef ; },
              sty : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','lef','sty' ));  return  this.a.bord.lef ; },
              wid : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','lef','wid' ));  return  this.a.bord.lef ; },
              val : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','lef'));  return  this.a.bord ; },
              aa  : ()=>{ return  this.bor ; },
              ds  : ()=>{ return  this ; },
          },
          rig : {
              clr : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','rig','clr' ));  return  this.a.bord.rig ; },
              sty : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','rig','sty' ));  return  this.a.bord.rig ; },
              wid : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','rig','wid' ));  return  this.a.bord.rig ; },
              val : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','rig' ));  return  this.a.bord ; },
              aa  : ()=>{ return this.a},
              ds  : ()=>{ return this ; },
          },
          rad : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','rad' ));  return  this.a.bord ; },
          ima : {
              os  : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','ima','os'  ));  return  this.a.bord.ima ; },
              rep : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','ima','sli' ));  return  this.a.bord.ima ; },
              sli : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','ima','rep' ));  return  this.a.bord.ima ; },
              wid : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','ima','wid' ));  return  this.a.bord.ima ; },
              src : (val)=>{this._css.val_key( val,  this._css.spread( 'bor','ima','src' ));  return  this.a.bord.ima ; },
              aa  : ()=>{ return  this.a ; },
              ds: ()=>{ return  this ; },
          },
          clr  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','clr' ));  return  this.a.bord ; },  
          sty  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','sty' ));  return  this.a.bord ; },  
          wid  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','wid' ));  return  this.a.bord ; },  
          rdi  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','rdi' ));  return  this.a.bord ; },  
          spa  :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','spa' ));  return  this.a.bord ; },  
          coll :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','coll'));  return  this.a.bord ; },  
          t    :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','t' ));    return  this.a.bord ; },  
          b    :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','b' ));    return  this.a.bord ; },  
          l    :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','l' ));    return  this.a.bord ; },  
          r    :(val)=>{ this._css.val_key( val,  this._css.spread( 'bor','r' ));    return  this.a.bord ; },  
          
          aa  : ()=>{ return  this.a ; },
          ds: ()=>{ return  this ; },
      },
      
      mar  : (val)=>{ this._css.val_key( val,  this._css.spread( 'mrg' ));  return  this.a ; },
      marg : {
          top :(val)=>{ this._css.val_key( val,  this._css.spread( 'mrg', 'top' ));  return  this.a.marg ; },
          lef :(val)=>{ this._css.val_key( val,  this._css.spread( 'mrg', 'lef' ));  return  this.a.marg ; },
          rig :(val)=>{ this._css.val_key( val,  this._css.spread( 'mrg', 'rig' ));  return  this.a.marg ; },
          bot :(val)=>{ this._css.val_key( val,  this._css.spread( 'mrg', 'bot' ));  return  this.a.marg ; },
          aa  : ()=>{ return  this.a ; },
          ds: ()=>{ return  this ; },
      },
      mbm  : {
        nor   : ()=>{ this._css.val_key( 'normal',        'mix-blend-mode' ) ; return this.a;},
        muti  : ()=>{ this._css.val_key( 'multiply',      'mix-blend-mode' ) ; return this.a;},
        scr   : ()=>{ this._css.val_key( 'screen',        'mix-blend-mode' ) ; return this.a;},
        ol    : ()=>{ this._css.val_key( 'overlay',       'mix-blend-mode' ) ; return this.a;},
        dk    : ()=>{ this._css.val_key( 'darken',        'mix-blend-mode' ) ; return this.a;},
        lit   : ()=>{ this._css.val_key( 'lighten',       'mix-blend-mode' ) ; return this.a;},
        cd    : ()=>{ this._css.val_key( 'color-dodge',   'mix-blend-mode' ) ; return this.a;},
        cb    : ()=>{ this._css.val_key( 'color-burn',    'mix-blend-mode' ) ; return this.a;},
        diff  : ()=>{ this._css.val_key( 'difference',    'mix-blend-mode' ) ; return this.a;},
        ex    : ()=>{ this._css.val_key( 'exclusion',     'mix-blend-mode' ) ; return this.a;},
        hue   : ()=>{ this._css.val_key( 'hue',           'mix-blend-mode' ) ; return this.a;},
        satu  : ()=>{ this._css.val_key( 'saturation',    'mix-blend-mode' ) ; return this.a;},
        c     : ()=>{ this._css.val_key( 'color',         'mix-blend-mode' ) ; return this.a;},
        lumi  : ()=>{ this._css.val_key( 'luminosity',    'mix-blend-mode' ) ; return this.a;},
      },
      clr  : (val)=>{ this._css.val_key( val,  'color');    return  this.a ; },
      cont : (val)=>{ this._css.val_key( `'${val}'`,  'content' ); return  this.a ; },
     
      //imp  : (val)=>{ this._css.val_key( `(${val})`,  '@import');  return  this.a ; },
      opc  : (val)=>{ this._css.val_key( val,  'opacity');  return  this.a ; },
      ovf  : {
          vis   : (val)=>{ this._css.val_key( 'visible',  'overflow');  return  this.a ; },
          hid   : (val)=>{ this._css.val_key( 'hidden',   'overflow');  return  this.a ; },
          scl   : (val)=>{ this._css.val_key( 'scroll',   'overflow');  return  this.a ; },
          auto  : (val)=>{ this._css.val_key( 'auto',     'overflow');  return  this.a ; },
          clip  : (val)=>{ this._css.val_key( 'clip',     'overflow');  return  this.a ; },
      },  
      ovfl : {
          x : {
              vis   : (val)=>{ this._css.val_key( 'visible',  'overflow-x');  return  this.a ; },
              hid   : (val)=>{ this._css.val_key( 'hidden',   'overflow-x');  return  this.a ; },
              scl   : (val)=>{ this._css.val_key( 'scroll',   'overflow-x');  return  this.a ; },
              auto  : (val)=>{ this._css.val_key( 'auto',     'overflow-x');  return  this.a ; },
              clip  : (val)=>{ this._css.val_key( 'clip',     'overflow-x');  return  this.a ; },
          },
          y : {
              vis   : (val)=>{ this._css.val_key( 'visible',  'overflow-y');  return  this.a ; },
              hid   : (val)=>{ this._css.val_key( 'hidden',   'overflow-y');  return  this.a ; },
              scl   : (val)=>{ this._css.val_key( 'scroll',   'overflow-y');  return  this.a ; },
              auto  : (val)=>{ this._css.val_key( 'auto',     'overflow-y');  return  this.a ; },
              clip  : (val)=>{ this._css.val_key( 'clip',     'overflow-y');  return  this.a ; },
          },
      },
      pad  : (val)=>{ this._css.val_key( val,  'padding');  return  this.a ; },
      padd : {
          top :(val)=>{ this._css.val_key( val,  this._css.spread( 'pdi', 'top' ));  return  this.a.padd ; },
          lef :(val)=>{ this._css.val_key( val,  this._css.spread( 'pdi', 'lef' ));  return  this.a.padd ; },
          rig :(val)=>{ this._css.val_key( val,  this._css.spread( 'pdi', 'rig' ));  return  this.a.padd ; },
          bot :(val)=>{ this._css.val_key( val,  this._css.spread( 'pdi', 'bot' ));  return  this.a.padd ; },
          aa  : ()=>{ return  this.a ; },
          ds: ()=>{ return  this ; },
      },
      pos  : {
          abs :()=>{ this._css.val_key( 'absolute', this._css.spread( 'pos' ));  return  this.a ; },
          rel :()=>{ this._css.val_key( 'relative', this._css.spread( 'pos' ));  return  this.a ; },
          fix :()=>{ this._css.val_key( 'fixed',    this._css.spread( 'pos' ));  return  this.a ; },
          stk :()=>{ this._css.val_key( 'sticky',   this._css.spread( 'pos' ));  return  this.a ; },
          sti :()=>{ this._css.val_key( 'static',   this._css.spread( 'pos' ));  return  this.a ; },
          ds: ()=>{ return  this ; },
      },
      txt  : {
          ali : {
              s     : ()=>{ this._css.val_key( 'start',  'text-align');  return  this.a.txt ; },
              e     : ()=>{ this._css.val_key( 'end',    'text-align');  return  this.a.txt ; },
              c     : ()=>{ this._css.val_key( 'center', 'text-align');  return  this.a.txt ; },
              l     : ()=>{ this._css.val_key( 'left',   'text-align');  return  this.a.txt ; },
              r     : ()=>{ this._css.val_key( 'right',  'text-align');  return  this.a.txt ; },
          },
          aa   : ()=>{ return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      tsf  : (val)=>{ this._css.val_key( val,  'transform');  return  this.a ; },
      tsl  : (val)=>{ this._css.val_key( val,  'translate');  return  this.a ; },
      tsi  : (val)=>{ this._css.val_key( val,  'transition');  return  this.a ; },
      trsf : {
          ori  : (val)=>{ this._css.val_key( val,  'transform-origin');  return  this.a ; },
          sty  : (val)=>{ this._css.val_key( val,  'transform-style');   return  this.a ; },
      },
      trsi : {
          time  : (val)=>{ this._css.val_key( val,  'transition-timing-function');  return  this.a.trsi ; },
          dla   : (val)=>{ this._css.val_key( val,  'transition-delay');            return  this.a.trsi ; },
          dua   : (val)=>{ this._css.val_key( val,  'transition-duration');         return  this.a.trsi ; },
          ppt   : (val)=>{ this._css.val_key( val,  'transition-property');         return  this.a.trsi ; },
          aa   : ()=>{ return  this.a ; },
          ds   : ()=>{ return  this ; },
      },
      
      //float：none | left | right
      
      flo  : {
          no    : ()=>{this._css.val_key( 'none',     'float');  return  this.a ; },
          lef   : ()=>{this._css.val_key( 'left',     'float');  return  this.a ; },
          rig   : ()=>{this._css.val_key( 'right',    'float');  return  this.a ; },
      },
      vtl  : {
        ali : {
          bl    : ()=>{this._css.val_key( 'baseline',     'vertical-align');  return  this.a ; },
          sub   : ()=>{this._css.val_key( 'sub',          'vertical-align');  return  this.a ; },
          sup   : ()=>{this._css.val_key( 'super',        'vertical-align');  return  this.a ; },
          top   : ()=>{this._css.val_key( 'top',          'vertical-align');  return  this.a ; },
          txt   : ()=>{this._css.val_key( 'text-top',     'vertical-align');  return  this.a ; },
          mid   : ()=>{this._css.val_key( 'middle',       'vertical-align');  return  this.a ; },
          bot   : ()=>{this._css.val_key( 'bottom',       'vertical-align');  return  this.a ; },
          txtb  : ()=>{this._css.val_key( 'text-bottom',  'vertical-align');  return  this.a ; },
          val   : (val)=>{this._css.val_key( val,         'vertical-align');  return  this.a ; },
        },
      },
      //align： | sub | super | top | text-top | middle | bottom | text-bottom | <percentage> | <length>
      vis  : {
        yes : ()=>{this._css.val_key( 'visible',  'visibility');  return  this.a ; },
        no  : ()=>{this._css.val_key( 'hidden',  'visibility');  return  this.a ; },
      },
      border : (val)=>{ return this.a.bor(val)},
      wich   : (val)=>{ this._css.val_key( val,  'will-change');  return  this.a ; },
      zidx   : (val)=>{ this._css.val_key( val,  'z-index');  return  this.a ; },
      ff   : ()=>{ return  this.f ; },
      ds   : ()=>{ return  this ; },
  }
 
  //#fast
  f = {
    abs : ()=>{ this.a.pos.abs();       return  this.f ; },
    rel : ()=>{ this.a.pos.rel();       return  this.f ; },
    fix : ()=>{ this.a.pos.fix();       return  this.f ; },
    blk : ()=>{ this.a.dsp.blk();       return  this.f ; },
    tac : ()=>{ this.a.txt.ali.c();     return  this.f ; },
    tar : ()=>{ this.a.txt.ali.r();     return  this.f ; },
    tal : ()=>{ this.a.txt.ali.l();     return  this.f ; },
    tsp : ()=>{ this.a.bgd.tsp();       return  this.f ; },
    fs  : (val)=>{ this.a.fnt.size(val);return  this.f ; },
    flx : {
        flx  : ()=>{ this.a.dsp.flx();       return  this.f.flx ;},
        jcc  : ()=>{ this.a.jc.c();          return  this.f.flx ;},
        jcfs : ()=>{ this.a.jc.fs();         return  this.f.flx ;},
        jcfe : ()=>{ this.a.jc.fe();         return  this.f.flx ;},
        jcsa : ()=>{ this.a.jc.sa();         return  this.f.flx ;},
        jcsb : ()=>{ this.a.jc.sb();         return  this.f.flx ;},
        jcii : ()=>{ this.a.jc.init();       return  this.f.flx ;},
        jcih : ()=>{ this.a.jc.inh();        return  this.f.flx ;},
        aic  : ()=>{ this.a.ai.c();          return  this.f.flx ;},
        aifs : ()=>{ this.a.ai.fs();         return  this.f.flx ;},
        aife : ()=>{ this.a.ai.fe();         return  this.f.flx ;},
        aisa : ()=>{ this.a.ai.sa();         return  this.f.flx ;},
        aisb : ()=>{ this.a.ai.sb();         return  this.f.flx ;},
        aiii : ()=>{ this.a.ai.init();       return  this.f.flx ;},
        aiih : ()=>{ this.a.ai.inh();        return  this.f.flx ;},
        fdc  : ()=>{ this.a.flx.dir.col();   return  this.f.flx ;},
        fdcv : ()=>{ this.a.flx.dir.cv();   return  this.f.flx ;},
        fdr  : ()=>{ this.a.flx.dir.row();   return  this.f.flx ;},
        fdrv : ()=>{ this.a.flx.dir.rv();   return  this.f.flx ;},
        wry  : ()=>{ this.a.flx.wrap.yes();  return  this.f.flx ;},
        wrn  : ()=>{ this.a.flx.wrap.no();   return  this.f.flx ;},
        wrii : ()=>{ this.a.flx.wrap.init(); return  this.f.flx ;},
        wrih : ()=>{ this.a.flx.wrap.inh();  return  this.f.flx ;},
        aa   : ()=>{ return  this.a ; },
        ff   : ()=>{ return  this.f ; },
        ds   : ()=>{ return  this ; },
    },
    aa  : ()=>{ return  this.a ; },
    ds  : ()=>{ return  this ; },
  }
  
 /*
  number keyboard
  
  col
  7    8    9
  0    0    0
  4    5    6
  0    0    0
  1    2    3
  
  row
  7  0  8  0  9
  4  0  5  0  6
  1  0  2  0  3
  
 */
  //#kb
  kb = {
      col   : {
            //1
            es   : ()=>{ this.f.flx.flx().fdc().jcfe().aifs();    return  this ;},
            //2
            ec   : ()=>{ this.f.flx.flx().fdc().jcfe().aic();     return  this ;},
            //3
            ee   : ()=>{ this.f.flx.flx().fdc().jcfe().aife();    return  this ;},
            //4
            cs   : ()=>{ this.f.flx.flx().fdc().jcc().aifs();     return  this ;},
            //5
            cc   : ()=>{ this.f.flx.flx().fdc().jcc().aic();      return  this ;},
            //6
            ce   : ()=>{ this.f.flx.flx().fdc().jcc().aife();     return  this ;},
            //7
            ss   : ()=>{ this.f.flx.flx().fdc().jcfs().aifs();    return  this ;},
            //8
            sc   : ()=>{ this.f.flx.flx().fdc().jcfs().aic();     return  this ;},
            //9
            se   : ()=>{ this.f.flx.flx().fdc().jcfs().aife();    return  this ;},
            //71
            sbs : ()=>{ this.f.flx.flx().fdc().jcsb().aifs();     return  this ;},
            //82
            sbc  : ()=>{ this.f.flx.flx().fdc().jcsb().aic();     return  this ;},
            //93
            sbe : ()=>{ this.f.flx.flx().fdc().jcsb().aife();     return  this ;},
            //7040
            sas : ()=>{ this.f.flx.flx().fdc().jcsa().aifs();     return  this ;},
            //8050
            sac  : ()=>{ this.f.flx.flx().fdc().jcsa().aic();     return  this ;},
            //9060
            sae : ()=>{ this.f.flx.flx().fdc().jcsa().aife();     return  this ;},
            
            p   : (n)=>{
                if(n ==   1 ){ return  this.kb.col.es() ;   }else 
                if(n ==   2 ){ return  this.kb.col.ec() ;   }else
                if(n ==   3 ){ return  this.kb.col.ee() ;   }else 
                if(n ==   4 ){ return  this.kb.col.cs() ;   }else
                if(n ==   5 ){ return  this.kb.col.cc() ;   }else 
                if(n ==   6 ){ return  this.kb.col.ce() ;   }else
                if(n ==   7 ){ return  this.kb.col.ss() ;   }else 
                if(n ==   8 ){ return  this.kb.col.sc() ;   }else
                if(n ==   9 ){ return  this.kb.col.se() ;   }else
                if(n ==  71 ){ return  this.kb.col.sbs() ;  }else
                if(n ==  82 ){ return  this.kb.col.sbc() ;  }else
                if(n ==  93 ){ return  this.kb.col.sbe() ;  }else
                if(n ==  17 ){ return  this.kb.cv.sbs() ;   }else
                if(n ==  28 ){ return  this.kb.cv.sbc() ;   }else
                if(n ==  39 ){ return  this.kb.cv.sbe() ;   }else
                if(n == 7040){ return  this.kb.col.sas() ;  }else
                if(n == 8050){ return  this.kb.col.sac() ;  }else
                if(n == 9060){ return  this.kb.col.sae() ;  }else
                if(n == 1040){ return  this.kb.cv.sas() ;   }else
                if(n == 2050){ return  this.kb.cv.sac() ;   }else
                if(n == 3060){ return  this.kb.cv.sae() ;   }
                return  this ;
            },
      },
      cv    : {
            //1
            ss   : ()=>{ this.f.flx.flx().fdcv().jcfs().aifs();    return  this ;},
            //2
            sc   : ()=>{ this.f.flx.flx().fdcv().jcfs().aic();     return  this ;},
            //3
            se   : ()=>{ this.f.flx.flx().fdcv().jcfs().aife();    return  this ;},
            //4
            cs   : ()=>{ this.f.flx.flx().fdcv().jcc().aifs();     return  this ;},
            //5
            cc   : ()=>{ this.f.flx.flx().fdcv().jcc().aic();      return  this ;},
            //6
            ce   : ()=>{ this.f.flx.flx().fdcv().jcc().aife();     return  this ;},
            //7
            es   : ()=>{ this.f.flx.flx().fdcv().jcfe().aifs();    return  this ;},
            //8
            ec   : ()=>{ this.f.flx.flx().fdcv().jcfe().aic();     return  this ;},
            //9
            ee   : ()=>{ this.f.flx.flx().fdcv().jcfe().aife();    return  this ;},
            //17
            sbs : ()=>{ this.f.flx.flx().fdcv().jcsb().aifs();     return  this ;},
            //28
            sbc  : ()=>{ this.f.flx.flx().fdcv().jcsb().aic();     return  this ;},
            //39
            sbe : ()=>{ this.f.flx.flx().fdcv().jcsb().aife();     return  this ;},
            //7040
            sas : ()=>{ this.f.flx.flx().fdcv().jcsa().aifs();     return  this ;},
            //8050
            sac  : ()=>{ this.f.flx.flx().fdcv().jcsa().aic();     return  this ;},
            //9060
            sae : ()=>{ this.f.flx.flx().fdcv().jcsa().aife();     return  this ;},
            
            
            p   : (n)=>{
                if(n ==   1 ){ return  this.kb.cv.ss() ;   }else 
                if(n ==   2 ){ return  this.kb.cv.sc() ;   }else
                if(n ==   3 ){ return  this.kb.cv.se() ;   }else 
                if(n ==   4 ){ return  this.kb.cv.cs() ;   }else
                if(n ==   5 ){ return  this.kb.cv.cc() ;   }else 
                if(n ==   6 ){ return  this.kb.cv.ce() ;   }else
                if(n ==   7 ){ return  this.kb.cv.es() ;   }else 
                if(n ==   8 ){ return  this.kb.cv.ec() ;   }else
                if(n ==   9 ){ return  this.kb.cv.ee() ;   }else
                if(n ==  17 ){ return  this.kb.cv.sbs() ; }else
                if(n ==  28 ){ return  this.kb.cv.sbc() ;  }else
                if(n ==  39 ){ return  this.kb.cv.sbe() ; }else
                if(n == 1040){ return  this.kb.cv.sas() ; }else
                if(n == 2050){ return  this.kb.cv.sac() ; }else
                if(n == 3060){ return  this.kb.cv.sae() ; }
                if(n ==  71 ){ return  this.kb.col.sbs() ; }else
                if(n ==  82 ){ return  this.kb.col.sbc() ;  }else
                if(n ==  93 ){ return  this.kb.col.sbe() ; }else
                if(n == 7040){ return  this.kb.col.sas() ; }else
                if(n == 8050){ return  this.kb.col.sac() ; }else
                if(n == 9060){ return  this.kb.col.sae() ; }
                return  this ;
            },
      },
      row   : {
            //1
            se : ()=>{ this.f.flx.flx().fdr().jcfs().aife();      return  this ;},
            //2
            ce : ()=>{ this.f.flx.flx().fdr().jcc().aife();    return  this ;},
            //3
            ee : ()=>{ this.f.flx.flx().fdr().jcfe().aife();    return  this ;},
            //4
            sc : ()=>{ this.f.flx.flx().fdr().jcfs().aic();    return  this ;},
            //5
            cc : ()=>{ this.f.flx.flx().fdr().jcc().aic();    return  this ;},
            //6
            ec : ()=>{ this.f.flx.flx().fdr().jcfe().aic();     return  this ;},
            //7
            ss : ()=>{ this.f.flx.flx().fdr().jcfs().aifs();     return  this ;},
            //8
            cs : ()=>{ this.f.flx.flx().fdr().jcc().aifs();     return  this ;},
            //9
            es : ()=>{ this.f.flx.flx().fdr().jcfe().aifs();     return  this ;},
            //13
            sbe : ()=>{ this.f.flx.flx().fdr().jcsb().aife();     return  this ;},
            //46
            sbc  : ()=>{ this.f.flx.flx().fdr().jcsb().aic();     return  this ;},
            //79
            sbs : ()=>{ this.f.flx.flx().fdr().jcsb().aifs();     return  this ;},
            //1020
            sae : ()=>{ this.f.flx.flx().fdr().jcsa().aife();     return  this ;},
            //4050
            sac  : ()=>{ this.f.flx.flx().fdr().jcsa().aic();     return  this ;},
            //7080
            sas : ()=>{ this.f.flx.flx().fdr().jcsa().aifs();     return  this ;},
            
            p   : (n)=>{
                if(n ==   1 ){ return  this.kb.row.se() ; }else 
                if(n ==   2 ){ return  this.kb.row.ce() ; }else
                if(n ==   3 ){ return  this.kb.row.ee() ; }else 
                if(n ==   4 ){ return  this.kb.row.sc() ; }else
                if(n ==   5 ){ return  this.kb.row.cc() ; }else 
                if(n ==   6 ){ return  this.kb.row.ec() ; }else
                if(n ==   7 ){ return  this.kb.row.ss() ; }else 
                if(n ==   8 ){ return  this.kb.row.cs() ; }else
                if(n ==   9 ){ return  this.kb.row.es() ; }else
                if(n ==  13 ){ return  this.kb.row.sbe() ; }else
                if(n ==  46 ){ return  this.kb.row.sbc() ; }else
                if(n ==  79 ){ return  this.kb.row.sbs() ; }else
                if(n == 1020){ return  this.kb.row.sae() ; }else
                if(n == 4050){ return  this.kb.row.sac() ; }else
                if(n == 7080){ return  this.kb.row.sas() ; }else
                if(n ==  31 ){ return  this.kb.rv.sbe() ; }else
                if(n ==  64 ){ return  this.kb.rv.sbc() ; }else
                if(n ==  97 ){ return  this.kb.rv.sbs() ; }else
                if(n == 3020){ return  this.kb.rv.sae() ; }else
                if(n == 6050){ return  this.kb.rv.sac() ; }else
                if(n == 9080){ return  this.kb.rv.sas() ; }
                return  this ;
            }
      },
      rv    : {
            //1
            ee : ()=>{ this.f.flx.flx().fdrv().jcfe().aife();      return  this ;},
            //2
            ce : ()=>{ this.f.flx.flx().fdrv().jcc().aife();    return  this ;},
            //3
            se : ()=>{ this.f.flx.flx().fdrv().jcfs().aife();    return  this ;},
            //4
            ec : ()=>{ this.f.flx.flx().fdrv().jcfe().aic();    return  this ;},
            //5
            cc : ()=>{ this.f.flx.flx().fdrv().jcc().aic();    return  this ;},
            //6
            sc : ()=>{ this.f.flx.flx().fdrv().jcfs().aic();     return  this ;},
            //7
            es : ()=>{ this.f.flx.flx().fdrv().jcfe().aifs();     return  this ;},
            //8
            cs : ()=>{ this.f.flx.flx().fdrv().jcc().aifs();     return  this ;},
            //9
            ss : ()=>{ this.f.flx.flx().fdrv().jcfs().aifs();     return  this ;},
            //31
            sbe : ()=>{ this.f.flx.flx().fdrv().jcsb().aife();     return  this ;},
            //64
            sbc  : ()=>{ this.f.flx.flx().fdrv().jcsb().aic();     return  this ;},
            //97
            sbs : ()=>{ this.f.flx.flx().fdrv().jcsb().aifs();     return  this ;},
            //3020
            sae : ()=>{ this.f.flx.flx().fdrv().jcsa().aife();     return  this ;},
            //6050
            sac  : ()=>{ this.f.flx.flx().fdrv().jcsa().aic();     return  this ;},
            //9080
            sas : ()=>{ this.f.flx.flx().fdrv().jcsa().aifs();     return  this ;},
            
            p   : (n)=>{
                if(n ==   1 ){ return  this.kb.rv.ee() ; }else 
                if(n ==   2 ){ return  this.kb.rv.ce() ; }else
                if(n ==   3 ){ return  this.kb.rv.se() ; }else 
                if(n ==   4 ){ return  this.kb.rv.ec() ; }else
                if(n ==   5 ){ return  this.kb.rv.cc() ; }else 
                if(n ==   6 ){ return  this.kb.rv.sc() ; }else
                if(n ==   7 ){ return  this.kb.rv.es() ; }else 
                if(n ==   8 ){ return  this.kb.rv.cs() ; }else
                if(n ==   9 ){ return  this.kb.rv.ss() ; }else
                if(n ==  31 ){ return  this.kb.rv.sbe() ; }else
                if(n ==  64 ){ return  this.kb.rv.sbc() ; }else
                if(n ==  97 ){ return  this.kb.rv.sbs() ; }else
                if(n == 3020){ return  this.kb.rv.sae() ; }else
                if(n == 6050){ return  this.kb.rv.sac() ; }else
                if(n == 9080){ return  this.kb.rv.sas() ; }else
                if(n ==  13 ){ return  this.kb.row.sbe() ; }else
                if(n ==  46 ){ return  this.kb.row.sbc() ; }else
                if(n ==  79 ){ return  this.kb.row.sbs() ; }else
                if(n == 1020){ return  this.kb.row.p(3020) ; }else
                if(n == 4050){ return  this.kb.row.sac() ; }else
                if(n == 7080){ return  this.kb.row.p(9080) ; }
                
                return  this ;
            }
      },
      ccc   : ()=>{ return this.kb.col.cc() },
      rcc   : ()=>{ return this.kb.row.cc() },
      all   : ()=>{
          if(Doc.api.query('style #cssFlexAll'))return this;
          let col = [1,2,3,4,5,6,7,8,9,17,71,28,82,39,93,1040,7040,2050,8050,3060,9060];
          let row = [1,2,3,4,5,6,7,8,9,13,31,46,64,79,97,1020,3020,4050,6050,7080,9080];
          let all = [row,col];
          let ppt = ['row','col'];
          let cs = new Css();
              cs.style(['cssAjs','cssFlexAll']);
          for(let a = 0; a < all.length; a++){
            let arr = all[a];
            arr.forEach((num)=>{
              cs.slt(`.flex-${ppt[a]}-p${num}`);
              let obj = Reflect.get(cs.flex,ppt[a]);
                        Reflect.get(obj,'p')(num);
              
            })
          }
          cs.ok();
      },
      ds   : ()=>{ return  this ; },
  }
  
  //#flex
  flex = this.kb;
  
  ds = ()=>{
      return this;
  }
  
  zz(key,val){
     this._css.val_key(val,`--${key}`);
     return this;
  }
  
  //define,--varible
  df(...args){
    return this.zz(...args);
  }
  
  //#time
  t = {
      infi  : 'infinite',
      line  : 'linear',
      ez    : 'easy',
      ei    : 'easy-in',
      eo    : 'easy-out',
      eio   : 'easy-in-out',
      ss    : 'step-start',
      se    : 'step-end',
  }

  
  //function
  fn = {
      tsl   : (val)=>{ return `translate(${val})`},
      tslx  : (val)=>{ return `translatex(${val})`},
      tsly  : (val)=>{ return `translatey(${val})`},
      tslz  : (val)=>{ return `translatez(${val})`},
      tsl3d : (val)=>{ return `translate3d(${val})`},
      tsf   : (val)=>{ return `transform(${val})`},
      tsi   : (val)=>{ return `transition(${val})`},
      mat   : (val)=>{ return `matrix(${val})`},
      mat3d : (val)=>{ return `matrix3d(${val})`},
      rot   : (val)=>{ return `rotate(${val})`},
      rotx  : (val)=>{ return `rotatex(${val})`},
      roty  : (val)=>{ return `rotatey(${val})`},
      rotz  : (val)=>{ return `rotatez(${val})`},
      rot3d : (val)=>{ return `rotate3d(${val})`},
      sca   : (val)=>{ return `scale(${val})`},
      scax  : (val)=>{ return `scalex(${val})`},
      scay  : (val)=>{ return `scaley(${val})`},
      scaz  : (val)=>{ return `scalez(${val})`},
      sca3d : (val)=>{ return `scale3d(${val})`},
      ske   : (val)=>{ return `skew(${val})`},
      skex  : (val)=>{ return `skewx(${val})`},
      skey  : (val)=>{ return `skewy(${val})`},
      pep   : (val)=>{ return `perspective(${val})`},
      svg   : (val)=>{ return `svg(${val})`},
      url   : (val)=>{ return `url('${val}')`},
      fmt   : (val)=>{ return `format('${val}')`},
      'var' : (val)=>{ return `var(${val})`},
      ligr  : (...args)=>{ return `linear-gradient(${[...args].join(',')})`},
      ccr   : ()=>{ return `currentColor()`},
      st    : (a,b)=>{ return `steps(${a},${b})`; },
      cb    : (a,b,c,d)=>{ return `cubic-bezier(${a},${b},${c},${d})`; },
  }
  
  
  /*
    param :
            i     : integer    : 0 ~ 15 (div=16)
                                 0 ~ 31 (div= 8)
                                 0 ~  7 (div=32)
            opc   : opacity    : 0 ~  1
            div   : division   : 8,16,32
            color : color name : 'red','yellow','blue','green','fuchsia','aqua','white'
            n     : 0 ~ 6
    usage : 
            let cs = new Css();
            let a  = cs.rgba.red(1);
            let b  = cs.rgba.get('red',1);
            let c  = cs.rgba.arr(0,1);
            //a,b,c get same result : "rgba(  239,     0,      0,    1 )"
  */
  //#rgba
  rgba = {
    red     : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},     0,      0,  ${opc} )` ;},
    yellow  : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},  ${x},      0,  ${opc} )` ;},
    blue    : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(     0,     0,   ${x},  ${opc} )` ;},
    green   : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(     0,  ${x},      0,  ${opc} )` ;},
    fuchsia : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},     0,   ${x},  ${opc} )` ;},
    aqua    : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(     0,  ${x},   ${x},  ${opc} )` ;},
    white   : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},  ${x},   ${x},  ${opc} )` ;},
    rgb     : ( r, g, b )=>{ return `rgb(  ${r},  ${g},  ${b}  )` ;},
    get     : (color, i, opc=1, div=16 )=>{
                return Reflect.get(this.rgba,color)(i,opc,div);
              },
    arr     : (n, i, opc=1, div=16)=>{
                let arr = ['red','yellow','blue','green','fuchsia','aqua','white'];
                return this.rgba.get(arr[n],i,opc,div);
              },
  }
  
  
  /*
    usage:
    let cs = new Css();
    let hsl = new cs.hsl(0,50,50);
    let str1 = hsl.out(1);      //str1: hsl( 12,50,50);
    let str2 = hsl.out(1,2);    //str2: hsl( 12,70,50);
    let str3 = hsl.out(10,2,3); //str3: hsl(120,70,80);
  
  */
  hsl = class{
    
    constructor(h=0,s=10,l=10){
        this.dat = {
            hsl  : [h,s,l],
            hmax : 120,
            div : [12,10,10],
            inc : [12,10,10],
            mod : 'inc',
        }
    }
    
    h = (val)=>{this.dat.hsl[0]=val;return this;}
    s = (val)=>{this.dat.hsl[1]=val;return this;}
    l = (val)=>{this.dat.hsl[2]=val;return this;}
    
    hmax = (hmax)=>{
        return this._hsl.setDat('hmax',hmax);
    }
    
    
    div = (n1,n2,n3)=>{
        return this._hsl.setDat('div',[n1,n2,n3]);
    }
    
    inc = (n1,n2,n3)=>{
        return this._hsl.setDat('inc',[n1,n2,n3]);
    }
    
    mod = (mod)=>{
        return this._hsl.setDat('mod',mod);
    }
    
    step =  (...args)=>{
      
        let i = -1;
        if(this.dat.mod == 'div'){
            if(this.dat.hmax <= this.dat.h){
                this.dat.hmax = this.dat.h + 120;
            }
        }
        let d          = this.dat;
        let mod        = d.mod;
        let hsl        = [360, d.hsl[1], d.hsl[2]];
        let [hh,ss,ll] = [...hsl];
        for(let a of args){
            i++;
            if(typeof(a) !== 'number'){
                alert('3486:input must be number');
                return this;
            }
            if( mod == 'inc'){
                hsl[i] = d.hsl[i]+d.inc[i]*a;
            }
        }
        hh = hsl[0].toString().padStart(3,' ');
        ss = hsl[1].toString().padStart(3,' ');
        ll = hsl[2].toString().padStart(3,' ');
        return `hsl( ${hh}, ${ss}%, ${ll}% )`;
    }
    
    _hsl = {
        setDat : (k,v)=>{
            Reflect.set(this.dat,k,v);
            return this;
        }, 
        fout : (...args)=>{
            let [a,b,c,hh,ss,ll]=[0,0,0,0,0,0];
            if(Array.isArray(args[0])){
                a = args[0][0];
                b = args[0][1];
                c = args[0][2];
            }else{
                a = args[0];
                b = args[1];
                c = args[2];
            }
            hh = a.toString().padStart(3,' ');
            ss = b.toString().padStart(3,' ');
            ll = c.toString().padStart(3,' ');
            return `hsl( ${hh}, ${ss}, ${ll} )`;
        }
    }

  }
  
  /*
  color = {
    _dat    : [],
    _set    : (arr)=>{ this.color._dat = [...arr] ; return this.color;},
    _get    : ()=>{},
    red     : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return this.color._set(  x,  0,  0,  opc ) ;},
    yellow  : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return this.color._set(  x,  x,  0,  opc ) ;},
    blue    : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return this.color._set(  0,  0,  x,  opc ) ;},
    green   : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return this.color._set(  0,  x,  0,  opc ) ;},
    fuchsia : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return this.color._set(  x,  0,  x,  opc ) ;},
    aqua    : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return this.color._set(  0,  x,  x,  opc ) ;},
    white   : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return this.color._set(  x,  x,  x,  opc ) ;},
    rgb     : ()=>{ let [r,g,b,opc] = [...this.color._dat]; return  `rgb(  ${r},  ${g},  ${b}  )` ;},
    rgba    : ()=>{ let [r,g,b,opc] = [...this.color._dat]; return `rgba(  ${r},  ${g},  ${b},  ${opc} )` ;},
    get     : (color, i, opc=1, div=16 )=>{
                return Reflect.get(this.rgba,color)(i,opc,div);
              },
    arr     : (n, i, opc=1, div=16)=>{
                let arr = ['red','yellow','blue','green','fuchsia','aqua','white'];
                return this.color.get(arr[n],i,opc,div);
              },
  }
  */
  
  //#_css
  _css = {
    //##abbr
    abbr      : {
              t    : 'top',
              b    : 'bottom',
              l    : 'left',
              r    : 'right',
              w    : 'width',
              h    : 'height',
              
              //##a
              abs  : 'absolute',
              ac   : 'align-content',
              ai   : 'align-items',
              as   : 'align-self',
              ali  : 'align',
              alg  : 'align',
              adj  : 'adjust',
              ani  : 'animation',
              aro  : 'around',
              att  : 'attachment',
              aut  : 'auto',
              //##b
              
              bas  : 'basis',
              bal  : 'balance',
              bdr  : 'border',
              beha : 'behavior',
              bet  : 'between',
              bf   : 'backface',
              bg   : 'background',
              bgd  : 'background',
              bl   : 'baseline',
              bld  : 'blend',
              blk  : 'block',
              bot  : 'bottom',
              bor  : 'border',
              btm  : 'bottom',
              //##c
              cap  : 'caption',
              chr  : 'character',
              col  : 'column',
              cols : 'columns',
              coll : 'collapse',
              ctr  : 'center',
              crvs : 'column-reverse',
              clr  : 'color',
              cont : 'content',
              cnt  : 'count',
              cnr  : 'counter',
              //##d
              dla  : 'delay',
              dec  : 'decoration',
              dir  : 'direction',
              dsp  : 'display',
              dur  : 'duration',
              //##e
              evt  : 'events',
              
              //##f
              fix  : 'fixed',
              flx  : 'flex',
              flxb : 'flexbox',
              fml  : 'family',
              fnc  : 'function',
              fnt  : 'font',
              foo  : 'footer',
              ftr  : 'footer',
              fun  : 'function',
              //##g
              grp  : 'group',
              //##h
              hang : 'hanging',
              hei  : 'height',
              hea  : 'header',
              //##i
              idx  : 'index',
              init : 'initial',
              inh  : 'inherit',
              inl  : 'inline',
              inr  : 'inter',
              ima  : 'image',
              img  : 'image',
              inc  : 'increment',
              iter : 'iteration',
              
              //##j
              jc   : 'justify-content',
              jst  : 'justify',
              jus  : 'justify',
              
              //##k
              kf   : '@keyframes',
              kern : 'kerning',
              //##l
              lef  : 'left',
              lis  : 'list',
              //##m
              mrg  : 'margin',
              mtx  : 'matrix',
              //##n
              non  : 'none',
              nwr  : 'nowrap',
              
              //##o
              obj  : 'object',
              ol   : 'outline',
              os   : 'outset',
              ori  : 'origin',
              //##p
              pad  : 'padding',
              pdi  : 'padding',
              pepe : 'perspective',
              ppt  : 'property',
              ptr  : 'pointer',
              pos  : 'position',
              //##r
              rad  : 'radius',
              rdi  : 'radius',
              rep  : 'repeat',
              rpt  : 'repeat',
              rel  : 'relative',
              res  : 'reset',
              rig  : 'right',
              rin  : 'run-in',
              rot  : 'rotate',
              rrvs : 'row-reverse',
              rtx  : 'rotatex',
              rty  : 'rotatey',
              rtz  : 'rotatez',
              rvs  : 'reverse',
              //##s
              sca  : 'scale',
              scl  : 'scroll',
              siz  : 'size',
              shr  : 'shrink',
              sizi : 'sizing',
              sli  : 'slice',
              spg  : 'spacing',
              spa  : 'space',
              sta  : 'state',
              sti  : 'static',
              stk  : 'sticky',
              stc  : 'stretch',
              sty  : 'style',
              src  : 'source',
              //##t
              tbl  : 'table',
              tim  : 'timing',
              temp : 'template',
              tsf  : 'transform',
              tsi  : 'transition',
              tsl  : 'translate',
              txt  : 'text',
              //##u
              uni  : 'unicode',
              //##v
              var  : 'variant',
              vis  : 'visibility',
              vtl  : 'vertical',
              //##w
              wei  : 'weight',
              wid  : 'width',
              wri  : 'writing',
              wra  : 'wrap',
              //##z
              zidx : 'z-index',
              

    },
    
    //##key
    keyWords  : [ 'align-content',
                  'align-items',
                  'align-self',
                  
                  'animation',
                  'animation-delay',
                  'animation-direction',
                  'animation-duration',
                  'animation-fill-mode',
                  'animation-iteration-count',
                  'animation-name',
                  'animation-play-state',
                  'animation-timing-function',
                  'appearance',
                  
                  'backface-visibility',
                  'background',
                  'background-attachment',
                  'background-blend-mode',
                  'background-clip',
                  'background-color',
                  'background-image',
                  'background-origin',
                  'background-position',
                  'background-repeat',
                  'background-size',  
                  'border',
                  'border-bottom',
                  'border-bottom-color',
                  'border-bottom-left-radius',
                  'border-bottom-right-radius',  
                  'border-bottom-style',
                  'border-bottom-width',
                  'border-collapse',
                  'border-color',
                  'border-image',  
                  'border-image-outset',  
                  'border-image-repeat', 
                  'border-image-slice', 
                  'border-image-source', 
                  'border-image-width', 
                  'border-left',
                  'border-left-color',
                  'border-left-style',
                  'border-left-width',
                  'border-radius', 
                  'border-right',
                  'border-right-color',
                  'border-right-style',
                  'border-right-width',
                  'border-spacing',  
                  'border-style',
                  'border-top',
                  'border-top-color',
                  'border-top-left-radius', 
                  'border-top-right-radius',
                  'border-top-style',
                  'border-top-width',
                  'border-width',
                  'bottom',
                  'box-decoration-break', 
                  'box-shadow', 
                  'box-sizing', 
                  
                  'caption-side',
                  'caret-color',
                  '@charset',
                  'clear',
                  'clip',
                  'color',
                  'column-count',
                  'column-fill',
                  'column-gap',
                  'column-rule',
                  'column-rule-color',
                  'column-rule-style',
                  'column-rule-width',
                  'column-span',
                  'column-width',
                  'columns',
                  'content',
                  'counter-increment',
                  'counter-reset',
                  'cursor',
                  
                  'direction',
                  'display',
                  'empty-cells',
                  'filter',
                  'flex',
                  'flex-basis',
                  'flex-direction',
                  'flex-flow',
                  'flex-grow',
                  'flex-shrink',
                  'flex-wrap',
                  'float',
                  'font',
                  '@font-face', 
                  'font-family',
                  'font-kerning',
                  'font-size',
                  'font-size-adjust',  
                  'font-stretch', 
                  'font-style',
                  'font-variant',
                  'font-weight',
                  
                  'grid',
                  'grid-area',
                  'grid-auto-columns',
                  'grid-auto-flow',
                  'grid-auto-rows',
                  'grid-column',
                  'grid-column-end',
                  'grid-column-gap',
                  'grid-column-start',
                  'grid-gap',
                  'grid-row',
                  'grid-row-end',
                  'grid-row-gap',
                  'grid-row-start',
                  'grid-template',
                  'grid-template-areas',
                  'grid-template-columns',
                  'grid-template-rows',
                  
                  'hanging-punctuation',
                  'height',
                  'hyphens',
                  '@import',
                  'isolation',
                  'justify-content',
                  '@keyframes',
                  'left',
                  'letter-spacing',
                  
                  'line-height',
                  'list-style',
                  'list-style-image',
                  'list-style-position',
                  'list-style-type',
                  
                  'margin',
                  'margin-bottom',
                  'margin-left',
                  'margin-right',
                  'margin-top',
                  'max-height',
                  'max-width',
                  '@media',
                  'min-height',
                  'min-width',
                  'mix-blend-mode',
                  
                  'object-fit', 
                  'object-position', 
                  'opacity', 
                  'order', 
                  'outline',
                  'outline-color',
                  'outline-offset',  
                  'outline-style',
                  'outline-width',
                  'overflow',
                  'overflow-x',  
                  'overflow-y',
                  
                  'padding',
                  'padding-bottom',
                  'padding-left',
                  'padding-right',
                  'padding-top',
                  'page-break-after',
                  'page-break-before',
                  'page-break-inside',
                  'perspective',
                  'perspective-origin',
                  'pointer-events',
                  'position',
                  'quotes',
                  
                  'resize',
                  'right',
                  
                  'scroll-behavior',
                  
                  'tab-size',
                  'table-layout',
                  'text-align',
                  'text-align-last',
                  'text-decoration',
                  'text-decoration-color',
                  'text-decoration-line',
                  'text-decoration-style',
                  'text-indent',
                  'text-justify',
                  'text-overflow',  
                  'text-shadow', 
                  'text-transform',
                  'top',
                  
                  'transform',
                  'transform-origin',
                  'transform-style',
                  'transition',
                  'transition-delay',
                  'transition-duration',
                  'transition-property',
                  'transition-timing-function',
                  
                  'unicode-bidi', 
                  'user-select', 
                  
                  'vertical-align',
                  'visibility',
                  
                  'white-space',
                  'width',
                  'will-change',
                  'word-break',  
                  'word-spacing',
                  'word-wrap',
                  'writing-mode',  
                  
                  'z-index',
                ],
                
    keymap  : [ 'align-content',
                  'align-items',
                  'align-self',
                  
                  'animation',
                  'animation-delay',
                  'animation-direction',
                  'animation-duration',
                  'animation-fill-mode',
                  'animation-iteration-count',
                  'animation-name',
                  'animation-play-state',
                  'animation-timing-function',
                  
                  'backface-visibility',
                  'background',
                  'background-attachment',
                  'background-blend-mode',
                  'background-clip',
                  'background-color',
                  'background-image',
                  'background-origin',
                  'background-position',
                  'background-repeat',
                  'background-size',  
                  'border',
                  'border-bottom',
                  'border-bottom-color',
                  'border-bottom-left-radius',
                  'border-bottom-right-radius',  
                  'border-bottom-style',
                  'border-bottom-width',
                  'border-collapse',
                  'border-color',
                  'border-image',  
                  'border-image-outset',  
                  'border-image-repeat', 
                  'border-image-slice', 
                  'border-image-source', 
                  'border-image-width', 
                  'border-left',
                  'border-left-color',
                  'border-left-style',
                  'border-left-width',
                  'border-radius', 
                  'border-right',
                  'border-right-color',
                  'border-right-style',
                  'border-right-width',
                  'border-spacing',  
                  'border-style',
                  'border-top',
                  'border-top-color',
                  'border-top-left-radius', 
                  'border-top-right-radius',
                  'border-top-style',
                  'border-top-width',
                  'border-width',
                  'bottom',
                  'box-decoration-break', 
                  'box-shadow', 
                  'box-sizing', 
                  
                  'caption-side',
                  'caret-color',
                  '@charset',
                  'clear',
                  'clip',
                  'color',
                  'column-count',
                  'column-fill',
                  'column-gap',
                  'column-rule',
                  'column-rule-color',
                  'column-rule-style',
                  'column-rule-width',
                  'column-span',
                  'column-width',
                  'columns',
                  'content',
                  'counter-increment',
                  'counter-reset',
                  'cursor',
                  
                  'direction',
                  'display',
                  'empty-cells',
                  'filter',
                  'flex',
                  'flex-basis',
                  'flex-direction',
                  'flex-flow',
                  'flex-grow',
                  'flex-shrink',
                  'flex-wrap',
                  'float',
                  'font',
                  '@font-face', 
                  'font-family',
                  'font-kerning',
                  'font-size',
                  'font-size-adjust',  
                  'font-stretch', 
                  'font-style',
                  'font-variant',
                  'font-weight',
                  
                  'grid',
                  'grid-area',
                  'grid-auto-columns',
                  'grid-auto-flow',
                  'grid-auto-rows',
                  'grid-column',
                  'grid-column-end',
                  'grid-column-gap',
                  'grid-column-start',
                  'grid-gap',
                  'grid-row',
                  'grid-row-end',
                  'grid-row-gap',
                  'grid-row-start',
                  'grid-template',
                  'grid-template-areas',
                  'grid-template-columns',
                  'grid-template-rows',
                  
                  'hanging-punctuation',
                  'height',
                  'hyphens',
                  '@import',
                  'isolation',
                  'justify-content',
                  '@keyframes',
                  'left',
                  'letter-spacing',
                  
                  'line-height',
                  'list-style',
                  'list-style-image',
                  'list-style-position',
                  'list-style-type',
                  
                  'margin',
                  'margin-bottom',
                  'margin-left',
                  'margin-right',
                  'margin-top',
                  'max-height',
                  'max-width',
                  '@media',
                  'min-height',
                  'min-width',
                  'mix-blend-mode',
                  
                  'object-fit', 
                  'object-position', 
                  'opacity', 
                  'order', 
                  'outline',
                  'outline-color',
                  'outline-offset',  
                  'outline-style',
                  'outline-width',
                  'overflow',
                  'overflow-x',  
                  'overflow-y',
                  
                  'padding',
                  'padding-bottom',
                  'padding-left',
                  'padding-right',
                  'padding-top',
                  'page-break-after',
                  'page-break-before',
                  'page-break-inside',
                  'perspective',
                  'perspective-origin',
                  'pointer-events',
                  'position',
                  'quotes',
                  
                  'resize',
                  'right',
                  
                  'scroll-behavior',
                  
                  'tab-size',
                  'table-layout',
                  'text-align',
                  'text-align-last',
                  'text-decoration',
                  'text-decoration-color',
                  'text-decoration-line',
                  'text-decoration-style',
                  'text-indent',
                  'text-justify',
                  'text-overflow',  
                  'text-shadow', 
                  'text-transform',
                  'top',
                  
                  'transform',
                  'transform-origin',
                  'transform-style',
                  'transition',
                  'transition-delay',
                  'transition-duration',
                  'transition-property',
                  'transition-timing-function',
                  
                  'unicode-bidi', 
                  'user-select', 
                  
                  'vertical-align',
                  'visibility',
                  
                  'white-space',
                  'width',
                  'will-change',
                  'word-break',  
                  'word-spacing',
                  'word-wrap',
                  'writing-mode',  
                  
                  'z-index',
                ],
            
    handle    : {
      
      ppt  : (ppt,key,...args)=>{
          //$lg('4783::ppt',ppt);
          
          this._css.val_key(args[0],key);
          if(ppt == 'appearance'){
					    this._css.val_key(args[0],`-webkit-${key}`);
					}
          return this;
      },
      
    },
                
    //##vk(css)            
    val_key   : (...args)=>{
                  //$lg('Css::val_key:828',args);
                  //alert(JSON.stringify(args));
                  if(args.length < 2){
                     //$lg('Css::val_key:830','args.length < 2',args);
                    //alert('Css::val_key:826:\nargs.length < 2');
                    return this;
                  }
                  
                  let val = args[0];
                  let key = args[1];
                  
                  let code = `${key}:${val};`;
                  //$lg('5246::code::bgg',code);
                  //$lg('5247::this.object::bgb',this.object,this.object.type);
                  this.object.add(code);
                  return this;
                },
    //##fmt
    format  : (arr)=>{
        let out = '';
        let maxLen = 0;
        let i = 0;
        for(let item of arr){
            let kvs = item.split(';')
            for(let kv of kvs){
                let k = kv.split(':')[0];
                if(k.length > maxLen) maxLen = k.length;
            }
        }
        for(let item of arr){
            i++;
            let kvs = item.split(';')
            let j = 0;
            for(let kv of kvs){
                if(kv.length == 0)continue;
                j++;
                let p = kv.split(':');
                let k = p[0];
                let v = p[1];
                if(i == 1)out += '\n'+' '.repeat(10);
                else      out += ' '.repeat(10);
                out += k.padEnd(maxLen+2)+`: ${v};`;
                if(kvs.length > 1) out+= '\n';
            }
        }
        
        return out;
    },
    
    //##obj(css)
    obj       : {
        //##frags
        frags : (...args)=>{
        
            let fgs = {
                type : 'frags',
                arr   : [],
                add   : function(frag){
                    this.arr.push(frag);
                },
                last  : function(){
                    //return frag
                    return this.arr[this.arr.length-1];
                },
                query : function(anyStr){
                    let DocObj = null;
                    for(let frag of this.arr){
                      DocObj = frag.query(anyStr);
                      if(DocObj) return DocObj;
                    }
                    return DocObj;
                },
                out : function(){
                    for(let frag of this.arr){
                        frag.out();
                    }
                },
            }
            return fgs;
        },
        //##frag
        frag  : (anyStr,topDocElm)=>{
            let dcdf = document.createDocumentFragment();
            let ofg = {
                ffn   : 'dom',
                type  : 'frag',
                que   : anyStr,
                top   : topDocElm,
                fgm   : dcdf,
                styles : [], //obj.styles
                
                query : function(anyStr){
                    for(let ObjStyle of this.styles){
                        let DocObj = ObjStyle.query(anyStr);
                        if(DocObj) return DocObj;
                    }
                },
                last  : function(){
                    return this.styles[this.styles.length-1];
                },
                add   : function(objStyle){
                    this.styles.push(objStyle);
                },
                out   : function(patt='new'){
                    if(patt == 'new'){
                        //新建模式
                        //向目标元素添加新的style
                        for(let ObjStyle of this.styles){
                            let DocStyle = ObjStyle.out();
                            this.fgm.appendChild(DocStyle);
                        }
                        this.top.appendChild(this.fgm);
                    }else if(patt == 'inc'){
                        //increment增量模式
                        //向相同id的style标签新增slt
                    }else if(patt == 'rep'){
                        //replace替换模式
                        //相同id的style标签替换相同签名的slt
                    }
                },
            }
        
            return ofg;
        },
        //##style
        style : (id,clazz='')=>{
            let sty = this.docu.celm('style',id,clazz);
                sty.setAttribute('data-ajs-cidx',Css.cidx);
            Css.cidx++;
            return {
                ffn  : 'style',
                type : 'style',
                sty : sty,
              //slt or kf
                slts : [],
                kfs  : [],
                child : [],
                clone : (...args)=>{
                    return this.clone(...args);
                },
                html       : function(html){
                    this.sty.innerHTML = html;
                },
                add_slt    : function(obj_sltor){
                    this.slts.push(obj_sltor);
                },
                add_kf     : function(obj_keyframes){
                    this.kfs.push(obj_keyframes);
                },
                add_child  : function(obj_style){
                    //let proto = Reflect.getPrototypeOf(this);
                    //$lg('css::2896::listKeys(proto)',$log.listKeys(proto));
                    //$lg('css::2896::this.type',this.type);
                    this.child.push(obj_style);
                },
                last_slt   : function(){
                    return this.slts[this.slts.length-1];
                },
                last_kf    : function(){
                    return this.kfs[this.kfs.length-1];
                },
                last_child : function(){
                    return this.child[this.child.length-1];
                },
                /*query  : function(anyStr){
                  let search = function(ObjStyle,cidx){
                      if(ObjStyle.sty.getAttribute('data-ajs-cidx')==cidx) 
                          return ObjStyle.sty;
                      for(let child of ObjStyle.child ){
                          if(child.sty.getAttribute('data-ajs-cidx')==cidx) 
                              return child.sty;
                      }
                      return null;
                  }
                  let docStyle = Ajs.clone(this.sty);
                  $lg('2889:docStyle',docStyle);
                  $lg('2890::one',$log.strify.html.one(docStyle));
                  this.out(docStyle);
                  let docObj = docStyle.querySelector(anyStr);
                  if(docObj){
                      let cidx = docObj.getAttribute('data-ajs-cidx');
                      if(cidx){
                          return search(this,cidx);
                      }else{
                          let   msg  = 'ajs.js::Css::_css::obj::style:2919\n';
                                msg += 'cidx == null:\n';
                                msg += `your input : '${anyStr}'`;
                          alert(msg);
                      }
                  }else{
                      let msg  = 'ajs.js::Css::_css::obj::style:2922\n';
                          msg += '在当前的ObjStyle中找不到你指定的内容:\n';
                          msg += `your input : '${anyStr}'`;
                      alert(msg);
                  }
                },  */
                query      : function(id){
                    if(this.sty.id == id) return this;
                    for(let child of this.child ){
                        if(child.sty.id == id) return child;
                    }
                    return null;
                },
                out  : function(DocStyle = this.sty){
                  
                  //let head = ' '.repeat(2) + `${this.slt}`;
                  let arr = [];
                  if(this.slts.length>0){
                      let cont = '';
                      for(let obj_slt of this.slts){
                          cont += obj_slt.out();
                      }
                      DocStyle.innerHTML += cont;
                  }
                  if(this.kfs.length>0){
                      let cont = '';
                      for(let obj_kf of this.kfs){
                          cont += obj_kf.out();
                      }
                      DocStyle.innerHTML += cont;
                  }
                  if(this.child.length>0){
                      for(let chd of this.child){
                        DocStyle.appendChild(chd.out());
                      }
                  }
                  return DocStyle;
                },
          };
        },
        //##sltor
        sltor : (slt)=>{
          return {
                  slt : slt ,
                  fmt : (...args)=>{
                      return this._css.format(...args);
                  },
                  type : 'slt',
                  //propertys
                  codes : [] ,
                  add  : function(kvstr){
                      this.codes.push(kvstr) ;
                      //$lg('5031::codes:::bgy',...this.codes);
                      return this;
                  },
                  out  : function(){
                      let head = '\n' + ' '.repeat(4) + `${this.slt}`;
                      let cont = this.fmt(this.codes);
                      /*for(let code of this.codes){
                          cont += ' '.repeat(6) + code + '\n';
                      }*/
                      let str  = `${head}{  `;
                          str += `${cont}`
                          str += ' '.repeat(4)+'}\n';
                      return str;
                  },
            }
        },
        //##kf
        //##@type:w='-webkit-', m='-moz-'
        kf : (name,webkit='')=>{
            return {
              wk   : webkit,
              name : name,
              type : 'kf',
              pcs  : [],
              add  : function(pco){
                  this.pcs.push(pco);
              },
              last : function(){
                  return this.pcs[this.pcs.length-1];
              },
              out  : function(){
                  let head = '\n'+' '.repeat(4) + `@${this.wk}keyframes ${this.name}`;
                  let cont = '';
                  for(let pco of this.pcs){
                      cont += pco.out();
                  }
                  return `${head}{\n${cont}`+' '.repeat(4)+`}\n`;
              },
            }
        },
        //##pc
        pcent : (val)=>{
            return {
                type : 'pc',
                pcent : val,
                codes  : [],
                fmt   : (...args)=>{
                    return this._css.format(...args);
                },
                add   : function(kvstr){
                    this.codes.push(kvstr);
                    return this;
                },
                out   : function(){
                    let cont = this.fmt(this.codes);
                    
                    
                    /*
                    for(let item of this.codes){
                        cont +=  item ;
                    }
                    */
                    let pc   = ' '.repeat(6)+`${this.pcent}`.padStart(3,' ');
                    let str  = `${pc}%{${cont}`;
                        str += ' '.repeat(10)+`}\n`;
                    return str;
                },
            }
        },
     
    },
    
    //##reset
    reset     : ()=>{
        this.object      = undefined;
        this.topObject   = undefined;
        this.styleObject = undefined;
        this.frags       = this._css.obj.frags();
        this.dom('head');
        
        return this;
      },
  
    //##spread
    spread    : (...args)=>{
                  //$lg('Css::spread:849',args);
                  let i = 0;
                  let key = '';
                  for(let a of args){
                    let aa = a;
                    try{ aa = Reflect.get(this._css.abbr,a)}
                    catch(err){alert('Css::spread:855:err:'+err.message)};
                    let cc = aa == undefined ? a : aa;
                    key += "-".repeat(i) + `${cc}`;
                    i = 1;
                  }
                  //alert(key);
                  //$lg('Css::spread:861',key);
                  return key;
                },
    //##define
    define    : (ppt,key,callback)=>{
                    Reflect.defineProperty( Css.prototype, ppt, {
          						name : ppt,
          						value: function(val){
          						  return callback(val,key=`${key}`);
          						}
          					});
                },
  
    autorun   : ()=>{
        //$lg('5433::autorun start',Log.now());
        //let ppt2Arr = [];      
        //let sty = 'bgg';
        let keyWords = this._css.keyWords;
        for(let key of keyWords){
          // font-size-adjust -> font_size_adjust
          let ppt1 = key.replace(/\-/,'_');
          //this._css.define(ppt1,key,this._css.val_key);
          
          //$lg('5436::'+sty,key);
          //$lg(ppt1);
          Reflect.defineProperty( Css.prototype, ppt1, {
						name : ppt1,
						value: function(...args){
						  return this._css.handle.ppt(ppt1,key,...args);
						}
					});
					
					
					
					
          // font-size-adjust -> fontSizeAdjust
          let arr = key.split('-');
          if(arr.length == 1) continue;
          //$lg('5159::bgg',...arr);
          let i = 0;
          let ppt2 = '';
          
          for(let word of arr){
            
            let p1 = word.substr(0,1).toUpperCase();
              if(i == 0)p1 = word.substr(0,1).toLowerCase();
            let p2 = word.slice(1).toLowerCase();
            ppt2 += p1 + p2;
            i++;
          }
          //ppt2Arr.push(ppt2);
          //$lg(ppt2);
          Reflect.defineProperty( Css.prototype, ppt2, {
    						name : ppt2,
    						value: function(...args){
    						  return this._css.handle.ppt(ppt2,key,...args);
    						}
    			});
        
          
        }
        //$lg('5179::bgb',...ppt2Arr);
          //alert(k2);
          //this._css.define(ppt2,key,this._css.val_key);
        //$lg('5479::autorun end',Log.now());
    },
    
  }
  
}

//@load
/**
 * path : 此参数是指：
 *        从使用本class的html文件所在文件夹出发
 *        至本class所在文件夹的相对路径
 **/ 
class Load{
  
  constructor(path = "../import/thirdpart/"){
    this.basePath = path;
    if(self.$lg == undefined){
        new Log();
    }
  }
  
  //#add(load)
  add = {
      script : (src,onloadCallBack,head=document.head)=>{
          let script = document.createElement('script'); 
                  script.setAttribute( "src",this.basePath + src); 
                  //$lg('Load::add::scriot:235',this.basePath + src);
                  //this.add.a('url',this.basePath + src);
                  script.onload = onloadCallBack;
          head.appendChild(script);
          return this;
      },
      a : (text,href)=>{
          let a = document.createElement('a'); 
              a.setAttribute( "href",href);
              a.innerText = text;
          //alert(a);
          return this;
      },
      link : (href,callBack=null,rel='stylesheet',type='text/css',head=document.head)=>{
          let e = document.createElement('link'); 
                  e.setAttribute( "href",this.basePath + href); 
                  e.setAttribute( "rel",rel); 
                  e.setAttribute( "type",type); 
                  //$lg('Load::add::link:6023',this.basePath + src);
                  //this.add.a('url',this.basePath + src);
                  if(callBack)
                  e.onload = callBack;
          head.appendChild(e);
          return this;
      },
  }
  
  eruda = {
    load  : ()=>{
            //$lg('eruda is loading');
            return new Promise((resolve,reject)=>{
              let res = function(){
                //self.eruda.init(); 
                eruda.init(); 
                //$lg("eruda init done");
                resolve();
              };
              let file = "eruda/eruda.min.js";
              this.add.script(file,res);/*
              let script = document.createElement('script'); 
                  script.setAttribute( "src",this.basePath + "eruda/eruda.min.js"); 
                  script.onload = res;
              document.head.appendChild(script);*/
            });
            //return this;
          }
  };
  
  jquery = {
    load  : ()=>{
              //console.log('jquery is loading');
              return new Promise((resolve)=>{
                let res = function(){
                  console.log('jquery ok');
                  resolve();
                }
                let file = "jquery/jquery-3.3.1.js";
                this.add.script(file,res);
                /*let script = document.createElement('script'); 
                    script.setAttribute( "src",this.basePath + "jquery/jquery-3.3.1.js"); 
                    script.onload = res;
                document.head.appendChild(script);*/
              });
              //return this;
            } 
  };
  
  zepto = {
    load  : (file="")=>{
              if(file=="es6"){
                file = "zepto_es6.js";
                //import zepto from `this.basePath + "zepto/" + file`;
              }else{
                file = "zepto.js";
                let script = document.createElement('script'); 
                    script.setAttribute( "src",this.basePath + "zepto/" + file); 
                    script.onload = function () { console.log('zepto ok');} 
                document.head.appendChild(script);
              }
              return this;
            }
  };
  
  bootstrap = {
    loadJs  : ()=>{
                //console.log('bootstrap.js is loading');
             // console.log('third.js >> bootstrap >> load()');
                let script = document.createElement('script'); 
                    script.setAttribute( "src",this.basePath + "bootstrap/v5.1.3/bootstrap.bundle.js"); 

                    script.onload = function () { 
                    console.log('bootstrap loaded');
                    console.log(script.src);
                } 
                document.head.appendChild(script);
                return this;
              },
    loadCss : ()=> {
                //console.log('bootstrap.css is loading');
                let link = document.createElement('link'); 
                    link.setAttribute( "rel","stylesheet"); 
                    link.setAttribute( "type","text/css"); 
                    link.setAttribute( "href",this.basePath + "bootstrap/v5.1.3/bootstrap.css");
                    link.onload = function () { 
                      console.log('bootstrap.css loaded');
                    }
                 document.head.appendChild(link);
                 return this;
               }
  };
  
  bspIcon = {
    load  : ()=>{
            //$lg('bspIcon is loading');
            return new Promise((resolve,reject)=>{
              let res = function(){
                //$lg('bspIcon was loaded');
                resolve();
              };
              //
              let file = "bootstrap-icons/v1.8.3/font/bootstrap-icons.css";
              this.add.link(file,res);/*
              let script = document.createElement('script'); 
                  script.setAttribute( "src",this.basePath + "eruda/eruda.min.js"); 
                  script.onload = res;
              document.head.appendChild(script);*/
            });
            //return this;
          }
  };
  
  icono = {
    load  : ()=>{
              //console.log('jquery is loading');
              return new Promise((resolve)=>{
                let res = function(){
                  console.log('icono ok');
                  resolve();
                }
                  let link = document.createElement('link'); 
                      link.setAttribute( "rel","stylesheet"); 
                      link.setAttribute( "type","text/css"); 
                      link.setAttribute( "href",this.basePath + "icono/icono.css"); 
                      link.onload = res;
                  document.head.appendChild(link);
              });
              
            } 
  };
  
  recorder = {
    load : ()=>{
      return new Promise((resolve)=>{
        let res = function(){
          console.log('recorder ok');
          resolve();
        }
        let script = document.createElement('script'); 
            script.setAttribute( "src",this.basePath + "rec/recorder.js"); 
            script.onload = res;
        document.head.appendChild(script);
      });
    },
  }
  
  
}

//@xhr
/**
 * addr : address   , "../code/php/nur.php"
 * op   : operation , "getData" or "saveData"
 * da   : data      , {a:111,b:222}
 * 
 * let xhr = new Xhr(addr);
 *     xhr.ask(op,da)
 *        .rsp((data)=>{
 * 
 *        },(err)=>{
 * 
 *        })
 **/ 
//import {Html,Log}
class Xhr{
  constructor(addr,type='json'){
    this.addr = addr;
    //$lg('6193::xhr::addr',addr);
    this.opda = '';//this.pack(op,da);
    
    this.header = this.headerObj.app;
    //this.rsp(rsp,err);
    if(self.$lg == undefined){
        new Log();
    }
  }
  
  headerObj = {
      app   : "application/x-www-form-urlencoded; charset=UTF-8",
      
      es    : "text/event-source",
      
      html  : "text/html",
  }
  
  
  pack(op,da) {

    let key   = "opda";
    let value = {
        op      : op,
        da      : da
    };
    let gift = encodeURIComponent( key ) + "=" + encodeURIComponent( JSON.stringify(value) );
    //let opda = properEncodeURIComponent( key ) + "=" + properEncodeURIComponent( JSON.stringify(value) );
    return gift;
    
  }
  
  req = (addr,opda)=>{
    //$lg('Xhr::req:2993:',addr,opda);
    let promise = new Promise(function(resolve, reject){
      let type    = "text";//json
      let header  = "application/x-www-form-urlencoded; charset=UTF-8";
      //let header  = "text/event-source";
      let handler = function(){
          if (this.readyState !== 4) {
            return;
          }
          if (this.status === 200) {
            resolve(this.response);
          } else {
            reject(new Error(this.statusText));
          }
      };
    
      let http = new XMLHttpRequest();
           //alert('Log::2999:this.pget:'+this.pget);
            
        //$lg('Ajs::Xhr:req:3012');
        http.timeout = 1000 * 20;
        //let opda = task_build_request(user, op, da);
        http.open('post', addr,true);
        http.setRequestHeader("Content-Type",header);
        http.onreadystatechange = handler;
        //http.setRequestHeader("Connection","Keep-Alive");
        //http.setRequestHeader("Keep-Alive","timeout=50, max=100");
        http.responseType = type;
        http.send(opda);    
            
    });
    return promise;
  }
  
  ask(op,da=null){
    //$lg('Xhr::ask:3034');
    this.opda = this.pack(op,da);
    //$lg('6253::this.opda',this.opda);
    return this;
  }
  
  /**
   * rsp  : respone
   * suc  : callback function
   * err  : callback function
   **/ 
  rsp(suc,err){
    this.req(this.addr,this.opda)
        .then(function(data) {
            suc(data);
            //console.log('Contents: ' + data);
        }, function(error) {
            err(error);
            //console.error('出错了', error);
        });
  }
  
}

//@log
class Log{
  constructor(mode='htm',color='white'){
    if(self.$lg) return;
    this.x = 0;
    this.y = 0;
    
    this.icc  = -1;
    this.idsp = -1;//btn for switching lgHtml ot lgText
    this.itop = 1;
    this.execTimes = 0;
    self.$lg = this.log;
    self.$log = this;
    this.lastClickId = 'lgToolBtnDsp';
    this.txt = '';
    this.debugMode = 1;
    this.mode = mode;
    this.color = color;
    //$lg('Log::6250::this.color:',this.color);
    this.css().htm().event.setup();
    this.topbar.init();
    this.progress.into('#lgShowbox',10);
    
  }
  
  debug(mode=1){
      this.debugMode = mode;
      return this;
  }
  
  //#api
  api = {
    elm : (tag,id,cl='',text='',onEventArr=null)=>{
            let e = document.createElement(tag);
                if(id   !== '') e.setAttribute('id',id);
                if(cl   !== '') e.setAttribute('class',cl);
                if(text !== '') e.innerHTML = text;
                if(onEventArr !== null && Array.isArray(onEventArr)){
                    for(let evt of onEventArr){
                        //e.setAttribute(evt.name,evt.callback);
                        Reflect.set(e,evt.name,evt.callback);
                    }
                }
            return e;
          },
    text: (id,txt)=>{
            let e = document.querySelector('#'+id);
                e.innerText = txt;
            return this.api;
          },
    html: (id,txt)=>{
            let e = document.querySelector('#'+id);
                e.innerHTML = txt;
            return this.api;
          },
    fg  : ()=>{
            let fg = document.createDocumentFragment();
            return fg;
          },
    show  : (str)=>{
                let arr = document.querySelectorAll(str);
                for(let a of arr){
                    a.style.visibility = 'visible';
                }
                return this;
            },
    hide  : (str)=>{
                let arr = document.querySelectorAll(str);
                for(let a of arr){
                    a.style.visibility = 'hidden';
                }
                return this;
            },
    zindex : (str,idx)=>{
                    let arr = document.querySelectorAll(str);
                    for(let a of arr){
                        a.style.zIndex = idx;
                    }
                    return this;
                },
    style : (slt,prop,val)=>{
                    let arr = document.querySelectorAll(slt);
                    for(let a of arr){
                        
                        Reflect.set(a.style,prop,val);
                    }
                    return this;
                },
    add   : {
        style : (id,html='',onEventArr=null)=>{
            let s = document.createElement('style');
                s.setAttribute('id',id);
            if(html !== '') s.innerHTML = '\n' + ' '.repeat(4) + html + '\n' ;
            if(onEventArr !== null && Array.isArray(onEventArr)){
                for(let evt of onEventArr){
                    s.setAttribute(evt.name,evt.callback);
                }
            }
            return s;
        },
        children :  (topObject,arrChildren)=>{
                        for(let child of arrChildren){
                            topObject.appendChild(child);
                        }
                        return this;
                    },
    },
    attr  :  (obj,prop,val)=>{
                obj.setAttribute(prop,val);
            },
    gbid  :  (id)=>{
                return document.getElementById(id);
            },
    query :  (anyStr)=>{
                return document.querySelector(anyStr);
    },
    setdata  :  (obj,key,val)=>{
        obj.setAttribute('data-'+key,val);
    },
  }
  
  //#rgba(log)
  rgba = {
    red     : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},     0,      0,  ${opc} )` ;},
    yellow  : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},  ${x},      0,  ${opc} )` ;},
    blue    : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(     0,     0,   ${x},  ${opc} )` ;},
    green   : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(     0,  ${x},      0,  ${opc} )` ;},
    fuchsia : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},     0,   ${x},  ${opc} )` ;},
    aqua    : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(     0,  ${x},   ${x},  ${opc} )` ;},
    white   : ( i, opc=1, div=16 )=>{ let one = 256/div; let x = (div-i)*one-1; return `rgba(  ${x},  ${x},   ${x},  ${opc} )` ;},
    rgb     : ( r, g, b )=>{ return `rgb(  ${r},  ${g},  ${b}  )` ;},
    get     : (color, i, opc=1, div=16 )=>{
                //if(color == undefined )color = 'yellow';
                return Reflect.get(this.rgba,color)(i,opc,div);
              },
    arr     : (n, i, opc=1, div=16)=>{
                let arr = ['red','yellow','blue','green','fuchsia','aqua','white'];
                return this.rgba.get(arr[n],i,opc,div);
              },
  }
  
  //#htm
  htm = ()=>{
    
    if(Doc.api.gbid('lg')) return this;
   
    let frag = this.api.fg();
    
    let btn1 = this.api.elm('button','lgToolBtnClear','lgToolbtns','clear');
    let btn2 = this.api.elm('button','lgToolBtnDsp','lgToolbtns','txt');
    let btn3 = this.api.elm('button','lgToolBtnChar','lgToolbtns','char');
    let btn4 = this.api.elm('button','lgToolBtnIcon','lgToolbtns','icon');
    let btn5 = this.api.elm('button','lgToolBtnSQL','lgToolbtns','SQL');
    let btn6 = this.api.elm('button','lgToolBtnDocu','lgToolbtns','docu');
    let btn7 = this.api.elm('button','lgToolBtnTopbar','lgToolbtns','topbar');
  
    let icon = this.api.elm('div','lgIcon');
    let text = this.api.elm('textarea','lgText');
    let html = this.api.elm('div','lgHtml','lgCol');
    
    let titSpan = this.api.elm('span','lgTitleText');
    let title   = this.api.elm('div','lgTitle');
        title.appendChild(titSpan);
    
    let close = this.api.elm('div','lgClose','lgClose',`\u2612`);
    let close1 = this.api.elm('div','lgToolbarClose','lgClose',`\u2612`);
   
    
    let toolbar = this.api.elm('div','lgToolbar');
        toolbar.appendChild(close1);
        
    let toolbox = this.api.elm('div','lgToolbox');
        toolbox.appendChild(btn1);
        toolbox.appendChild(btn6);
        toolbox.appendChild(btn2);
        toolbox.appendChild(btn7);
        toolbox.appendChild(btn3);
        toolbox.appendChild(btn4);
        toolbox.appendChild(btn5);
    
    let ipt = this.api.elm('textarea','lgIpt','h50');
        ipt.rows = '1';
        
    let btnEnter = this.api.elm('button','lgbtnEnter','h50','\u25e3');
    let mutiline = this.api.elm('button','lgbtnMline','h50','\u25b2');
        
             
                         
    let cmd = this.api.elm('div','lgCmd','lgRow');
        cmd.appendChild(ipt);
        cmd.appendChild(btnEnter);
        cmd.appendChild(mutiline);
    
    
    let caption = this.api.elm('div','lgCaption');
        caption.appendChild(title);
        caption.appendChild(close);
        
    let showbox = this.api.elm('div','lgShowbox');
        showbox.appendChild(text);
        showbox.appendChild(html);
    
    let display = this.api.elm('div','lgDisplay','lgRow');
        display.appendChild(showbox);
        display.appendChild(toolbox);
        display.appendChild(toolbar);
    
    let wind = this.api.elm('div','lgWind','lgCol');
        wind.appendChild(caption);
        wind.appendChild(display);
        wind.appendChild(cmd);
    
    let log = this.api.elm('div','lg','lgBlk');
        log.appendChild(icon);
        log.appendChild(wind);
    
    frag.appendChild(log);
    document.body.appendChild(frag);
    return this;
  }
  
  //#css
  css(){
    
    if(Doc.api.gbid('cssLg')) return this;
    //let bg = this.rgba.get(this.color,12,0.80);
     
    let txt_blk         = `.lgBlk{
            display         : block;
            position        : absolute;
            padding         : 1vmin;
    }`;
    let txt_lgCol       = `.lgCol{
            display         : flex;
            flex-direction  : column;
            justify-content : flex-start;
            align-items     : center;
    }`;
    let txt_lgRow       = `.lgRow{
            display         : flex;
            flex-direction  : row;
            justify-content : center;
            align-items     : center;
    }`;
    let txt_h50         = `.h50{
            height          : 100%;
            //z-index         : 2020;
    }`;
    let txt_lgToolbtns  = `.lgToolbtns{
            position        : relative;
            display         : inline-block;
            width           : 100px;
            height          : 60px;
            border-radius   : 16px;
            //z-index         : 2023;
            padding         : 6px;
            font-size       : 3vmin;
            box-shadow      : none;
            border          : 1px solid transparent;
    }`;
    let txt_dspFlex     = `.dspFlex{
            position        : relative;
            display         : flex;
            flex-direction  : column;
            justify-content : flex-start;
            align-items     : flex-start;
            padding         : 6px;
            margin          : 0px;
            font-size       : 4vmin;
            height          : 100%;
            //z-index         : 9000;
            border-radius   : 0px;
    }`;
    let txt_dspTop      = `.dspTop{
            background      : lightyellow;
            width           : 100%;
            height          : 100px;
            overflow        : scroll;
            //z-index         : 9000;
    }`;
    let txt_dspChild    = `.dspChild{
            position        : relative;
            display         : inline-block;
            left            : 10px;
            top             : 20px;
            background      : white;
            width           : 450px;
            height          : auto;
            margin          : 10px;
            overflow        : auto;
            
            padding-left    : 6px;
            //z-index         : 9010;
            
    }`;
    let txt_dspKeys     = `.dspKeys{
            
            position        : relative;
            display         : block;
            background      : yellow;
            color           : black;
            border-radius   : 1px;
            width           : auto;
            height          : auto;
            padding-top     : 6px;
            padding-left    : 6px;
            //z-index         : 9090;
            font-size       : 4vmin;
            overflow        : scroll;
    }`;
    let txt_dspGson     = `.dspGson{
              top           : 70px;
              //z-index       : 9000;
              margin        : 20px;
              overflow      : scroll;
              
    }`;
    let txt_lightblue   = `.lightblue{
              background    : green;
              color         : white;
              height        : 60px;
    }`;
    let txt_lg          = `#lg{
            left            : 0px;
            top             : 0px;
            height          : 99%;
            width           : 99%;
            background      : transparent;
            padding         : 0px;
            //z-index         : 6600;
    }`;
    let txt_lgWind      = `#lgWind{
            position        : relative;
            display         : flex;
            visibility      : hidden;
            flex-direction  : column;
            justify-content : flex-start;
            align-items     : center;
            top             : 0px;
            left            : 0px;
            height          : 99%;
            width           : 99%;
            background      : ${this.rgba.get(this.color,10,1)};
            color           : black;
            padding         : 10px;
            border          : 0px solid blue;
            transition      : display 0.4s ease;
            z-index         : 6600;
            
    }`;
    let txt_lgDisplay   = `#lgDisplay{
            position        : relative;
            display         : flex;
            flex-direction  : row;
            justify-content : space-between;
            align-items     : flex-start;
            width           : 95%;
            height          : 80%;
            left            : 0px;
            margin          : 6px;
            padding         : 20px;
            border          : 0px solid green;
    }`;
    let txt_lgCaption   = `#lgCaption{
            position        : relative;
            display         : flex;
            flex-direction  : row;
            justify-content : space-between;
            align-items     : center;
            width           : 95%;
            height          : 80px;
            font-size       : 6vmin;
            color           : black;
            border          : 0px solid black;
            padding         : 10px;
            margin          : 10px;
            zindex          : 6601;
    }`;
    let txt_lgTitle     = `#lgTitle{
            position        : relative;
            display         : flex;
            flex-direction  : row;
            justify-content : center;
            align-items     : center;
            text-align      : center;
            background      : transparent;
            color           : white;
            width           : 90%;
            padding-top     : 5px;
            border          : 0px solid red;
    }`;
    let txt_lgClose     = `.lgClose{
            position        : relative;
            top             : 0px;
            right           : 0px;
            text-align      : center;
            font-size       : 9vmin;
            border          : 0px solid ${this.rgba.get(this.color,6,0.8)};
            color           : white;
            width           : 10%;
            
    }`;
          
    let txt_lgShowbox   = `#lgShowbox{
            display         : block;
            position        : relative;
            height          : 100%;
            width           : 90%;
            overflow        : scroll;
            border-right    : 0px solid black;
            padding         : 0px;
            border-radius   : 10px;
    }`;
    let txt_lgCmd       = `#lgCmd{
            position        : relative;
            height          : 70px;
            width           : 95%;
            padding         : 3px;
            border-top      : 0px solid black;
    }`;
    let txt_lgIcon      = `#lgIcon{
            background      : black;
            opacity         : 0.2;
            padding         : 6px;
            width           : 60px;
            height          : 60px;
            position        : fixed;
            display         : block;
            top             : 100px;
            left            : 800px;
            border-radius   : 50%;
            z-index         : 6600;
    }`;
    let txt_lgText      = `#lgText{
            position        : absolute;
            left            : 0px;
            top             : 0px;
            display         : block;
            overflow        : scroll;
            white-space     : pre-line;
            font-size       : 3vmin;
            width           : 100%;
            height          : 100%;
            border          : 0px solid black;
            border-radius   : 10px;
            //z-index         : 2020;
            background      : ${this.rgba.get(this.color,8,0.99)};
            color           : white;
    }`;
    let txt_lgHtml      = `#lgHtml{
            position        : absolute;
            left            : 0px;
            top             : 0px;
            display         : flex;
            flex-direction  : column;
            justify-content : flex-start;
            align-items     : flex-start;
            overflow        : scroll;
            white-space     : pre;
            font-size       : 3vmin;
            width           : 96%;
            height          : 98%;
            border          : 0px solid green;
            border-radius   : 10px;
            padding         : 16px;
            background      : ${this.rgba.get(this.color,8,0.99)};
    }
    .log-htm-item{
            position        : relative;
            
            display         : flex;
            flex-direction  : column;
            justify-content : center;
            align-items     : flex-start;
            overflow-wrap   : break-spaces;
            white-space     : pre;
            font-size       : 3vmin;
            width           : 96%;
            height          : auto;
            border          : 2px solid ${this.rgba.get(this.color,5,0.99)};
            border-radius   : 10px;
            padding         : 3px;
            margin          : 10px;
            background      : ${this.rgba.get(this.color,8,0.99)};
    }
    .log-htm-txt{
            position        : relative;
            font-size       : 3vmin;
            width           : 97%;
            min-height      : 50px;
            
            border          : 0px solid blue;
            border-radius   : 6px;
            padding         : 6px;
            padding-top     : 16px;
            margin          : 3px;
            overflow-x      : scroll;
            word-break      : break-word;
            background      : ${this.rgba.get(this.color,4,0.9)};
            color           : ${this.rgba.get(this.color,13,0.99)};
    }
    .log-htm-red{
            color           : red;  
    }
    .log-htm-yellow{
            color           : yellow;  
    }
    .log-htm-blue{
            color           : blue;  
    }
    .log-htm-orange{
            color           : orange;  
    }
    .log-htm-green{
            color           : green;  
    }
    .log-htm-red{
            color           : red;  
    }
    .log-htm-bg-blue{
            color           : white;  
            background      : lightblue;  
    }
    .log-htm-bg-orange{
            color           : white;  
            background      : orange;  
    }
    .log-htm-bg-green{
            color           : white;  
            background      : lightgreen;  
    }
    .log-htm-bg-yellow{
            color           : black;  
            background      : yellow;  
    }
    `;
    let txt_lgToolbox   = `#lgToolbox{
            position        : relative;
            top             : 0;
            width           : 16%;
            height          : 99.6%;
            padding         : 0px;  
            margin-left     : 10px;
            display         : flex;
            flex-direction  : column;
            justify-content : space-around;
            align-items     : center;
            border          : 0px solid red;
            background      : ${this.rgba.get(this.color,6,1)};;
            border-radius   : 16px;
    }`;
    let txt_lgToolbarCL = `#lgToolbarClose{
            position        : fixed;
            display         : none;
            right           : 36px;
            top             : 150px;
            /*background      : red;
            border          : red solid 3px;*/
    }`;
    let txt_lgToolbar   = `#lgToolbar{
            position        : fixed;
            right           : 10px;
            top             : 157px;
            width           : 0px;
            height          : 77.6%;
            padding         : 0px;  
            margin          : 0px;
            display         : flex;
            flex-direction  : column;
            justify-content : space-around;
            align-items     : center;
            border-radius   : 10px;
            border          : 0px solid red;
            background      : ${this.rgba.get(this.color,8,1)};
            transition      : width 0.3s ease;
            //z-index         : 9900;
            /*background      : red;
            border          : red solid 3px;*/
    }`;
    let txt_lgInput     = `#lgIpt{
            width           : 70%;
            font-size       : 4vmin;
            position        : relative;
            height          : 100%;
            vertical-align  ：text-top;
            word-wrap       : pre-line;
    }`;
    let txt_lgEnter     = `#lgbtnEnter{
            width           : 15%;
            font-size       : 4vmin;
            position        : relative;
            height          : 100%;
    }
    #lgbtnMline{
            width           : 15%;
            font-size       : 4vmin;
            position        : relative;
            height          : 100%;
    }`;
    
    let fg          = this.api.fg();
    let lg          = this.api.add.style('cssLg',       txt_lg);
    let lgIcon      = this.api.add.style('cssLgIcon',   txt_lgIcon);
  
    let lgWind      = this.api.add.style('cssLgWind',   txt_lgWind);
    let lgCaption   = this.api.add.style('cssLgCaption',txt_lgCaption);
    let lgTitle     = this.api.add.style('cssLgTitle',txt_lgTitle);
    let lgClose     = this.api.add.style('cssLgClose',txt_lgClose);
    let lgDisplay   = this.api.add.style('cssLgDisplay',txt_lgDisplay);
    let lgShowbox   = this.api.add.style('cssLgShowbox',txt_lgShowbox);
    let lgText      = this.api.add.style('cssLgText',   txt_lgText);
    let lgHtml      = this.api.add.style('cssLgHtml',   txt_lgHtml);
    let lgToolbox   = this.api.add.style('cssLgToolbox',txt_lgToolbox);
    let lgToolbar   = this.api.add.style('cssLgToolbar',txt_lgToolbar);
    let lgToolbarCL = this.api.add.style('cssLgToolbarCL',txt_lgToolbarCL);
    let lgCmd       = this.api.add.style('cssLgCmd',    txt_lgCmd);
    let lgInput     = this.api.add.style('cssLgInput',  txt_lgInput);
    let lgEnter     = this.api.add.style('cssLgEnter',  txt_lgEnter);
    let lgId        = this.api.add.style('cssLgId');
    let lgClass     = this.api.add.style('cssLgClass');
    let lgCol       = this.api.add.style('cssLgCol',    txt_lgCol);
    let lgRow       = this.api.add.style('cssLgRow',    txt_lgRow);
    let dspFlex     = this.api.add.style('cssDspFlex',  txt_dspFlex);
    let dspChild    = this.api.add.style('cssDspChild', txt_dspChild);
    let dspKeys     = this.api.add.style('cssDspKeys',  txt_dspKeys);
    let dspGson     = this.api.add.style('cssDspGson',  txt_dspGson);
    let lightblue   = this.api.add.style('cssLightblue',txt_lightblue);
    let lgToolbtns  = this.api.add.style('cssToolbtns', txt_lgToolbtns);
    let h50         = this.api.add.style('cssH50',      txt_h50);
    let blk         = this.api.add.style('cssBlk',      txt_blk);
    

    this.api.add.children(lgCaption,[lgTitle,lgClose]);
    this.api.add.children(lgShowbox,[lgText,lgHtml]);
    this.api.add.children(lgDisplay,[lgShowbox,lgToolbox,lgToolbar,lgToolbarCL]);
    this.api.add.children(lgCmd,[lgInput,lgEnter]);
    this.api.add.children(lgWind,[lgCaption,lgDisplay,lgCmd]);
    this.api.add.children(lgId,[lgIcon,lgWind]);
    this.api.add.children(lgClass,[lgCol,lgRow,dspFlex,dspChild,dspKeys,dspGson,lightblue,lgToolbtns,h50,blk]);
    this.api.add.children(lg,[lgId,lgClass]);
               fg.appendChild(lg);
    document.head.appendChild(fg);
    
    return this;
  }
  
  //#event
  event = {
    
    btns : {
      
      clear   : {
        click : ()=>{
          if(this.idsp == -1){
            let text = document.getElementById('lgText');
                text.innerText = '';
          }else{
            let html = document.getElementById('lgHtml');
                html.innerHTML = '';
          }
          
        },
      },
      
      docu   : {
        click : ()=>{
          
          this.event.btns.clear.click();
          
          this.cmd.input('docu');
          
        },
      },
      
      dsp   : {
        click : ()=>{
          let text   = document.getElementById('lgText');
          let html   = document.getElementById('lgHtml');
          let btnDsp = document.getElementById('lgToolBtnDsp');
              
          this.idsp *= -1;
        
          if(this.idsp == 1){
            html.style.visibility = 'visible';
            text.style.visibility = 'hidden';
            btnDsp.innerText  = 'htm';
          } else {
            text.style.visibility = 'visible';
            html.style.visibility = 'hidden';
            btnDsp.innerText  = 'txt';
          }
          
          this.lastClickId = 'lgToolBtnDsp';
          
          return this.event;
        },
      },
      
      topbar : {
          click : ()=>{
              let tb = this.api.gbid('lgTopbar');
              if(tb.style.visibility == 'hidden'){
                  if(this.lastClickId == 'lgToolBtnDsp')
                      this.topbar.add.searchBtn();
                      this.topbar.show();
              }else{
                  this.topbar.hide();
              }
              return this.event;
          }
      },
      
      char  : {
        click : ()=>{ 
          //$lg('6859::char::click::'+Log.now());
          let text   = document.getElementById('lgText');
          let html   = document.getElementById('lgHtml');
          let btnDsp = document.getElementById('lgToolBtnDsp');
          let btnChar = document.getElementById('lgToolBtnChar');
              
          this.idsp = 1;
          html.style.visibility = 'visible';
          text.style.visibility = 'hidden';
          btnDsp.innerText  = 'htm';
          
          this.progress.css.update(0.1).show();
          //return;
          let prepare = ()=>{
              return new Promise((res)=>{
          
                  let css = (()=>{
                      let content = `
                        .lgCharsetBox{
                            position        : relative;
                            display         : flex;
                            flex-direction  : column;
                            justify-content : flex-start;
                            align-items     : center;
                            padding         : 10px;
                            margin          : 6px;
                            width           : 96%;
                            height          : auto;
                            border-radius   : 10px;
                            background      : ${this.rgba.white(9,0.8)};
                        }
                        .lgCharsetName{
                            color           : ${this.rgba.white(1,0.8)};;
                            font-size       : 7vmin;
                        }
                        .lgCharsetSymBox{
                            position        : relative;
                            display         : flex;
                            flex-direction  : row;
                            flex-wrap       : wrap;
                            justify-content : flex-start;
                            align-items     : center;
                            padding         : 10px;
                            margin          : 6px;
                            width           : 96%;
                            height          : auto;
                            background      : ${this.rgba.white(6,0.8)};
                        }
                        .lgCharsetObj{
                            position        : relative;
                            display         : flex;
                            flex-direction  : column;
                            flex-wrap       : wrap;
                            justify-content : center;
                            align-items     : center;
                            padding         : 6px;
                            margin          : 6px;
                            width           : auto;
                            height          : auto;
                            border-radius   : 6px;
                            background      : ${this.rgba.white(3,0.8)};;
                           
                        }
                        .lgCharsetHex{
                            position        : relative;
                            display         : block;
                            padding         : 2px;
                            margin          : 3px;
                            background      : ${this.rgba.white(2,0.8)};
                            color           : black;
                            text-align      : center;
                            padding         : 3px;
                            border-radius   : 3px;
                            font-size       : 3vmin;
                        }
                        .lgCharsetSymb{
                            position        : relative;
                            display         : block;
                            padding         : 10px;
                            margin          : 6px;
                            background      : ${this.rgba.white(3,0.8)};;
                            color           : black;
                            text-align      : center;
                            padding-top     : 3px;
                            border-radius   : 6px;
                            font-size       : 7vmin;
                        }
                      `;
                  let sty   = this.api.add.style('cssLgCharsetList',content);
                  let cssLg = this.api.gbid('cssLg');
                      cssLg.appendChild(sty);
                  //$lg('css added');
                  })();
                  
                  let pack = (min,max,name)=>{
                      let callback = function(e){
                          //$lg('6910::span-hex:click');
                          //alert(e.target.innerText);
                          new Css().docu.exe.copy(e.target.innerText,true);
                      }
                      let eveArr = [{name:'onclick',callback:callback}];
                      let divBox = this.api.elm('div','','lgCharsetBox');
                      let spName = this.api.elm('span','','lgCharsetSymb lgCharsetName',name);
                      let br     = this.api.elm('br','','','');
                      let divSym = this.api.elm('div','','lgCharsetSymBox');
                      for(let hex = min; hex <= max; hex++){
                         let char = String.fromCharCode(hex);
                         let obj  = this.api.elm('div','','lgCharsetObj');
                         let spHex  = this.api.elm('span','','lgCharsetHex',`0x${hex.toString(16)}`,eveArr);
                         let symb = this.api.elm('span','','lgCharsetSymb',char);
                         obj.appendChild(spHex);
                         obj.appendChild(symb);
                         divSym.appendChild(obj);
                      }
                      divBox.appendChild(spName);
                      divBox.appendChild(divSym);
                      //divBox.appendChild(br);
                      return divBox;
                  }
                  
                  //show all the char
                  let fg = this.api.fg();
                  let char = new Char();
                 
                  let arr = Reflect.get(char,'utf8');
                  for(let a of arr){
                      //$lg(a[0],a[1],a[2]);
                      let min  = a[0];
                      let max  = a[1];
                      let name = a[2];
                      fg.appendChild(pack(min,max,name));
                  }
                  res(fg);
                  //$lg('6988::resolve',Log.now());
              })
          }
          
          prepare().then((fg)=>{
              html.innerHTML = '';
              html.appendChild(fg);
              //$lg('6996::lgHtml.appendChild done',Log.now());
              //let symbs = html.querySelectorAll('.lgCharsetSymb');
              //$lg('6998::all done',symbs.length,Log.now());
              
          })
          
          return this.event;
        },
      },
      
      icon  : {
        click : async ()=>{ 
          let text   = document.getElementById('lgText');
          let html   = document.getElementById('lgHtml');
          let btnDsp = document.getElementById('lgToolBtnDsp');
          let btnChar = document.getElementById('lgToolBtnChar');
              
          this.idsp = 1;
          html.style.zIndex = '9023';
          text.style.zIndex = '9020';
          btnDsp.innerText  = 'htm';
          
          let css = (()=>{
              let content = `
                .lgCharsetBox{
                    position        : relative;
                    display         : flex;
                    flex-direction  : column;
                    justify-content : flex-start;
                    align-items     : center;
                    padding         : 10px;
                    margin          : 6px;
                    width           : 96%;
                    height          : auto;
                    border-radius   : 10px;
                    background      : ${this.rgba.white(9,0.8)};
                }
                .lgCharsetName{
                    color           : ${this.rgba.white(1,0.8)};;
                    font-size       : 7vmin;
                }
                .lgCharsetSymBox{
                    position        : relative;
                    display         : flex;
                    flex-direction  : row;
                    flex-wrap       : wrap;
                    justify-content : flex-start;
                    align-items     : center;
                    padding         : 10px;
                    margin          : 6px;
                    width           : 96%;
                    height          : auto;
                    background      : ${this.rgba.white(6,0.8)};
                }
                .lgCharsetObj{
                    position        : relative;
                    display         : flex;
                    flex-direction  : column;
                    flex-wrap       : wrap;
                    justify-content : center;
                    align-items     : center;
                    padding         : 6px;
                    margin          : 6px;
                    width           : auto;
                    height          : auto;
                    border-radius   : 6px;
                    background      : ${this.rgba.white(3,0.8)};;
                   
                }
                .lgCharsetHex{
                    position        : relative;
                    display         : block;
                    padding         : 2px;
                    margin          : 3px;
                    background      : ${this.rgba.white(2,0.8)};
                    color           : black;
                    text-align      : center;
                    padding         : 3px;
                    border-radius   : 3px;
                    font-size       : 3vmin;
                }
                .lgCharsetSymb{
                    position        : relative;
                    display         : block;
                    padding         : 10px;
                    margin          : 6px;
                    background      : ${this.rgba.white(3,0.8)};;
                    color           : black;
                    text-align      : center;
                    padding-top     : 3px;
                    border-radius   : 6px;
                    font-size       : 7vmin;
                }
                .f-size{
                    font-size       : 2.5rem;   
                }
                .iframe-bsp-icon{
                    width           : 100%;
                    height          : 100%;
                    
                }
              `;
          let sty   = this.api.add.style('cssLgCharsetList',content);
          let cssLg = this.api.gbid('cssLg');
              cssLg.appendChild(sty);
          //$lg('css added');
          })();
          
          let t3d = new Load('../import/thirdpart/');
            await t3d.bspIcon.load();
          
          let listAll = (()=>{
                let str = "areaChart,barChart,book,book,book,bookmarkEmpty,bookmarkEmpty,camera,chain,chain,clock,commentEmpty,creditCard,crop,crop,display,document,eye,file,flag,flag,folder,forbidden,frown,frown,headphone,heart,heart,heart,home,home,home,imac,imacBold,image,infinity,infinity,iphone,iphoneBold,keyboard,macbook,macbookBold,mail,mail,market,market,meh,meh,microphone,microphone,mouse,mouse,nexus,paperClip,paperClip,paperClip,piano,pin,pin,power,rename,ruler,search,signIn,signIn,signOut,signOut,smile,smile,stroke,sync,tag,tag,terminal,trash,user,user,video,volumeHigh,volumeHigh,volumeLow,volumeMedium,youtube,youtube"
                let arr = str.split(',');
                let uri = 'http://127.0.0.1:8080/project/import/thirdpart/bootstrap-icons/v1.8.3/font/index.html';
                let h = new Html();
                    h.dom('#lgHtml')
                      .iframe('iframe-bsp-icon').src(uri)
                      .ok();
          })();
        
          return this.event;
        },
      },
      
      sql   : {
        click : ()=>{ 
          this.toolbar.show();
          return this.event;
        },
      },
      
      enter : {
          click : (e)=>{
            let str  = document.getElementById('lgIpt').value;
            //$lg('input:',str);
            this.cmd.input(str);
            
          }
      },
      
      mline : {
          click : (e)=>{
            let inp    = document.getElementById('lgIpt');
            let mline  = document.getElementById('lgbtnMline');
            
            if(inp.style.height == null || inp.style.height == '100%'){
                inp.style.height = '300px';
                inp.rows = '10';
                if(mline)
                    mline.innerText = String.fromCharCode(0x25bd);
            }else{
                inp.style.height = '100%';
                inp.rows = '1';
                if(mline)
                    mline.innerText = String.fromCharCode(0x25b2);
            }
            
          }
      },
      
      
      close : {
          click : ()=>{
              let wind = document.getElementById('lgWind');
              
              wind.style.visibility = 'hidden';
              wind.style.zIndex = '0';
             
              return this.event;
          },
      },
      
      toolbarCl : {
          click : ()=>{
              this.toolbar.hide();
              return this.event;
          },
      },
      
    },
    
    icon : {
        click : (e)=>{
          //alert('icon clicked');
          let wind = document.getElementById('lgWind');
          this.icc *= -1;
          
          if( wind.style.visibility == 'hidden') {
              wind.style.visibility = 'visible';
              wind.style.zIndex = '6700';
          }else {
              wind.style.visibility = 'hidden';
              wind.style.zIndex = '0';
              
          }
          return this.event;
        },
        touch : {
              x : 0,
              y : 0,
          start : (e)=>{
              e.stopPropagation();

            return this.event.icon.touch;
          },
          move : (e)=>{
            //
            e.stopPropagation();
            let x = e.touches[0].clientX;
            let y = e.touches[0].clientY;
            /*
            
            let xx = this.event.icon.touch.x - x;
            let yy = this.event.icon.touch.y - y;
            */
            //let icon = document.getElementById('lgIcon');
            let icon = e.target;
                icon.style.left = x+`px`;
                icon.style.top  = y+`px`;
            return this.event.icon.touch;
          },
          end : (e)=>{
              e.stopPropagation();
            //
            //let x = e.touches[0].clientX;
            //let y = e.touches[0].clientY;
            //
            return this.event.icon.touch;
          },
    },
        drag  : {
          x     : 0,
          y     : 0,
          start : (e)=>{
            e.preventDefault();
            
            
            return this.event.icon.drag;
          },
          move  : (e)=>{
            e.preventDefault();
            
            
            return this.event.icon.drag;
          },
          end   : (e)=>{
            e.preventDefault();
            
            return this.event.icon.drag;
          },
        },
    },
    
    setup : ()=>{
      let icon = document.getElementById('lgIcon');
          icon.addEventListener('click',this.event.icon.click,false);
          /*
          icon.setAttribute('draggable','true');
          icon.addEventListener('dragstart', this.event.icon.drag.start, false);
          icon.addEventListener('drag',  this.event.icon.drag.move,  false);
          icon.addEventListener('dragend', this.event.icon.drag.end,   false);
          */
          icon.addEventListener('touchstart', this.event.icon.touch.start, false);
          icon.addEventListener('touchmove',  this.event.icon.touch.move,  false);
          icon.addEventListener('touchend',   this.event.icon.touch.end,   false);
          
      let btnEnter = document.getElementById('lgbtnEnter');
          btnEnter.addEventListener('click',this.event.btns.enter.click,false);
         
      let btnMline = document.getElementById('lgbtnMline');
          btnMline.addEventListener('click',this.event.btns.mline.click,false);
         
      let btnClose = document.getElementById('lgClose');
          btnClose.addEventListener('click',this.event.btns.close.click,false);
      let btnTbCl = document.getElementById('lgToolbarClose');
          btnTbCl.addEventListener('click',this.event.btns.toolbarCl.click,false);
         
      let btnClear = document.getElementById('lgToolBtnClear');
          btnClear.addEventListener('click',this.event.btns.clear.click,false);
         
      let btnDsp = document.getElementById('lgToolBtnDsp');
          btnDsp.addEventListener('click',this.event.btns.dsp.click,false);
         
      let btnTopbar = document.getElementById('lgToolBtnTopbar');
          btnTopbar.addEventListener('click',this.event.btns.topbar.click,false);
         
      let btnChr = document.getElementById('lgToolBtnChar');
          btnChr.addEventListener('click',this.event.btns.char.click,false);
         
      let btnIcon = document.getElementById('lgToolBtnIcon');
          btnIcon.addEventListener('click',this.event.btns.icon.click,false);
         
      let btnSQL = document.getElementById('lgToolBtnSQL');
          btnSQL.addEventListener('click',this.event.btns.sql.click,false);
         
      let btnDocu = document.getElementById('lgToolBtnDocu');
          btnDocu.addEventListener('click',this.event.btns.docu.click,false);
         
      let toolbox = document.getElementById('lgToolbox');
          toolbox.addEventListener('click',function(e){
              if(e.target && e.target.nodeName == 'DIV'){
                  
              }
          },false);
         
          
      return this;
    },
    
    
    
  }
  
  //#toolbar
  toolbar = {
    
      lastClick : '',
      show  : ()=>{
          let toolbar   = document.getElementById('lgToolbar');
          let toolbarCl = document.getElementById('lgToolbarClose');
          toolbar.style.width = '160px';
          toolbarCl.style.display = 'block';
          return this;
      },
      hide  : ()=>{
          let toolbar = document.getElementById('lgToolbar');
          let toolbarCl = document.getElementById('lgToolbarClose');
              toolbar.style.width = '0px';
              toolbarCl.style.display = 'none';
          return this;
      },
      
  }
  
  topbar = {
    
      init  : ()=>{
          return this.topbar.css().html().hide();
      },
    
      html : ()=>{
          if(this.api.gbid('lgTopbar'))return this.topbar;
          let topbar = this.api.elm('div','lgTopbar');
              this.api.gbid('lgTitle').appendChild(topbar);
          return this.topbar;
      },
      
      css  : ()=>{
          if(this.api.gbid('cssLgTopbar'))return this.topbar;
         
          let cssText   = `
              #lgTopbar{
                  position        : relative;
                  display         : flex;
                  visibility      : hidden;
                  flex-direction  : row;
                  justify-content : center;
                  align-items     : center;
                  width           : 60%;
                  height          : 96%;
                  left            : 0px;
                  top             : 0px;
                  margin          : 6px;
                  padding         : 6px;
                  border          : 0px solid green;
                  border-radius   : 10px;
                  background      : ${this.rgba.get(this.color,9,1)};
                  color           : ${this.rgba.get(this.color,3,1)};
              }
              #lgTopbarInp{
                  position        : relative;
                  display         : block;
                  width           : 83%;
                  height          : 80%;
                  //left            : 0px;
                  //top             : 0px;
                  margin          : 6px;
                  font-size       : 4vmin;
                  padding         : 10px;
                  border-radius   : 10px;
                  border          : 0px solid red;
                  background      : ${this.rgba.get(this.color,6,1)};
                  color           : ${this.rgba.get(this.color,12,1)};
              }
              .log-hidden{
                  visibility      : hidden;
              }
          `;
          let cssTopbar = this.api.add.style('cssLgTopbar',cssText);
          this.api.gbid('cssLgCaption').appendChild(cssTopbar);
          return this.topbar;
      },
      
      add  : {
          
          searchBtn  : ()=>{
              let btn1  = this.api.elm('button','lgTopbarBtnSearch','lgToolbtns','search');
                  btn1.onclick = this.topbar.event.btns.search.click;
              let input = this.api.elm('input','lgTopbarInp');
  
              let topbar = this.api.gbid('lgTopbar');
                  topbar.innerHTML = '';
                  
                  topbar.appendChild(input);
                  topbar.appendChild(btn1);
              return this.topbar;
          },
          
      },
      
      event : {
          btns : {
              search : {
                  click : (e)=>{
                      let txt = this.api.gbid('lgTopbarInp').value;
                      
                      let num = txt.match(/^\d+$/i);
                      if(num){
                          let spans = this.api.gbid('lgHtml').querySelectorAll(`span[data-num]`);
                          //$lg('5739::spans.length',spans.length);
                          for(let span of spans){
                              let dnum = span.getAttribute('data-num');
                              if(dnum != num){
                                  //span.parentElement.style.visibility = 'hidden';
                                  span.classList.add('log-hidden');
                              }
                          }
                      }
                      if(txt == ''){
                          this.topbar.showAll();
                      }
                  },
              },
          },
      },
      
      show : ()=>{
          let titText = this.api.gbid('lgTitleText')
              titText.innerText = '';
          let topbar = this.api.gbid('lgTopbar')
              topbar.style.visibility = 'visible';
          return this.topbar;
      },
      
      hide : ()=>{
          let titText = this.api.gbid('lgTitleText')
              titText.innerText = 'Log';
          let topbar = this.api.gbid('lgTopbar')
              topbar.style.visibility = 'hidden';
          return this.topbar;
      },
      
      reset  : (txt = 'Log')=>{
          let titBar = this.api.gbid('lgTitle')
              titBar.innerHTML = txt;
          return this.topbar;
      },
    
      showAll : ()=>{
          let objs = this.api.gbid('lgHtml').querySelectorAll(`.log-hidden`);
          for(let obj of objs){
              obj.classList.remove('log-hidden');
          }
      },
    
  }
  
  
  //#pgs
  //#progress
  progress = {
    into   :   (anyStr,second)=>{
        let target = this.api.query(anyStr);
        if(target){
          this.progress.html(anyStr)
                       .css.add(second)
                       .event.setup();
          //$lg('7299::progress::done;',Log.now());
        }
        return this.progress;
    },
    show   :   ()=>{
        let pgbox = this.api.query('#lgProgressBox');
        if(pgbox){
          pgbox.style.display = 'flex';
          //
        }
        return this.progress;
    },
    hide   :   ()=>{
        let pgbox = this.api.query('#lgProgressBox');
        if(pgbox){
          pgbox.style.display = 'none';
          //
        }
        return this.progress;
    },
    html   :   (anyStr)=>{
        //
        let fgm    = this.api.fg();
        let pgs    = this.api.elm('div','','lgProgress');
        let pgsbox = this.api.elm('div','lgProgressBox');
            pgsbox.appendChild(pgs);
               fgm.appendChild(pgsbox);
        let elmObj = this.api.query(anyStr);
            elmObj.appendChild(fgm);
        return this.progress;
    },
    css    :   {
      add     :   (second='10',color=this.color)=>{
        let code = `
            #lgProgressBox{
                
                position        : fixed;
                display         : none;
                flex-direction  : row;
                justify-content : flex-start;
                align-items     : center;
                top             : 200px;
                left            : 100px;
                width           : 60%;
                height          : 60px;
                margin          : 0px;
                border-radius   : 10px;
                padding         : 6px;
                border          : 0px solid red;
                background      : ${this.rgba.get(this.color,10,1)};
                //z-index         : 9030;
            }
            .lgProgress{
                display         : block;
                width           : 50%;
                height          : 99%;
                border-radius   : 6px;
                text-align      : center;
                border          : 0px solid green;
                background      : ${this.rgba.get(color,2,1)};
                animation       : lgAniLoading ${second}s;
            }
            /*
            .lgProgress::after{
                content         : "50%";
                color           : black;
                font-size       : 5vmin;
            }*/
            @keyframes lgAniLoading{`;
        let j = 0;
        for(let i=0 ; i<=100; i+=10){
              j = i.toString().padStart(3,' ');
              code += `
                ${j}%{ width           : ${j}%;  
                       color           : black; 
                       font-size       : 5vmin;
                       ::after:content : "${j}%";
                   }\n`;
        }
        code += ' '.repeat(12) + `}`;
        let style = this.api.add.style('cssProgress',code);
        let find = this.api.query('cssProgress');
        if(find){
          document.head.removeChild(find);
        }
        this.api.query('#cssLg').appendChild(style);
        //
        return this.progress;
      },
      update  :   (second)=>{
          let pgs = this.api.query('.lgProgress');
              if(pgs == null) return this.progress;
              pgs.style.animation = `lgAniLoading ${second}s ease`;
          /*
          let code = style.innerHTML;
          let patt = new RegExp(/(lgAniLoading\s)\d+([\w\s]+)/);
              code.replace(patt,`$1${second}$2`);
          */
          return this.progress;
      },
    },
    remove :   ()=>{
        let pbox = this.api.query('#lgProgressBox');
        let sbox = this.api.query('#lgShowbox');
        if(pbox){
          sbox.removeChild(pbox);
        }
        return this.progress;
    },
    event : {
        setup : ()=>{
            let pgs = this.api.query('.lgProgress');
            pgs.addEventListener('animationend',(e)=>{
                this.progress.hide();
                $lg('7424::animationend',Log.now());
            });
            return this.progress;
        }
    }
  }
  
  
  //#now
  static now  = ()=>{
    let  d = new Date();
    let hh = d.getHours();
    let mm = d.getMinutes();
    let ss = d.getSeconds();
    let ms = d.getMilliseconds();
    return `${hh}:${mm}:${ss}:${ms.toString().padStart(4,'0')}`;
  }
  

  
  //#strify
  strify = {
    html : {
      frag :  (docFragObj)=>{
                
                let str = '';
                let hasChild  = docFragObj.hasChildNodes();
                if(hasChild){
                  let arr = docFragObj.childNodes;
                  for(let obj of arr){
                    str += this.strify.html.tree(obj);
                  }
                }
                //
                return str;
              },
      one  :  (htmlElementObject,space=4)=>{
                let object    = htmlElementObject;
                //
                let attrs     = object.attributes;
                let text      = object.innerText;
                //let type = object.nodeType;
                let tag       = object.tagName.toLowerCase();
                
                let str       = ' '.repeat(space) + '<'+tag;
                for(let key of Reflect.ownKeys(attrs)){
                  
                  if(parseInt(key)||parseInt(key)===0){
                    continue;
                  }
                  
                  let val = object.attributes.getNamedItem(key).value;
                  
                  str += ` ${key}='${val}'`;
                  
                }
                str += '>'+ text + '</'+tag+'>\n';
                return str;
              },
      tree :  (object,space=4)=>{
                //let object    = htmlElementObject;
                
                let type      = object.nodeType;
                let tag       = object.nodeName.toLowerCase();
                let hasChild  = object.hasChildNodes();
                let str       = this.strify.html.one(object,space);

                if(hasChild){
                  let children  = object.children;
                  for(let child of children){
                  //let nn = child.nodeName;
                  //let nt = child.nodeType;
                  //str += this.strify.html.one(child,space);
                  
                    str += this.strify.html.tree(child,space+4);
                  }
                }
                //str += ' '.repeat(space) + '</'+tag+'>\n';
                return str;
              },
    },
    object  : (obj,space=2)=>{
                return this.listKeys(obj,space);
              },
  }
 
  
  //#tree
  tree(htmlobj){
    let str = this.strify.html.tree(htmlobj,4);
    this.lgg(str);
    return str;
  }
  
  //#fgm
  fgm(fg){
    //let fg = Test.frag();
    let str = this.strify.html.frag(fg);
    this.lgg(str);
  }
  
  //#fgs
  fgs = (frags)=>{
    //
    let str = '';
    for(let f of frags){
      let top = f.top;
      //
      let frg = f.frag;
      
      str += '\n' + this.strify.html.frag(frg);
    }
    return str;
  }
  
  //#html
  html = {
    wrapArray : (obj)=>{
      
      let i = 0;
      let h = document.body.querySelector('#lgHtml');
      
      let fg = document.createDocumentFragment();
      let top = undefined;
      let idx = obj.idx * 10000;
      let id  = idx;
      
      let topClick = (e)=>{
          e.preventDefault();
          e.stopPropagation();
          this.itop *= -1;
          let id   = e.target.id;
          let slt = `#${id} .dspChild`;
          //
          let children = document.querySelectorAll(slt);
          //
          if(this.itop == -1){
              for(let c of children){
                  c.style.display = 'none';
              }
          }else{
              for(let c of children){
                  c.style.display = 'flex';
              }
          }
      }
      let clk = (e)=>{
          e.preventDefault();
          e.stopPropagation();
          let span = e.target;
          let id   = span.id;
          let text = span.innerText;
          //let p = document.getElementById(id);
          let gp = span.parentNode.parentNode;
          
          
          let cmd  = gp.getAttribute('data-cmd');
              cmd  = `${cmd}.${text}`;
              
          let arr = eval(`this.listKeys(${cmd},'arr')`);
          let fg2 = document.createDocumentFragment();
          let p2 = span.parentNode;
          if(this.lastClickId !== '' && p2.id !== this.lastClickId)
          {
            this.api.style(this.lastClickId,'height','60px');
          }   
          p2.style.height = 'auto';
          this.lastClickId = p2.id;
          let pid = p2.id.replace('dspChild_','');
          let gid = 0;
          this.api.hide('.dspGson');
          
          for(let a of arr){
              gid++;
              let div = this.api.elm('div','dspChild_'+pid+'_'+gid,'dspChild dspGson dspFlex');
              let span = this.api.elm('span','dspKey_'+pid+'_'+gid,'dspKeys lightblue');
                  span.onclick = clk;
                  span.innerText = a.replace(/\"/g,'');
              div.appendChild(span);
              fg2.appendChild(div);
          }
          
          p2.appendChild(fg2);
          
          
          
          
          
          this.log(id,cmd);
      }

      for(let a of obj.child){
          if(i == 0){
              top = this.api.elm('div','dspTop_'+idx,'dspTop');
              top.innerText = obj.top;
              top.onclick = topClick;
              top.setAttribute('data-cmd',obj.top);
              top.setAttribute('data-idx',obj.idx);
              fg.appendChild(top);
          }else{
              id++;
              //let div = this.api.elm('div','dspChild_'+id,'dspChild');
              let span = this.api.elm('div','dspKey_'+id,'dspChild');
                  span.onclick = clk;
                  span.innerText = a.replace(/\"/g,'');
              //div.appendChild(span);
              //top.appendChild(div);
              fg.appendChild(span);
          }
          i++;
      }
      
      //fg.appendChild(top);
      h.appendChild(fg);
      
    },
  }
  
  //#listKeys
  listKeys = (obj,format='str',space=2)=>{

    let isCapital = (str)=>{
         if( str.match(/^[A-Z]/g )) return true;
         return false;
    }
    
    
    let out = format =='str' ? '' : [];
    
    
    for(let key of Reflect.ownKeys(obj)){
      
      
      
      //let desc = Reflect.getOwnPropertyDescriptor(obj,key);
      
      
      
      let blackList = ['Function','undefined'];
      if( blackList.includes(key)){
        //$lg('blackList key:' + key);
        continue;
      }
      if(isCapital(key)==false){
        //continue;   
      }
      
      if(format == 'str'){
        out += ' '.repeat(space) + key + '\n'
      }else if(format == 'arr'){
        out.push(key);
      }
      
      
      
    };
    
    
    return out;
  }
  
  //#cmd
  cmd = {
      input : (str)=>{
                  let p = /^\s*(\w+)\(*([a-zA-Z\.\d\$]*)\)*/i;
                  let rst = str.match(p);
                  if(rst != null)
                    this.cmd.exec(rst);
              },
      exec  : (arr)=>{
                  if(arr == null) alert('unknow command');
                  this.execTimes++;
                  let text = document.getElementById('lgText');
                  let c = arr[1];
                  if( c == 'clr' ){
                    
                    this.event.btns.clr.click();
                  }else if( c == 'docu' ){
                      //text.innerText = document.documentElement.innerHTML;
                      //let str = this.strify.html.tree(document.documentElement);
                      //this.lgg(str);
                      text.innerText = '';
                      text.style.whiteSpace = 'pre';
                      //let str = document.documentElement.innerHTML;
                      //str = str.replace(/(\<[.\w\s\.]+\>[.\w\.\s]*\<\/[\w]*\>)/ig,'$1\n');
                      //str = str.replace(/\>/ig,'>\n');
                      let obj = document.documentElement;
                      let str = this.strify.html.tree(document.body);
                          
                      this.lgg(str);
                      
                  }else if( c == 'f' ){
                    
                  }else if( c == 'now' ){
                    $lg(Log.now());
                    
                  }else if( c == 'keys' ){
                    text.innerHTML = '';
                    try{
                      let cmd = `this.listKeys(${arr[2]})`;
                      let str = eval(cmd);
                      this.lgg(str);
                    }catch(err){
                      alert(err.message);
                    }
                    
                  }else if( c == 't' ){
                    let str = this.strify.html.tree(document.body);
                    this.lgg(str);
        
                  }else if( c == 'tw' ){
                    //eval("this.cmd(['fgm'])");
                    
                    let str = this.strify.object(self);
                    this.lgg(str);
                    
                  }else if( c == 'lg' ){
                      //alert(arr[0]);
                      try{
                        let cmd = `$${arr[0]}`;
                        eval(cmd);
                      }catch(err){
                        alert('Log::exec:3824:\n'+err.message+'\n'+'your input:\n'+arr[0]);
                      }
                  }else if( c == 'ta' ){
                    //eval("this.cmd(['fgm'])");
                    let arr = Test.arr();
                    //$lg(arr);
                  }else{
                    
                    let ___ = `${'-'.repeat(40)}\n`;
                    text.innerHTML = '';
                    let out = undefined;
                    let cmd = undefined;
                    
                    if(this.idsp == -1){
                      try{
                        cmd = `this.listKeys(${arr[0]})`;
                        out = '';
                        out = eval(cmd);
                        out = ___ + arr[0] + ':\n' + ___ + out;
                        this.lgg(out);
                      }catch(err){
                        alert(err.message);
                      }
                    }else{
                      try{
                        cmd = `this.listKeys(${arr[0]},'arr')`;
                        out = [];
                        out = eval(cmd);
                        let obj = {
                          idx : this.execTimes,
                          top : arr[0],
                          child : out,
                        }
                        this.html.wrapArray(obj);
                      }catch(err){
                        alert(err.message);
                      }
                    }
                  }
                  return this;
              },
  }
  
  //#objType
  objType(obj){
      let rst = [];
      try{
          let typeList = this.listKeys(self,'arr');
          //
          if(typeList == null)alert('Log::objType>error');
          
          for(let t of typeList){
              if(t == null)continue;
              //
              let pt = undefined;
                  //pt = Reflect.getPrototypeOf(`self.${t}`);
                  pt = Reflect.get(self,t);
              let desc = Reflect.getOwnPropertyDescriptor(self,t);
              //
              if(typeof(pt) !== 'object')continue;
              //if( eval(`obj instanceof ${t}`) ){
              if( obj instanceof pt ){
                  //return `${t}`;
                  //
                  //
                  
                  rst.push(t);
              }
          }
          return rst;
      }catch(err){
          alert(`Log::objType>err:\n${err.message}`);
      }
      return rst;
  }
   
  //#type
  type(obj){
      const arr = ['undefined','function','symbol','NaN','boolean','object','array','number','string','null'];
      let rst = undefined;
      let item = arr.pop();
      const ask = () =>{
          item = arr.pop();
          
          rst = typeof(obj) == item ? item : 
                    item == undefined ? undefined : ask(); 
          return rst;
      }
      try{
          rst = Array.isArray(obj) ? 'array' : 
                    typeof(obj) == item ? item : 
                        ask() ;
          return rst;
      }catch(err){
          alert('7856::Log::type>error:\n'+err.message);
          return 'error';
      }
  }
  
  
  copyArrayNoSymbol(input){
    let hadSymbol = 0;
    let arr = [];
    for(let a of input){
        if(typeof(a) === 'symbol'){
            hadSymbol = 1;
            arr.push('symbolValue');
        }else if(Array.isArray(a)){
            arr.push(this.copyArrayNoSymbol(a));
        
        }else{
          arr.push(a);
        }
    }
    return arr;
  }
  
  
  //#isHtmlObj
  isHtmlObj(obj){
      let str = `${obj}`;
      let a = str.includes('HTML');
      let b = str.includes('Document');
      let c = str.includes('Element');
      return ( a || b || c );
  }
  
  //#open
  open = {
      array : (arr,space=0)=>{
          
          return `${JSON.stringify(arr)}\n`;
          
      },
      object : (obj,space=0)=>{
          
          
          return `${obj}\n`;
      },
      string : (str,space=0)=>{
          return `'${str}'\n`;
              
      },
      number : (num,space=0)=>{
          return `${num}\n`;
              
      },
      boolean : (obj,space=0)=>{
          return `${JSON.stringify(obj)}\n`;
              
      },
      'function' : (obj,space=0)=>{
          return `${JSON.stringify(obj)}\n`;
              
      },
      'undefined' : (obj,space=0)=>{
          return `${JSON.stringify(obj)}\n`;
              
      },
      'null' : (obj,space=0)=>{
          return `${JSON.stringify(obj)}\n`;
              
      },
      symbol : (obj,space=0)=>{
          return `${JSON.stringify(obj)}\n`;
              
      },
      error : (obj,space=0)=>{
          return `${JSON.stringify(obj)}\n`;
              
      },
  }
  
  hack = (lineNum,obj)=>{
    
        let ts = ['function','object'];
        let name = '';
        //$lg('130::Ajs.type(obj)',Ajs.type(obj));
        if(typeof obj === 'string'){
            name = obj;
            obj  = Reflect.get(self,obj);
        }else if( ts.includes(Ajs.type(obj)) ){
            name = Reflect.get(obj,'name');
            //$lg('137::name',name);
        }
        if(obj == 'undefined') return;
        
        let arr = Reflect.ownKeys(obj);
        
        let keys = [];
        for(let a of arr){
          if(typeof a === 'symbol')continue;
          keys.push(a);
        }
        $lg('::bug',name,`${lineNum}::${name}.keys`,...keys);
  }
  
  //#lgg
  lgg(...args){
    let text = document.getElementById('lgText');
    let txt = '';
    for(let a of args){
      txt += a + `\n`;
    }
    text.innerHTML += txt;
    return this;
  }
  
  //#log
  log = (...args)=>{
    //try{
      if(this.debugMode == 0)return this;
      let last = args[args.length-1];
      let t = typeof(last);
      if( t == 'string' && last == '::lgg'){
          args.pop();
          return this.lgg(...args);
      }
      if( t == 'string' && last == '::htm'){
          this.mode = 'htm';
      }
      if(this.mode == 'htm'){
          return this.lgh.log(...args);
      }
      
      let text = document.getElementById('lgText');
      let txt = '';
      let i = 0;
      let tips = (i,type,input)=>{
          
          if(this.type(input) === "symbol"){
              type = type.padEnd(8," ");
              return `[${i}]:${type}=>can't not show symbol\n`;
          
          }else if(type === 'array'){
              //array contain symbol
              let hadSymbol = 0;
              let arr = [];
              for(let a of input){
                  if(this.type(a) === 'symbol'){
                      hadSymbol = 1;
                      arr.push('symbolValue');
                  }else{
                    arr.push(a);
                  }
              }
           
              if(hadSymbol) return `[${i}]:${type}=>${arr}\n`;
              else return `[${i}]:${type}=>${input}\n`;
          }else{
              type = type.padEnd(8," ");
              input = this.type(input)=='symbol' ? 'symbolValue' : input;
              return `[${i}]:${type}=>${input}\n`;
          }
      }
      for(let a of args){
          
          let type = this.type(a);
          $lg('8238::type::bgb',type);
          //let rst = (Reflect.get(this.open,type))(type);
          txt += tips(i,type,a);
          
          i++;
      }
      txt += `${'-'.repeat(40)}\n`;
      text.innerHTML += txt ;
    //}catch(err){
      //$lg('8248::bgo',err.message);
      //return this;
    //}
  }
  
  
    
  
  lgh = {
      
      debug_click : (e)=>{
          let obj = e.target;
          let name = obj.getAttribute('data-ajs-name');
          if(name)$lg(name);
      },
      ul : (arr, clArr = null)=>{
          let ule = this.api.elm('ul');
          for(let a of arr){
              let cl = clArr == null ? '' : clArr.join(' ');
              let e = this.api.elm('li','', cl ,a);
              ule.appendChild(e);
          }
          return ule;
      },
      colorize : (a)=>{
          let [c,bg] = ['',''];
          let list = {
              b   : 'blue',
              g   : 'green',
              r   : 'red',
              o   : 'orange',
              y   : 'yellow',
              bgb : 'blue',
              bgg : 'green',
              bgo : 'orange',
              bgy : 'yellow',
          }
          let change = (mark,where='')=>{
              let name = Reflect.get(list,mark);
              return `log-htm${where}-${name}`;
          }
          if(a != null){
              let keys = Reflect.ownKeys(list);
              for(let key of keys){
                  //if(a.toString().endsWith(`::${key}`))c = 'log-htm-red';
                  if(a.toString().endsWith(`::${key}`)){
                      if(key.length == 3 ) bg = change(key,'-bg');
                      if(key.length == 1 ) c  = change(key);
                      a = a.toString().replace(/\:{2}bg[a-z]\b/ig,'');  
                      a = a.replace(/\:{2}[a-z]\b/ig,''); 
                      break;
                  }
              }
          }
          return {a,c,bg};
      },
      item  : (...args)=>{
          let i = -1;
          let debug = 0;
          let fg  = this.api.fg();
          let color = '';
          let last = args[args.length-1];
          let f1 = args[0];
          let f2 = args[1];
          if( f1 == '::red') color = 'log-htm-red';
          if( f1 == '::bug') debug = 1;
          
          let div  = this.api.elm('ul','',`log-htm-item ${color}`,'');
              if(debug){ 
                  div.onclick = this.lgh.debug_click;
                  div.setAttribute('data-ajs-name',f2);
              }
          let args2 = this.copyArrayNoSymbol(args);
          for(let a of args2){
              i++;
              if(debug && i < 2 ) continue;
              if(typeof(a)=='symbol')continue;
              if(a == '::red' || a == undefined)continue;
              let [c,bg] = ['',''];
              if(a != null){
                  c  = this.lgh.colorize(a).c;
                  bg = this.lgh.colorize(a).bg;
                  a  = this.lgh.colorize(a).a;
              }
              let num = a.toString().match(/^\d{1,5}/i);
              let span = this.api.elm('li','',`log-htm-txt ${c} ${color} ${bg}`,a);
              if(num) span.setAttribute('data-num',num);
              if(debug){ 
                  span.onclick = this.lgh.debug_click;
                  span.setAttribute('data-ajs-name',f2+'.'+a);
              }
              div.appendChild(span);
          }
          fg.appendChild(div);
          //let s = this.strify.html.frag(fg);
          //this.lgg(s);
          return fg;
      },
      log   : (...args)=>{
          let lgHtml = document.getElementById('lgHtml');
          //for(let a of args){
              lgHtml.appendChild(this.lgh.item(...args));
          //}
      },
  
  }

  
}


//@recd
class Rec{

  constructor(){
    this.gumStream = undefined; //stream from getUserMedia()
    this.recorder  = undefined; //MediaRecorder object
    this.chunks    = []; //Array of chunks of audio data from the browser
    this.extension = 'ogg';
    if(self.$lg == undefined){
        new Log();
    }
  }

  stop() {
    console.log("stop");
    
    this.recorder.stop();

    //stop microphone access
    this.gumStream.getAudioTracks()[0].stop();

    const blob = new Blob(this.chunks, { t: 'audio/'+this.extension, bitsPerSecond:128000});
    this.showUrl(blob);

  }

  callback = (stream)=>{
    
      console.log("getUserMedia() success, stream created, initializing MediaRecorder");

      /*  assign to gumStream for later use  */
      this.gumStream = stream;

      if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          this.extension = "webm";
      } else {
          this.extension = "ogg"
      }

      //extension="ogg";


      let options = {
          audioBitsPerSecond: 128000,
          videoBitsPerSecond: 128000,

          mimeType: 'audio/' + this.extension + ';codecs=opus'
      }

      //bitsPerSecond:        128000,
      //update the format
      //document.getElementById("formats").innerHTML='Sample rate: 48kHz, MIME: audio/'+extension+';codecs=opus';

      /*
          Create the MediaRecorder object
      */
      this.recorder = new MediaRecorder(stream, options);

      //when data becomes available add it to our attay of audio data
      this.recorder.ondataavailable = (e)=>{
          console.log("recorder.ondataavailable:" + e.data);

          console.log("recorder.audioBitsPerSecond:" + this.recorder.audioBitsPerSecond);
          console.log("recorder.videoBitsPerSecond:" + this.recorder.videoBitsPerSecond);
          //console.log ("recorder.bitsPerSecond:"+recorder.bitsPerSecond);
          // add stream data to chunks
          this.chunks.push(e.data);
          // if recorder is 'inactive' then recording has finished
          if (this.recorder.state === 'inactive') {
              // convert stream data chunks to a 'webm' audio format as a blob
              const blob = new Blob(this.chunks, { t: 'audio/' + this.extension, bitsPerSecond: 128000 });
              this.showUrl(blob);
          }
      };

      this.recorder.onerror = (e)=>{
          console.log(e.error);
          //add_div_pop(e.error);
      };

      //start recording using 1 second chunks
      //Chrome and Firefox will record one long chunk if you do not specify the chunck length
      this.recorder.start(1000);

                  //recorder.start();
  }

  start = ()=>{
    console.log("start");


    //add_div_pop(extension);

    /*
        Simple constraints object, for more advanced audio features see
        https://addpipe.com/blog/audio-constraints-getusermedia/
    */

    //let constraints = { audio: true }

    /*
       Disable the record button until we get a success or fail from getUserMedia()
   */

    /*
        We're using the standard promise based getUserMedia()
        https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
    */

    navigator .mediaDevices
              .getUserMedia({ audio: true })
              .then(this.callback)
              .catch((err)=>{
              });
  }           

  showUrl = (blob)=>{

    var url = URL.createObjectURL(blob);
    var aud = document.createElement('audio');
    var li  = document.createElement('li');
    var link = document.createElement('a');

    //add controls to the <audio> element
    aud.controls = true;
    aud.src = url;

    //link the a element to the blob
    link.href = url;
    link.filename = new Date().toISOString() + '.' + this.extension;
    link.innerHTML = link.filename;

    //add the new audio and a elements to the li element
    li.appendChild(aud);
    li.appendChild(link);

    //add the li element to the ordered list
    //recordingsList.appendChild(li);

    document.body.append(li);

  }

}

//@char
class Char{
    
    utf8 = [
        [0x25A0,0x25FF,'Geometric Shapes'],
        [0x2600,0x26FF,'Miscellaneous Symbols'],
        [0x2700,0x27BF,'Dingbats'],
        [0x2000,0x206F,'General Punctuation'],
        [0x20A0,0x20CF,'Currency Symbols'],
        [0x2100,0x214F,'Letterlike Symbols'],
        [0x2200,0x22FF,'Math Symbols'],
        [0x2500,0x257F,'Box Drawings'],
        [0x2580,0x259F,'Block Elements'],
        [0x2190,0x21ff,'Arrows'],
        [0x0370,0x03ff,'Greek and Coptic'],
        [0x0080,0x00FF,'C1 Controls'],
        
    ]
    
    icon = {
        copy        : 0x2750,
        cut         : 0x2702,
        close       : 0x2716,
        music       : 0x266c,
        loop1       : 0x2673,
        play1       : 0x2023,
        rec         : 0x2588,
        'alert'     : 0x26a0,
        conf1       : 0x2699,
        conf2       : 0x2638,
        squ_empty   : 0x2610,
        squ_right   : 0x2611,
        squ_wrong   : 0x2612,
        menu1       : 0x2630,
        menu2       : 0x2263,
        star5       : 0x26e4,
        star_empty  : 0x2606,
        star_solid  : 0x2605,
        squ_empty   : 0x25fb,
        squ_solid   : 0x25fc,
    }
    
}

//webman
//#webworker
/*
  need Webman.php
  
  usage:
  let cont = `
      //this is a js file content;
      function helloWorld(){
          postmessage('hello-world');
          return;
      }
  `;
  let callbackErr = ()=>{
      ...
  }
  let callbackMsg = ()=>{
    
  }
  let man = new Webman();
      man.conf.file('handler.js')
              .text(cont)
              .addr('../php/webman.php');
      man.handle.msg(callbackMsg)
                .err(callbackErr);
      man.start();
  
*/
class Webman{
  
    constructor(){
        this.man         = undefined;
        this.addr        = undefined;
        this.output      = undefined;
        this.useJsFile   = undefined;
        this.input       = undefined;
        this.msgCallback = undefined;
        this.errCallback = undefined;
        this.rdyCallback = undefined;
        
    }
    
    conf = {
        php : {
            in  : (filename)=>{
                this.input = filename;
                return this.conf.php;
            },
            out : (filename)=>{
                this.output = filename;
                return this.conf;
            },
            cf     : ()=>{ return this.conf; },
        },
        use : (str)=>{
            this.useJsFile = str;
            return this.conf;
        },
        addr : (str)=>{
            this.addr = str;
            return this.conf;
        },
        ds : ()=>{  return this;  }
    }
    
    handle = {
      msg : (callback)=>{
          this.msgCallback = callback;
          return this.handle;
      },
    
      err : (callback)=>{
          this.errCallback = callback;
          return this.handle;
      },
      
      rdy : (callback)=>{
          this.rdyCallback = callback;
          return this.handle;
      },
      
      ds : ()=>{  return this;  }
      
    }
    
    post(dat){
        if(typeof(this.man) !== "undefined") 
            this.man.postMessage(dat);
        return this;
    }
    
    
    async start(){
        //$lg('8832::start');
        if(typeof(Worker) === "undefined") {
            alert('not supported WebWorker');
            return;
        }
        
        if(this.msgCallback === undefined) {
            alert('run "handle" first');
            return;
        }
        if(this.errCallback === undefined) {
            alert('run "handle" first');
            return;
        }
        
        await this.jsFromText().then((rst)=>{
          //$lg(`8848::file:'${this.useJsFile}' is ready::bgg`);
        },(err)=>{
          $lg('8850::err::bgo',err);
          return;
        });
        
        if( this.man === undefined) {
            this.man = new Worker(this.useJsFile);
            //$lg('8275::this.useJsFile',this.useJsFile);
        }
        
        this.man.onmessage = this.msgCallback;
        this.man.onerror   = this.errCallback;
        
        if(this.rdyCallback){
            this.rdyCallback();
        }
        //$lg('8865::webman::start::all done',Log.now());
        return this;
        
    }
    
    stop(){
        this.man.terminate();
        this.man = undefined;
    }
    
    reset(){
        this.man         = undefined;
        this.useJsFile   = undefined;
        this.input       = undefined;
        this.output      = undefined;
        this.addr        = undefined;
        this.msgCallback = undefined;
        this.errCallback = undefined;
        return this;
    }
    
    jsFromText(){
        //$lg('8887::jsFromText');
        return new Promise((res,rej)=>{
            if(this.output=== undefined) {
                alert('run "conf" first');
                rej();
                return;
            }
            
            if(this.input === undefined) {
                alert('run "conf" first');
               rej();
               return;
            }
            this.fileIsExists(this.output).then((rst)=>{
              //$lg('8901::rst',rst);
              if(rst == true){
                res();
              }else{
                let dat = {
                    file  : this.output,
                    cont  : this.input,
                }
    
                let xhr = new Xhr(this.addr);
                    xhr.ask('Webman__make_js_file',dat);
                    xhr.rsp((data)=>{
                        //
                        //$lg('8914',data);
                        let obj = JSON.parse(data);
                        //
                        if(obj.da.rst == 1) {
                          //
                            res();
                        }else{
                            rej();
                        }
                    },(err)=>{
                        $lg('8340::err',err.message);
                        rej();
                    })
              }
              
            })
             
        })
    }
    
    fileIsExists(fname){
      $lg('ajs_worker::8935::fileIsExists');
      return new Promise((res,rej)=>{
      
        let xhr = new Xhr(this.addr);
            xhr.ask('file__exists',{fname});
            xhr.rsp((data)=>{
              //$lg('8941::data',data);
              let dat = JSON.parse(data);
              let rst = dat.da.rst;
              //$lg('8935::rst::bgg',rst);
              res(rst);
              
            },(err)=>{
              $lg('ajs_worker::8938::webman::err::bgo',err);
              rej(err);
            })
          
      })
    }
    
}


class Sqlike{
  
      constructor(addr){
          //$lg('8288::Sqlike::constructor');
          this.pars = {
            
              tables  : [],
            
          },
          
          this.addr = addr;
        
      }
      
      run = (op,da)=>{
        $lg('ajs_worker::8973::addr,op,da::bgg',this.addr,op,JSON.stringify(da));
        return new Promise((res,rej)=>{
            new Xhr(this.addr)
            .ask(op,da)
            .rsp((data)=>{
                $lg('ajs_worker.js::8978::data::bgg',data);
            
                if(/<b>Warning<\/b>/i.test(data)){
                  if(/near/i.test(data)){
                    if(/syntax error/i.test(data)){
                      rej(data);
                    }
                  }
                }
                let obj = JSON.parse(data);
                /*let da  = obj.da;
                let dat = da.dat;
                $lg('8300::dat::bgy',dat);
                */
                res(obj);
                /*
                let ui = new Ui();
                let tbl = new ui.table(dat);
                    tbl.done();*/
                //$lg('100::dat',dat.id,dat.word,dat.pronun,dat.meaning,dat.english);
            },(err)=>{
                $lg('8304::err::bgo',err);
                rej(err);
            })
        })
      }
      
      tableWriter = (tableName,colArr)=>{
          let tsl = (str)=>{
            if(str == '') return '';
            let arr = str.split(',');
            let rst = '';
            for(let ss of arr){ 
              let s = ss.toLowerCase();
              if(s == 'pri')  {rst += ' PRIMARY KEY'}else
              if(s == 'auto') {rst += ' AUTOINCREMENT'}else
              if(s == 'uni')  {rst += ' UNIQUE'}else
              if(s == 'not')  {rst += ' NOT NULL'}else
              if(s == 'def')  {rst += ' DEFAULT'}
              else{rst += ` ${ss}`}
            }
            return rst;
          }    
          let cmds = [];
              cmds.push(`DROP TABLE IF EXISTS ${tableName};\n`);
              cmds.push(`CREATE TABLE IF NOT EXISTS ${tableName}(\n`);
          let i = -1;
          for( let dat of colArr){
              i++;
              let col  = dat[0];
              let type = dat[1];
              let cons = dat[2] == null ? '' : dat[2];
                  cons = tsl(cons);
              if(col == 'id' && cons == '')cons  = ' PRIMARY KEY AUTOINCREMENT';
              let tail = i == colArr.length-1 ? '\n);' : ',\n';
              let line = `  ${col.padEnd(10,' ')} ${type.padEnd(12,' ')} ${cons}${tail}`;
              cmds.push(line);
          }
          let sql = cmds.join('');
          //$lg('9191::sql::bgy',sql);
          return sql;

      }
      
      indexWriter = (tableName,colArr)=>{

          let cmds = [];
          
          for( let dat of colArr){
              
              let col  = dat[0];
              let type = dat[1] == undefined ? 'INDEX' : dat[1];
              
              let line = `CREATE ${type} IF NOT EXISTS ${tableName}_${col} ON ${tableName}(${col});\n`;
              cmds.push(line);
          }
        
          return cmds.join('');

      }
      
      conf  =   {
        
          table : (name,colsArr)=>{
              
              return this;
              
          },
          
          index : ()=>{
              
              return this;
              
          },
          
      }
      
      done  = ()=>{
          
          return this;
          
      }
      
  }


//export { Ajs, Load, Html, Css, Xhr, Log, Ui, Rec, Char, Doc, Webman } 