
import { Log } from './ajs.js'



//@load
/**
 * path : 此参数是指：
 *        从使用本class的html文件所在文件夹出发
 *        至本class所在文件夹的相对路径
 **/ 
export class Loader{
  
  constructor(path = "../import/thirdpart/"){
    
    let plen = path.length;
    
    if( path.charAt( plen-1 ) !== '/' ){
      path += '/';
    }
    
    this.basePath = path;
    if(window.$lg == undefined){
        //new Log();
    }
  }
  
  //#add(load)
  add = {
      script : (src,onloadCallBack,head=document.head)=>{
          let script = document.createElement('script'); 
                  script.setAttribute( "src",this.basePath + src); 
                  //$lg('Load::add::scriot:235',this.basePath + src);
                  //this.add.a('url',this.basePath + src);
                  script.onload = onloadCallBack;
          head.appendChild(script);
          return this;
      },
      a : (text,href)=>{
          let a = document.createElement('a'); 
              a.setAttribute( "href",href);
              a.innerText = text;
          //alert(a);
          return this;
      },
      link : (href,callBack=null,rel='stylesheet',type='text/css',head=document.head)=>{
          let e = document.createElement('link'); 
                  e.setAttribute( "href",this.basePath + href); 
                  e.setAttribute( "rel",rel); 
                  e.setAttribute( "type",type); 
                  //$lg('Load::add::link:6023',this.basePath + src);
                  //this.add.a('url',this.basePath + src);
                  if(callBack)
                  e.onload = callBack;
          head.appendChild(e);
          return this;
      },
  }
  
  eruda = {
    load  : ()=>{
            //$lg('eruda is loading');
            return new Promise((resolve,reject)=>{
              let res = function(){
                //window.eruda.init(); 
                eruda.init(); 
                //$lg("eruda init done");
                resolve();
              };
              let file = "eruda/eruda.min.js";
              this.add.script(file,res);/*
              let script = document.createElement('script'); 
                  script.setAttribute( "src",this.basePath + "eruda/eruda.min.js"); 
                  script.onload = res;
              document.head.appendChild(script);*/
            });
            //return this;
          }
  };
  
  jquery = {
    load  : ()=>{
              //console.log('jquery is loading');
              return new Promise((resolve)=>{
                let res = function(){
                  console.log('jquery ok');
                  resolve();
                }
                let file = "jquery/jquery-3.3.1.js";
                this.add.script(file,res);
                /*let script = document.createElement('script'); 
                    script.setAttribute( "src",this.basePath + "jquery/jquery-3.3.1.js"); 
                    script.onload = res;
                document.head.appendChild(script);*/
              });
              //return this;
            } 
  };
  
  zepto = {
    load  : (file="")=>{
              if(file=="es6"){
                file = "zepto_es6.js";
                //import zepto from `this.basePath + "zepto/" + file`;
              }else{
                file = "zepto.js";
                let script = document.createElement('script'); 
                    script.setAttribute( "src",this.basePath + "zepto/" + file); 
                    script.onload = function () { console.log('zepto ok');} 
                document.head.appendChild(script);
              }
              return this;
            }
  };
  
  bootstrap = {
    loadJs  : ()=>{
                //console.log('bootstrap.js is loading');
             // console.log('third.js >> bootstrap >> load()');
                let script = document.createElement('script'); 
                    script.setAttribute( "src",this.basePath + "bootstrap/v5.1.3/bootstrap.bundle.js"); 

                    script.onload = function () { 
                    console.log('bootstrap loaded');
                    console.log(script.src);
                } 
                document.head.appendChild(script);
                return this;
              },
    loadCss : ()=> {
                //console.log('bootstrap.css is loading');
                let link = document.createElement('link'); 
                    link.setAttribute( "rel","stylesheet"); 
                    link.setAttribute( "type","text/css"); 
                    link.setAttribute( "href",this.basePath + "bootstrap/v5.1.3/bootstrap.css");
                    link.onload = function () { 
                      console.log('bootstrap.css loaded');
                    }
                 document.head.appendChild(link);
                 return this;
               }
  };
  
  bspIcon = {
    load  : ()=>{
            //$lg('bspIcon is loading');
            return new Promise((resolve,reject)=>{
              let res = function(){
                //$lg('bspIcon was loaded');
                resolve();
              };
              //
              let file = "bootstrap-icons/v1.8.3/font/bootstrap-icons.css";
              this.add.link(file,res);/*
              let script = document.createElement('script'); 
                  script.setAttribute( "src",this.basePath + "eruda/eruda.min.js"); 
                  script.onload = res;
              document.head.appendChild(script);*/
            });
            //return this;
          }
  };
  
  icono = {
    load  : ()=>{
              //console.log('jquery is loading');
              return new Promise((resolve)=>{
                let res = function(){
                  console.log('icono ok');
                  resolve();
                }
                  let link = document.createElement('link'); 
                      link.setAttribute( "rel","stylesheet"); 
                      link.setAttribute( "type","text/css"); 
                      link.setAttribute( "href",this.basePath + "icono/icono.css"); 
                      link.onload = res;
                  document.head.appendChild(link);
              });
              
            } 
  };
  
  recorder = {
    load : ()=>{
      return new Promise((resolve)=>{
        let res = function(){
          console.log('recorder ok');
          resolve();
        }
        let script = document.createElement('script'); 
            script.setAttribute( "src",this.basePath + "rec/recorder.js"); 
            script.onload = res;
        document.head.appendChild(script);
      });
    },
  }
  
  sparkMd5 = {
    load : ()=>{
      return new Promise((resolve)=>{
        let res = function(){
          //console.log('sparkMd5 ok');
          resolve();
        }
        let script = document.createElement('script'); 
            script.setAttribute( "src",this.basePath + "spark_md5/spark-md5.min.js"); 
            script.onload = res;
        document.head.appendChild(script);
      });
    },
  }
  
  log6 = {
    load : ()=>{
      //return new Promise((resolve)=>{
        let path = "http://127.0.0.1:8080/project/import/module/log.js";
        let s = document.createElement('script'); 
            s.setAttribute( "src",path); 
            s.onload = ()=>{new Log();};
        document.head.appendChild(s);
      //});
    },
  }
  
  ffmpeg = {
    
    load : ()=>{
      
      return new Promise((resolve)=>{
        let res = function(){
          //console.log('ffmpeg ok');
          resolve();
        }
        let script = document.createElement('script'); 
            script.setAttribute( "src",this.basePath + "ffmpeg/ffmpeg.min.js"); 
            script.onload = res;
        document.head.appendChild(script);
      });
    },
  }
  
  
}