  (function(){
    let file = "http://127.0.0.1:8080/project/import/thirdpart/eruda/eruda.min.js";
    let script = document.createElement('script'); 
        script.setAttribute( "src",file); 
        script.onload = function(){
          eruda.init(); 
        };
    document.head.appendChild(script);
  })()
  
  (function(){
    let log = "http://127.0.0.1:8080/project/import/module/log.js";
    let script2 = document.createElement('script'); 
        script2.setAttribute( "src",log); 
        //script2.setAttribute( "type",'module'); 
        script2.onload = ()=>{
          
          new Log();
        }
    document.head.appendChild(script2);
  })()