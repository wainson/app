


  window.onerror = function(){
      let m = '';
      for(a of arguments){ m += a + '\n'; }
      return alert(m + 'version:3.00');
  };
  //alert('onerror setup done');


