
<?php

/**
 *  类型缩写:
 *            s:string
 *            i:integer,int
 *            d:double,float
 *            b:blob
 *            n:null
 *  使用方式:
 *           $sql = " SELECT * 
 *                    FROM table 
 *                    WHERE name=? AND age=? AND cm=?
 *                    ORDER BY id DESC
 *                    LIMIT 1
 *                  ";
 *           $arr = array("sid","vincent",40,165.5);
 *           $rsp = GET_DATA($sql,$arr);
 *           if(!data_is_good){
 *             echo $rsp->msg;
 *             return;
 *           }
 *           $dat  = $rsp->dat;
 *           $id   = $dat['id'];
 *           $name = $dat['name'];
 *           $cm   = $dat['cm'];
 *        
 */

function rst($rst=TRUE,$dat=NULL,$msg=''){
  $obj = (object)[];
  $obj -> rst   = $rst;
  $obj -> dat   = $dat;
  $obj -> msg   = $msg;
  return $obj;
}


function data_is_good($rsp){
  if($rsp->rst == 1 && is_array($rsp->dat) && count($rsp->dat)>=1){
    return 1;
  }
  return 0;
}

function data_is_bad($rsp){
  if(!data_is_good($rsp)){
    return 1;
  }
  return 0;
}

function result_is_true($rsp){
  if($rsp->rst == 1){
    return 1;
  }
  return 0;
}

function result_is_false($rsp){
  if(!result_is_true($rsp)){
    return 1;
  }
  return 0;
}

//define('SQLITE_FILE_NAME',"data.db");

//DELETE_FROM_WHERE
//INSERT_INTO_VALUES
//UPDATE_SET_WHERE
function GET_RESULT($sql,$arr){
    $msg = "sqlite3.php >> GET_RESULT >> ";
    try{
        $sqlike  = new SQlike3(SQLITE_FILE_NAME);
        $rsp     = $sqlike->GetResult($sql,$arr);
        return $rsp;
    
    }catch (Exception $e){
        return rst(FALSE,$sql,"$msg Exception:".$e->getMessage());
    }
    return rst(FALSE,$sql,$msg. "unknow error");
}


//SELECT_FROM_WHERE
function GET_DATA($sql,$arr){
    $msg = "sqlite3.php >> GET_DATA >> ";
    try{
        $sqlike = new SQlike3(SQLITE_FILE_NAME);
        $rsp = $sqlike->GetData($sql,$arr);
        return $rsp;
    }catch (Exception $e){
        return rst(FALSE,null,"$msg Exception:".$e->getMessage());
    }
    return rst(FALSE,null,$msg. "unknow error");
}





class SQlike3 extends SQLite3
{

    function __construct($filename)
    {
       $this->open($filename);
    }

    function run($sql){
      $msg = "SQlike3 >> run >> ";
      try{
        //$sql = $this->escapeString($sql);
        $rsp = $this->exec($sql);
        
        if($rsp == FALSE){
          return rst(FALSE,$sql,$msg . 'FALSE >> ' . $this->lastErrorMsg());
        }
        return rst(TRUE,$rsp,"");
      }catch(Exception $e){
        return rst(FALSE,$sql,$msg ."Exception:". $e->getMessage());
      }
      return rst(FALSE,$sql,$msg . "unknow error");
    }
    
    function que($sql){
      $msg = "SQlike3 >> que >> ";
      try{
        $SQLite3Result = $this->query($sql);
        
        
        if($SQLite3Result == FALSE){
          return rst(FALSE,$sql,$msg . $this->lastErrorMsg());
        }
        
        $data= array();
        // Fetch Associated Array (1 for SQLITE3_ASSOC)
        
        $j = 0 ;
        $col = array();
        while ($res= $SQLite3Result->fetchArray(1)){
            $arr = array();
            
          
            foreach ($res as $key => $value){
            //insert row into array
              if($j == 0){array_push($col,$key);}
              array_push($arr,$value);
              
            }
            $j=1;
            array_push($data, $arr);
          
        }
        $obj = (object)[];
        $obj->col = $col;
        $obj->arr = $data;
        
        //bug($obj);
        
        return rst(TRUE,$obj,"");
        
      }catch(Exception $e){
        return rst(FALSE,$sql,$msg ."Exception:". $e->getMessage());
      }
      return rst(FALSE,$sql,$msg . "unknow error");
    }



    //将查询结果返回到一个数组里面
    function GetData($sql, $arr)
    {
        $msg = "SQlike3 >> GetData >> ";
        $dat = null;
        $rsp = $this->GetSTMT($sql, $arr);
        try {
            if ($rsp->rst == TRUE) {
                $stmt = $rsp->dat;
                
                $r = $stmt->execute();
                if($r == FALSE){
                  return rst(FALSE,$sql, $msg . $this->getMessage());
                }
                $dat = [];
                while ($res = $r->fetchArray(1)) {
                    array_push($dat, $res);
                }
                $stmt->close();
                return rst(TRUE,$dat,"");
            }else{
              return $rsp;
            }
        } catch (Exception $e) {
            $msg .= " Exception:" . $e->getMessage();
            return rst(FALSE,$sql,$msg);
        }
        return rst(FALSE,$sql, $msg . " unknow error");
    }

    function GetSTMT($sql, $arr)
    {
        $msg = "SQlike3 >> GetSTMT >> ";
        //bug($msg,$sql);
        try {
            $stmt = $this->prepare($sql);
            if($stmt == FALSE){
              return rst(FALSE,$sql,$msg . $this->lastErrorMsg());
              //return 0;
            }
            $rstmt = new ReflectionClass('SQLite3Stmt');
            //$rstmt = new ReflectionClass($stmt);
            $i = 0;
            $d = array();
            $format = array();
            foreach ($arr as $key => $value) {
                //var_dump($value);
                if ($i == 0) {
                    $format = str_split($value);
                    //var_dump($format);
                } else {
                    array_push($d, $value);
                }
                $i++;
            }

            $f = 0;
            $i = 0;
            foreach ($format as $k => $v) {
                if ($v == "i") {
                    $f = SQLITE3_INTEGER;
                } else if ($v == "d") {
                    $f = SQLITE3_FLOAT;
                } else if ($v == "s") {
                    $f = SQLITE3_TEXT;
                } else if ($v == "b") {
                    $f = SQLITE3_BLOB;
                } else if ($v == "n") {
                    $f = SQLITE3_NULL;
                }
                $a = array();
                array_push($a, $i + 1);
                array_push($a, $d[$i]);
                array_push($a, $f);
                //var_dump($a);
                $i++;
                $method = $rstmt->getMethod('bindParam');
                $method->invokeArgs($stmt, $this->refValues($a));
            }
            return rst(TRUE,$stmt,"");
            //return $stmt;
        } catch (Exception $e) {
            //echo "GetSTMT>>Exception:" . $e->getMessage() . "<br>";
            return rst(FALSE,$sql,"$msg Exception:" .  $e->getMessage());
            //return 0;
          
        }
        return rst(FALSE,$sql,"$msg unknow error");
        //return 0;
      
    }


    //返回操作影响的行数
    function GetResult($sql, $arr)
    {
      $msg = "SQlike3 >> GetResult >> ";
      /*echo $msg . "<br>";
      echo "<textarea style='width:800px;height:1200px;'>";
      print_r( $sql );
      print_r( $arr) ;
      echo "</textarea>";
      echo  "<br>";*/
      
      try {
          $rsp = $this->GetSTMT($sql, $arr);
          //$stmt = $this->GetSTMT($sql, $arr);
          if ($rsp->rst == TRUE) {
              $stmt = $rsp->dat;
              if ($stmt->execute()) {
                  //$ar = $stmt->affected_rows;
                  $ch = $this->changes();
                  $stmt->close();
                  return rst(TRUE,$ch,"");
              } else {
                  return rst(FALSE,$sql,$msg .  $e->getMessage());
              }
          }else{
             return $rsp;
          }
      } catch (Exception $e) {
          //echo 'SQlike3 >> GetResult >> ' .  $e->getMessage() . "\n";
          return rst(FALSE,$sql,$msg .  $e->getMessage());
      }
      return rst(FALSE,$sql,"$msg >> unknow error");
    }


    function refValues($arr)
    {
        if (version_compare(PHP_VERSION, '5.3.0') >= 0) {
            $refs = array();
            foreach ($arr as $key => $value)
                $refs[$key] = &$arr[$key];
            return $refs;
        }
        return $arr;
    }



    function __destruct()
    {
        //$this->close();
        //echo ">>sqlite>close";
    }
}
