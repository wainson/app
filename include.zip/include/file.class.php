
<?php

//include_once('public.php');

class File{

    function is_dir($op,$da){
        $fname    = $da->fname;
        $ft = filetype($fname);
    }
    
    function exists($op,$da){
        $fname    = $da->fname;
        $es = file_exists($fname);
        rsp($op,$es,null);
    }
    
    function mime($op,$da){
        $fname    = $da->fname;
        //image/gif
        $mime = mime_content_type($fname);
        
    }
    
    function copy($op,$da){
        $fname    = $da->fname;
        $newfname = $da->$newfname;
        copy($fname, $newfname);
    }
    
    function cut($op,$da){
        $fname    = $da->fname;
        $newfname = $da->$newfname;
        if(copy($fname,$newfname)){
            unlink($fname);
        }
    }
    
    function del($op,$da){
        $fname = $da->filename;
        unlink($filename);
    }
    
    function rename($op,$da){
        $oldname = $da->oldname;
        $newname = $da->newname;
        rename($oldname,$newname);
    }
    
    function info($op,$da){
      
        $fpath = $da->fpath;
        $unit  = $da->unit;
      
        $filesize = filesize($fpath);

        //$KB = round($filesize / 1024, 2);
        $MB = round($filesize / 1048576, 2);
      
        $fname = $da->filename;
        $size  = filesize($fname);
        $time  = filemtime($fname);
        $type  = filetype($fname);
    }
    
    function size($op,$da){
      
        $fpath = $da->fpath;
        $unit  = $da->unit;
      
        $filesize = filesize($fpath);
        
        if($filesize == null) { 
          //rsp($op,false,0,'file not found');
          rsp($op,true,-1,'file not found');
          return;
        }
        
        $KB = null;
        $MB = null;
        $GB = null;
        
        if($unit == 'KB')      $size = round($filesize / 1024, 2);
        else if($unit == 'MB') $size = round($filesize / (1024*1024), 2);
        else if($unit == 'GB') $size = round($filesize / (1024*1024*1024), 2);
        else                   $size = round($filesize / (1024*1024*1024), 2);
      
        rsp($op,true,$size,$unit);
        
    }
    
    function open($op,$da){
        //bug($op,$da);
        $fname = $da->filename;
        $fcont = file_get_contents($fname);
        //bug('file.class.php::59::\$fcont',$fcont);
        //bug(strlen($fcont));
        $rst = 0;
        if(strlen($fcont)>0){
            //bug('strlen($fcont):',strlen($fcont));
            $rst = 1;
        }
        rsp($op,$rst,$fcont,null);
    }
    
    function save($op,$da){
        $fname   = $da->name;
        $fcont   = $da->cont;
        $rst = file_put_contents($fname,$fcont);
        rsp($op,$rst,null,null);
    }
    
    function upload($op,$da){
        bug($op,$da);
        $path  = $da->path;
        $name  = $da->name;
      
        $mkdir = $da->mkdir;
        
        if( $mkdir == 1 )mkdir($path, 0777, true);
        if( $name ) $path = "$path/$name";
        //bug($path,$type);
        $rst = move_uploaded_file($_FILES['file']['tmp_name'], $path);
        rsp($op,$rst,$da,$path);
    }
    
    
    
    function pic_get($op,$da){
        //bug($op,$da);
        
        $sql  = $da->sql;
      
        //连接数据库
        //$db = new SQLite3('database.db');
        
        // 查询blob数据
        //$sql = "SELECT blob_data FROM table WHERE id = 1";
        $result = $db->query($sql);
        
        // 读取blob数据
        if ($result) {
          $row = $result->fetchArray(SQLITE3_ASSOC);
          $blob_data = $row['blob_data'];
          header("Content-Type: image/jpeg"); // 设置响应头，告诉浏览器响应的是JPEG图片
          echo $blob_data; // 输出blob数据
        } else {
          echo "No blob data found";
        }
        
        // 关闭连接
        $db->close();
      
        rsp($op,$rst,$da,$path);
    }
    
    function findAll($path,$key){

      $cont = file_get_contents($path);
      if( $cont ){
        $m = null;
        preg_match_all( $key, $cont, $m );
        if($m) return $m;
      }
      return null;
    }
    
    function searchByLine($path,$key){
      $i   = 0;
      $rst = [];
      $cont = file_get_contents($path);
      if( $cont ){
        
        $lines = preg_split("/\n/",$cont);
        foreach ($lines as $line){
          $i++;
          $m = null;
          preg_match( $key, $line, $m );
          if($m) array_push($rst,[$i,$line]);
        }
      }
      return $rst;
    }
    
}

class Folder{

    function scan( $path, $ext, $key, $keyInPath = null ){
      
        $level = count(explode('/',$path))-8;
      
        $dit = new DirectoryIterator($path);
      
        foreach ($dit as $item){
            $fname = $item->getFilename();
            $fpath = $item->getPathname();
            
            $mp = null;
            
            if( $keyInPath ){
              
              preg_match( $keyInPath, $fpath, $mp );
              if( $mp ){
                
              }
            }
            
            if      ($item->isDot()  ){
            
            }else if($item->isFile() ){
                /*echo "-----------------------\n";
                
                echo $fpath . "\n";
                echo $fname . "\n";
                echo $item->getExtension() . "\n";
                */
                if( $keyInPath ){
                  if( $mp == null ) continue;
                }
                if( $ext == $item->getExtension() ){
                  $cont = file_get_contents($fpath);
                  if( $cont ){
                    $m = null;
                    //$key = preg_quote($key, '/');
                    preg_match_all( $key, $cont, $m );
                    if( isset($m[0][0]) ){
                      echo $fpath . "\n";
                      echo "-----------------------\n";
                      foreach ($m[0] as $s){
                        echo "&nbsp;&nbsp;" . $s . "\n";
                      }
                      echo "-----------------------\n";
                      //var_dump($m);
                    }
                  }
                }
                
                
            }else if($item->isDir()  ){
          
                $this->scan($fpath,$ext,$key,$keyInPath);
                
            }
        }
    }
    
    function list($op,$da){
        //bug('list',$op,$da);
        $path = $da->path;
        $dit  = new DirectoryIterator($path);
        $type = 0;
        $ext  = '';
        $arr  = [];
        foreach ($dit as $item){
            $fname = $item->getFilename();
            $fpath = $item->getPathname();
            if      ($item->isDot()  ){
                $type = 0;
            }else if($item->isFile() ){
                $type = 1;
                //$ext  = $item->getExtension();
            }else if($item->isDir()  ){
                $type = 2;
            }
            //$bag = [];
            //array_push($bag,$type,$name);
            array_push($arr,[$type,$fname]);
        }
        $dat = (object)[];
        $dat->path  = $path;
        $dat->items = $arr;
        rsp($op,1,$dat,null);
        
    }
    
    function copy(){
        
    }
    
    function cut(){
        
    }
    
    function del(){
        
    }
    
    function rename(){
        
    }
    
    function add(){
        
    }
    
}


function htmlScan(){

    echo "<html lang=zh-cn>\n";
    echo "<head>\n";
    //echo "<meta>";
    echo "<style>\n";
    echo "body,html{\n";
    echo "width:96%;height:99%;font-size:30px;\n";
    echo "display:flex;flex-direction:column;\n";
    echo "justify-content:flex-start;\n";
    echo "align-items:center;\n";
    echo "}\n";
    echo "textarea{\n";
    echo "font-size:20px;\n";
    echo "overflow:scroll;\n";
    echo "white-space:pre;\n";
    echo "position:relative;\n";
    echo "width:96%;height:90%;\n";
    echo "margin:10px;padding:10px;\n";
    echo "border:3px solid black;\n";
    echo "}\n";
    echo "</style>\n";
    echo "</head>\n";
    echo "<body>\n";
    echo "<textarea>\n";
    
    $folder = new Folder();
    $file = new File();
    
    
    $name = "../../vscode/dev/vs/editor/editor.main.js";
    $path = "../../vscode/dev/vs";
    $ext = "js";
    //$k = '/create\([a-z\_]+\,[a-z\_]+\)/';
    //$key = '/[a-z]+\.createInstance\([a-z\,\s]*\)/i';
    //$key = '/[a-zA-Z_.]*createInstance\(.*\)/i';
    //$key = '/[a-z_\s.]+FoldingController[a-z_\s.]+/i';
    $key = '/setSelectionAnchor/i';
    //$key = '/[a-zA-Z_.]*initialize\(.*\)/i';
    //$key = '/\$lg/i';
    //$key = '/\s(?!nls|Object|(\w*trace)|this|(\w*module)|(small\w*)|(context\w+)|(\w+factory))[a-zA-Z\.]*\bcreate\(.*\)/i';
    //$kp = '/.+editor.+/';
    //$k = '/function createModel\([a-z\,\s]*\)/i';
    //$k = '/\$lg\(/i';
    $kp = null;
    
    
    //echo "search file:$name\n";
    echo "file中包含:$key\n";
    if( $kp ) echo "路径中包含:$kp\n";
    echo "================================\n";
    $mt1 = microtime(1);
    $folder->scan( $path, $ext, $key, $kp );
    
    //$rst = $file->findAll($name,$k);
    //$rst = $file->searchByLine($name,$key);
    //var_dump($rst);
    /*
    if( $rst ){
      
      echo $name . "\n";
      foreach ($rst as $n){
        echo "&nbsp;" . $n[0] . "\n";
      }
      echo "-----------------------\n";
      
    }
    */
    $mt2 = microtime($mt1);
    
    $dur = $mt2-$mt1;
    echo round( $dur * 1000, 3) . '毫秒';
            
    echo "</textarea>\n";
    echo "</body>\n";
    echo "</html>\n";
}


//htmlScan();