
<?php

//
/*spl_autoload_register(function ($class_name) {
    require_once $class_name . '.php';
});*/

include_once 'public.php';

include_once "webman.class.php";

//include_once "event_source.class.php";
include_once "file.class.php";
include_once "food.class.php";
include_once "data.class.php";


try{
      
    /*if(isset($_REQUEST))bug(json_encode($_REQUEST));
    if(isset($_POST))bug(json_encode($_POST));
    if(isset($_FILES)){
      bug(json_encode($_FILES));
    }*/
    $opda = null;
    
    if(!empty($_POST['opda'])) {
        //bug($_POST);
        $opda = json_decode($_POST['opda']);
      
    }else if(!empty($_GET['opda'])) {
        //bug($_GET);
        $opda = json_decode($_GET['opda']);
  
    }else{
        //echo 'both $_POST and $_GET is empty';
        rsp('error',FALSE,null,'both $_POST and $_GET is empty');
        exit();
    }
    
    $op  = $opda->op;
    $da  = $opda->da;
    
    //bug($op,$da);
    //err($op,$da);
    
    $items = explode('__',$op);
    $className = $items[0];
    $funcName  = $items[1];
  
    /*
    class SomeClass{
      someMethod($a,$b){
        return $a+$b;
      }
    }
    $method = new ReflectionMethod('SomeClass', 'someMethod');
    $method->invokeArgs(NULL, [12, 7];
    */
    $Class = ucfirst(strtolower($className));
    //bug($Class,$className,$funcName);
    $function = new ReflectionMethod($className, $funcName);
    $function -> invokeArgs(new $Class(), [$op,$da]);

}catch (Error $ex){
    $msg = $ex->getMessage();
    $code =  $ex->getCode();           // 返回异常代码
    $file =  $ex->getFile();           // 返回发生异常的文件名
    $line =  $ex->getLine();           // 返回发生异常的代码行号
    $trace =  $ex->getTrace();          // backtrace() 数组
    err("file:$file","line:$line","code:$msg",$trace);

}catch (Exception $ex){
    $msg = $ex->getMessage();
    $code =  $ex->getCode();           // 返回异常代码
    $file =  $ex->getFile();           // 返回发生异常的文件名
    $line =  $ex->getLine();           // 返回发生异常的代码行号
    $trace =  $ex->getTrace();          // backtrace() 数组
    err("file:$file","line:$line","code:$msg",$trace);

}finally {
    //echo "Second finally.\n";
    //var_dump($_GET == null);
    //var_dump($_POST == null);
    //var_dump($_POST == null);
    //var_dump(empty($_POST['opda']));
}

/*
function bug($obj) {

    $numargs = func_num_args();
    $arg_list = func_get_args();
    $arr = [];

    $subname = "";

    for ($i = 0; $i < $numargs; $i++) {
        if($i === 0){
            $ty = gettype($arg_list[0]);
            if($ty === "string" && preg_match("/fn\:.+/",$arg_list[0])) {
                $ar = explode(":",$arg_list[0]);
                $subname = "_" . $ar[1]. "_";
            }else{
                array_push($arr,$arg_list[$i]);
            }
        }else{
            array_push($arr,$arg_list[$i]);
        }

    }


    //$text = json_encode($arr,320);

    $backtrace = debug_backtrace();
    $file =  $backtrace[0]["file"];
    $line =  $backtrace[0]["line"];
    $func =  $backtrace[0]["function"];

    $text = "   " . json_encode($arr, JSON_UNESCAPED_SLASHES );
    $from = "   " . $file . " line:" . $line .  " name:" . $func;
    file_put_contents ( "bug" . $subname . ".txt",  date_time() .  "\n" . $from . "\n" . $text . "\n\n" , FILE_APPEND );

    preg_match('/[a-z]{3,}\.{1}php$/',$file,$matches);

    $str = $matches[0] . "->" . $line ;

}

function date_time(){
    //return date('YmdHis',time());
    $mt = microtime();
    list($usec, $sec) = explode(" ", $mt);
    $da = date('Y-m-d H:i:s ',$sec);
    $msec = mb_substr($usec,2,4,'utf-8');
    return $da . $msec;
}

*/