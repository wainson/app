
<?php

class Webman{
  
    function make_js_file($op,$da){
        
        //bug($op,$da);
        
        
        $fname   = $da->file;
        $cont    = $da->cont;
        $rsp     = file_put_contents($fname,$cont);
        
        $msg = 'fail';
        if(file_exists($fname)){
            $msg = "exists file : '".$fname."'";
            $rsp = 1;
        }
        
        $this->rsp($op,$rsp,null,$msg);
        
    }
  
    function rsp($op,$true_false,$dat=null,$msg=null){

        //header('content-type:application:json;charset=utf8');  
        //header("Content-type:text/html",true);
    
        //$res = ["fail","success","exception","progress"];
    
        $da = (object)[];
        $da->rst = $true_false;//$res[$result];
        $da->dat = $dat;
        $da->msg = $msg;
        
        //$da->op = $op;
    
        $resp = (object)[];
        $resp -> op    = $op;
        $resp -> da    = $da;
    
        //ob_start();
    
        echo json_encode($resp,320);
        /*
        ob_flush();
        flush();
        clearstatcache();
        */
    }

  
}
