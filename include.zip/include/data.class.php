<?php

include_once "sqlite3.php";

class Data{
  
  
    function run_cmd($op,$da){
        
        //bug($op,$da);
        
        $file = $da->file;
        $sql  = $da->sql;
        
        $act  = $da->act;
        
        $m   = null;
        $cmd = null;
        
        if($act == 'que'){
          preg_match( '/attach database/i', $sql, $m );
          if($m) {
            $arr = preg_split("/;/",$sql);
            if($arr){ 
              $cmd = $arr[0];
              $sql = $arr[1];
            }
          }
        }
        //bug("is array : " . is_array($arr));
        
        define('SQLITE_FILE_NAME',$file);
        
        //bug(SQLITE_FILE_NAME,$sql,$act,$arr);
        
        $dat  = null;
        $rst  = null;
        
        if($act == 'dat'){
            //bug("\$act == 'dat'");
            $arr = $da->arr;
            $dat = GET_DATA($sql,$arr);
            
        }else 
        if($act == 'rst'){
            $arr = $da->arr;
            $dat = GET_RESULT($sql,$arr);
            
        }else 
        if($act == 'run'){
            //bug('run');
            $sqlike = new SQlike3(SQLITE_FILE_NAME);
            $dat = $sqlike->run($sql);
            //bug($dat);
            $sqlike->close();
            if($dat->rst == 0){
              err($dat);
            }
        }else 
        if($act == 'que'){
            //bug('run');
            $sqlike = new SQlike3(SQLITE_FILE_NAME);
            if($cmd){
              $r = $sqlike->run($cmd);
            }
            $dat = $sqlike->que($sql);
            //bug($dat);
            $sqlike->close();
        }
        
        
        rsp($op,$dat->rst,$dat->dat,$dat->msg);
        
    }
    
    function save_as_blob($op,$da){
      
      $path  = $da->path;
      $name  = $da->name;
      $file  = $da->file;
      $sql   = $da->sql;
        
      $act   = $da->act;
      $mkdir = $da->mkdir;
      
      if( $mkdir == 1 )mkdir($path, 0777, true);
      if( $name ) $path = "$path/$name";
      //bug($path,$type);
      $rst = move_uploaded_file($_FILES['file']['tmp_name'], $path);
      rsp($op,$rst,$da,$path);
      
    }
  
}