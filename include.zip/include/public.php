<?php



//ob_end_clean();//清空（擦除）缓冲区并关闭输出缓冲
//ob_implicit_flush(1);//将打开或关闭绝对（隐式）刷送。绝对（隐式）刷送将导致在每次输出调用后有一次刷送操作，以便不再需要对 flush() 的显式调用




//include_once  "config.php" ;
//include_once  "sqlite3.php" ;




//ob_end_flush();
//ob_implicit_flush();

//date_default_timezone_set('PRC');
date_default_timezone_set('Asia/Hong_Kong');



ini_set('max_execution_time', '100000000');

set_time_limit(0);


mb_internal_encoding('utf8');
mb_regex_encoding('utf8');




// $ip = ip();

// $black = blacklist_judge_ip($ip);

// if($black === 1){
//     exit;
// }




function op($request,$result,$msg,$data){
    $op = (object)[];
    $op -> req   = $request;
    $op -> rst   = $result;
    $op -> msg   = $msg;
    $op -> data  = $data;
    return $op;
}


function bug($obj) {
    //return;

    $numargs = func_num_args();
    $arg_list = func_get_args();
    $arr = [];

    $subname = "";

    for ($i = 0; $i < $numargs; $i++) {
        if($i === 0){
            $ty = gettype($arg_list[0]);
            if($ty === "string" && preg_match("/fn\:.+/",$arg_list[0])) {
                $ar = explode(":",$arg_list[0]);
                $subname = "_" . $ar[1]. "_";
            }else{
                array_push($arr,$arg_list[$i]);
            }
        }else{
            array_push($arr,$arg_list[$i]);
        }

    }


    //$text = json_encode($arr,320);

    $backtrace = debug_backtrace();
    $file =  $backtrace[0]["file"];
    $line =  $backtrace[0]["line"];
    $func =  $backtrace[0]["function"];

    $text = "   " . json_encode($arr, JSON_UNESCAPED_SLASHES );
    $from = "   " . $file . " line:" . $line .  " name:" . $func;
    file_put_contents ( "bug" . $subname . ".txt",   date_time()  . "\n" . $from . "\n" . $text . "\n\n" , FILE_APPEND );

    //preg_match('/[a-z]{3,}\.{1}php$/',$file,$matches);

    //$str = $matches[0] . "->" . $line ;

    //log_add($str,$arr);


}

function err($obj) {
    //return;

    $numargs = func_num_args();
    $arg_list = func_get_args();
    $arr = [];

    $subname = "";

    for ($i = 0; $i < $numargs; $i++) {
        if($i === 0){
            $ty = gettype($arg_list[0]);
            if($ty === "string" && preg_match("/fn\:.+/",$arg_list[0])) {
                $ar = explode(":",$arg_list[0]);
                $subname = "_" . $ar[1]. "_";
            }else{
                array_push($arr,$arg_list[$i]);
            }
        }else{
            array_push($arr,$arg_list[$i]);
        }

    }


    //$text = json_encode($arr,320);

    $backtrace = debug_backtrace();
    $file =  $backtrace[0]["file"];
    $line =  $backtrace[0]["line"];
    $func =  $backtrace[0]["function"];

    $text = "   " . json_encode($arr, JSON_UNESCAPED_SLASHES );
    $from = "   " . $file . " line:" . $line .  " name:" . $func;
    file_put_contents ( "error" . $subname . ".txt",   date_time()  . "\n" . $from . "\n" . $text . "\n\n" , FILE_APPEND );

    //preg_match('/[a-z]{3,}\.{1}php$/',$file,$matches);

    //$str = $matches[0] . "->" . $line ;

    //log_add($str,$arr);


}

function rsp($op,$true_false,$dat=null,$msg=null){

    //header('content-type:application:json;charset=utf8');  
    //header("Content-type:text/html",true);

    //$res = ["fail","success","exception","progress"];

    $da = (object)[];
    $da->rst = $true_false;//$res[$result];
    $da->dat = $dat;
    $da->msg = $msg;
    
    //$da->op = $op;

    $resp = (object)[];
    $resp -> op    = $op;
    $resp -> da    = $da;

    //ob_start();

    echo json_encode($resp,320);

    //ob_flush();
    flush();
    clearstatcache();
}

function eventDown($op,$result,$msg,$data=null){

    $res = ["fail","success","exception","progress"];

    $da = (object)[];
    $da->rst = $res[$result];
    $da->msg = $msg;
    $da->dat = $data;
    $da->op = $op;

    $rsp = (object)[];
    $rsp -> op    = $op;
    $rsp -> da    = $da;

    header("Content-Type: text/event-stream",true);
    header("Cache-Control: no-cache");
    header("Connection: keep-alive");

    //bug(headers_list());

    set_time_limit(0);

    echo "event:"   . $op . "\n";
    echo "data:"    . json_encode($rsp,320) . "\n";
    echo "id:e"     . mt_rand(10000,99999) . "\n";
    echo "retry:"   . "36000000"  . "\n";
    echo "\n\n";

    ob_flush();
    flush();
    clearstatcache();

}




function now(){
    //return date('YmdHis',time());
    $mt = microtime();
    list($usec, $sec) = explode(" ", $mt);
    $da = date('YmdHis',$sec);
    $msec = mb_substr($usec,2,4,'utf-8');
    return $da . $msec;
}


function now_ymd(){
    $mt = microtime();
    list($usec, $sec) = explode(" ", $mt);
    $da = date('Ymd',$sec);
    return $da ;
}


function date_time(){
    //return date('YmdHis',time());
    $mt = microtime();
    list($usec, $sec) = explode(" ", $mt);
    $da = date('Y-m-d H:i:s ',$sec);
    $msec = mb_substr($usec,2,4,'utf-8');
    return $da . $msec;
}


error_reporting(1);

function userErrorHandler($errno=-1, $errmsg="", $filename="", $linenum=0, $vars=[])
{
    if($errno == -1) return;
    err($errno, $errmsg, $filename, $linenum, $vars);
    $errortype = array (
        E_ERROR              => 'Error',
        E_WARNING            => 'Warning',
        E_PARSE              => 'Parsing Error',
        E_NOTICE             => 'Notice',
        E_CORE_ERROR         => 'Core Error',
        E_CORE_WARNING       => 'Core Warning',
        E_COMPILE_ERROR      => 'Compile Error',
        E_COMPILE_WARNING    => 'Compile Warning',
        E_USER_ERROR         => 'User Error',
        E_USER_WARNING       => 'User Warning',
        E_USER_NOTICE        => 'User Notice',
        E_STRICT             => 'Runtime Notice',
        E_RECOVERABLE_ERROR  => 'Catchable Fatal Error'
    );
    // set of errors for which a var trace will be saved
    $user_errors = array(E_USER_ERROR, E_USER_WARNING, E_USER_NOTICE);
//    $err = "";
//    $err .= $errno . "\n";
//    $err .= $errortype[$errno] . "\n";
//    $err .= $errmsg . "\n";
//    $err .= $filename . "\n";
//    $err .= $linenum . "\n";
//    $err .= $vars . "\n";

    if (in_array($errno, $user_errors)) {
        err($errno,$user_errors);
    }
    //$err .= "\n\n";
    //bug($err);
    if(!empty($vars)){
        //$vars = $vars["_POST"];
    }
    
    if ($errno !== E_NOTICE) {
        //mail("phpdev@example.com", "Critical User Error", $err);
        //err_ex_add($errmsg,$errno,$errortype[$errno],$filename,$linenum,$vars);
    }


    if ($errno == E_USER_ERROR) {
        //mail("phpdev@example.com", "Critical User Error", $err);
    }

    //throw new Exception($errmsg,$errno);

}



function exception_handler($ex){
    $msg = $ex->getMessage();

    $code =  $ex->getCode();           // 返回异常代码
    $file =  $ex->getFile();           // 返回发生异常的文件名
    $line =  $ex->getLine();           // 返回发生异常的代码行号
    $trace =  $ex->getTrace();          // backtrace() 数组

    err("file:$file","line:$line","code:$msg",$trace);
}

set_exception_handler('exception_handler');

register_shutdown_function( "userErrorHandler" );
set_error_handler("userErrorHandler");




