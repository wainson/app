
      
    importScripts('../../import/module/ajs_worker.js')
    //import {Xhr} from '../../import/module/ajs.js'
    
    function $lg(...anyStr){
      let op = 'lg';
      let da = [...anyStr];
      self.postMessage({op,da});
      return this;
    }
    
    class Message{
        
        constructor(obj){
          this.map = new Map();
          this.add(obj);
        }
        
        handle(op,da){
          let fn = this.map.get(op);
          if(fn){
            fn(op,da);
          }
        }
        
        add = (fnObj)=>{
          let keys = Object.keys( fnObj );
          keys.forEach((key)=>{
            let fn = fnObj[key];
            if(fn)this.map.set(key,fn);
          })
          return this;
        }
        
        post(...args){
          self.postMessage(...args);
        }
        
        test(op,da){
        
          this.post({op,msg:'test',dat:'test done'})
        }
        
    }
    
    
    function timeCounting(){
      let msCount = ()=>{
        if(pause)return;
        ms += 10;
      }
      return self.setInterval(msCount,10);
    }
      
    
    function listenToMessage(msg){
    
      self.addEventListener('message', function (e) {
        //$lg('1392::msg from host',JSON.stringify(e.data));
        let data = e.data;
        let op = data.op;
        let da = data.da;
        msg.handle(op,da);
      
      })
    
    }
  
    
  
  
    let ms = 0;
    
    let pause = 0;
    
    let timeCountingId = null;
    
    let dat = {
      addr : '../../include/handler.php',
      file : '../app/mod/lrc.db',
      getLineLen : (sid)=>{
          //$lg('83::getLineLen::sid',sid);
          //$lg('84::typeof(Promise)',typeof(Promise));
          //$lg('85::dat.addr',dat.addr);
          return new Promise((ok,fail)=>{
              let sqlText = 'select max(lidx) from word where sid='+sid;
              let op = 'data__run_cmd';
              let da = {
                  act   : 'que',
                  file  : dat.file,
                  sql   : sqlText,
              };
              //$lg('92::dat.addr',dat.addr);
              let sqlike = new Sqlike(dat.addr);
                  sqlike.run(op,da).then((rsp)=>{
                    //$lg('94::rsp',JSON.stringify(rsp));
                    if(rsp.da.rst == true) ok(rsp);
                    else fail(rsp);
                  })
          })
      },
      
    }
    
    let rsp = {
      
      start   : (op,da)=>{
        self.postMessage({op:op,da:{msg:'started'}});
        return self;
      },
      
      timeCountStart   : (op,da)=>{
        pause = 0;
        if(timeCountingId == null){
          timeCountingId = timeCounting();
        }
        self.postMessage({op:op,da:{msg:'timeCount started'}});
        return self;
      },
      
      timeCountPause   : (op,da)=>{
        pause = 1;
        self.postMessage({op:op,da:{msg:'timeCountPause done'}});
        return self;
      },
      
      timeCountStop    : (op,da)=>{
        self.clearInterval(self.timeCountingId);
        $lg('2016::timeCountStop done');
        //self.postMessage({op:op,da:{msg:'timeCountStop done'}});
        return self;
      },
      
      file__open   : (op,da)=>{
        let xhr = new Xhr(da.addr);
            xhr.ask(op,da);
            xhr.rsp((data)=>{
              let dat = JSON.parse(data);
              self.postMessage(dat);
            },(err)=>{
              self.postMessage({op:op,da:{msg:'err',dat:err.message}});
            })
        return self;
      },
      
      timeReport   : (op,da)=>{
        self.postMessage({op:op,da:{msg:'timeReport',dat:ms/1000}});
        return self;
      },
      
      getData   : (op,da)=>{
        //$lg('147::getData');
        dat.getLineLen(2).then((rsp)=>{
          
          self.postMessage({op:op,da:{msg:'getData',dat:rsp}});
        })
        return self;
      },
      
      adjTime   : (op,da)=>{
        let time = da.time;
        let rate = da.rate;
        time = Math.floor(time*1000);
        ms = time;
        self.postMessage({op:op,msg:'adjTime done',dat:da});
        return self;
      },
      
      test   : (op,da)=>{
        self.postMessage({op:op,da:{msg:'test ok',dat:null}});
        return self;
      },
      
      stop   : (op,da)=>{
        
        return self;
      },
    }
    
    let msg = new Message(rsp);
    
    listenToMessage(msg);
    
      