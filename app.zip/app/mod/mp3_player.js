
import { Log,Html,Css,Xhr,Sqlike,Doc,Ajs,Ui,Webman,Rec,Tool,Socket } from '../../import/module/ajs.js'

import WaveSurfer  from '../../import/thirdpart/wavesurfer/wavesurfer.esm.js'

import { ajString } from '../../import/module/ajs.js'

import { Loader } from '../../import/module/loader.js'

//import { stemmer } from '../../import/thirdpart/others/stemming.js'

//import * as eruda  from '../../import/thirdpart/eruda/eruda.js'

import { Dict } from '../../mod/dict.module.js'
import { Mp3Encoder } from '../../mod/mp3Enc.module.js'


export class mp3player{
  
  constructor(){
    
    new Log();
    
    this.lastTime = 0;
    
    this.dur = 0;
    
    this.loopAB = 0;
    
    this.loopDur = [];//[a,b]
    
    this.abList = [];
    
    this.playbackRate = 1;
    
    this.microAdjStartTime = [];
    
    this.adjBtnPos = [0.01,0.01];
    
    this.songId = null;
  
    this.timeSvr = new Webman();
    this.dataSvr = new Webman();
    //this.webman.init();
    this.socket = new WebSocket("ws://127.0.0.1:8081");
    this.socket.addEventListener("message", this.dat.socket.handler);
    //$lg('47::bgb','socket binaryType:',this.socket.binaryType,this.socket.bufferedAmount);
    
    this.avdUpdateTimes = 0;
    
    this.objLrc = this.obj.lrc(this);
    
    this.setTimePoint = 0;
    
    this.autoSetTime = 0;
    
    //1 在.box显示歌词
    //2 在.lrcBox显示歌词
    this.showLrc = 0;
    
    this.dic = new Dict();
    
    this.mp3Enc = new Mp3Encoder();
    
    
    this.MEMO_TYPE_WORD     = 0;
    this.MEMO_TYPE_PHRASE   = 1;
    this.MEMO_TYPE_SENTENTS = 2
    
    
    
    this.flag_RepeatOnlyOneTimes = 0;
    
    this.volArr = [];
    
    //this.audio1 = new Audio();
    this.myAudio = new Audio();
    this.audio2 = new Audio();
    //$lg('110::this.myAudio==undefined',this.myAudio == undefined);
    //$lg('111::this.audio1==undefined',this.audio1 == undefined);
    this.audio.myAudio = this.myAudio;
    
    this.app.run();
  }
  
    app = {
      
        run     : ()=>{
            this.app.load();
            
            //eruda.init();
            
            ( new Ui() ).css.all();
            
            this.ui.frame.html()
                         .css.all();
            this.ui.lrcBox.css();
            
            this.ui.spreadMenu.add();
            this.ui.range.addto('.range-box');
            this.ui.range.event.setup();
            
            this.ui.volume.addto('.range-volume-box');
            this.ui.volume.event.setup();
            
            this.ui.range2.addto('.range2-box');
            this.ui.speed.addto('.speed-box');
            
            
            this.ui.adjBtn.eventSetup();
            
            this.ui.sliderMenu.addto('body');
            
            //this.dat.buildTable();
            //this.dat.tableTbl.fillData();
            
            this.ui.tabMenu.into(`#${this.ui.sliderMenu.id}-content`);
            
            this.ui.article.add();
            
            this.ui.lrcMisc.event.setup();
            
            this.ui.msgbox.css().htm();
            
            this.mod.dict.init();
            this.mod.mp3Encoder.init();
            
            
            this.service.time.init();
            this.service.data.init();
            
            //this.audio.load('./mod/lonely.mp3');
            //this.audio.load('./mp3/i_believe_i_can_fly.mp3');
            //this.audio.load('./mod/audio.mp3');
            //this.audio.load('./mod/the_rain_dialog.mp3');
            //this.audio.load('./mod/the_rain.mp3');
            //this.audio.load('./mp3/lonely.mp3');
            //this.audio.load('./mp3/as_long_as_you_love_me.mp3');
            //this.audio.load('./mp3/the_day_you_went_away.mp3');
            
            //this.webman.file.open('../app/txt/lonely.txt');
            this.ui.lrcBox.event.all();
            
            return this.app;
        },
        
        load    : async ()=>{
            //alert('hello-world-load');
            let t3d = new Loader('../import/thirdpart/');
            await t3d.eruda.load();
            //await t3d.log6.load();
            return this.app;
        },
        
    }
  
    ui  = { 
      
        event : {
          
          handler : ( e )=>{
              
              let type = e.type;
              //if(/focus/.test(type))
              //$lg('164::event.type::bgo',type);
              
              let ds  = e.target;
              let dp  = null;
              let dpp = null;
              if(ds.parentElement) dp = ds.parentElement;
              if(dp && typeof dp.parentElement != undefined)
                  dpp = dp.parentElement;
              
              let parent = (...args)=>{ return dp.classList.contains(...args); }
              let claxx  = (...args)=>{ return ds.className.includes(...args); }
              let clazz  = (...args)=>{ return ds.classList.contains(...args); }
              
              let $event = this.ui.article.content.event;
              let $tabMenu = this.ui.tabMenu;
              
              if( type == 'click' ){
              
                //$lg('2018',ds.className);
                //ui.content
            
                if( clazz( 'focus-btn') ){
                
                  //let ds = e.target;
                  this.ui.fn.highlight(e);
                  
                }
                //----------------------------
                if( clazz( 'line') ){
                
                  return this.ui.article.content.event.click.line(e);
                  
                }else
                if( clazz( 'word') ){
                
                  return this.ui.article.content.event.click.word(e);
                  
                }else
                if( clazz( 'sent') ){
                
                  return this.ui.article.content.event.click.sentence(e);
                  
                }else
                if( claxx( 'btn-' )){
                  if( clazz( 'btn-play-chip') ){
                  
                    return $event.click.btnPlayChip(e);
                    
                  }else
                  if( clazz( 'btn-num') ){
                  
                    return this.ui.article.sentence.menu(e);
                    
                  }else
                  if( clazz( 'btn-play') ){
                  
                    $lg('btn-play');
                    
                  }else
                  if( clazz( 'btn-song-play' )){
                    $tabMenu.tabs.song.play(e);
                  }else
                  if( clazz( 'btn-song-enter' )){
                    $tabMenu.tabs.song.enter(e);
                  }else
                  if( clazz( 'btn-song-lock-media' )){
                    //$lg('231::bgg','btn-song-lock-media');
                    $tabMenu.tabs.song.lock_media(e,ds);
                  }else
                  if( clazz( 'btn-song-remove' )){
                    return;
                    let a = window.confirm('remove it ?');
                    if(a == true){
                      let sid = ds.getAttribute('data-ajs-sid');
                          sid = parseInt(sid);
                      $tabMenu.tabs.song.remove(sid);
                    }
                  }
                }else
                if( claxx( 'tab-' )){
                  if( clazz( 'tab-song' )){
                      //$lg('1222::tab-song');
                      $tabMenu.fn.switchPanel(e);
                      
                      if(Doc.has( '.panel-song .panel-menu .create-article') == false ){
                        $tabMenu.tabs.song.topMenu.build();
                        $tabMenu.tabs.song.list();
                      }
                      $tabMenu.fn.showBodyPanel('.panel-song');
                      
                  }else 
                  if( clazz( 'tab-dict' )){
                      //$lg('2820::tab-dict::bgb');
                      $tabMenu.fn.switchPanel(e);
                      $tabMenu.tabs.dict.htm();
                      $tabMenu.fn.showBodyPanel('.panel-dict');
                  }else
                  if( clazz( 'tab-cata' )){
                      //$lg('2890::tab-cata::bgb');
                      $tabMenu.fn.switchPanel(e);
                      let $cata = Doc.api.query('#sliderMenu .panel-cata .panel-cont');
                          $cata.classList.remove('flex-col-8');
                          $cata.classList.add('flex-col-7');
                          
                      //$tabMenu.fn.cleanBodyPanel('.panel-cata');
                      $tabMenu.tabs.cata.topMenu.build();
                      $tabMenu.tabs.cata.index('.panel-cata .panel-cont');
                      $tabMenu.fn.showBodyPanel('.panel-cata');
                  }else
                  if( clazz( 'tab-book' )){
                    this.ui.book.index();    
                  }else
                  if( clazz( 'tab-info' )){
                      $tabMenu.fn.switchPanel(e);
                      //$lg('2890::tab-cata::bgb');
                      $tabMenu.fn.cleanBodyPanel('.panel-info .panel-cont');
                      $tabMenu.tabs.info.index();
                      $tabMenu.fn.showBodyPanel('.panel-info');
                  }else
                  if( clazz( 'tab-test' )){
                      
                      $tabMenu.fn.switchPanel(e);
                      $tabMenu.fn.cleanBodyPanel('.panel-test .panel-cont');
                      $tabMenu.tabs.test.index();
                      $tabMenu.fn.showBodyPanel('.panel-test');
                  }
                }else
                if( claxx( 'word-cut-' )){
                  
                  let obj = Doc.api.query('.word-cut-frame .yelack');
                  if( obj ) obj.classList.remove('yelack');
                  ds.classList.add('yelack');
                  
                  if( clazz( 'word-cut-reset' )){
                    this.ui.article.tool.fn.wordCut.fn.reset(e);
                    
                  }else
                  if( clazz( 'word-cut-cut' )){
                    this.ui.article.tool.fn.wordCut.fn.cut(e);
                  }else
                  if( clazz( 'word-cut-ok' )){
                    this.ui.article.tool.fn.wordCut.event.clickOkBtn(e);
                  }else
                  if( clazz( 'word-cut-part-list' )){
                    this.ui.article.tool.fn.wordCut.event.clickPartListNum(e,ds);
                  }
                }else
                if( claxx( 'media-' )){
                  if( clazz( 'media-title' )){
                    this.ui.mediaBinding.event.click.title(e,ds,dp);
                  }else
                  if( clazz( 'media-uploader' )){
                    Doc.api.query('.input-file').click();
                  }else
                  if( clazz( 'media-ok' )){
                    this.ui.mediaBinding.event.click.ok(e,ds,dp);
                  }else
                  if( clazz( 'media-select-ext' )){
                    this.ui.mediaBinding.event.click.ext(e,ds);
                  }else
                  if( clazz( 'media-select' )){
                    this.ui.mediaBinding.event.click.select(e,ds);
                  }
                }else
                if( claxx( 'listen-' )){
                  
                  if( clazz( 'listen-mod-bg' )){
                    
                    this.ui.listen.event.closeIndex();
                    
                    let id = dp.id.replace('listen-mod-','');
                    //return alert(id);
                    
                    this.ui.listen.mod.index( parseInt(id) );
                    /*
                    let obj = Reflect.get(this.ui.listen.mod,`m${id}`);
                        obj.index();
                    */
                  
                  }else
                  if( clazz( 'listen-item' )){
                    this.ui.listen.event.clickItem(e,ds);
                  }else
                  if( clazz( 'listen-title' )){
                    this.ui.listen.event.clickTitle(e,ds);
                  }else
                  if( clazz( 'listen-progress' )){
                    this.ui.listen.event.clickProgress(e,ds);
                  }else
                  if( clazz( 'listen-menu' )){
                    this.ui.listen.event.clickMenu(e,ds);
                  }else
                  if( clazz( 'listen-pre' )){
                    this.ui.listen.event.clickPre(e,ds);
                  }else
                  if( clazz( 'listen-next' )){
                    this.ui.listen.event.clickNext(e,ds);
                  }else
                  if( clazz( 'listen-play' )){
                    this.ui.listen.event.clickPlay(e,ds);
                  }else
                  if( clazz( 'listen-skip' )){
                    this.ui.listen.event.clickSkip(e,ds);
                  }else
                  if( clazz( 'listen-stop' )){
                    this.ui.listen.event.clickStop(e,ds);
                  }else
                  if( clazz( 'listen-play-example' )){
                    this.ui.listen.event.clickPlayExample(e,ds);
                  }else
                  if( clazz( 'listen-answer' )){
                    this.ui.listen.event.ClickAnswerOption(e,ds);
                  }else
                  if( clazz( 'listen-mark-unknow' )){
                    this.ui.listen.event.MarkUnknow(e,ds);
                  }else
                  if( clazz( 'listen-show-info' )){
                    this.ui.listen.event.ShowInfo(e,ds);
                  }else
                  if( clazz( 'listen-input-finish' )){
                    this.ui.listen.event.clickFinish(e,ds);
                  }else
                  if( clazz( 'listen-show-input' )){
                    this.ui.listen.event.ShowInput(e,ds);
                  }else
                  if( clazz( 'listen-show-option' )){
                    this.ui.listen.event.ShowOption(e,ds);
                  }else
                  if( clazz( 'listen-show-item' )){
                    this.ui.listen.event.ShowItem(e,ds);
                  }else
                  if( clazz( 'listen-show-right-answer' )){
                    this.ui.listen.event.ShowRightAnswer(e,ds);
                  }else
                  if( clazz( 'listen-show-text' )){
                    this.ui.listen.fn.showText(e,ds);
                  }
                  
                }else
                if( clazz( 'cont-head-box' )){

                    //e.stopPropagation();
                    
                    let ds = e.target;
                    
                    //$lg('1123::text::bgb',ds.innerText);
                    
                    this.ui.fn.highlight(e);
                    
                    $tabMenu.fn.hideBodyPanel();
                    $tabMenu.fn.cleanPanel();
                  
                }else
                if( clazz( 'img' )){
                  $tabMenu.tabs.song.ext(e);
                }else
                if( clazz( 'song-add-ok' )){
                  $tabMenu.tabs.song.add.fn.ok(e);
                }else
                if( clazz( 'list-right' )){
                  let box = Doc.api.query('.ext-tool-box');
                  if( box ) box.parentElement.removeChild(box);
                }else
                if( clazz( 'test-btn-listening' )){
                  this.ui.tabMenu.tabs.test.listening.index();
                }else
                if( clazz( 'info-item-detail' )){
                  this.ui.tabMenu.tabs.info.fn.detail(e);
                }else
                if( clazz( 'word-detail-mn' )){
                  this.mod.dict.event.showInputBox(1);
                }else
                if( claxx( 'dic-' )){
                    if( clazz( 'dic-edit-cancle' )){
                        this.mod.dict.event.clickCancle(e,ds);
                    }else
                    if( clazz( 'dic-edit-enter' )){
                        this.mod.dict.event.clickEnter(e,ds);
                    }
                }else
                if( clazz( 'sts-ass-word' )){
                  this.ui.article.sentence.fn.assWordClick(e);
                }
              }else
              
              if( type == 'animationend'){
                
                if( clazz( 'flash-btn') ){
                
                  return $event.aniEnd.flashBtn(e);
                  
                }
                
              }else
              
              if( type == 'mousedown'){
                
                if( clazz( 'flash-btn') ){
                
                  return $event.mouseDown.flashBtn(e);
                  
                }
                
              }else
              
              if( type == 'scroll'){
                
                if( clazz( 'art-line-box') ){
                  return;
                  return $event.scroll.artLineBox(e);
                  
                }
                
              }else
              
              if( type == 'context'){
                
                if( clazz( 'song-name' )){
                  
                  let a = window.confirm('remove it ?');
                  if(a == true){
                    //let sid = ds.getAttribute('data-ajs-sid');
                    let sid = ds.getAttribute('id').replace('song-id-','');
                        sid = parseInt(sid);
                        //$lg('1310::sid::bgg',sid);
                    $tabMenu.tabs.song.remove(sid);
                  }
                }
                  
                
              }else
              
              if( type == 'touchstart'){
                
                if(clazz('ap-arrow-mid')){
                  //this.ui.article.tool.fn.wordCut.event.touchMove(e);
                }
                  
                
              }else
              
              if( type == 'touchmove'){
                
                if(clazz('ap-arrow-mid')){
                  this.ui.article.tool.fn.wordCut.event.touchMove(e);
                }
                  
                
              }else
              
              if( type == 'touchend'){
                
                if(clazz('ap-arrow-mid')){
                  this.ui.article.tool.fn.wordCut.event.touchEnd(e);
                }
                  
                
              }else
              
              if( type == 'focus'){
                
                if(clazz('listen-input-answer')){
                  $lg('516:listen-input-answer.focus::bgb');
                  this.ui.listen.fn.showBox('.listen-quick-menu',0)
                }
                  
                
              }
              
              
            },
      
          
      
        },
      
        frame      : {
          
          html    : ()=>{
              let h = new Html();
              //h.demo('app-mp3player');
              h.dom('body')
                  .on.click(this.ui.event.handler,0)
                  .on.aniEnd(this.ui.event.handler,0)
                  .on.mouseDown(this.ui.event.handler,0)
                  .on.touchStart(this.ui.event.handler,0)
                  .on.touchMove(this.ui.event.handler,0)
                  .on.touchEnd(this.ui.event.handler,0)
                  .on.focus(this.ui.event.handler,0)
                  .div('#box','.box')
                      .audio('.audio')
               .ok();
              return this.ui.frame;
          },
          
          css     : {
              body : ()=>{
                  let cs = new Css();
                  cs.flex.all();
                  cs.style(['cssApp','cssBody'])
                    .slt('html,body')
                        .kb.col.p(5)
                        .a.bg( cs.rgba.yellow(3,0.5) )
                          .wh('100%','100%')
                          .ovfl.y.scl()
                        .ds()
                    .slt('*')
                        .touch_action('manipulation')
                    .slt('.yelack')
                      .a.bg('yellow !important')
                        .clr('black !important')
                        .ds()
                    .slt('.bg-green')
                      .a.ani('ani-bg-green 0.1s 10 backwards').ds()
                    .slt('.bg-red')
                      .a.ani('ani-bg-red 0.1s 10 backwards').ds()
                    .slt('.bg-flash')
                      .a.ani('ani-bg-flash 0.1s 100 forewards')
                        .ds()
                    .kf('ani-bg-red')
                      .pc(  0).a.bg('transparent').ds()
                      .pc( 50).a.bg('hsl(36,100%,60%)').ds()
                      .pc(100).a.bg('transparent').ds()
                    .kf('ani-bg-green')
                      .pc(  0).a.bg('transparent').ds()
                      .pc( 50).a.bg('hsl(80,60%,80%)').ds()
                      .pc(100).a.bg('transparent').ds()
                    .kf('ani-bg-flash')
                      .pc(  0).a.bg('orange').ds()
                      .pc( 50).a.bg('white').ds()
                      .pc(100).a.bg('orange').ds()
                    .ok(); 
                  return this.ui.frame.css;
              },
              
              box  : ()=>{
                  let cs = new Css();
                  cs.dom('.cssApp')
                    .style('cssBox').slt('.box')
                    .kb.col.p(8)
                    .a.bg( cs.rgba.yellow(6) )
                      .wh('80%','40%')
                      .bor('3px solid '+cs.rgba.yellow(0))
                      .pad('20px')
                      .ovfl.y.scl()
                    .ds()
                    .ok(); 
                  return this.ui.frame.css;
              },
              
              all  : ()=>{
                  Ajs.runAll(this.ui.frame.css,['all']);
                  return this.app;
              },
              
          },
          
        },
      
        spreadMenu : {
          
            add : ()=>{
              /*window.compEveArr.push(()=>{
                $lg('151::spreadMenu.add::bgo');
                //alert('151::spreadMenu.add::bgo');
                
              });*/
              this.ui.spreadMenu.css.all()
                            .htm()
                            .event.setup()
                            .action.spread();
                  
              return this.ui.spreadMenu;
              
            },
          
            css : {
              
              menu  : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Menu'])
                    .slt('.spread-menu')
                        .overflow_y('scroll')
                        .f.fix().blk().ds()
                        .flex.col.p(8050)
                        .a.wh('93%','auto')
                          .max.h('86%')
                          //.ovfl.y.scl()
                          .tr('200px','10px')
                          //.bgd.tsp()
                          .bg(cs.rgba.white(1,0.9))
                          .bord.rad('15px')
                          .bor('6px solid black')
                          .pad('6px')
                          .ds()
                    .slt('.action-spread')
                          .a.ani('ajs-menu-spread 1s ease forwards').ds()
                    .slt('.action-shrink')
                          .a.ani('ajs-menu-shrink 1s ease forwards').ds()
                    .ok();
                  return this.ui.spreadMenu.css;
              },
              
              box   : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Box'])
                    .slt('.spread-box')
                        .f.rel().ds()
                        .flex.col.p(8050)
                        .a.wh('90%','96%')
                          .dsp.flx()
                          .pad('6px')      
                          .bor('0px solid green').ds()
                    .slt('.spread-box *')
                        .touch_action('manipulation')
                    .slt('.range-time-box')
                        .flex.row.p(5)
                        .f.rel().ds()
                        .a.wh('93%').pad('6px')
                          .bor('2px solid black')
                          .bord.rad('6px')
                          .ds()
                    .slt('.AB-slice-box')
                        .flex.row.p(4050)
                        .a.bg(cs.rgba.white(6,1))
                          .wh('99%','99%')
                          .ds()
                    .slt('.AB-list-box')
                        .flex.row.p(4)
                        .a.ovfl.x.scl()
                          .wh('80%','99%')
                          .marg.lef('10px')
                          .marg.rig('10px')
                          .bgd.tsp().ds()
                          //.bg('lightyellow').ds()
                    .slt('.AB-pick-box')
                        //.flex.row.p(5)
                        .flex_shrink(0)
                        .a.wh('116px','96%')
                          .pos.rel()
                          .dsp.blk()
                          .mar('0px')
                          .pad('0px')
                          .bgd.tsp()
                          .ds()
                    .ok();
                  return this.ui.spreadMenu.css;
              },
              
              mAdjBox   : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Micro-adj-Box'])
                    .slt('.micro-adj-box')
                        .f.rel().ds()
                        .flex.col.p(8050)
                        .a.wh('96%','auto')
                          .pad('6px').ds()        
                        .ok();
                  return this.ui.spreadMenu.css;
              },
              
              line  : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Line'])
                    .slt('.spread-line')
                        
                        .f.rel().ds()
                        .flex.row.cc()
                        .a.wh('96%','auto')
                          .pad('6px').mar('6px')        
                          .bor('0px solid black')
                          .bord.rad('10px')
                          .ovfl.x.scl()
                          .bg(cs.rgba.white(6,0.6))
                          .ds()
                    .slt('.line-hide')
                        .a.dsp.no().ds()
                    .slt('.line-show')
                        .a.dsp.flx().ds()
                    .ok();
                  return this.ui.spreadMenu.css;
              },
              
              line2 : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Line2'])
                    .slt('#spmenu .spread-box div:not(:first-child)')
                        .a.dsp.no().ds()
                    .ok();
                    return this.ui.spreadMenu.css;
              },
              
              adjBtn : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Adj'])
                    .slt('.range2-adj-btn')
                        .f.rel().blk().tac().ds()
                        .a.wh('60px','60px')
                          .bor('0px solid red')
                          //.bord.rad('50%').aa()
                          .pad('6px').mar('6px')
                          .fnt.size('4vmin')
                          .tsf(cs.fn.sca(1.7))
                          .ds()
                    
                    .ok();
                    return this.ui.spreadMenu.css;
              },
              
              lbl  : ()=>{
                  let cs = new Css();
                  let color = cs.rgba.white( 5, 1 );
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_label'])
                    
                    .slt('.lrc-lbl-start,.lrc-lbl-end')
                        .f.abs().blk()
                          .fs('3vmin').ds()
                        .a.wh('auto')
                          .bgd.tsp()
                          .pad('0px')
                          .ds()
                    .slt('.lrc-lbl-start')
                        .width(0)
                        .height(0)
                        .border_bottom('20px solid '+color)
                        .border_right('20px solid transparent')
                        .a.bl('0px','0px').ds()
                    .slt('.lrc-lbl-end')
                        .width(0)
                        .height(0)
                        .border_top('20px solid '+color)
                        .border_left('20px solid transparent')
                        .a.tr('0px','0px').ds()
                    .slt('.ab-lbl-start,.ab-lbl-end')
                        .f.abs().blk()
                          .fs('2vmin').ds()
                        .a.wh('auto')
                          .bgd.tsp()
                          .pad('0px')
                          .mar('0px')
                          .bor('0px')
                          .clr('transparent')
                          .bg('transparent')
                          .ds()
                    .slt('.ab-lbl-start')
                        .width(0)
                        .height(0)
                        .border_bottom('20px solid '+cs.rgba.white(6,0.6))
                        .border_right('20px solid transparent')
                        .a.bl('0px','0px').ds()
                    .slt('.ab-lbl-end')
                        .width(0)
                        .height(0)
                        .border_top('20px solid '+cs.rgba.white(6,0.6))
                        .border_left('20px solid transparent')
                        .a.tr('0px','0px').ds()
                    
                    .ok();
                    return this.ui.spreadMenu.css;
              },
              
              btns  : ()=>{
                  let cs = new Css();
                  let color = cs.rgba.white( 6, 1 );
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_btns'])
                    .slt('.spread-box button',{
                        'font-size' : '4vmin',
                        'margin'    : '6px',
                        'min_width' : '65px',
                        
                    })
                    .slt('.range-time-box button')
                        .font_size('26px !')
                        .padding_left('10px !')
                        .padding_right('10px !')
                        .a.bg(cs.rgba.white(1))
                          .ds()
                    /*.slt('.btn-lrc-preline')
                        .a.vtl.ali.top()
                        .ds()*/
                    .slt('.btn-slow-play')
                        .a.tsf(`${cs.fn.roty('180deg')}`)
                        .ds()
                    .slt('.flash')
                        .a.ani('flash-bg-yellow 0.15s ease')
                        .ds()
                    .slt('.btn-rate-add,.btn-rate-mus')
                        .a.bg('hsl(60,60%,86%)')
                          .ds()
                    
                    .slt('.lrc-inp')
                        .f.tac().fs('4vmin').ds()
                        .a.wh('100px','96%')
                          .bor('0px solid white')
                          .bord.rad('10px')
                          .bg(cs.rgba.white(2,1))
                          .ds()
                    .slt('.btn-a-forw,.btn-a-back,.loop-time-a>div,.btn-a-add')
                        .a.bg('hsl(60,20%,90%)')
                          .ds()
                    .slt('.btn-b-forw,.btn-b-back,.loop-time-b>div,.btn-b-add')
                        .a.bg('hsl(60,30%,80%)')
                          .ds()
                    .slt('.btn-AB-pick')
                        //.a.bg('white')
                        .a.wh('90%','96%')
                        .ds()
                    .slt('.AB-list-first,.AB-list-last')
                        //.a.bg('white')
                        .a.wh('auto','90%')
                        .ds()
                    .slt('.lrc-set-AB-A')
                        .a.tsf(cs.fn.roty('180deg'))
                          .h('60px')
                        .ds()
                    .ok();
                    return this.ui.spreadMenu.css;
              },
              
              dur   : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Dur'])
                    .slt('.dur-box')
                        .f.rel().ds()
                        .flex.col.p(5)
                        .a.wh('auto')
                          .bord.rad('10px')
                          //.bg('white')
                          .bgd.tsp()
                        .ds()
                    .slt('.dur')
                        .a.fnt.size('4vmin')
                          .mar('6px')
                          .pad('6px')
                          .bor('1px solid black')
                          //.bgd.tsp()
                          .bg('white')
                          .bord.rad('10px')
                          .ds()
                    .slt('.sp')
                        .a.bor('1px solid black')
                          .h('auto')
                          .fnt.size('2vmin')
                          .bg(cs.rgba.white(2))
                          .clr(cs.rgba.white(12))
                          .ds()
                    .ok();
                    return this.ui.spreadMenu.css;
              },
              
              btn   : ()=>{
                  
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Btn'])
                    .slt(`.spread-menu button,.spread-btn`)
                        .a.h('96%')
                          .pad('6px').mar('6px')
                          .fnt.size('4vmin')
                          .bor('1px solid transparent')
                          .bord.rad('10px')
                        .ds()
                        .flex_grow(1)
                        .flex_shrink(0.5)
                    .slt('.btn-time')
                        //.flex_grow(2)
                        
                    .ok();
                  return this.ui.spreadMenu.css;
              },
              
              ani   : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Ani'])
                    .kf('ajs-menu-spread')
                        .pc(  0).a.wh('70px','70px')
                                  .opc(0.6)
                                  .bord.rad('35px').ds()
                        .pc( 99).a.wh('93%','70px')
                                  .bord.rad('35px').ds()  
                        .pc(100).a.wh('96%','auto')
                                  .opc(1)
                                  .bord.rad('35px').ds()
                    .kf('ajs-menu-shrink')
                        .pc(  0).a.wh('96%','70px')
                                  .opc(1)
                                  .bord.rad('35px').ds()
                        .pc( 50).a.wh('70px')
                                  .bord.rad('35px').ds()
                        .pc(100).a.wh('70px')
                                  .opc(0.6)
                                  .bord.rad('50%').ds()
                    .kf('flash-bg-yellow')
                        .pc(  0).a.bg('yellow').ds()
                        .pc(100).a.bg('yellow').ds()
                    .kf('flash-working-yellow')
                        .pc(  0).a.bg('yellow').ds()
                        .pc( 50).a.bg('white').ds()
                        .pc(100).a.bg('yellow').ds()
                    .ok();
                  return this.ui.spreadMenu.css;
              },
              
              other : ()=>{
                  let cs = new Css();
                  cs.style(['cssAjs','cssUi','cssSpreadMenu','css_Other'])
                    .slt('.spread-box-hide')
                        .a.dsp.no().ds()
                    .slt('.spread-box-show')
                        .a.dsp.flx().ds()
                    .slt('.flex-row-5')
                        .flex.row.p(5)
                    .slt('.flash-working')
                        .a.ani('flash-working-yellow 0.2s backwards '+cs.t.infi)
                        .ds()
                    .slt('.lrc-box')
                        .a.ovfl.y.scl()
                        .ds()
                    .ok();
                  return this.ui.spreadMenu.css;
              },
              
              all   : ()=>{
                
                Ajs.runAll(this.ui.spreadMenu.css,['all']);
                return this.ui.spreadMenu;
                
              },
              
              
            },
            
            htm : ()=>{
                let spcode = ':';
                let h = new Html();
                let [spbtn,spline] = ['spread-btn','spread-line'];
                h.dom('body')
                  .div('#spmenu','.spread-menu').top()
                    .div('.spread-box spread-box-hide').as(1)
                        .div('.spread-line',1).as(10)
                            .button('.spread-btn btn-menu flash-btn','!\u2630',10)
                            .button('.spread-btn btn-slow-play flash-btn','!\u27a0',10)
                            .button('.spread-btn top-rate-show','!1.0x',10)
                            .button('.spread-btn btn-fast-play flash-btn','!\u27a0',10)
                            .button('.spread-btn btn-play','!\u25b6',10)
                            .button('.spread-btn btn-lrc','!\u21c8',10)
                            .button('.spread-btn btn-ext','!\u25bd',10)
                        .div('.spread-line',1).as(20)
                            .button('.spread-btn btn-time yelack','!\u25f3',20)
                            .button('.spread-btn btn-vol','!\u266a',20)
                            .button('.spread-btn btn-speed','!\u279f',20)
                            .button('.spread-btn btn-play-loop','!\u267e',20)
                            .button('.spread-btn btn-play-AB','!\u21b9',20)
                            .button('.spread-btn btn-play-AB-one','!\u21e5',20)
                            .button('.spread-btn btn-AB','!\u2756',20)
                            .button('.spread-btn btn-AB-list','!\u2505',20)
                            .button('.spread-btn btn-lrc-tool','!\u2699',20)
                        .div('.spread-line range-time-box',1).as(0)
                            .button('.spread-btn btn-time-now','!00:00',0)
                            .div('.spread-line range-box',0)
                            .button('.spread-btn btn-time-dur','!00:00',0)
                        .div('.spread-line range-volume-box line-hide',1)
                        .div('.spread-line speed-box line-hide',1)
                        .div('.spread-line range2-adj-box line-hide',1).as(0)
                            .span('.range2-adj-btn zoom-out flash-btn','!\u229d',0)
                            .div('.spread-line range2-box',0)
                            .span('.range2-adj-btn zoom-in flash-btn','!\u2719',0)
                        .div('.spread-line AB-slice-box line-hide',1).as(0)
                            .button('.spread-btn AB-list-remove','!\u00a4',0)
                            .div('.AB-list-box',0)
                            .button('.spread-btn AB-list-save','!\u272a',0)
                            
                        .div('.spread-line line-loop-a line-hide',1).as(20)
                            .div('loop-time-a flex-row-5',20).as(11)
                                .div('.dur-box',11).as().span('.dur dur-mm','!00',0)
                                //.div('.dur-box',11).as().span('.dur sp',`!${spcode}`,0)
                                .div('.dur-box',11).as().span('.dur dur-ss','!00',0)
                                //.div('.dur-box',11).as().span('.dur sp',`!${spcode}`,0)
                                .div('.dur-box',11).as().span('.dur dur-ms','!000',0)
                            .button('.spread-btn btn-a-add flash-btn','!\u2691',20)
                            .button('.spread-btn btn-a-back flash-btn','!\u25c1',20)
                            .button('.spread-btn btn-a-forw flash-btn','!\u25b7',20)
                            .button('.spread-btn btn-time-move-up flash-btn','!\u25b2',20)
                            .button('.spread-btn btn-rate-add flash-btn','!\u25b3',20)
                            //.button('.spread-btn btn-a-rate-mus flash-btn','!-',20)
                        .div('.spread-line line-loop-b line-hide',1).as(20)
                            .div('loop-time-b flex-row-5',20).as(11)
                                .div('.dur-box',11).as().span('.dur dur-mm','!00',0)
                                //.div('.dur-box',11).as().span('.dur sp',`!${spcode}`,0)
                                .div('.dur-box',11).as().span('.dur dur-ss','!00',0)
                                //.div('.dur-box',11).as().span('.dur sp',`!${spcode}`,0)
                                .div('.dur-box',11).as().span('.dur dur-ms','!000',0)
                            .button('.spread-btn btn-b-add flash-btn','!\u2691',20)
                            .button('.spread-btn btn-b-back flash-btn','!\u25c1',20)
                            .button('.spread-btn btn-b-forw flash-btn','!\u25b7',20)
                            .button('.spread-btn btn-time-move-down flash-btn','!\u25bc',20)
                            //.button('.spread-btn btn-b-rate-add flash-btn','!+',20)
                            .button('.spread-btn btn-rate-mus flash-btn','!\u25bd',20)
                        .div('.spread-line line-lrc-misc line-hide',1).as(0)
                            .button('.lrc-btn btn-lrc-mark','!\u2610',0)
                            .button('.lrc-btn btn-lrc-adj','!\u21c5',0)
                            .button('.lrc-btn lrc-set-AB-A','!\u22b8',0)
                            .button('.lrc-btn lrc-set-AB-B','!\u22b8',0)
                          
                            .button('.lrc-btn btn-lrc-save-all flash-btn','!\u272a',0)
                            .button('.lrc-btn btn-lrc-save-one flash-btn','!\u25a4',0)
                            .button('.lrc-btn btn-lrc-test flash-btn','!test',0)
                        .div('.spread-line line-lrc-tool line-hide',1).as(0)
                            .button('.lrc-btn btn-lrc-firstline','!\u22d6',0)
                            .button('.lrc-btn btn-lrc-lastline','!\u22d7',0)
                            /*.input.text('.lrc-inp btn-lrc-lineidx',0)
                                  .at.value('0')*/
                            .button('.lrc-btn btn-lrc-preword','!\u00ab',0)
                            .button('.lrc-btn btn-lrc-preline','!\u21da',0)
                            .button('.lrc-btn btn-lrc-lineidx','!0',0)
                            .button('.lrc-btn btn-lrc-nextline','!\u21db',0)
                            .button('.lrc-btn btn-lrc-nextword','!\u00bb',0)
                            //.button('.lrc-btn btn-lrc-pause','!\u25b6',0)
                        .div('.spread-line lrc-box line-hide flex-row-4',1);
                   
                    h.queryAll(`*`).on.dblClick((e)=>{
                        e.preventDefault();
                        e.stopPropagation();
                    },0);
                    
                    [...(h.queryAll(`.line-lrc-tool>button,.btn-lrc-save`).result)].forEach((ds)=>{
                        ds.setAttribute('disabled',true);
                    });
                    
                    //state button
                    h.queryAll(`*[class*='btn']:not(.flash-btn)`).on.click((e)=>{
                        
                        let dsp = (anyStr,cl=['hide','show'],objs=(Doc.api.queryAll(anyStr)))=>{
                            objs.forEach((obj)=>{
                              //if(obj.className.indexOf('AB-list-box')>-1)$lg('269::className::bgo',obj.className);
                              obj.classList.remove(`line-${cl[0]}`);
                              obj.classList.add(`line-${cl[1]}`);
                            })
                        };
                        
                        let ds = e.target;
                        let val = 0;
                        
                        if(ds.classList.contains('yelack')){
                          ds.classList.remove('yelack');
                          val = 0;
                        }else{
                          ds.classList.add('yelack');
                          val = 1;
                        }
                        
                        if(ds.classList.contains('btn-lrc-tool')){
                          this.setTimePoint = ds.classList.contains('yelack') ? 1 : 0;
                          this.setTimePoint == 1 ? dsp('.line-lrc-tool,.lrc-box') : dsp('.line-lrc-tool,.lrc-box',['show','hide']);
                          this.setTimePoint == 1 ? dsp('.line-lrc-misc,.lrc-box') : dsp('.line-lrc-misc,.lrc-box',['show','hide']);
                          this.setTimePoint == 1 ? this.showLrc ++ : this.showLrc --;
                          if(this.objLrc && this.objLrc.ready){
                            this.ui.spreadMenu.fn.disLrcTool(false);
                          }
                          
                        }else
                        if(ds.classList.contains('btn-time')){
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          val == 1 ? dsp('.range-time-box') : dsp('.range-time-box',['show','hide']);
                        }else
                        if(ds.classList.contains('btn-AB')){
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          val == 1 ? dsp('.line-loop-a,.line-loop-b,.range2-adj-box') : dsp('.line-loop-a,.line-loop-b,.range2-adj-box',['show','hide']);
                        }else
                        if(ds.classList.contains('btn-AB-list')){
                          //$lg('300::btn-AB-list');
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          val == 1 ? dsp('.AB-slice-box') : dsp('.AB-slice-box',['show','hide']);
                        }else
                        if(ds.classList.contains('btn-AB-pick')){
                          /*this.ui.fn.highlight(e);
                          let abidx = ds.getAttribute('data-ajs-abidx');
                              abidx = parseInt(abidx);
                          //$lg('300::abidx::bgo',abidx);
                          let timeArr = this.abList[abidx];
                          //$lg('303::abidx::timeArr',timeArr);
                          this.loopDur = this.abList[abidx];
                          this.ui.loopAB.replace(timeArr);
                          if(this.loopAB) {
                            this.audio.fn.setCurrTime(this.loopDur[0]);
                          }*/
                          //val = ds.classList.contains('yelack') ? 1 : 0;
                          /*if ( val == 1 ) { ds.innerText = '\u2611';this.autoSetTime = 1; }
                          else            { ds.innerText = '\u2610';this.autoSetTime = 0; }*/
                          //$lg('262::this.autoSetTime::bgy',this.autoSetTime);
                        }else 
                        if(ds.classList.contains('btn-play-AB-one')){
                          this.flag_RepeatOnlyOneTimes = val;
                          //$lg('1097::flag_RepeatOnlyOneTimes',this.flag_RepeatOnlyOneTimes);
                        }else 
                        if(ds.classList.contains('btn-vol')){
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          val == 1 ? dsp('.range-volume-box') : dsp('.range-volume-box',['show','hide']);
                        }else
                        if(ds.classList.contains('btn-speed')){
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          val == 1 ? dsp('.speed-box') : dsp('.speed-box',['show','hide']);
                        }else
                        if(ds.classList.contains('btn-play-loop')){
                          //$lg('277::btn-play-loop::bgo');
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          val == 1 ? this.myAudio.loop = 1 : this.myAudio.loop = 0;
                        }else
                        if(ds.classList.contains('btn-lrc')){
                          val == 1 ? this.showLrc ++ : this.showLrc --;
                        }else 
                        if(ds.classList.contains('btn-lrc-mark')){
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          if ( val == 1 ) { ds.innerText = '\u2611';this.autoSetTime = 1; }
                          else            { ds.innerText = '\u2610';this.autoSetTime = 0; }
                          //$lg('262::this.autoSetTime::bgy',this.autoSetTime);
                        }else
                        if(ds.classList.contains('btn-lrc-save')){
                          val = ds.classList.contains('yelack') ? 1 : 0;
                          /*if ( val == 1 ) { ds.innerText = '\u2611';this.autoSetTime = 1; }
                          else            { ds.innerText = '\u2610';this.autoSetTime = 0; }*/
                          //$lg('262::this.autoSetTime::bgy',this.autoSetTime);
                        }else
                        if(ds.classList.contains('btn-lrc-pause')){
                          this.audio.play();
                          if(this.audio.paused) ds.innerText = '\u25b6';
                          else ds.innerText = '\u2759'.repeat(2);
                        }else
                        if(ds.classList.contains('btn-play')){
                          if(this.audio.paused){
                            this.audio.play();
                            
                          }else {
                            this.audio.pause();
                            
                          }
                        }
                    },0);
                    
                    
                    h.queryAll(`.flash-btn`).on.aniEnd((e)=>{
                        
                        let ds = e.target;
                        let val = 0;
                        //$lg('280::aniEnd::className',ds.className,Log.now());
                        if(ds.classList.contains('flash')){
                          ds.classList.remove('flash');
                          //ds.classList.toggle('flash');
                        }
                        //$lg('284::aniEnd::className',ds.className,Log.now());
                    },0);
                    
                    
                    h.queryAll(`.flash-btn`).on.mouseDown((e)=>{
                        
                        let ds = e.target;
                        let val = 0;
                        //$lg('280::mouseDown::className',ds.className,Log.now());
                        if(ds.classList.contains('flash') == false){
                          ds.classList.add('flash');
                          //ds.classList.toggle('flash');
                        }else{
                          ds.classList.toggle('flash');
                        }
                        
                        if(ds.classList.contains('btn-rate-add')){
                            this.ui.loopAB.setRate('+',e);
                            //$lg('343::rate',this.ui.loopAB.getRate());
                        }else
                        if(ds.classList.contains('btn-rate-mus')){
                            this.ui.loopAB.setRate('-',e);
                            //$lg('347::rate',this.ui.loopAB.getRate());
                        }else
                        if(ds.classList.contains('btn-menu')){
                            Doc.api.query('#spmenu').style.zIndex = 0;
                            Doc.api.query('#sliderMenu').style.zIndex = 100;
                            //$lg('347::rate',this.ui.loopAB.getRate());
                        }
                        //$lg('284::mouseUp::className',ds.className,Log.now());
                    },0);
                    
                    
                    h.queryAll(`.btn-time-move-up,.btn-time-move-down`).on.mouseDown((e)=>{
                        
                        let ds = e.target;
                        let val = 0;
                        //$lg('315::mouseDown::className',ds.className,Log.now());
                        if(ds.classList.contains('btn-time-move-up')){
                          //$lg('315::up::bgo');
                          this.ui.spreadMenu.event.btnAdjAB.action('back',this.ui.loopAB.getRate(),0);
                          this.ui.spreadMenu.event.btnAdjAB.action('back',this.ui.loopAB.getRate(),1);
                        }else if(ds.classList.contains('btn-time-move-down')){
                          //$lg('321::down::bgo');
                          this.ui.spreadMenu.event.btnAdjAB.action('forw',this.ui.loopAB.getRate(),0);
                          this.ui.spreadMenu.event.btnAdjAB.action('forw',this.ui.loopAB.getRate(),1);
                        }
                        //$lg('284::mouseUp::className',ds.className,Log.now());
                        
                    },0);
                        
                    
                        
                       
                    h.ok();
                
                
                 
                return this.ui.spreadMenu;
            },
            
            event : {
              
              menuClick   : (e)=>{
                  //$lg('190::menuClick::bgg');
                  let ds = e.target;
                  //$lg('234::',ds.className);
                  if(ds.classList.contains('spread-menu') == false)return;
                  let val = ds.getAttribute('data-ajs-action');
                  //$lg('237::',val);
                  if(val == 'shrink'){
                      let box = Doc.api.query('#spmenu .spread-box');
                          box.classList.remove('spread-box-show');
                          box.classList.add('spread-box-hide')
                  }
                  Reflect.get(this.ui.spreadMenu.action,val)();
                  return this.ui.spreadMenu;
              },
              
              menuAniEnd  : (e)=>{
                  //$lg('228::bgb','MenuAniEnd');
                  //return;
                  let ds = e.target;
                  let val = ds.getAttribute('data-ajs-action');
                  //$lg('::action',val);
                  //Reflect.get(this.ui.spreadMenu.action,val)();
                  if(val == 'spread'){
                      //$lg('259::bgo','shrink end');
                      /*ds.classList.remove('action-shrink');
                      ds.style.width = '70px';
                      ds.style.height = '70px';
                      ds.style.borderRadius = '50%';
                      */
                  }else if(val == 'shrink'){
                      //$lg('265::bgo','spread end');
                      /*ds.classList.remove('action-spread');
                      ds.style.width = '96%';
                      ds.style.height = 'auto';
                      ds.style.borderRadius = '16px';*/
                      let box = Doc.api.query('#spmenu .spread-box');
                          box.classList.remove('spread-box-hide');
                          box.classList.add('spread-box-show');
                
                  }
                  return this.ui.spreadMenu;
              },
              
              menuTouch   : {
                pars : {
                    ox : 0,
                    oy : 0,
                },      
                start : (e)=>{
                    e.stopPropagation();
                    let x = e.touches[0].offsetLeft;
                    let y = e.touches[0].offsetTop;    
                    let ars = Reflect.ownKeys(e.touches);
                    
                    let pars = this.ui.spreadMenu.event.menuTouch.pars;
                        pars.ox = x;
                        pars.oy = y;
                    return this.ui.spreadMenu.event.menuTouch;
                },
                
                move : (e)=>{
                  
                  e.stopPropagation();
                  let x = e.touches[0].clientX;
                  let y = e.touches[0].clientY;
                  let pars = this.ui.spreadMenu.event.menuTouch.pars;
                  let xx =  x - pars.ox;
                  let yy =  y - pars.oy;
                        
                  let icon = e.target;
                      icon.style.left = xx+`px`;
                      icon.style.top  = yy+`px`;
                  return this.ui.spreadMenu.event.menuTouch;
                },
                
                end : (e)=>{
                    e.stopPropagation();

                  return this.ui.spreadMenu.event.menuTouch;
                },
                
                
              },
              
              btnShowExtLine  : ()=>{
                  
                  let btnShowLine = Doc.api.query('.spread-line:first-child button:last-child');
                                  //.querySelector('button:last-child');
                      btnShowLine.addEventListener('click', (e)=>{
                          //alert('btn5.1');
                          
                          let line2 = Doc.api.query('.css_Line2')
                          if(line2.disabled == false)
                              line2.disabled = true;
                          else
                              line2.disabled = false;
                              //line2.setAttribute('data-ajs-use','no');
                          
                      },false);
                  return this.ui.spreadMenu;
              },
              
              btn_add_click  : ()=>{
                  
                  let btn_add = Doc.api.query('.spread-line .btn-add');
                                  //.querySelector('button:last-child');
                      btn_add.addEventListener('click', (e)=>{
                          //alert('btn5.1');
                          let aud = this.myAudio;
                          let time = aud.currentTime;
                          $lg('352::bgy',`${time-this.lastTime}`);
                          this.lastTime = time;
                          
                      },false);
                  return this.ui.spreadMenu;
              },
             
              btnSetLoop  : ()=>{
                  
                  let btnPl = Doc.api.query('.btn-play-AB');
                                  //.querySelector('button:last-child');
                      btnPl.addEventListener('click', (e)=>{
                          //alert('btn5.1');
                          this.loopAB = ! this.loopAB;
                          if(this.loopAB) btnPl.style.color = 'green';
                          else btnPl.style.color = 'black';
                          
                      },false);
                  return this.ui.spreadMenu;
              },
              
              btnAddAB    : ()=>{
                  let addLabel = (pos=0,widx)=>{
              
                    let pars = [
                        ['start','\u25e3'],
                        ['end','\u25e5']
                      ];
                    let arrow = Doc.api.celm('span','',`lrc-lbl-${pars[pos][0]}`,pars[pos][1]);
                    Doc.api.query(`.lrc-word[data-ajs-widx='${widx}']`).appendChild(arrow);
                    
                    return this;
                  }
            
                  let define = (cl,idx)=>{
                      let btn = Doc.api.query(`.btn-${cl}-add`);
                          btn.addEventListener('click', (e)=>{
                              //alert('btn5.1');
                              let aud  = this.myAudio;
                              let time = aud.currentTime;
                              
                              this.loopDur[idx] = time;

                              this.ui.loopAB.setText(time,String.fromCharCode(idx+97));
                              
                              let pc = time / aud.duration;
                              
                              this.ui.range2.updatePos(pc,idx+1);
                              
                              //b,push dur to abList
                              let btn = 'b';
                              if(e.target.classList.contains('btn-a-add')) btn='a';
                              /*
                              let ab = Doc.api.query('.btn-AB');
                                if(ab.classList.contains('yelack')==0) return;
                              */
                              /*if(this.abList.length >=10){
                                alert('AB list full');
                                return;
                              }*/
                              
                              //let bp = Doc.api.query(`.btn-AB-pick[data-ajs-abidx='0']`);
                              
                              /*if(bp.disabled == true){
                                //this.ui.ABList.setItemVal(0,this.loopDur);
                                this.abList[0][0] = time;
                                    
                                bp.disabled = false;
                                
                              }else{*/
                                
                                
                                
                              if( btn == 'a'){
                                //0x03bf
                                let slen = `${this.abList.length}`.padStart(2,'0');//`01`~`99`
                                let bits = [ parseInt(slen.charAt(0)), parseInt(slen.charAt(1)) ];
                                
                                let iconCode1 =  0x278a + bits[0];
                                let iconCode2 =  0x278a + bits[1];
                                
                                let char = String.fromCharCode(iconCode1)+String.fromCharCode(iconCode2);
              
                                let h = new Html();
                                h.dom('.AB-list-box')
                                  .div('.AB-pick-box').top()
                                    .button('.spread-btn btn-AB-pick',`!${char}`)
                                        .disable('true').data('abidx',this.abList.length)
                                        .on.click((e)=>{
                                          //$lg('902::click');
                                          let ds = e.target;
                                          [...Doc.api.queryAll('.btn-AB-pick')].forEach((elm)=>{
                                            elm.classList.remove('yelack')
                                          })
                                          this.ui.fn.highlight(e);
                                          let abidx = ds.getAttribute('data-ajs-abidx');
                                              abidx = parseInt(abidx);
                                          //$lg('300::abidx::bgo',abidx);
                                          let timeArr = this.abList[abidx];
                                          //$lg('303::abidx::timeArr',timeArr);
                                          this.loopDur = this.abList[abidx];
                                          this.ui.loopAB.replace(timeArr);
                                          if(this.loopAB) {
                                            this.audio.fn.setCurrTime(this.loopDur[0]);
                                          }
                                        },0)
                                    .span('.ab-lbl-start')
                                  .ok();
                                let box = [time,null];
                                this.abList.push(box);
                                  
                              }else 
                              if( btn == 'b'){
                                  if(this.abList.length == 0)return;
                                  //add a button to AB-list-box
                                  //$lg('910::this.abList.length',this.abList.length);
                                  let x = null;
                                  for(let z=this.abList.length-1; z>=0; z--){
                                    //$lg('913::this.abList[z][1]::bgy',`'${this.abList[z][1]}'`,this.abList[z][1] == null);
                                    if(this.abList[z][1] == null){
                                        this.abList[z][1] = time;
                                        x = z;
                                        //$lg('916::x::bgo',x);
                                        break;
                                    }
                                  }
                                  if(x == null) return;
                                  //$lg('922::x::bgo',x);
                                  let e = Doc.api.query(`.btn-AB-pick[data-ajs-abidx='${x}']`);
                                  //if(e == null) return;  
                                      //e.setAttribute('disabled' , false);
                                      e.disabled = false;
                                      e.parentNode.appendChild(Doc.api.celm('span','','ab-lbl-end'));
                                    
                                  //this.ui.ABList.addBtn();
                                  
                              }
                                
                              //}
                              
                          },false);
                  }
                  define('a',0);
                  define('b',1);
                  
                  return this.ui.spreadMenu;
              
              },
              
              btnAdjAB    : {
                  action : (dir,sec,bit)=>{
                          sec = parseFloat(sec).toFixed(3);
                          sec = parseFloat(sec);
                          
                          //$lg('853::sec::bgy',sec,typeof(sec));
                           
                          if(this.loopDur[bit] == null)this.loopDur[bit]=0;
                          if( dir == 'forw' ){
                            //tg.innerText = tnum + nn ;
                            //this.loopDur[bit] += sec;
                            this.loopDur[bit] =  parseFloat(this.loopDur[bit])+sec;
                            //$lg('857::this.loopDur[bit]::bgo',this.loopDur[bit],typeof(this.loopDur[bit]));
                            this.ui.loopAB.setText(this.loopDur[bit],String.fromCharCode(bit+97));
                          }else if( dir == 'back' ){
                            //tg.innerText = tnum - nn >= 0 ? tnum - nn : tnum;
                            //this.loopDur[bit] -= sec;
                            this.loopDur[bit] = parseFloat(this.loopDur[bit]) - sec;
                            //$lg('862::this.loopDur[bit]::bgo',this.loopDur[bit],typeof(this.loopDur[bit]));
                           
                            this.ui.loopAB.setText(this.loopDur[bit],String.fromCharCode(bit+97));
                          }
                          
                          let lrcBtnAdj = Doc.api.query('.btn-lrc-adj');
                          if(lrcBtnAdj.classList.contains('yelack')){
                              this.objLrc.setTime(...this.loopDur);
                          }
                      },
                  click : ()=>{
                      let click = (a)=>{
                        [...Doc.api.queryAll(`.btn-${a}-forw,.btn-${a}-back`)].forEach((btn)=>{
                          btn.addEventListener('click',(e)=>{
                              let ds = e.target;
                              let dir = 'forw';
                              let bit = a.toString().charCodeAt(0)-97;
                              //$lg('454::charCode::bgg',a,bit);
                              if(ds.className.indexOf('back')>=0)dir = 'back';
                              //$lg('454::bgg',ds.className,dir);
                              let tg = Doc.api.query(`.loop-time-${a} .dur[data-ajs-active='1']`);
                              //$lg('456::bgy',tg.className.toString().replace(/dur[\-\s]+/g,'').trim());
                              if(tg){
                                  //$lg('457::bgo',tg.className);
                                  let nn = this.ui.loopAB.getRate();
                                  let sec = 0;
                                  
                                  if(tg.classList.contains('dur-ms')){sec = nn;}else 
                                  if(tg.classList.contains('dur-ss')){sec = nn*10;}else 
                                  if(tg.classList.contains('dur-mm')){sec = nn*10*60;}
                                  //$lg('819::nn,sec',nn,sec);
                                  //let tnum = Number.parseInt(tg.innerText);
                                  
                                  this.ui.spreadMenu.event.btnAdjAB.action(dir,sec,bit);
                                  
                              }else{
                                // 没有指定'时分秒'
                                  //this.ui.loopAb.setRate();
                                  this.ui.spreadMenu.event.btnAdjAB.action(dir,this.ui.loopAB.getRate(),bit);
                              }
                              
                          },false);
                        })
                      }
                      click('a');
                      click('b');
                  },
              },
              
              timeBitSetFocus : ()=>{
                  //let spans = Doc.api.queryAll(`.dur-mm,.dur-ss,.dur-ms`);
                  let spans = Doc.api.queryAll(`.dur:not(.sp)`);
                  for(let span of spans){
                      //$lg('449:cl',span.className);
                      //continue;
                      span.addEventListener('click', (e)=>{
                          let ds = e.target;
                          let pn = ds.parentNode;
                          [...Doc.api.queryAll('.dur')].forEach((span)=>{
                              span.style.backgroundColor = 'white';
                              span.setAttribute('data-ajs-active','0');
                          })
                          ds.style.backgroundColor = 'lightgreen';
                          ds.setAttribute('data-ajs-active','1');
                      },false);
                  }
                  /*
                  define('a',0);
                  define('b',1);*/
                  
                  return this.ui.spreadMenu;
              
              },
            
              fastPlay  : {
                  
                  mousedown : (e)=>{
                      let fsp = Doc.api.query('.btn-fast-play');
                          fsp.addEventListener('mousedown',(e)=>{
                              let aud = this.myAudio;
                                  aud.playbackRate += 0.1;
                                  this.audio.play();
                                  //aud.play();
                                  //this.service.time.req.setRate(aud.playbackRate);
                          },0);
                      
                      return this;
                  },
  
              },
              
              slowPlay  : {
                  
                  mousedown : (e)=>{
                      let fsp = Doc.api.query('.btn-slow-play');
                          fsp.addEventListener('mousedown',(e)=>{
                              let aud = this.myAudio;
                                  aud.playbackRate -= 0.1;
                                  this.audio.play();
                                  //aud.play();
                                  //this.service.time.req.setRate(aud.playbackRate);
                          },0);
                      
                      return this;
                  },
  
              },
              
              
              
              setup       : ()=>{
                    //$lg('190::event.setup::bgg');
                    //this.ui.spreadMenu.event.menuClick();
                    let spMenu = Doc.api.gbid('spmenu');
                        spMenu.addEventListener('click',this.ui.spreadMenu.event.menuClick,false);
                        spMenu.addEventListener('touchstart',this.ui.spreadMenu.event.menuTouch.start,false);
                        spMenu.addEventListener('touchmove', this.ui.spreadMenu.event.menuTouch.move, false);
                        spMenu.addEventListener('touchend',  this.ui.spreadMenu.event.menuTouch.end,  false);
                        spMenu.addEventListener('animationend',  this.ui.spreadMenu.event.menuAniEnd,  false);
                    
                    this.ui.spreadMenu.event.btnShowExtLine();
                    this.ui.spreadMenu.event.btnSetLoop();
                    this.ui.spreadMenu.event.btnAddAB();
                    this.ui.spreadMenu.event.timeBitSetFocus();
                    this.ui.spreadMenu.event.btnAdjAB.click();
                    this.ui.spreadMenu.event.fastPlay.mousedown();
                    this.ui.spreadMenu.event.slowPlay.mousedown();
                    //this.ui.spreadMenu.event.fastPlay.dblclick();
                    return this.ui.spreadMenu;
                },
                
            },
            
            action : {
              
              spread : ()=>{
                  /*let box = Doc.api.query('#spmenu .spread-box');
                      box.classList.remove('spread-box-hide');
                      box.classList.add('spread-box-show');*/
                  let obj = Doc.api.gbid('spmenu');
                      obj.classList.remove('action-shrink');
                      obj.classList.add('action-spread');
                      obj.setAttribute('data-ajs-action','shrink');
                      /*obj.style.width  = '95%';
                      obj.style.height = 'auto';
                      obj.style.borderRadius = '16px';*/
                  return this.ui.spreadMenu;
              },
              
              shrink : ()=>{
                  let box = Doc.api.query('#spmenu .spread-box');
                      box.classList.remove('spread-box-show');
                      box.classList.add('spread-box-hide');
                  let obj = Doc.api.gbid('spmenu');
                      obj.classList.remove('action-spread');
                      obj.classList.add('action-shrink');
                      obj.setAttribute('data-ajs-action','spread');
                      /*obj.style.width = '70px';
                      obj.style.height = '70px';
                      obj.style.borderRadius = '50%';*/
                  return this.ui.spreadMenu;
              },
              
            },
            
            fn : {
              
              lineShow : (anyStr)=>{
                let line = Doc.api.query(anyStr);
                    line.classList.remove('.line-hide');
                    line.classList.add('.line-show');
                return this;
              },
              
              lineHide : (anyStr)=>{
                let line = Doc.api.query(anyStr);
                    line.classList.remove('.line-show');
                    line.classList.add('.line-hide');
                return this;
              },
              
              disLrcTool : (val = true)=>{
                  //$lg('1020::disLrcTool::bgg');
                  [...Doc.api.queryAll(`.line-lrc-tool>button,.btn-lrc-save`)].forEach((ds)=>{
                      ds.disabled = val;
                      //$lg(`1023::${ds.className}::disabled='${ds.disabled}'`);
                  });
                  return this;
              }
              
            },
          
        },
      
        sliderMenu : {
          ds    : null,
          id    : 'sliderMenu',
          addto : async (anyStr)=>{
            let ui  = new Ui();
            let sld = new ui.slider();
                sld.into(anyStr).openby('#spmenu .btn-menu')
                   .id(this.ui.sliderMenu.id)
                   .title('menu')
                   .opc(1)
                   .afterOpen(()=>{
                     /*this.ui.tabMenu.fn.cleanPanel();
                     this.ui.tabMenu.tabs.song.list();*/
                     let elm = Doc.api.query('.cont-head-box .yelack');
                     if(elm){ 
                       //this.ui.tabMenu.fn.cleanPanel();
                       elm.click();
                     }
                   });
            await sld.done();
            this.ui.sliderMenu.ds = sld;
          },
          
          close : ()=>{
            
            Doc.api.query('#sliderMenu .ajs-slider-close').click();
            
          }
          
        },
        
        article : {
          
          ds    : null,
          
          id    : 'article',
          
          add   : async ()=>{
            let ui  = new Ui();
            this.ui.article.ds = new ui.slider();
            let art = this.ui.article.ds;
                art.into('body')
                   .id(this.ui.article.id)
                   .title('article')
                   .bg('white').level(10).opc(0.99)
                   .pos('R');
            await art.done();
            //await art.event.open();
            
          },
          
          content : {
            
            pars : {
              
              
              lastScrollTop : 0,
              
            },
        
            add   : async ()=>{
              //$lg('1218::ui::article::content::add');
              this.ui.article.content.css();
              this.ui.article.tool.add();
              
              await this.ui.article.content.show();
              Doc.api.query('#spmenu').style.zIndex = 100;
              return this;
              
            },
            
            css   : ()=>{
              if(Doc.has('.cssArticle .cssContent'))return;
              
              let cs = new Css();
              
              new Css('.phrase-part,.phrase-input,.locate-result',{
                background      : `hsl(160,30%,70%)`,
                border_radius   : `10px`,
                border          : `3px solid black`,
                padding         : `6px`,
                margin          : `6px`,
              })//.phrase-part,.phrase-input
              new Css('.phrase-input,.phrase-btn',{
                font_size       : '4vmin',
                padding         : `6px`,
                margin          : `6px`,
              })//.phrase-input,.phrase-btn
              new Css('.phrase-input',{
                flex_grow       : 3,
              })//.phrase-input
              new Css('.line-active',{
                background       : new Css().rgba.white(9,0.6),
              })//.bg-lite-yel
              new Css('.tool-line-active,.rec-active',{
                background       : 'rgb(126,162,126)',
              })//.tool-line-active
              new Css('.hide-line',{
                display       : 'none !important',
              })//.hide-line
              new Css('.sent',{
                //flex_wrap       : 'wrap',
                width           : '85%'
              })//.sent
              new Css('.word-box',{
                flex_wrap       : 'wrap',
                width           : '99%'
              })//.word-box
              new Css('.sent-box',{
                //flex_wrap       : 'wrap',
                width           : '99%'
              })//.sent-box
              new Css('.memo-box',{
                flex_wrap       : 'wrap',
                width           : '99%',
          
              })//.memo-box
              new Css('.memo',{
                padding         : '10px',
                margin          : '6px',
                background      : cs.rgba.white(2,0.6),
                border_radius   : '10px',
                font_size       : '36px',
              })//.memo
              
              
              let cont = (()=>{
                let cs = new Css();
                
                let badArr = cs.rgba.getArray('yellow',7);
                let badHsl = cs.rgbToHsl(...badArr);
                let badBg = `hsl(${badHsl[0]*0.8},${badHsl[1]*0.36}%,${badHsl[2]*2.5}%)`;
                let badCo = `hsl(${badHsl[0]+40},${badHsl[1]*0.7}%,${badHsl[2]*0.8}%)`;
                
                let friArr = cs.rgba.getArray('green',7);
                let friHsl = cs.rgbToHsl(...friArr);
                let friBg = `hsl(${friHsl[0]*0.8},${friHsl[1]*0.36}%,${friHsl[2]*2.5}%)`;
                let friCo = `hsl(${friHsl[0]+40},${friHsl[1]*0.7}%,${friHsl[2]*0.8}%)`;
                
                
                cs.style(['cssAjs','cssUi','cssArticle','cssContent','css_Content'])
                  .slt('#article-content')
                      .a.bg('lightgreen')
                        .ovfl.y.scl()
                        .pad('10px')
                        .mar('6px')
                        .t('100px').wh('98%','90%').ds()
                      .ok();
                cs.dom('.cssArticle .cssContent');
                cs.style('cssArtLineBox').slt('.art-line-box')
                    .f.rel().ds()
                    .a.top('280px')
                      .wh('94%','70%')
                      .ovfl.y.scl()
                      .bor('6px solid black')
                      .bord.rad('10px')
                      .pad('10px')
                    .ds()
                    .ok();
                cs.style('cssLine').slt('.line')
                    .f.fs('5vmin').ds()
                    .kb.row.p(7080)
                    .a.w('96%')
                      .flx.wrap.yes()
                      .mar('6px')
                      .pad('6px')
                      .padd.lef('20px')
                      .bg(cs.rgba.white(6,0.6)).ds()
                      .ok();
                cs.style('cssCol').slt('.row')
                    .a.dsp.flx()
                      .flx.dir.row()
                      .flx.wrap.yes()
                      .jc.fs()
                      .ai.fs()
                      .ds()
                      .ok();
                cs.style('cssSent').slt('.sent')
                    .a.w('85%').ds()
                    .ok();
                cs.style('cssBtn').slt('.btn-box')
                    .a.wh('15%','96%').ds()
                    .ok();
                cs.style('cssWord').slt('.word')
                    .min_width('60px')
                    .min_height('60px')
                    .f.tac().ds()
                    .a.mar('6px').pad('10px')
                      .bord.rad('10px')
                      .bg(cs.rgba.white(3,0.6))
                      .clr(cs.rgba.white(12,1))
                      .ds()
                .slt('.word-stranger')
                    //.a.bg('orange')//hsl(46,100%,50%)
                    .a.bg( badBg )
                      .clr( badCo )
                      .ds()
                .slt('.word-friend')
                    //.a.bg('lightgreen')//hsl(136,30%,80%)
                    .a.bgd.clr('hsl(70,46%,70%)')
                      .clr( 'black' )
                      .ds().ok();
                cs.style('cssNum').slt('.btn-num')
                    .a.bgd.clr('orange')
                      .pad('10px')
                      .clr('white').ds()
                  .slt('.btn-play-chip')
                    .a.marg.top('16px !important')
                      .mar('6px')
                      .pad('6px').ds()
                      .ok();
                cs.style('cssFirstWord').slt('.first-word')
                    .a.bgd.clr( 'hsl(70,66%,70%)' )
                      .pad('10px')
                      .clr('black').ds()
                    .ok();
                cs.style('cssType1').slt('.t1')
                    .a.bg( cs.rgba.white(3,0.6) )
                      .clr( cs.rgba.white(9,1) )
                      .pad('10px')
                      
                      .ds()
                    .ok();
                cs.style('cssType2').slt('.t2')
                    .a.bg( cs.rgba.white(3,0.6) )
                      .clr( cs.rgba.white(9,1) )
                      .padd.lef('0px')
                      .marg.lef('0px')
                      
                      //.marg.top('20px')
                      .ds()
                    .ok();
                cs.style('cssType3').slt('.t3')
                    .a.bg( cs.rgba.white(3,0.6) )
                      .clr( cs.rgba.white(9,1) )
                      .ds()
                    .ok();
                cs.style('cssOther')
                  .slt('.word-detail-box')
                      .flex.col.p(7)
                      .a.mar('10px')
                        .pad('10px')
                        .bg('white')
                        .bord.rad('10px')
                        .ds()
                  .slt('.word-detail-box>span')
                      .f.fs('5vmin').ds()
                      .a.marg.lef('30px')
                        .mar('10px')
                        .pad('10px')
                        .bg('white')
                        .ds()
                  .slt('.wd-hidden')
                      //.a.vis.no().ds()
                      //.a.dsp.no().ds()
                      .a.clr('orange').ds()
                  .slt('.wd-visible')
                      //.a.vis.yes().ds()
                      .a.clr('white').ds()
                      //.a.dsp.flx().ds()
                        .ok();
              })()
                
              return this;
              
            },
            
            show  : async (arr = null)=>{
              //$lg('1282::content::show');
              //let msg = Doc.api.query();
              
              //$lg('1347::msg',msg.innerText);
              
                const obj = this.objLrc;
                this.ui.article.content.pars.lastScrollTop = 0;
                if(obj.ready == false)return this;
                let clazz = 'word';
                const h = new Html();
                let box = Doc.api.query('.art-line-box');
                if( box == null ){
                  h.dom('#article-content')
                      .div('.art-line-box')
                      
                      .ok();
                }else{
                  box.innerHTML = '';
                  //box.children.forEach( el =>{ el.parentNode removeChild(el)});
                }
                
                let max = obj.lines.length > obj.lines.length ? 50 : obj.lines.length;
                if( arr ) max = obj.lines.length;
                
                h.dom('.art-line-box')
                    .data('sid',this.songId)
                    .data('max',max)
                    .data('done','0')
                    .data('loading','0');
                    
                for (let i=0; i<max; i++){
                  //$lg('app.js:215',line);
                  
                  if( arr ){
                    
                    if( arr.includes(i) == false ) continue;
                    
                  }
                  
                  let line = obj.lines[i];
                  if( line == null ) continue;
                  let L = line.idx;
                     h.div('.line flex-row-82').data('lidx',L).as(10)
                          .div(10,'.sent flex-col-8').as(0)
                              .div('.word-box flex-row-7',0).as(1)
                              .div('.memo-box flex-row-4',0).as(3)
                                .at.data('data-lidx',line.idx)
                          .div(10,'.btn-box flex-col-82').as(2);
                
                  let hide = '';
                  let sts_start = null;
                  let sts_end = null;
                  
                  //$lg('1497::line.words::bgg',`${line.words.length}`);
                  for (let objWord of line.words){

                    const idx  = objWord.idx;
                    const word = objWord.word;
                    const type = objWord.type;
                    const start = objWord.start;
                    const end = objWord.end;
                    //$lg('1346::objWord::bgb',`${L}:${idx}`,`word:${word}`,`start:${start}`,`end:${end}`);
                    
                    if( idx == 0 ){
                      sts_start = start;
                    }else 
                    if( idx == line.words.length - 1 ){
                      sts_end = end == null ? line.words[line.words.length - 2].end : end ;
                    
                      //$lg('1514::bgy',`'${sts_start}'`,`'${sts_end}'`);
                    }
                    if( sts_start == null || sts_end == null ){
                      hide = ' hide';
                    }else{
                      hide = '';
                    }
                    
                    if(word.length == 0){
                      //$lg('1350::word.length == 0::bgy',`'${word}'`);
                      //continue;
                    };
                    
                    clazz = idx == 0 ? 'word first-word' : 'word';
                    if(type == 1) clazz += ' t1';else 
                    if(type == 2) clazz += ' t2';else 
                    if(type == 3) clazz += ' t3';
                    h.span(`.${clazz} flash-btn`,`!${word}`,1)
                        .data('widx',idx)
                        .data('type',type)
                        .data('txt',word)
                        
                  }
                  
                  h.span('.btn-num',`!${L}`,2)
                      
                  if( hide == ''){
                      h.span(`.btn-play-chip${hide} spread-btn flash-btn`,`!\u25b6`,2)
                        .data('st',sts_start)
                        .data('ed',sts_end)
                        
                  }
                }

                h.ok();
                
                await this.ui.article.content.colorate.all();

                return;    
            },
            
            event : {
              /*
              handler : ( e )=>{
                  
                  let type = e.type;
                  
                  let ds = e.target;
                  let dp = ds.parentNode;
                  let dpp = ds.parentNode.parentNode;
                  
                  let clazz = (...args)=>{ return ds.classList.contains(...args); }
                  
                  let $event = this.ui.article.content.event;
                  
                  if( type == 'click' ){
                  
                    $lg('2018',ds.className);
                  
                    if( had( 'line') ){
                    
                      return this.ui.article.content.event.click.line(e);
                      
                    }else
                    if( had( 'word') ){
                    
                      return this.ui.article.content.event.click.word(e);
                      
                    }else
                    if( had( 'sent') ){
                    
                      return this.ui.article.content.event.click.sentence(e);
                      
                    }else
                    if( had( 'btn-play-chip') ){
                    
                      return $event.click.btnPlayChip(e);
                      
                    }else
                    if( had( 'btn-num') ){
                    
                      return this.ui.article.sentence.menu(e);
                      
                    }else
                    if( had( 'btn-play') ){
                    
                      $lg('btn-play');
                      
                    }
                    
                  }else
                  
                  if( type == 'animationend'){
                    
                    if( had( 'flash-btn') ){
                    
                      return $event.aniEnd.flashBtn(e);
                      
                    }
                    
                  }else
                  
                  if( type == 'mousedown'){
                    
                    if( had( 'flash-btn') ){
                    
                      return $event.mouseDown.flashBtn(e);
                      
                    }
                    
                  }else
                  
                  if( type == 'scroll'){
                    
                    if( had( 'art-line-box') ){
                      return;
                      return $event.scroll.artLineBox(e);
                      
                    }
                    
                  }
                  
                  
                },
              */
              click   :  {
                
                line : (e)=>{
                  
                  [...Doc.api.queryAll('.art-line-box .line-active')].forEach(obj=>{
                    //if( obj.classList.contains('line-active') )
                        obj.classList.remove('line-active')
                  })
                  
                  let ds = e.target;
                  if( ds.classList.contains('line'))
                      ds.classList.add('line-active');
                  else if (ds.classList.contains('sent')){
                    let dp = ds.parentNode;
                        dp.classList.add('line-active');
                  }
                  else if (ds.classList.contains('word')){
                    let dpp = ds.parentNode.parentNode;
                        dpp.classList.add('line-active');
                  }
                  else if (ds.classList.contains('btn-play-chip')){
                    let dpp = ds.parentNode.parentNode;
                        dpp.classList.add('line-active');
                  }
        
                },
                
                word : async (e)=>{
                  e.stopPropagation();
                  const fn = this.ui.article.tool.fn;
                  let btn = Doc.api.query(`#${this.ui.article.id} #article-tool .yelack`);
                      if(btn == null) return;
                  let ds = e.target;
                  let dpp = e.target.parentNode.parentNode;
                  let lidx = dpp.getAttribute('data-ajs-lidx');
                  let widx = ds.getAttribute('data-ajs-widx');
                  if( lidx ) lidx = parseInt( lidx );
                  if( widx ) widx = parseInt( widx );
                  //$lg('1368::btn::bgy',btn.className);
                  const contains = (...args)=>{return btn.classList.contains(...args)};
                  if(contains('a-tool-findword')){
                    await fn.findword(e);
                    this.ui.article.content.colorate.one(e);
                  }else 
                  if(contains('a-tool-findPhrase')){
                    if(e.target.classList.contains('word') == false) return;
                    let idx = e.target.getAttribute('data-ajs-idx');
                    let inp = Doc.api.query('.phrase-input');
                        inp.setAttribute('data-target-idx',idx);
                    let wd = e.target.innerText;
                    inp.value += ' ' + wd;
                    e.target.classList.add('phrase-part');
                    
                  }else 
                  if(contains('a-tool-stranger')){
                    await fn.activitySetVal(e,102,-1);
                    this.ui.article.content.colorate.one(e);
                  }else 
                  if(contains('a-tool-friend')){
                    await fn.activitySetVal(e,103,1);
                    this.ui.article.content.colorate.one(e);
                  }else
                  if(contains('b-tool-editor')){
                    this.ui.article.tool.fn.editorWord(e);
                  }else
                  if(contains('b-tool-menu')){
                    this.ui.article.words.menu(e);
                  }else
                  if(contains('b-tool-voice')){
                    //$lg('b-voice');
                    let ds = e.target;
                    let dpp = e.target.parentNode.parentNode;
                    let lidx = dpp.getAttribute('data-ajs-lidx');
                    let widx = ds.getAttribute('data-ajs-widx');
                    if( lidx ) lidx = parseInt( lidx );
                    if( widx ) widx = parseInt( widx );
                    if( lidx == null || widx == null ) return;
                    this.ui.article.tool.fn.playWord(lidx,widx,1);
                  }else
                  if(contains('b-tool-microAdj')){
                    //$lg('2188::word-microAdj-time');
                    let ds = e.target;
                    /*let dpp = e.target.parentNode.parentNode;
                    let lidx = dpp.getAttribute('data-ajs-lidx');
                    let widx = ds.getAttribute('data-ajs-widx');
                    if( lidx ) lidx = parseInt( lidx );
                    if( widx ) widx = parseInt( widx );*/
                    if( lidx > -1 && widx > -1 ) {
                      this.ui.article.tool.fn.microAdjTime(lidx,widx);
                    }
                  }else
                  if(contains('word-adj-sound')){
                    //$lg('2188::word-microAdj-time');
                    let ds = e.target;
                    /*let dpp = e.target.parentNode.parentNode;
                    let lidx = dpp.getAttribute('data-ajs-lidx');
                    let widx = ds.getAttribute('data-ajs-widx');
                    if( lidx ) lidx = parseInt( lidx );
                    if( widx ) widx = parseInt( widx );*/
                    if( lidx > -1 && widx > -1 ) {
                      this.ui.article.tool.fn.microAdjTime(lidx,widx);
                    }
                  }else
                  if(contains('b-tool-cut')){
                    this.ui.article.tool.fn.wordCut.index({word:ds.innerText});
                  }else
                  if(contains('b-tool-wave')){
                    if( lidx > -1 && widx > -1 ) {
                      this.ui.aiCoach.index(lidx,widx);
                    }
                  }
                  return;
                  
                },
                
                sentence : (e)=>{
                          let ds = e.target;
                          let dp = e.target.parentNode;
                  
                  dp.classList.add('line-active');
                  
                },
                
                btnPlayChip : (e)=>{
                          let ds = e.target;
                          let st = parseFloat( ds.getAttribute('data-ajs-st') );
                          let ed = parseFloat( ds.getAttribute('data-ajs-ed') );
                          if( typeof(st) == 'number' && typeof(st) == 'number' ){
                            this.ui.loopAB.replace( [st,ed] );
                            this.loopAB = 1;
                            let btnPlayAb = Doc.api.query('.btn-play-AB');
                                btnPlayAb.classList.add('yelack');
                            let aud = this.myAudio;
                                aud.currentTime = st;
                                this.audio.play();
                                //$lg('1835::btn-play-clip::bgo',st);
                          }
                },
                
              },
              
              aniEnd : {
                
                
                flashBtn : (e)=>{
                  
                  let ds = e.target;
                        let val = 0;
                        //$lg('280::aniEnd::className',ds.className,Log.now());
                        if(ds.classList.contains('flash')){
                          ds.classList.remove('flash');
                          //ds.classList.toggle('flash');
                        }
                  
                }
                
              },
              
              mouseDown : {
              
                flashBtn : (e)=>{
                  
                  let ds = e.target;
                        let val = 0;
                        //$lg('1396::mouseDown::className',ds.className,Log.now());
                        if(ds.classList.contains('flash') == false){
                          ds.classList.add('flash');
                          //ds.classList.toggle('flash');
                        }else{
                          ds.classList.toggle('flash');
                        }
                  
                }
                
              },
              
              scroll : {
                
                artLineBox : (e)=>{
                  
                  const ds = e.target;
                    
                    //$lg('1366::scroll::bgb',`height:${ds.scrollHeight}`,`clientHeight:${ds.clientHeight}`,`scrollTop:${ds.scrollTop}`);
                    //dds.innerText = `${ds.scrollTop.toFixed(0)}`;
                    let a = parseFloat( ds.scrollHeight );
                    let b = parseFloat( ds.scrollTop + ds.getBoundingClientRect().height );
                    
                    /*let ads = Doc.api.query('.a-tool-ds');
                    ads.innerText = parseFloat(b-a).toFixed(0);
                    */
                    //if (/*Math.floor*/(ds.scrollTop) - p.lastScrollTop == 0) {
                    if( a - b <= 200 ){
                        
                        //alert('1378::scroll bottom');
                        //test.innerText = '-2';
                        //$lg('1381::scroll bottom::bgg');
                        let linebox = Doc.api.query('.art-line-box');
                        let done    = linebox.getAttribute('data-ajs-done');
                        let loading = linebox.getAttribute('data-ajs-loading');
                        if(done == '1') return;
                        if(loading == '1') return;
                        linebox.setAttribute('data-ajs-loading','1');
                        
                        /*let ui = new Ui();
                        let ld = new ui.loading();
                            ld.square.rot('.art-line-box');*/
                            //ld.square.msg('show content');
                        /*this.ui.msgbox.fn.show();*/
                        //alert('1395::showNext');
                        
                        this.ui.article.content.showNext();
                        linebox.setAttribute('data-ajs-loading','0');
                        //ld.square.remove();
                      
                        //this.ui.msgbox.fn.hide();
                        //this.ui.msgbox.fn.hide();
                    }else if(ds.scrollTop == 0){
                        //test.innerText = '-1';
                        //$lg('1392::scroll top::bgb');
                    }
                  
                }
                
              },
              
            },
            
            colorate : {
              
              stranger : async ()=>{
                const sid = this.songId;
                const rsp = await this.service.data.req('tableAware.getList',sid,0);
                if(rsp.da.rst == false)$lg('1603::error::bgo',rsp.da.msg);
                //$lg('1613::rsp',JSON.stringify(rsp.da.dat));
                let words = Doc.api.queryAll(`.art-line-box .word[data-ajs-type='0']:not(.word-friend)`);
                for(let od of words){
                  let txt = od.innerText.toLowerCase();
                  for(let obj of rsp.da.dat.arr){
                    if(txt == obj[0].toLowerCase()){
                        od.classList.add('word-stranger');
                        break;
                    }
                  }
                }
                return this;
              },
              
              friend : async ()=>{
                const sid = this.songId;
                const rsp = await this.service.data.req('tableAware.getList',sid,1);
                if(rsp.da.rst == false)$lg('1603::error::bgo',rsp.da.msg);
                //$lg('1613::rsp',JSON.stringify(rsp.da.dat));
                let words = Doc.api.queryAll(`.art-line-box .word[data-ajs-type='0']:not(.word-stranger)`);
                let arr = [];
                for(let od of words){
                  let txt = od.innerText.toLowerCase();
                  arr.push(txt);
                  for(let obj of rsp.da.dat.arr){
                    //['word','val']
                    if(txt == obj[0].toLowerCase()){
                        od.classList.add('word-friend');
                        break;
                    }
                  }
                }
                $lg('word-friend::bgy',...arr);
                return this;
              },
              
              all : async ()=>{
                this.ui.article.tool.fn.busy(1);
                const sid = this.songId;
                const rsp = await this.service.data.req('tableActivity.listStrangerWord',);
                if(rsp.da.rst == false){
                  $lg('1603::error::bgo',rsp.da.msg);
                  return;
                }
                //$lg('1613::rsp',JSON.stringify(rsp.da.dat));
                let clazz = ['word-stranger' , 'word-friend'];
                let words = Doc.api.queryAll(`.art-line-box .word[data-ajs-type='0']`);
                for(let od of words){
                  let txt = od.innerText;
                  if(od.classList.contains(clazz[0]))od.classList.remove(clazz[0]);
                  if(od.classList.contains(clazz[1]))od.classList.remove(clazz[1]);
                  //if(txt == 'how')$log.lgg('1688::bgb',JSON.stringify(rsp.da.dat.arr));
                  
                  for(let arr of rsp.da.dat.arr){
                    //['word','val']
                    let word = arr[0];
                    let val  = arr[1];
                    let clz = val == -1 ? clazz[0] : clazz[1];
                    if(txt.toLowerCase() == word.toLowerCase()){
                        od.classList.add(clz);
                        if(clz == 'word-stranger' && od.classList.contains('first-word'))od.classList.remove('first-word');
                        
                        //if(txt == 'how')$lg('1696::bgg',word,val,od.className);
                 
                        break;
                    }
                  }
                }
                this.ui.article.tool.fn.busy(0);
                return this;
              },
              
              one : async (e)=>{
                this.ui.article.tool.fn.busy(1);
                const ds = e.target;
                const wd = ds.innerText;
                const sid = this.songId;
                const rsp = await this.service.data.req('tableActivity.getWordValue',wd);
                if(rsp.da.rst == false)$lg('1603::error::bgo',rsp.da.msg);
                if(rsp.da.dat.arr.length == 0){
                  $lg(`1718::not found ${wd} in tableActivity`);
                  return;
                }
                //$lg('2396::rsp',JSON.stringify(rsp.da.dat));
                let clazz = ['word-stranger' , 'word-friend'];
                let words = Doc.api.queryAll(`.art-line-box .word[data-ajs-txt='${wd}']`);
                //$lg('1715::words.length::bgg',words.length);
                //let arr9 = [];
                //[...words].forEach((obj)=>{arr9.push(obj.innerText)});
                //$lg('1727::txt::bgb',...arr9);
                for(let od of words){
                  let txt = od.innerText.toLowerCase();
                  //if(txt == 'parkour')
                  //$lg('1748::txt::bgy',txt);
                  if(od.classList.contains(clazz[0]))od.classList.remove(clazz[0]);
                  if(od.classList.contains(clazz[1]))od.classList.remove(clazz[1]);
                  //if(txt == 'how')$log.lgg('1688::bgb',JSON.stringify(rsp.da.dat.arr));
                  
                  let arr = rsp.da.dat.arr[0];
                    //['word','val']
                    let word = arr[0];
                    //if(word == 'parkour')$lg('1756::word::bgo',word)
                    let val  = arr[1];
                    let clz = val < 0 ?  clazz[0] : clazz[1];
                    if(txt == word.toLowerCase()){
                      
                        
                        od.classList.add(clz);
                        if( od.classList.contains('first-word'))od.classList.remove('first-word');
                        
                        //$lg('1696::bgg',word,val,od.className);
                    }
                  
                }
                this.ui.article.tool.fn.busy(0);
                return this;
              },

            },
            
            mask : (show)=>{
              
              let objs = Doc.api.queryAll(`.word[data-ajs-type='0']`);
              
            },
            
            clean : ()=>{
              
              let box = Doc.api.query('.art-line-box');
              if(box)box.innerHTML = '';
              return this;
              
            },
            
            load : async (sid)=>{
              
                $lg('1840::content::load::bgy');
                
                Doc.api.query('#sliderMenu .ajs-slider-close').click();
                await this.ui.article.ds.event.open();
                $lg('1842::after::open::done::bgy');
                /*let lineBox = Doc.api.gbcl('art-line-box')[0];
                $lg('1844::加载内容,查找lineBox',lineBox);
                
                if(lineBox){ 
                  let djsid = lineBox.getAttribute('data-ajs-sid');
                  $lg('2327::djsid::bgo',`sid:${sid}`,`djsid:${djsid}`,`djsid == sid:${djsid == sid}`);
                  if(parseInt(djsid) == sid) { return };
                }*/
                this.ui.article.content.clean();
                let maxLineNum = await this.service.data.req('tableWord.getNumberOf.maxLineIdx',sid);
                let ui = new Ui();
                let ld = new ui.loading();
                let sq = ld.square;
                    sq.rot('#article-content');
                    sq.msg(maxLineNum);
                await this.dat.fn.buildObjLrcAll(sid,sq);
                if(this.objLrc == null ) return alert('2570:buildObjLrcAll fail');
                
                await this.ui.tabMenu.tabs.song.load(sid);
                await this.ui.article.content.add();
                await this.ui.article.sentence.fn.listMemoAll( sid );
                sq.remove();
  
            },
            
            
            
          },
          
          tool : {
            
            ds : null,
            
            data : {
              
              
              wordCharObj : null,
              
              
            },
            
            rcd : null,
            
            id : 'article-tool',
            
            add : ()=>{
              if(Doc.has(`#${this.ui.article.tool.id} .spread-line`)) return this;
              let ui = new Ui();
              let sp = new ui.spmenu();
                  sp.into('#article-content')
                    .id(this.ui.article.tool.id)
                    .width('96%')
                    .top('360px')
                    .right('10px')
                    .zidx(1)
                    .done();
              this.ui.article.tool.ds = sp;
              this.ui.article.tool.css();
              this.ui.article.tool.htm();
            },
            
            css : ()=>{
              
              if(Doc.api.query('.cssArticle .cssTool'))return;
              
              let tool = (()=>{
                let cs = new Css();
                cs.style(['cssApp','cssArticle','cssTool'])
                    .slt('.a-tool-findword,.a-tool-findPhrase')
                        .f.fs('4vmin').ds()
                        .a.tsf(cs.fn.rotx('180deg'))
                          .ds()
                    .slt('.a-tool-stranger')
                        .a.clr('orange').ds()
                    .slt('.a-tool-friend')
                        .a.clr('green').ds()
                    .slt('.a-tool-busy')
                        .a.clr('lightgreen').ds()
                    .slt('.light-flash')
                        .a.ani('ani-flash-light 0.1s '+cs.t.infi)
                          .ds()
                    .slt('.light-red')
                        .a.clr('orange')
                          .ds()
                    .slt('.light-green')
                        .a.clr('lightgreen')
                          .ds()
                    .kf('ani-flash-light')
                        .pc(  0).a.clr('red').ds()
                        .pc( 50).a.clr('white').ds()
                        .pc(100).a.clr('red').ds()
                    
                    .ok();
              })()
              
              let feedback = (()=>{
                
                new Css('.r-feedback-box',{
                  width           : '40%',
                  border          : '1px solid gray',
                  border_radius   : '6px',
                })//.r-feedback-box
                new Css('.r-feedback-cell',{
                  width           : '49%',
                  //border          : '3px solid black',
                })//.r-feedback-cell
                new Css('.r-feedback-vol',{
                  height          : '10px',
                  padding         : '2px',
                  background      : 'orange',
                })//.r-feedback-box
              
              })()
              
              new Css('.rec-list-box',{
                height            : 'auto',
                max_height        : '450px',
                overflow_y        : 'scroll',
              })//.rec-list-box
              new Css('.rec-list',{
                width             : '96%',
                
              })//.rec-list
              new Css('.tag-speaker-box',{
                overflow_y        : 'scroll',
                max_height        : '450px',
                width             : '96%',
                background        : new Css().rgba.white(6,0.6),
                padding           : '6px',
                margin            : '6px',
                border_radius     : '10px',
              })//.tag-speaker-box
              new Css('.tag-speaker-box>button',{
                min_width         : '70px',
              })//.tag-speaker-box>button
              return this;
            },
            
            htm : ()=>{
              //$lg('1470::dom',`'#${this.ui.article.tool.id} .spread-box'`);
              let htm = new Html();
              htm.dom(`#${this.ui.article.tool.id} .spread-box`)
                  .div('.spread-line line-a').as(1)
                      /*.on.click((e)=>{
                          let ds = e.target;
                          let cts = (...args)=>{return ds.classList.contains(...args);}
                          let val = cts('yelack') ? 1 : 0;
                          return;
                      },0)*/
                      .button(1,'.spread-btn a-tool-busy',`!\u25fc`)
                      .button(1,'.spread-btn a-tool-findword',`!\u260c`)
                      .button(1,'.spread-btn a-tool-findPhrase',`!\u26a3`)
                      .button(1,'.spread-btn a-tool-stranger',`!\u2639`)
                      .button(1,'.spread-btn b-tool-show flash-btn',`!\u25eb`)/*25e78*/
                          .data('show','0')
                      .button(1,'.spread-btn a-tool-friend',`!\u263b`)
                      .button(1,'.spread-btn a-tool-menu',`!\u25b2`)
                      //.button(1,'.spread-btn a-tool-test',`!test`)
                      //.button(1,'.spread-btn a-tool-test2',`!test2`)
                      .button(1,'.spread-btn a-tool-ext',`!\u25bc`)
                      .button(1,'.spread-btn a-tool-sent',`!\u2254`)
                  .div('.spread-line line-phrase line-hide').as(5)
                      .input.text(5,'.spread-btn phrase-input')
                          .at.autofocus(false)
                      .button(5,'.spread-btn phrase-clean',`!x`)
                      .button(5,'.spread-btn phrase-ok',`!\u260c`)
                      .button(5,'.spread-btn phrase-locate-ok',`!\u21b7`)
                      .button(5,'.spread-btn word-add-tag',`!\u2616`)
                          
                  .div('.spread-line line-sent line-hide').as(4)
                      .button(4,'.spread-btn b-tool-text',`!\u274f`)
                      .button(4,'.spread-btn b-tool-voice',`!\u269f`)
                      .button(4,'.spread-btn b-tool-microAdj',`!\u22b6`)
                      .button(4,'.spread-btn b-tool-editor',`!\u270e`)
                      .button(4,'.spread-btn b-tool-wave',`!\u25ed`)
                      .button(4,'.spread-btn b-tool-cut',`!\u22ef`)
                      .button(4,'.spread-btn b-tool-phrase',`!\u25aa\u25aa\u25ab`)
                  .div('.spread-line line-rec line-hide').as(2)
                      /*.on.click((e)=>{
                          let ds = e.target;
                          let cts = (...args)=>{return ds.classList.contains(...args);}
                          let val = cts('yelack') ? 1 : 0;
                          return;
                      },0)*/
                      .div(2,'.spread-btn r-feedback-box flex-row-5').as(20)
                          .div(20,'.r-feedback-cell flex-row-6').as(21)
                              .span(21,'#r-feedback-vol0','.r-feedback-vol')
                          .div(20,'.r-feedback-cell flex-row-4').as(22)
                              .span(22,'#r-feedback-vol1','.r-feedback-vol')
                      .button(2,'.spread-btn r-tool-conf',`!\u269b`)
                      .button(2,'.spread-btn r-tool-start',`!\u25fc`)
                          .data('rec','0')
                      .button(2,'.spread-btn r-tool-start2',`!\u2698`)
                          .data('rec2','0')
                      .button(2,'.spread-btn r-tool-play',`!\u25b6`)
                          .disable(true)
                          .on.click((e)=>{
                            let rec = Doc.api.query('.rec-active');
                            if( rec ){
                              let path = rec.getAttribute('data-ajs-path');
                              if( path ){
                                let name = rec.innerText;
                                let uri = path + '/' +  name;
                                $lg('2144::uri',uri);
                                this.audio.load(uri);
                              }
                            }
                          },0)
                      .button(2,'.spread-btn r-tool-ext',`!\u25bd`)
                  .div('.spread-line rec-list-box flex-col-82 line-hide')
                  .div('.spread-line line-cata line-hide').as(3)
                      .button(3,'.spread-btn cata-tool-set w:10% r:6px p:6px m:3px',`!set`)
                      .button(3,`.spread-btn cata-tool-up w:6% r:6px bor:2px-solid-black m:3px p:3px`,'!\u00ab')
                      .button(3,'.spread-btn cata-tool-btn w:6%',`!ok`)
                          .disable(true)
                      .button(3,'.spread-btn show-speaker-box w:6%',`!\u25bc`)
                          .on.click((e)=>{
                            let box = Doc.api.query('.tag-speaker-box');
                            if( box == null ) return;
                            if( box.classList.contains('line-hide')) {
                              box.classList.remove('line-hide');
                              this.ui.article.tool.fn.cataTool.listSpeaker();
                            }
                            else box.classList.add('line-hide');
                          },0)
                  .div(`.tag-speaker-box line-hide flex-col-7080`)
                      
              .queryAll(`button[class*='a-tool-']`)
                  .on.click((e)=>{
                    let ds = e.target;
                    this.ui.fn.highlight(e);
                    let has = (...args)=>{return ds.classList.contains(...args)}
                    //let add      = (...args)=>{return ds.classList.add(...args)}
                    //let remove   = (...args)=>{return ds.classList.remove(...args)}
                    let toggle   = (...args)=>{return ds.classList.toggle(...args)}
                    /*if(contains('yelack'))
                      toggle('word-stranger');
                      toggle('word-friend');
                    */
                      if(has('a-tool-findPhrase')){
                        let tool = this.ui.article.tool.ds;
                            //在#article-tool下面查找.spread-line,找到后排除.line-a
                            //翻转除.lina-a以外的.spread-line，显示改隐藏，隐藏改显示
                            tool.fn.turn('#article-tool .line-phrase');
                        //this.ui.article.tool.fn.findPhrase();     
                      }else
                      if(has('a-tool-stranger')){
                        //toggle('a-tool-stranger');
                        //Doc.api.query('.a-tool-friend').classList.toggle('a-tool-friend');
                        //this.ui.article.content.colorate.all();
                      }else 
                      if(has('a-tool-friend')){
                        //toggle('a-tool-friend');
                        //Doc.api.query('.a-tool-stranger').classList.toggle('a-tool-stranger');
                        //this.ui.article.content.colorate.all();
                      }else
                      if(has('a-tool-menu')){
                        let spm = Doc.api.query('#spmenu');
                        let zidx =  spm.style.zIndex;
                        if(zidx == '100')spm.style.zIndex = '0';else 
                        if(zidx == '0')spm.style.zIndex = '100';
                      }else 
                      if(has('a-tool-sent')){
                        let arr = ['rec','cata','phrase','sent']
                        let iid = ds.getAttribute('data-iid');
                        if( iid == null || parseInt( iid ) > arr.length-1 ) iid = 0;
                        iid = parseInt( iid );
                        let which = arr[ iid ];
                        
                        let act = Doc.api.query('.tool-line-active');
                          if( act ) act.classList.remove('tool-line-active');
                        
                        //$lg('2128::obj.className::bgb');
                        if(has('yelack')){
                          let curTool = Doc.api.query(`#article-tool .line-${which}`);
                            if( curTool ) curTool.classList.remove('line-hide')
                          if( which == 'rec' ){ 
                            let acLine = Doc.api.query('.art-line-box .line-active')
                            if( acLine ){
                              curTool.classList.add( 'tool-line-active' )
                              //let lidx = acLine.getAttribute('data-ajs-lidx');
                              
                            }
                          }
                        }
                        else {
                          Doc.api.query(`#article-tool .line-${which}`).classList.add('line-hide');
                          if( which == 'sent' ){
                            let rst = Doc.api.query('.locate-result');
                            if( rst ) rst.classList.remove('locate-result');
                          }
                        }
                        let objs = Doc.api.queryAll(`#article-tool .spread-line`);
                            objs.forEach(obj=>{
                              //$lg('2197',obj.className);
                              if( obj.classList.contains('line-a')  ||
                                  obj.classList.contains(`line-${which}`) ) {
                              }else{  
                                obj.classList.add('line-hide');
                              }
                            })
                        if(has('yelack')){ds.setAttribute('data-iid',iid+1);}
                        
                      }else
                      if(has('a-tool-ext')){
                        let tool = this.ui.article.tool.ds;
                            //在#article-tool下面查找.spread-line,找到后排除.line-a
                            //翻转除.lina-a以外的.spread-line，显示改隐藏，隐藏改显示
                            tool.fn.turn('#article-tool .spread-line:not(.line-a)');
                      }
                      
                  },0)
              .queryAll(`button[class*='b-tool-']`)
                  .on.click((e)=>{
                    let ds = e.target;
                    let dp = e.target.parentElement.parentElement.parentElement;;
                    this.ui.fn.highlight(e);
                    let lidx = parseInt( dp.getAttribute('data-ajs-lidx') );
                    let widx = parseInt( ds.getAttribute('data-ajs-widx') );
                    let contains = (...args)=>{return ds.classList.contains(...args)}
                    //let add      = (...args)=>{return ds.classList.add(...args)}
                    //let remove   = (...args)=>{return ds.classList.remove(...args)}
                    let toggle   = (...args)=>{return ds.classList.toggle(...args)}
                    /*if(contains('yelack'))
                      toggle('word-stranger');
                      toggle('word-friend');
                    */
                      if(contains('b-tool-show')){
                        let action = (anyStr,toAdd=null,toRemove=null)=>{
                          let words = Doc.api.queryAll(`${anyStr}[data-ajs-type='0']`);
                          for(let wd of words){
                            if(toAdd)wd.classList.add(toAdd);
                            if(toRemove)wd.classList.remove(toRemove);
                          }
                        }
                        let btn = Doc.api.query('.b-tool-show');
                        let show = ds.getAttribute('data-ajs-show');
                            show = parseInt(show);
                            if(show > 1 )show=0;
                        if(show == 0){
                          action('.word-stranger','wd-hidden','wd-visible');
                          //action('.word-friend','wd-visible','wd-hidden');
                          btn.innerHTML = '\u25e8';
                        }else 
                        if(show == 1){
                          //action('.word-friend','wd-hidden','wd-visible');
                          action('.word-stranger','wd-visible','wd-hidden');
                          btn.innerHTML = '\u25e7';
                        }else 
                        if(show == 2){
                          //action('.word-friend','wd-visible','wd-hidden');
                          action('.word-stranger','wd-visible','wd-hidden');
                          btn.innerHTML = '\u25eb';
                        }
                            show++;
                            ds.setAttribute('data-ajs-show',show);
                        //alert(show);
                      }else
                      if(contains('b-tool-editor')){
                        
                      }else
                      if(contains('b-tool-voice')){
                        
                      }else
                      if(contains('b-tool-microAdj')){
                        
                      }else
                      if(contains('b-tool-cut')){
                        //this.ui.article.tool.fn.wordCut.index(e);
                      }else
                      if(contains('b-tool-text')){
                        //alert('b-tool-text');
                        this.ui.article.tool.fn.outputArticle();
                      }
                      
                  },0)
              .queryAll(`button[class*='r-tool-']`)
                  .on.click( async (e)=>{
                    let ds = e.target;
                    this.ui.fn.highlight(e);
                    let contains = (...args)=>{return ds.classList.contains(...args)}
                    //let add      = (...args)=>{return ds.classList.add(...args)}
                    //let remove   = (...args)=>{return ds.classList.remove(...args)}
                    let toggle   = (...args)=>{return ds.classList.toggle(...args)}
                    /*if(contains('yelack'))
                      toggle('word-stranger');
                      toggle('word-friend');
                    */
                      if(contains('r-tool-start')){
                        //$lg('1952::rec');
                        if(typeof(MediaRecorder) == undefined){
                          return alert('浏览器不支持或没有录音权限');
                        }
                        //let rcd = this.ui.article.tool.rcd;
                        let drec = ds.getAttribute('data-ajs-rec');
                        if(drec == '0'){
                          $lg('1952::rec::start::bgy');
                          ds.setAttribute('data-ajs-rec','1');
                          let objVol0 = Doc.api.gbid('r-feedback-vol0');
                          let objVol1 = Doc.api.gbid('r-feedback-vol1');
                          
                          document.addEventListener('cpuWorking',(e)=>{
                            //$lg(`2161::cpuWorking::${e.detail}::bgb`);
                            let vol = e.detail;
                            let pc = Math.abs( vol ) / 0.2 * 100;
                            if( pc > 96 ) pc = 96;
                            //$lg('2198',vol,pc,Log.now());
                            if( vol > 0 ){
                              objVol1.style.width = pc + '%';
                              objVol0.style.width = '0';
                            }else{
                              objVol0.style.width = pc + '%';
                              objVol1.style.width = '0';
                            }
                            this.volArr.push(Math.abs( vol ));
                          },0);
                          this.mp3Enc.start();
                          ds.style.color = 'red';
                        }else{
                          /*if(this.ui.article.tool.rcd !== undefined){
                            let blob = this.ui.article.tool.rcd.getBlob();
                            let url = URL.createObjectURL(blob);
                            
                            let linea = Doc.api.query('.line-aud')
                                linea.classList.remove('line-hide');
                                linea.classList.add('line-show');
                            let aud = Doc.api.query('.aud-rec')
                                aud.src = url;
                                aud.controls = true;
                                aud.preload  = true;
                          }   */
                          //$lg('1952::rec::stop');
                          ds.style.color = 'black';
                          ds.setAttribute('data-ajs-rec','0');
                          
                          let lidx = null;
                          let actLine = Doc.api.query('.art-line-box .line-active');
                          if( actLine ){
                            lidx = actLine.getAttribute('data-ajs-lidx');
                            if( lidx ) lidx = parseInt( lidx );
                          }
                          
                          let getAvg = ()=>{
                            let sum = 0;
                            let len = this.volArr.length;
                            this.volArr.forEach( val => {sum += val;})
                            $lg('2226::avg::bgo',sum/len);
                          }
                          let rsp = await this.mp3Enc.stop(this.songId,lidx);
                          $lg('2235',JSON.stringify(rsp));
                          if( rsp.rst == false ) return;
                          
                          let path = rsp.dat.path.replace('../app/','./');
                          let name = rsp.dat.name;
                          let time = rsp.dat.datetime.replace(/\_/g,':');
                          let sid  = parseInt( rsp.dat.sid  );
                              lidx = parseInt( rsp.dat.lidx );
                          let widx = parseInt( rsp.dat.widx );
                          
                          await this.service.data.req('tableMp3.add',sid,lidx,widx,name,path,'me',time);
                          
                          //getAvg();
                          
                          //this.dat.tableMp3.add(sid,name,path,artist,datetime);
                        }
                        
                      }else 
                      if(contains('r-tool-start2')){
                        //$lg('1952::rec');
                        if(typeof(MediaRecorder) == undefined){
                          return alert('浏览器不支持或没有录音权限');
                        }
                        //let rcd = this.ui.article.tool.rcd;
                        let drec2 = ds.getAttribute('data-ajs-rec2');
                        if(drec2 == '0'){
                          $lg('2887::rec::start::bgy');
                          ds.setAttribute('data-ajs-rec2','1');
                          let objVol0 = Doc.api.gbid('r-feedback-vol0');
                          let objVol1 = Doc.api.gbid('r-feedback-vol1');
                          
                          document.addEventListener('cpuWorking',(e)=>{
                            //$lg(`2161::cpuWorking::${e.detail}::bgb`);
                            let vol = e.detail;
                            let pc = Math.abs( vol ) / 0.2 * 100;
                            if( pc > 96 ) pc = 96;
                            //$lg('2198',vol,pc,Log.now());
                            if( vol > 0 ){
                              objVol1.style.width = pc + '%';
                              objVol0.style.width = '0';
                            }else{
                              objVol0.style.width = pc + '%';
                              objVol1.style.width = '0';
                            }
                            this.volArr.push(Math.abs( vol ));
                          },0);
                          this.mp3Enc.start2(this.myAudio);
                          ds.style.color = 'red';
                        }else{
                          /*if(this.ui.article.tool.rcd !== undefined){
                            let blob = this.ui.article.tool.rcd.getBlob();
                            let url = URL.createObjectURL(blob);
                            
                            let linea = Doc.api.query('.line-aud')
                                linea.classList.remove('line-hide');
                                linea.classList.add('line-show');
                            let aud = Doc.api.query('.aud-rec')
                                aud.src = url;
                                aud.controls = true;
                                aud.preload  = true;
                          }   */
                          //$lg('1952::rec::stop');
                          ds.style.color = 'black';
                          ds.setAttribute('data-ajs-rec2','0');
                          
                          let lidx = null;
                          let actLine = Doc.api.query('.art-line-box .line-active');
                          if( actLine ){
                            lidx = actLine.getAttribute('data-ajs-lidx');
                            if( lidx ) lidx = parseInt( lidx );
                          }
                          
                          let getAvg = ()=>{
                            let sum = 0;
                            let len = this.volArr.length;
                            this.volArr.forEach( val => {sum += val;})
                            $lg('2226::avg::bgo',sum/len);
                          }
                          let rsp = await this.mp3Enc.stop(this.songId,lidx);
                          $lg('2940',JSON.stringify(rsp));
                          if( rsp.rst == false ) return;
                          
                          let path = rsp.dat.path.replace('../app/','./');
                          let name = rsp.dat.name;
                          let time = rsp.dat.datetime.replace(/\_/g,':');
                          let sid  = parseInt( rsp.dat.sid  );
                              lidx = parseInt( rsp.dat.lidx );
                          let widx = parseInt( rsp.dat.widx );
                          
                          await this.service.data.req('tableMp3.add',sid,lidx,widx,name,path,'me',time);
                          
                          //getAvg();
                          
                          //this.dat.tableMp3.add(sid,name,path,artist,datetime);
                        }
                        
                      }else 
                      if(contains('r-tool-play')){
                        $lg('1968::rec-play');
                        //let rec = this.ui.article.tool.rec;
                        //if(rec)
                      }else
                      if(contains('r-tool-conf')){
                        $lg('2255::rec-conf');
                        this.ui.article.tool.fn.recTool.config.index();
                      }else
                      if(contains('r-tool-ext')){
                        $lg('2255::rec-ext');
                        if(ds.classList.contains('yelack')){
                          let lidx = -1;
                          let actLine = Doc.api.query('.line-active');
                          if( actLine ) lidx = actLine.getAttribute('data-ajs-lidx');
                          if( typeof(lidx) == 'string' ) lidx = parseInt( lidx );
                          $lg('2374::lidx',lidx);
                          await this.ui.article.tool.fn.recTool.ext.listByLine(this.songId,lidx);
                          Doc.api.query('.rec-list-box').style.display = 'flex';
                          
                        }else{
                          Doc.api.query('.rec-list-box').style.display = 'none';
                          let p = Doc.api.query('.r-tool-play');
                          if( p ) {
                            p.style.color = 'black';
                            p.disabled = true;
                          }
                        }
                      }
                      
                  },0)
              .queryAll(`button[class*='sent-tool-']`)
                  .on.click((e)=>{
                    let ds = e.target;
                    this.ui.fn.highlight(e);
                    let has = (...args)=>{return ds.classList.contains(...args)}
                    
                    if(has('sent-tool-copy')){
                      this.ui.article.sentence.fn.copy(e);
                    }else 
                    if(has('sent-tool-tsl')){
                      this.ui.article.sentence.fn.tsl(e);
                    }else
                    if(has('sent-tool-phrase')){
                      this.ui.article.sentence.fn.phrase(e);
                    }
                    
                  },0)
              .queryAll(`button[class*='phrase-']`)
                  .on.click((e)=>{
                    let ds = e.target;
                    this.ui.fn.highlight(e);
                    let has = (...args)=>{return ds.classList.contains(...args)}
                    
                    if(has('phrase-ok')){
                      let ph = Doc.api.query('.phrase-input').value.trim();
                      //$lg('2103::phrase-input::bgo',ph);
                      this.ui.article.tool.fn.findword(ph);
                    }else
                    if(has('phrase-locate-ok')){
                      //$lg('3054::locate-ok');
                      let ph = Doc.api.query('.phrase-input');
                      if( ph ) ph = ph.value;
                      //let idx = ph.getAttribute('data-target-idx');
                      //$lg('3057::phrase-input::bgo',`ph:${ph}`);
                      this.ui.article.tool.fn.locateWord(ph,e);
                    }else
                    if(has('phrase-clean')){
                      Doc.api.query('.phrase-input').value = '';
                      [...Doc.api.queryAll('.phrase-part')].forEach((obj)=>{
                        if(obj)obj.classList.remove('phrase-part');
                      })
                    }
                    
                  },0)
              .queryAll(`*[class*='cata-tool-']`)
                  .on.click((e)=>{
                    let ds = e.target;
                    this.ui.fn.highlight(e);
                    let has = (...args)=>{return ds.classList.contains(...args)}
                    
                    if(has('cata-tool-set')){
                      
                      this.ui.article.tool.fn.cataTool.set(e);
                      
                    }else
                    if(has('cata-tool-ops')){
                      
                      this.ui.article.tool.fn.cataTool.ops(e);
                      
                    }else
                    if(has('cata-tool-up')){
                      
                      this.ui.article.tool.fn.cataTool.up();
                      
                    }
                  
                    
                  },0)
              .ok();
              
              return this;
              
            },
            
            fn : {
              
              wordCut : {
                
                data : {
                  
                  partlist : null,
                  
                },
                
                index :  (e)=>{
                  let ds,dp,wd;
                  if( e.target ){
                    ds = e.target;
                    dp = e.target.parentNode;
                    wd = dp.firstChild.innerText;
                  }else{
                    wd = e.word;
                  }
                  //alert(wd);

                  let css = (()=>{
                    
                    if(Doc.has(`style[class*='word-inline']`)) return;
                    
                    let cs = new Css();
                    
                    new Css('.word-cut-frame,.word-cut-frame *',{
                      width           : '96%',
                      height          : 'auto',
                      border_radius   : '10px',
                      border          : '0px solid black',
                      margin          : '6px',
                      padding         : '6px',
                      font_size       : '4vmin',
                      text_align      : 'center',
                    })//.word-cut-frame,.word-cut-frame *
                    new Css('.word-char',{
                      position        : 'relative',
                      margin          : '2px',
                      //padding         : '10px',
                      padding_left    : '6px',
                      padding_right   : '6px',
                      flex_shrink     : 0.5,
                      border          : '0px solid black',
                      //border_radius   : '6px',
                    })//.word-char
                    new Css('.word-cut-list',{
                      border          : '1px solid black',
                      background      : 'hsla(60,30%,70%,0.6)',
                      padding_top     : '0px',
                      padding_bottom  : '0px',
                    })//.word-cut-list
                    new Css('.ap-div-list',{
                      margin_bottom  : '0px',
                    })//.ap-div-list
                    
                    
                    new Css('.word-cut-div,.ap-arrow',{
                      width           : '1px',
                      height          : '60px',
                      border          : '0px solid black',
                      background      : 'transparent',
                      padding         : '1px',
                      padding_top     : '0px',
                      padding_bottom  : '0px',
                      margin_top      : '0px',
                      margin_bottom   : '0px',
                      border_radius   : '0px',
                      flex_grow       : 2.5,
                    })//.word-cut-div,.ap-arrow'
                    new Css('.ap-arrow-top',{
                      background      : 'red',
                    })//.ap-arrow-top
                    new Css('.ap-arrow-box',{
                      position        : 'absolute',
                      top             : '200px',
                      margin_top      : '0px',
                      left            : '100px',
                      width           : '60px',
                      height          : '120px',
                      //background      : cs.rgba.white(6,0.6),
                      background      : 'transparent',
                      border          : '0px solid red',
                      flex_grow       : 1,
                      //font_size       : '6vmin',
                    })//.ap-arrow-box
                    new Css('.ap-mn-list',{
                      margin          : '10px',
                      margin_top      : '100px',
                      background      : 'lightyellow',
                    })//.ap-fn-list
                    new Css('.ap-arrow-mid',{
                      width           : 0,
                      height          : 0,
                      border_left     : '20px solid transparent',
                      border_right    : '20px solid transparent',
                      border_bottom   : '60px solid red',
                      border_radius   : '0px',
                      flex_grow       : 1,
                      flex_shrink     : 0.5,
                      z_index         : 100,
                    })//.ap-arrow-mid
                    new Css('.ap-arrow-bot',{
                      width           : 0,
                      height          : 0,
                      border          : '22px solid red',
                      border_radius   : '0px',
                      flex_grow       : 1,
                      flex_shrink     : 0.5,
                    })//.ap-arrow-bot
                    new Css('.word-inline',{
                      height          : '50px',
                      white_space     : 'pre',
                      overflow_x      : 'scroll',
                      overflow_y      : 'clip',
                      //text_overflow   : 'ellipsis',
                    })//.word-inline
                    new Css('.word-part,.word-cut-btn',{
                      border        : '3px solid black !',
                    })//.word-part
                  })()
                  
                  let htm = (()=>{
                      let htm = new Html();
                      htm.dom()
                          .div('.word-cut-frame flex-col-5').top()
                              .div('.word-cut-list ap-parts-list flex-row-4').as(3)
                              .div('.word-cut-list ap-result-list flex-row-5').as(3)
                                  .span(3,'.word-part',`!${wd}`)
                              .div('.word-cut-list ap-div-list flex-row-5').as(1)
                              .div('.word-cut-list ap-arrow-box flex-col-5').as(2)
                                  .at.draggable(true)
                                  .span(2,'.ap-arrow ap-arrow-top')
                                  .span(2,'.ap-arrow ap-arrow-mid')
                              .div('.word-cut-list ap-mn-list flex-col-4').as(5)
                              .div('.word-cut-list ap-fn-list flex-row-5').as(4)
                                  .button(4,'.word-cut-btn flash-btn word-cut-reset','!reset')
                                      
                                  .button(4,'.word-cut-btn flash-btn word-cut-cut','!cut')
                                    
                              .div('.word-cut-btn flash-btn word-cut-ok','!ok');
                    let i = -1;
                    for(let char of wd){
                        i++;
                        htm.div(1,'.word-char',`${char}`)
                              .data('i',i)
                        /*if(char != wd[wd.length-1]){ 
                          htm.span(1,'.word-cut-div'); 
                        }*/
                    }
                    htm.queryAll(`.flash-btn`).on.aniEnd((e)=>{
                            
                        let ds = e.target;
                        let val = 0;
                        //$lg('280::aniEnd::className',ds.className,Log.now());
                        if(ds.classList.contains('flash')){
                          ds.classList.remove('flash');
                          //ds.classList.toggle('flash');
                        }
                        //$lg('284::aniEnd::className',ds.className,Log.now());
                    },0);
                        
                        
                    htm.queryAll(`.flash-btn`).on.mouseDown((e)=>{
                        
                        let ds = e.target;
                        let val = 0;
                        //$lg('280::mouseDown::className',ds.className,Log.now());
                        if(ds.classList.contains('flash') == false){
                          ds.classList.add('flash');
                          //ds.classList.toggle('flash');
                        }else{
                          ds.classList.toggle('flash');
                        }
                    },0);
                        
                    this.ui.msgbox.fn.show( htm.pack() );
                    
                    this.ui.article.tool.fn.wordCut.fn.initData();
                    
                  })()
                  
                  
                  let chk = (async ()=>{
                    
                    let partArr = await this.dic.webman.request('tableCut.getAllPart',wd);
                    
                    //$log.lgg(JSON.stringify(partArr));

                    if( partArr.length == 0 ) return;
                    
                    this.ui.article.tool.fn.wordCut.data.partList = partArr;
                    
                    this.ui.article.tool.fn.wordCut.fn.showResult(partArr[0]);
                    
                    this.ui.article.tool.fn.wordCut.fn.makePartsList(partArr);
                    
                    
                    
                    
                  })()
                  
                
                },
                
                event : {
                  
                  touchMove : (e)=>{
                    //$lg('3360:wordCut:touchMove::bgb');
                    let ds = e.target;
                        if(ds.classList.contains('ap-arrow-mid')==false)return;
                    let x = parseInt( e.touches[0].pageX );
                        x = x - 130;
                    let dp = e.target.parentNode;
                		    dp.style.left = x + 'px';
                		
                		let charObj = this.ui.article.tool.data.wordCharObj;
                		let charArr = this.ui.article.tool.data.wordCharObj.arr;
                		
                	  //$lg('2146::x',x,arr.join(','));
                	  //let i = -1;
                	  
                	  let bgc = (n)=>{
                      const color = ['lightgreen','lightblue','lightyellow'];
                      if( n > 2 ) n = 0;
                      return color[n];
                    }
                	  
                		for(let obj of charArr){
                		  
                		  if(charObj.cut > 0 && obj.gp < charObj.cut){
                		    continue;
                		  }
                		  
                		  
                		  let char = Doc.api.query(`.word-char[data-ajs-i='${obj.idx}'`);
                		  if( x > obj.left ){
                		    if(char) char.style.backgroundColor = bgc(charObj.cut);
                		    charArr[obj.idx].gp = charObj.cut;
                		    
                		  }else{
                		    if(char) char.style.backgroundColor = bgc(charObj.cut+1);
                		    charArr[obj.idx].gp = charObj.cut+1;
                		    
                		  }
                		  
                		
                		}
  
                    /* let ds = e.target;
                    let charArr = this.ui.article.tool.data.wordCharArr;
                    $log.lgg('2177::charArr::bgb',JSON.stringify(charArr));
                    */
                    let rst = Doc.api.query('.ap-result-list');
                    if(rst)rst.innerHTML = '';
                    let words = [];
                    let htm = new Html();
                    htm.dom('.ap-result-list');
                    
                    let lastGp = -1;
                    for(let obj of charArr){
                      if(obj.gp > lastGp){
                        //if(words[obj.gp] == undefined)
                        words[obj.gp] = '';
                        words[obj.gp] += obj.txt;
                        lastGp = obj.gp;
                      }else{
                        words[obj.gp] += obj.txt;
                      }
                    }
                    this.ui.article.tool.data.wordCharObj.parts = [];
                    for(let word of words){
                          htm.span('.word-part',`!${word}`);
                          this.ui.article.tool.data.wordCharObj.parts.push(word);
                    }
                    htm.ok();
                    //if(ds.classList.contains('ap-arrow-box')==false)return;
                  },
                  
                  touchEnd : async (e)=>{
                    
                    let bgc = (n)=>{
                      const color = ['lightgreen','lightblue','lightyellow'];
                      if( n > 2 ) n = 0;
                      return color[n];
                    }
                    
                    let parts = this.ui.article.tool.data.wordCharObj.parts;
                    let list = Doc.api.query('.ap-mn-list');
                    if(list)list.innerHTML = '';
                    let htm = new Html();
                    htm.dom('.ap-mn-list');
                    let i = -1;
                    for(let part of parts){
                      let rsp = await this.dic.find(part);
                      if(rsp.arr.length == 0)continue;
                      i++;
                      let arr = rsp.arr[0];
                      let wd = arr[1];
                      let mn = arr[3];
                      //$lg('2234',JSON.stringify(rsp));
                      htm.span('.word-part word-inline',`!${wd} ${mn}`)
                          .at.style(`background:${bgc(i)};`);
                    }
                    htm.ok();
                  },
                  
                  clickOkBtn : async (e)=>{
                    
                    //alert('wordCut-ok');
                    let ds = e.target;
                    //let parts = Doc.api.queryAll('.ap-result-list .word-part')
                    await Tool.delay(100);
                    
                    ds.classList.remove('yelack');
                    
                    let arr = this.ui.article.tool.data.wordCharObj.parts;
                    
                    let word = arr.join('');
                    
                    let did = await this.dic.webman.request('tableWord.getId',word);
                    
                    let exist = await this.dic.webman.request('tableCut.exist',did);
                    
                    let todo = 1;
                    
                    if(exist > 0){
                      todo = window.confirm(`"${word}"的[拆词方案]已经存在，需要再次添加吗?`);
                    }
                    
                    if( todo == 0 ) return;
                    //$lg('3440',arr);
                    let rsp = await this.dic.webman.request('tableCut.addword',arr);
                    
                    
                    
                    if(rsp.da.rst == false){
                      this.fn.bg.red(ds);
                      await Tool.delay(500);
                      alert(JSON.stringify(rsp));
                    }
                    else this.fn.bg.green(ds);
                    
                    //alert(JSON.stringify(rsp));
                    
                  },
                  
                  clickPartListNum : (e,ds)=>{
                    
                    let idx = ds.id.replace('partList','');
                    if( idx ) idx = parseInt( idx );
                    
                    //alert(idx);
                    
                    let arr = this.ui.article.tool.fn.wordCut.data.partList[idx];
                    
                    if( arr ) this.ui.article.tool.fn.wordCut.fn.showResult( arr );
                    
                    
                    
                  }
                  
                },
                
                fn : {
                  
                  cut : ()=>{
                    
                    let charObj = this.ui.article.tool.data.wordCharObj;
                    
                    if(charObj) charObj.cut++;
                    
                    //$log.lgg('2208::cut::charObj',JSON.stringify(charObj));
                    
                  },
                  
                  reset : ()=>{
                      this.ui.article.tool.fn.wordCut.fn.initData();
                      let list = Doc.api.query('.ap-mn-list');
                      if(list)list.innerHTML = '';
                  },
                  
                  initData : ()=>{
                    //let ds = e.target;
                    //let dp = e.target.parentNode;
                		let LeftArr = [];
                		//if(this.ui.article.tool.data.wordCharObj == null){
                  		this.ui.article.tool.data.wordCharObj = {
                  		  cut   : 0,
                  		  arr   : [],
                  		  parts : [],
                  		};
                		
                  		let charArr = this.ui.article.tool.data.wordCharObj.arr;
                  		
                  		let widthAll = 0;
                      let chars = Doc.api.queryAll('.word-char');
                  		for(let char of chars){
                    		  let i = char.getAttribute('data-ajs-i');
                    		      i = parseInt(i);
                    		  let width = Doc.api.cspv(char,'width');
                    		      width = parseInt(width.replace('px',''));
                    		      widthAll += width;
                    		  charArr[i] = {
                    		    idx   : i,
                    		    txt   : char.innerText,
                    		    left  : widthAll,
                    		    gp    : 0,
                    		  };
                  		}
                		//}
                		//$lg('2137::LeftArr::bgb',...this.ui.article.tool.data.wordCharObj);
                  },
                  
                  showResult : (arr)=>{
                    
                    arr = arr[1].split(',');
                    
                    if(arr.length == 0 ) return;
                    
                    let rst = Doc.api.query('.ap-result-list');
                    if( rst ) rst.innerHTML = '';
                    
                    let html = new Html();
                    html.dom('.ap-result-list');
                    
                    for(let a of arr){
                      
                      html.span('.word-part',`!${a}`);
                      
                    }
                    
                    html.ok();
                    
                  },
                  
                  makePartsList : (partArr)=>{
                    
                    //let arr = this.ui.article.tool.fn.wordCut.data.partList;
                    
                    let html = new Html();
                    html.dom('.ap-parts-list');
                    for(let i=0; i<partArr.length; i++){
                      
                      html.button(`#partList${i}`,'.btn word-cut-part-list',`!${i}`);
                      
                    }
                    html.ok();
                  },
                  
                  
                }
                
              },
              
              editorWord : (e)=>{
                
                let ds = e.target;
                let dpp = e.target.parentNode.parentNode;
                
                let lidx = parseInt( dpp.getAttribute('data-ajs-lidx' ) );
                let widx = parseInt( ds.getAttribute('data-ajs-widx') );
                
                let css = (()=>{
                  if( Doc.api.query('.Ajs .wordEditBox')) return;
                  Css.root = 'Ajs/wordEditBox';
                  new Css('.word-editor-box *',{
                    font_size        : '5vmin',
                  })
                  new Css('.word-editor-box,.word-editor-line',{
                    display          : 'flex',
                    padding          : '10px',  
                    margin           : '16px',  
                    
                  })//.word-editor-box,.word-editor-line
                  new Css('.word-editor-box',{
                    flex_direction  : 'column',
                    justify_content : 'flex-start',
                    align_items     : 'center',
                    width           : '800px',
                    height          : 'auto',
                  })//.word-editor-box
                  new Css('.word-editor-line',{
                    flex_direction  : 'row',
                    justify_content : 'center',
                    align_items     : 'center',
                    width           : '96%',
                    height          : '70px',
                    padding         : '10px',  
                    margin_bottom   : '30px',
                  })//.word-editor-line
                  new Css('.word-editor-ok',{
                    width           : '96%',
                    background      : 'grey',
                    
                  })//.word-editor-ok
                  new Css('.word-editor-lbl',{
                    width           : '15%',
                  })//.word-editor-lbl
                  new Css('.word-editor-input',{
                    width           : '76%',
                    border          : '0px solid black',
                    
                  })//.word-editor-lbl
                  new Css('.editor-fn-switch',{
                    width           : '96%',
                    
                  })//.editor-fn-switch>*
                  new Css('.editor-fn-switch>*',{
                    width           : '45%',
                    border          : '0px solid black',
                  })//.editor-fn-switch>*
                  Css.root = 'Ajs';
                })()
                
                let htm = (()=>{
                  
                  let oldWord = dpp.querySelector(`.word[data-ajs-widx='${widx}'`);
                  let oldText = oldWord.innerText;
                  let [box,line,input,ok,del,lbl] = ['box','line','input','ok','del','lbl'];
                      [box,line,input,ok,del,lbl].forEach( s =>{ s = 'word-editor-'+s });
                  $lg('2932',box,line,input,ok,del,lbl);
                  let h = new Html();
                  h.dom()
                  .div('.word-editor-box').as(1)
                    .data('todo','editor')
                    .div(1,'.word-editor-line editor-fn-switch').as(2)
                        .button(2,'.btn editor-btn-del word-editor-lbl','删除')
                            .on.click((e)=>{
                              this.ui.fn.highlight(e);
                              let dpp = e.target.parentNode.parentNode;
                                  dpp.setAttribute('data-ajs-todo','delete');
                              Doc.api.query('.word-editor-box .line-new').style.display = 'none';
                            },0)
                        .button(2,'.btn editor-btn-editor word-editor-lbl yelack','修改')
                            .on.click((e)=>{
                              this.ui.fn.highlight(e);
                              let dpp = e.target.parentNode.parentNode;
                                  dpp.setAttribute('data-ajs-todo','editor');
                              Doc.api.query('.word-editor-box .line-new').style.display = 'flex';
                            },0)
                    .div(1,'.word-editor-line').as(2)
                        .span(2,'.btn word-editor-lbl','!范围')
                        .button(2,'.btn editor-range-one yelack','一个')
                        .button(2,'.btn editor-range-all','全部')
                    .div(1,'.word-editor-line').as(2)
                        .span(2,'.btn word-editor-lbl','!旧')
                        .input.text(2,'.word-editor-input word-editor-input-old')
                            .disable(true)
                            .at.value(oldText)
                    .div(1,'.word-editor-line line-new').as(2)
                        .span(2,'.btn word-editor-lbl','新')
                        .input.text(2,'.word-editor-input word-editor-input-new')
                    .div(1,'.word-editor-line').as(2)
                        .button(2,'.btn word-editor-ok','!ok')
                          .on.click(async (e)=>{
                            let ds = e.target;
                            let rsp = null;
                            let oldWord = Doc.api.query('.word-editor-input-old').value;
                            let newWord = Doc.api.query('.word-editor-input-new').value;
                            
                            let arr = newWord.trim().split(' ');
                            
                            let action = 0;
                            let todo = Doc.api.query('.word-editor-box').getAttribute('data-ajs-todo');
                            let rst = [];
                            //return alert(oldWord);
                            if( todo == 'editor' ){
                              for( let i = 0; i < arr.length; i++ ){
                                if( i == 0 ){
                                  if( arr[0] != oldWord ){
                                    rsp = await this.service.data.req('tableWord.update',this.songId,lidx,widx,arr[0]);
                                    rst.push( rsp.da.rst );
                                    if( rsp.da.rst ) {
                                      let target = Doc.api.query(`#article-content .line[data-ajs-lidx='${lidx}'`)
                                                  .querySelector(`.word[data-ajs-widx='${widx}'`); 
                                      if( target ) target.innerText = arr[0];
                                      ((this.objLrc.lines[lidx]).words[widx]).word = arr[0];
                                    }
                                    action = 1;
                                    $lg('2964::rst',...rst);
                                  }
                                }else{
                                  action = 2;
                                  rsp = await this.service.data.req('tableWord.adjIdx',this.songId,lidx,'>=', widx+i ,'+1');
                                      rst.push( rsp.da.rst );
                                  rsp = await this.service.data.req('tableWord.copyReplace',this.songId,lidx,widx,widx+i,arr[i]);
                                      rst.push( rsp.da.rst );
                                }
                              }
                            }else
                            if( todo == 'delete' ){
                              rsp = await this.service.data.req('tableWord.removeOne',this.songId,lidx,widx);
                                    rst.push( rsp.da.rst );
                              rsp = await this.service.data.req('tableWord.adjIdx',this.songId,lidx,'>', widx ,'-1');
                                    rst.push( rsp.da.rst );
                              action = 4;
                            }
                            $lg('2970::rst',...rst);
                            let total = 0;
                            rst.forEach( (r) => { total += r == true ? 1 : 0; });
                            
                            if( total > 0 ) {
                              this.fn.bg.green(ds);
                            }else{ 
                              this.fn.bg.red(ds);
                            }
                            
                            window.setTimeout(()=>{
                              if( action == 2 )alert('reload the article please');else
                              if( action == 4 ){
                                let wd = Doc.api.query(`#article-content .line[data-ajs-lidx='${lidx}']`)
                                            .querySelector(`.word[data-ajs-widx='${widx}']`);
                                if( wd ) wd.parentNode.removeChild( wd );
                              }
                              Doc.api.query('.msg-btn-close').click();
                            },1000);
                            
                          });
                          
                  this.ui.msgbox.fn.show( h.pack() );
                  
                })()
                
                
                
              },
              //从词典查找单词
              findword : async (e)=>{
                
                  //$lg('3819::findword');
                  
                  let word = e;
                  let lidx = null;
                  let widx = null;
                  let [st,ed,timeFromThisSong,mp3path] = [null,null,1,null];
                  
                  if(typeof(e) == 'object'){
                    // 输入参数是event事件对象
                    // 从event夹带的信息中提取lidx和widx
                    this.ui.article.tool.fn.busy(1);
                    const ds = e.target;
                    const dp = ds.parentElement.parentElement.parentElement;
                    lidx = parseInt( dp.getAttribute('data-ajs-lidx') );
                    widx = parseInt( ds.getAttribute('data-ajs-widx') );
                    //$lg('1349::lidx,widx::bgy',lidx,widx);
                    //return;
                    //从this.objLrc中取得单词
                    st   = this.objLrc.getObjWord(lidx,widx).start;
                    ed   = this.objLrc.getObjWord(lidx,widx).end;
                    word = this.objLrc.getObjWord(lidx,widx).word;
                    //$lg('3473:this.objLrc.getObjWord:',`'${word}'`);
                    word = word.replace(/([a-zA-Z]+)(\,|\.|\?|\:|\!)*\s*$/,'$1');
                    //$lg('3475:word.replace:',`'${word}'`);
                    this.ui.article.tool.fn.activitySetVal(e,101,-1);
                    
                  }
                  //$lg('3599::st,ed::bgg',`${st},${ed}`,`st==null:${st==null},ed==null:${ed==null}`);
                  if(st == null || ed == null){
                    
                    let rsp_word = await this.service.data.req('tableWord.listWordsWithTime',word);
                    //$log.lgg('3600',JSON.stringify(rsp_word));
                    if( rsp_word.da.rst !== false && rsp_word.da.dat.arr.length > 0 ){
                    
                      st      = rsp_word.da.dat.arr[0][4]/1000;
                      ed      = rsp_word.da.dat.arr[0][5]/1000;
                      mp3path = rsp_word.da.dat.arr[0][6];
                      timeFromThisSong = 0;
                      
                      let  aud = this.audio2;
                           aud.setAttribute('src',mp3path);
                           aud.setAttribute('preload','auto');
                           aud.addEventListener('canplay',(e)=>{
                             //$lg('3615::audio2::canplay',st,Log.now());
                             if( aud.currentTime !== st )aud.currentTime = st;
                             
                           })
                    }
                  }
                  
                  
                  //输入参数是一个单词字符串
                  word = word.replace(/([a-zA-Z]+)(\,|\.|\?|\:|\!)*\s*$/,'$1');
                  
                
                  this.service.data.req('tableActivity.add',this.songId,lidx,widx,word,101,-1,-1);
                  
                  //正式开始检索
                  let dat = await this.dic.find(word);
                  //$lg('1351::dic.find',word,JSON.stringify(dat));
                  /////////////////////////////////
                  // 动态创建一个弹窗展示结果
                  /////////////////////////////////
                  
                  let css = (()=>{
                    if( Doc.has(`style[class*='word-apart]`) == false ) {
                      new Css('.word-apart',{
                        width         : '100px',
                        heigh         : '36px',
                        border_radius : '6px',
                        background    : 'lightgreen',
                        padding       : '10px',
                        margin_left   : '20px',
                        color         : 'white',
                        font_size     : '3vmin',
                      });
                      new Css('.word-line-mn',{
                        flex_wrap        : 'wrap',
                      });
                      new Css('.dic-meaning-input',{
                        width            : '99%',
                        height           : '160px',
                        border_radius    : '10px',
                        white_space      : 'pre-wrap',
                        overflow_y       : 'scroll',
                        font_size        : '30px',
                      });//.word-dic-meaning
                    }
                  })()
                  
                  
                  //$lg('3579::findWord::bgb',`lidx:${lidx},widx:${widx}`)
                  let htm = (()=>{
                    let fgm = new Html();
                        fgm.dom();
                    for(let arr of dat.arr){
                      fgm.div('.word-detail-box').as(1)
                          //.span('.word-detail-id',`!${obj.id}`,0)
                          .div(1,'.spread-line flex-row-4').as(2)
                              .span(2,`#dict-word-id-${arr[0]}`,'.spread-btn word-detail-wd',`!${arr[1]}`)
                              .button(2,'.spread-btn word-cut',`!\u268b`)
                                  .on.click(this.ui.article.tool.fn.wordCut.index,0)
                              .button(2,'.spread-btn word-adj-sound',`!\u22b6`);
                          // 如果提供了lidx和widx，就额外增加一个发音按钮
                          //$lg('3589::bgb',lidx,widx);
                          if( st > 0 && ed > 0 ){
                              fgm.button(2,'.spread-btn word-play-sound w:100px',`!\u269f`)
                                 .on.click((e)=>{
                                   if( timeFromThisSong === 1 ){
                                    let setFlag = ()=>{this.flag_RepeatOnlyOneTimes = 0;}
                                    document.addEventListener('playOneTimesDone',setFlag,{once:1})
                                    //不重复，只播放1次
                                    this.ui.article.tool.fn.playWord(lidx,widx,0,1);
                                   }else{
                                     //$lg('3666::findword::this.audio2.play();');
                                     this.audio2.addEventListener('timeupdate',(e)=>{
                                       //$lg('3667::addEventListener','findword.timeupdate',Log.now());
                                       if( this.audio2.currentTime > ed ) {
                                         this.audio2.pause();
                                         this.service.time.req.pause();
                                       }
                                     });
                                     //this.service.time.req.start(1,'findword.timeupdate');
                                     this.audio2.currentTime = st;
                                     this.audio2.play();
                                   }
                                 },0)
                          }
                      /*fgm.span(1,'.word-origin',`!${oriWord}`)
                              .data('oriWord',oriWord)
                              .on.click((e)=>{
                                let ori = e.target.getAttribute('data-ajs-oriWord');
                                if(typeof ori == 'string')
                                    this.ui.article.tool.fn.findword(ori);
                                //this.ui.article.content.colorate.one(e);
                              })*/
                        fgm.div(1,'.spread-line flex-col-4').as(2)
                              .span(2,'.spread-btn word-detail-pn',`!${arr[2]}`)
                              .span(2,'.spread-btn word-detail-mn',`!${arr[3]}`)
                           .div(1,'.spread-line dic-edit-box flex-col-4 hide').as(2)
                              .div(2,'.spread-line flex-col-4').as(3)
                                  .textarea(3,'.dic-meaning-input')
                              .div(2,'.spread-line flex-row-4').as(3)
                                  .button(3,'.spread-btn dic-edit-cancle',`!cancle`)
                                  .button(3,'.spread-btn dic-edit-enter',`!enter`);
                    }
                    this.ui.msgbox.fn.show(fgm.pack());
                    this.ui.article.tool.fn.busy(0);
                  })()
                
              
                  //alert(rsp.da.msg);
                  //$lg('1938::bgo',JSON.stringify(rsp));
                  
                
              },
              
              findPhrase : (e)=>{
                
                let htm = new Html();
                htm.dom()
                    .div('.phraseBox flex-col-8').as(0)
                        .span(0,'.phrase-title','!phrase')
                        .input.text(0,'.phrase-input')
                            .at.autofocus(false)
                        .button(0,'.spread-btn phrase-btn','!ok')
                            .on.click((e)=>{
                              let ph = Doc.api.query('.phrase-input').value;
                              this.ui.article.tool.fn.findword(ph);
                            },0);
                
                this.ui.msgbox.fn.show(htm.pack());
                
              },
              
              locateWord : (ph,e)=>{
                //$lg('3670::locateWord::bgg',`ph:${ph}`);
                let arr = [];
                let ds = e.target;
                let rst = ds.getAttribute('data-rst');
                //$lg('3674::locateWord',`rst:'${rst}'`);
                
                if( rst  == '' || rst == 'null' || rst == null){
                  [...document.querySelectorAll(`.word[data-ajs-txt="${ph}"]`)].forEach( el =>{
                    let idx = el.getAttribute('data-ajs-idx');
                    if( idx ) arr.push(idx);
                  })
                }else{
                  arr = rst.split(',');
                }
                //$lg('3686::locateWord',`arr:'${arr.join(',')}'`);
                
                //locateWord
                let targetIdx = arr.shift();
                //$lg('3690::locateWord',`targetIdx:${targetIdx}`);
                let elm = document.querySelector(`.word[data-ajs-idx='${targetIdx}']`);
                //$lg('3692::locateWord',`elm:${elm}`);
                
                let pre = Doc.api.query('.locate-result');
                if( pre ) pre.classList.remove( 'locate-result');
                
                if( elm ) {
                  elm.scrollIntoView(true);
                  $lg('elm.scrollTop:',elm.scrollTop )
                  elm.scrollTop += 200;
                  //$lg('elm.scrollTop:',elm.scrollTop );

                  elm.classList.add( 'locate-result');
                  let box = Doc.api.query('.art-line-box');
                  if( box ) {
                    //box.scroll((parseInt(box.scrollHeight.toString().replace('px')) + 100)+'px') ;
                    box.scrollTop -= 200;
                    //$lg('box.scrollTop:',box.scrollTop,box.scrollHeight );
                  }
                }
                ds.setAttribute('data-rst',arr.join(','));
                //let ph = Doc.api.query('.phrase-input');
                //if( ph ) ph.value = '';
              },
              
              locateToLine : (lidx)=>{

                
                
                let targetIdx = lidx;
                $lg('3785::locateToLine',`targetIdx:${targetIdx}`);
                
                let elm = document.querySelector(`div[data-ajs-lidx='${targetIdx}']`);
                //$lg('3692::locateWord',`elm:${elm}`);
                let box = Doc.api.query('.art-line-box');
                if( box ) {
                  //box.scroll((parseInt(box.scrollHeight.toString().replace('px')) + 100)+'px') ;
                  //box.scrollTop = 0;
                  box.scrollIntoView(true);
                  //$lg('box.scrollTop:',box.scrollTop,box.scrollHeight );
                }
                
                if( elm ) {
                  
                  elm.scrollIntoView();
                  /*$lg('elm.scrollTop:',elm.scrollTop )
                  elm.scrollTop += 200;
                  //$lg('elm.scrollTop:',elm.scrollTop );

                  //elm.classList.add( 'locate-result');
                  let box = Doc.api.query('.art-line-box');
                  if( box ) {
                    //box.scroll((parseInt(box.scrollHeight.toString().replace('px')) + 100)+'px') ;
                    box.scrollTop -= 200;
                    //$lg('box.scrollTop:',box.scrollTop,box.scrollHeight );
                  }*/
                }
                
                
              },
              
              
              activitySetVal : (e,action,value)=>{
                
                  this.ui.article.tool.fn.busy(1);
                  const ds = e.target;
                  const dp = ds.parentElement.parentElement.parentElement;
                  const sid = this.songId;
                  const lidx = parseInt( dp.getAttribute('data-ajs-lidx') );
                  const widx = parseInt( ds.getAttribute('data-ajs-widx') );
                  
                  const word = this.objLrc.getObjWord(lidx,widx).word;
                  
                  return this.service.data.req('tableActivity.add',sid,lidx,widx,word,action,value,-1);
                //if(rsp.da.rst == false) alert(rsp.da.msg);
                
                //const clazz = val == 0 ? 'word-stranger' : 'word-friend';
                
                //$lg('1551::clazz',clazz);
                
                //ds.classList.add(clazz);
                
                //$lg('1555::className',ds.className);
                
                
              },
              
              busy : (val)=>{
                
                let btn = Doc.api.query('.a-tool-busy');
                if(val == 1){
                  btn.classList.add('flash-light');
                }else 
                if(val == 0){
                  btn.classList.remove('flash-light');
                }
                
              },
              
              cataTool : {
                
                listSpeaker : async (e)=>{
                  
                  let rsp = await this.service.data.req('tableTag.listSpeaker',this.songId);
                  $log.lgg('2460',JSON.stringify(rsp));
                  if( rsp.da.rst == 0 || rsp.da.dat.arr.length == 0  ) return;
                  
                  [...Doc.api.queryAll('.tag-speaker-box>*')].forEach( el =>{ el.parentNode.removeChild(el);})
                  
                  let htm = new Html();
                      htm.dom('.tag-speaker-box')
                  for( let item of rsp.da.dat.arr ){
                    //tag
                    htm.button('.spread-btn article-speaker',`!${item[0]}.${item[2]}`)
                          .data('speaker',item[0])
                          .data('sid',item[1])
                          .on.click( this.ui.article.tool.fn.cataTool.showSentence,0)
                  }
                  htm.ok();
                  
                },
                
                visibleSentence : async (e)=>{
                  
                  let ds = e.target;
                  let speaker = ds.getAttribute('data-ajs-speaker');
                  let sid = ds.getAttribute('data-ajs-sid');
                  if( sid ) sid = parseInt( sid );
                  
                  //request lidx from sqlite
                  let rsp = await this.service.data.req('tableTag.listSpeakerSentence',sid,speaker);
                  //$log.lgg('2486',JSON.stringify(rsp));
                  if( rsp.da.rst == 0 || rsp.da.dat.arr.length == 0  ) return;
                  
                  
                  //hide all sentence
                  [...Doc.api.queryAll('.art-line-box .line')].forEach( el =>{
                    if( el.classList.contains('hide-line') == false ) {
                      el.classList.add('hide-line');
                    }
                  })
                  
                  //merger result
                  let visibleLidx = [];
                  for( let item of rsp.da.dat.arr ){
                    //sid,lidx,speaker
                    visibleLidx.push(item[1]);
                  }
                  
                  $log.lgg('3426',visibleLidx);
                  
                  //show line which can be find in visibleLidx
                  [...Doc.api.queryAll('.art-line-box .line')].forEach( el =>{
                    let lidx = el.getAttribute('data-ajs-lidx');
                    if( lidx ){ 
                      lidx = parseInt( lidx );
                      if( visibleLidx.includes(lidx)){
                        el.classList.remove('hide-line');
                      }
                    }
                  })
                  
                },
                
                showSentence : async (e)=>{
                  
                  let ds = e.target;
                  this.ui.fn.highlight(e);
                  this.fn.bg.flash(ds);
                  let speaker = ds.getAttribute('data-ajs-speaker');
                  let sid = ds.getAttribute('data-ajs-sid');
                  if( sid ) sid = parseInt( sid );
                  
                  //request lidx from sqlite
                  let rsp = await this.service.data.req('tableTag.listSpeakerSentence',sid,speaker);
                  //$log.lgg('2486',JSON.stringify(rsp));
                  if( rsp.da.rst == 0 || rsp.da.dat.arr.length == 0  ) return;
                  
                  
                  //hide all sentence
                  //Doc.api.query('.art-line-box').innerHTML = '';
                  [...Doc.api.queryAll('.art-line-box .line')].forEach( el =>{
                    
                      el.parentNode.removeChild(el);
                    
                  })
                
                  
                  //merger result
                  let visibleLidx = [];
                  for( let item of rsp.da.dat.arr ){
                    //sid,lidx,speaker
                    visibleLidx.push(item[1]);
                  }
                  
                  $log.lgg('3426',visibleLidx);
                  
                  this.ui.article.content.show( visibleLidx );

                  this.fn.bg.green(ds);
                }
                
              },
              
              recTool : {
                
                config : {
                  
                  index : ()=>{
                    $lg('2775::rec-config');
                    
                    let css = (()=>{
                      if(Doc.has('.Ajs .recTool')) return;
                      Css.root = 'Ajs/recTool';
                      new Css('.rec-conf-box *',{
                        font_size       : '4vmin',
                      })//.rec-conf-box
                      new Css('.rec-conf-line',{
                        margin          : '10px',
                        padding         : '10px',
                        border_radius   : '10px',
                        border          : '3px solid grey',
                        width           : '90%',
                      })//.rec-conf-line
                      new Css('.rec-conf-lbl',{
                        width           : '25%',
                      })//.rec-conf-lbl
                      new Css('.rec-conf-range',{
                        width           : '72%',
                      })//.rec-conf-range
                      new Css('.rec-conf-ok',{
                        width           : '99%',
                        border_radius   : '10px',
                        border          : '0px solid grey',
                      })//.rec-conf-ok
                      new Css('.rec-conf-range::-webkit-slider-thumb',{
                        width           : '60px',
                        height          : '60px',
                        border_radius   : '50%',
                      })//.rec-conf-range::-webkit-slider-thumb
                      Css.root = 'Ajs';
                    })()
                    
                    let htm = (()=>{
                      let htm = new Html();
                      let flexLine = 'flex-row-46';
                      htm.dom()
                        .div('.rec-conf-box flex-col-82').as(1)
                          .div(1,`.rec-conf-line ${flexLine}`).as(2)
                            .span(2,'.rec-lbl-vol rec-conf-vol','!vol(3)')
                            .input.range(2,'.rec-range-vol rec-conf-range')
                              .at.min(0).at.max(20).at.value(3)
                          .div(1,`.rec-conf-line ${flexLine}`).as(2)
                            .span(2,'.rec-lbl-low rec-conf-lbl','!low(500)')
                            .input.range(2,'.rec-range-low rec-conf-range')
                                .at.min(0).at.max(1000).at.value(500)
                          .div(1,`.rec-conf-line ${flexLine}`).as(2)
                            .span(2,'.rec-lbl-std rec-conf-lbl','!std(500)')
                            .input.range(2,'.rec-range-std rec-conf-range')
                                .at.min(0).at.max(1000).at.value(500)
                          .div(1,`.rec-conf-line ${flexLine}`).as(2)
                            .span(2,'.rec-lbl-high rec-conf-lbl','!high(500)')
                            .input.range(2,'.rec-range-high rec-conf-range')
                                .at.min(0).at.max(1000).at.value(500)
                          .div(1,`.rec-conf-line ${flexLine}`).as(2)
                            .button(2,'.spread-btn rec-conf-ok','!ok')
                        
                      
                      .queryAll('.rec-conf-range,.rec-conf-ok').on.input((e)=>{
                          
                          let ds = e.target;
                          
                          let has = (s)=>{ return ds.classList.contains(s)};
                          
                          if( has('rec-range-vol') ){
                            //Doc.api.query('.rec-lbl-vol').innerText = `vol(${ds.value})`;
                            ds.previousSibling.innerText = `vol(${ds.value})`;
                          }else
                          if( has('rec-range-low') ){
                            ds.previousSibling.innerText = `low(${ds.value})`;
                            //Doc.api.query('.rec-lbl-low').innerText = `low(${ds.value})`;
                          }else
                          if( has('rec-range-std') ){
                            //Doc.api.query('.rec-lbl-std').innerText = `std(${ds.value})`;
                            ds.previousSibling.innerText = `std(${ds.value})`;
                          }else
                          if( has('rec-range-high') ){
                            //Doc.api.query('.rec-lbl-high').innerText = `high(${ds.value})`;
                            ds.previousSibling.innerText = `high(${ds.value})`;
                          }else
                          if( has('rec-conf-ok') ){
                            let btnConf = Doc.api.query('.r-tool-conf');
                            let vol = Doc.api.query('.rec-range-vol');
                            let low = Doc.api.query('.rec-range-low');
                            let std = Doc.api.query('.rec-range-std');
                            let heigh = Doc.api.query('.rec-range-heigh');
                            btnConf.setAttribute('data-vol',vol);
                            btnConf.setAttribute('data-low',low);
                            btnConf.setAttribute('data-std',std);
                            btnConf.setAttribute('data-heigh',heigh);
                          }
                          
                        },0)
                        
                        this.ui.msgbox.fn.show( htm.pack() );
                        
                    })()
                    
                  }
                  
                },
                
                ext : {
                  
                  listByLine : async ( sid, lidx )=>{
                    $lg('3000::listByLine',sid,lidx);
                    [...Doc.api.queryAll('.rec-list')].forEach(e=>{e.parentNode.removeChild(e)});
                    
                    let rsp = await this.service.data.req('tableMp3.listByLine',sid,lidx);
                    $log.lgg('3003::rsp',JSON.stringify(rsp));
                    if( rsp.da.rst == false ) return;
                    if( rsp.da.dat.arr.length == 0 ) return;


                    let flexLine = 'flex-row-46';
                    let htm = new Html();
                        htm.dom(`#article-tool .rec-list-box`);
                    for( let item of rsp.da.dat.arr){
                        //id,name,path,time 
                        htm.div('.spread-line rec-list flex-row-46').as(1)
                          .button(1,`.spread-btn rec-mp3-name`,`!${item[1]}`)
                              .data('path',item[2])
                              .on.click((e)=>{
                                let ds = e.target;
                                let act = Doc.api.query('.rec-active');
                                if( act ) act.classList.remove('rec-active');
                                ds.classList.add('rec-active');
                                let p = Doc.api.query('.r-tool-play');
                                if( p ) {
                                  p.style.color = 'rgb(126,162,126)';
                                  p.disabled = false;
                                }
                              },0)
                          
                    }
                    htm.ok();
                    
                  }
                  
                }
                
                
              },
              
              rsp : {
                
                fail : ()=>{
                
                let btn = Doc.api.query('.a-tool-busy');
                    btn.classList.remove('light-flash');
                    btn.classList.add('light-red');
                  
                
              },
              
                ok : ()=>{
                
                let btn = Doc.api.query('.a-tool-busy');
                    btn.classList.remove('light-flash');
                    btn.classList.add('light-green');
                
              },
              
              },
              
              playWord : (lidx,widx,loop = 0,onlyOneTimes = 1)=>{
                
                let timeArr = this.objLrc.getItemTime(lidx,widx);
                //$lg('2466::timeArr',...timeArr);
                this.loopAB = loop;
                this.loopDur = timeArr;
                this.ui.loopAB.replace(timeArr);
                this.flag_RepeatOnlyOneTimes = onlyOneTimes;
                //Doc.api.query('.audio').currentTime = timeArr[0];
                this.myAudio.currentTime = timeArr[0];
                
                this.audio.play();
                
              },
              
              microAdjTime : (lidx,widx)=>{
                
                $lg('3986::microAdjTime',lidx,widx);
                //get time info from objLrc
                let time = this.objLrc.getItemTime( lidx, widx );
                let st = time[0];
                let ed = time[1];
                //$lg('st,ed',st,ed);
                if( typeof st !== 'number' || typeof ed !== 'number' ) return;
                
                let range = [100,250,500,1000];
                let idx = 1;
                
                let rate = ( val )=>{
                  let value = ( val - 50 ) / range[idx];
                  return value;
                }
                
                let changeIdx = (e)=>{
                  idx ++;
                  if( idx > 3) idx = 0;
                  let ds = e.target;
                      ds.innerText = `\u00b1${50/range[idx]*1000}ms`;
                }
                
                let play = (e)=>{
                  let ds = e !== undefined ? e.target : Doc.api.query('.word-adj-play');
                  let r1 = ds.getAttribute('data-ajs-st');
                  let r2 = ds.getAttribute('data-ajs-ed');
                  let t1 = st + parseFloat(r1);
                  let t2 = ed + parseFloat(r2);
                  
                  this.loopDur = Array.of(t1,t2);
                  this.loopAB = 1;
                
                  this.ui.loopAB.replace( this.loopDur );
                  this.flag_RepeatOnlyOneTimes = 0;
                  //Doc.api.query('.audio').currentTime = timeArr[0];
                  this.myAudio.currentTime = t1;
                  
                  this.audio.play();
                  
                }
                
                let adj1 = (e)=>{
                  let ds = e.target;
                  let rat = rate( ds.value );
                  let t = this.fn.timeTsl(st+rat);
                  Doc.api.query('.word-adj-range-1 > span')
                    .innerText = `${t[0]}:${t[1]}.${t[2]}`;
                  Doc.api.query('.word-adj-play').setAttribute('data-ajs-st',rat);
                  play();
                }
                
                let adj2 = (e)=>{
                  let ds = e.target;
                  let rat = rate( ds.value );
                  let t = this.fn.timeTsl(ed+rat);
                  Doc.api.query('.word-adj-range-2 > span')
                    .innerText = `${t[0]}:${t[1]}.${t[2]}`;
                  Doc.api.query('.word-adj-play').setAttribute('data-ajs-ed',rat);
                  play();
                }
                
                let pause = (e)=>{
                  this.audio.pause();
                }
                
                let save = async (e)=>{
                  
                  let ds = e.target;
                  
                  let pl = Doc.api.query('.word-adj-play');
                  let r1 = pl.getAttribute('data-ajs-st');
                  let r2 = pl.getAttribute('data-ajs-ed');
                  let t1 = st + parseFloat(r1);
                  let t2 = ed + parseFloat(r2);
                  
                  this.objLrc.setItemTime( lidx, widx, t1, t2 );
                  
                  let rsp = await this.service.data.req('tableWord.setTime',this.songId,lidx,widx,t1*1000,t2*1000);
                  
                  if( rsp.da.rst == true ) this.fn.bg.green(ds);
                  else this.fn.bg.red(ds);
                  
                }
                
                let css = (()=>{
                  if( Doc.has('.Ajs style[class*="msg-cont"]') ) return;
                  new Css('.msg-cont',{
                    overflow      : 'hidden !important',
                    overflow_x    : 'hidden !important',
                    overflow_y    : 'hidden !important',
                  })
                })()
                
                let html = (()=>{
                  
                  let htm = new Html();
                  htm.dom()
                      .div('.word-adj-idx-box flex-row-5 w:760px m:20px').as(3)
                          .button(3,'.spread-btn word-adj-idx','!\u00b1200ms')
                              .on.click( changeIdx,0)
                      .div('.word-adj-range-box w:760px m:20px').as(1)
                          .div(1,'.word-adj-range-1 flex-row-46 w:700px m:20px').as(11)
                              .span(11,'.spread-btn w:10%','!begining')
                          .div(1,'.word-adj-range-2 flex-row-46 w:700px m:20px').as(12)
                              .span(12,'.spread-btn w:10%','!end')
                      .div('.btn word-adj-btn-box flex-row-4050 w:700px m:20px').as(2)
                          .button(2,'.spread-btn word-adj-save','!save')
                              .on.click( save,0)
                          .button(2,'.spread-btn word-adj-play','!play')
                              .data('st','0')
                              .data('ed','0')
                              .on.click( play,0)
                          .button(2,'.spread-btn word-adj-pause','!pause')
                              .on.click( pause,0);
                  this.ui.msgbox.fn.show(htm.pack());
                  ////////////////////////////////
                  let t = this.fn.timeTsl(st);
                  Doc.api.query('.word-adj-range-1 > span').innerText = `${t[0]}:${t[1]}.${t[2]}`;
                      t = this.fn.timeTsl(ed);
                  Doc.api.query('.word-adj-range-2 > span').innerText = `${t[0]}:${t[1]}.${t[2]}`;
                  ////////////////////////////////
                  let ui = new Ui();
                  let t1 = new ui.range();
                  let t2 = new ui.range();
                      t1.into('.word-adj-range-1')
                        .id('word-adj-p1').w('80%')
                        .done();
                      t2.into('.word-adj-range-2')
                        .id('word-adj-p2').w('80%')
                        .done();
                    t1.oninput( adj1, 0);
                    t2.oninput( adj2, 0);
                })()
                
              },
              
              outputArticle : ()=>{
                
                let txt = this.objLrc.outText();
                
                $log.lgg('4130::',txt);
                
              },
              
              
              
            },
            
            tag : {
              
              index : ()=>{
                
                
                
              },
              
              fn : {
                
                
              },
              
            }
            
          },
          
          sentence : {
            
            menu : (e)=>{
              
              let ds = e.target;
              
              let lidx = parseInt( ds.innerText );
              let sts = '';
              this.objLrc.getLine(lidx).words.forEach(obj=>{sts += ' '+ obj.word;})
              sts = sts.trim();
              let css = (()=>{
                if(Doc.has(`.Ajs style[class*='sts-box']`)) return;
                new Css('.sts-box',{
                  width           : '96%',
                  background      : 'lightyellow',
                  border_radius   : '10px',
                  border          : '0px',
                  margin          : '10px',
                  flex_wrap       : 'wrap',
                  //padding         : '10px',
                })//.sts-menu-box
                new Css('.sts-box *',{
                  font_size       : '4vmin',
                })
                new Css('.text',{
                  font_size       : '4vmin',
                  width           : '99%',
                  //height          : 'auto',
                  max_height      : '300px',
                  //background      : 'hsl(60,10%,90%)',
                  //background      : 'lightyellow',
                  border_radius   : '10px',
                  border          : '3px solid black',
                  border_radius   : '6px',
                  margin          : '3px',
                  padding         : '3px',
                })//.text
                new Css('.sts-line',{
                          position          : 'relative',
                          width             : '96%',
                          margin            : '3px',
                          //padding           : '3px',
                          border            : '0px solid black',
                          background        : 'white',
                        })//.sts-line
                new Css('.sts-line>span',{
                  font_size         : '4vmin',
                  margin            : '3px',
                  padding           : '3px',
                  border            : '0px',
                  background        : 'hsla(60,80%,10%,0.3)',
                  white_space       : 'pre',
                  overflow_x        : 'scroll',
                })//.sts-line>span
                new Css('.sts-line-idx',{
                  flex_grow       : 1,
                  width           : '6%',
                  text_align      : 'right',
                  color           : 'red',
                })//.sts-line-idx
                new Css('.sts-line-time',{
                  flex_grow       : 1,
                  width           : '10%',
                })//.sts-line-time
                new Css('.sts-line-memo',{
                  flex_grow       : 3,
                  width           : '80%',
                  
                })//.sts-line-memo
                new Css('.sts-line-drop',{
                  color           : 'red',
                  width           : '5%',
                  text_align      : 'center',
                })//.sts-line-drop
                new Css('.sts-list-box',{
                  max_height       : '300px',
                  overflow_y       : 'scroll',
                  padding_top      : '10px',
                  padding_bottom   : '10px',
                })//.sts-list-box
                new Css('.sts-menu-remove',{
                  color            : 'white',
                  background       : 'orange !important',
                })//.sts-menu-remove
              })()
              
              let htm = (()=>{
                
                const fn = this.ui.article.sentence.fn;
                
                let htm = new Html();
                
                htm.dom()
                    .div(`.sts-box sts-menu-box flex-row-46`,).as(2)
                        .button(2,`.btn sts-menu-copy flash-btn`,`!copy`)
                        .button(2,`.btn sts-menu-list flash-btn`,`!list`)
                        .button(2,`.btn sts-menu-memo flash-btn`,`!翻译`)
                        .button(2,`.btn sts-menu-phrase flash-btn`,`!词组`)
                        .button(2,`.btn sts-menu-rec flash-btn`,`!录音`)
                        .button(2,`.btn sts-menu-deduce flash-btn`,`!结构`)
                        .button(2,`.btn sts-menu-append flash-btn`,`!+句子`)
                        .button(2,`.btn sts-menu-remove flash-btn`,`!-句子`)
                        .button(2,`.btn sts-menu-tag flash-btn`,`标记`)
                    .div(`.sts-box sts-cont-box hide flex-col-5`,).as(1)
                        .data('lidx',lidx)
                        .data('sts',sts)
                        .textarea(1,'.text hide sts-input-1',`!${sts}`)
                        .textarea(1,'.text hide sts-input-2 sts-cont-tsl')
                            .on.input(fn.writtingAssistant,0)
                    .div(`.sts-box sts-list-box hide flex-col-8050`,).as(3)
                    .div(`.sts-box sts-ok-box hide flex-row-5`,).as(2)
                        .button(2,`.btn sts-ok-btn flash-btn w:96%`,`!ok`)
                      
                
                .query(`.sts-menu-box`).on.click(async (e)=>{
                  
                  this.ui.fn.highlight(e);;
                  let ds = e.target;
                  let has = (...args)=> ds.classList.contains(...args);
                  if(has('sts-menu-copy')){
                    $lg('2442::sts-menu-copy',sts);
                    //this.fn.clipboard.copyText(sts);
                  }else
                  if(has('sts-menu-list')){
                    //$lg('2445::sts-menu-tsl')
                    let box = Doc.api.query('.msg-box .msg-cont .sts-cont-box');
                    let lidx = parseInt( box.getAttribute('data-ajs-lidx') );
                    //let sts  =  ds.getAttribute('data-ajs-sts') ;
                    let lines = Doc.api.queryAll('.sts-list-box .sts-line');
                    [...lines].forEach(line=>line.parentNode.removeChild(line));
                    let clk = ds.getAttribute('data-ajs-clk');
                    if(clk == undefined || clk == '0' ){
                      ds.setAttribute('data-ajs-clk','1');
                      
                      let rspSts = await this.service.data.req('tableMemo.listSTS',this.songId,lidx);
                      if( rspSts.da.rst == false ) {
                        this.fn.bg.red(ds);
                        return;
                      }
                      this.fn.bg.green(ds);
                      let lbox = Doc.api.query('.msg-box .msg-cont .sts-list-box');
                      if( lbox ) lbox.classList.remove('hide');
                      //$log.lgg('2688',JSON.stringify(rspSts));
                      //return;
                      
                      let htm = new Html();
                      htm.dom('.sts-list-box')
                      let i = rspSts.da.dat.arr.length;
                      //$lg('2730::i::bgb',i);
                      for( let item of rspSts.da.dat.arr ){
          
                        let [id,sid,lidx,memo,time] = [...item];
                        i -= 1;
                        htm.div('.sts-line flex-row-4050').as(1)
                            .data('id',id)
                            .data('lidx',lidx)
                            //.span(1,'.sts-line-idx',`!${i}`)
                            .span(1,'.sts-line-idx',`!${i}`)
                                .on.click(async (e)=>{
                                  let ds = e.target;
                                  let dp = e.target.parentNode;
                                  let id = parseInt( dp.getAttribute('data-ajs-id') );
                                  let rsp = await this.service.data.req('tableMemo.drop', id );
                                  if( rsp.da.rst == false ) this.fn.bg.red(ds);
                                  Doc.api.query('.sts-menu-list').click();
                                  Doc.api.query('.sts-menu-list').click();
                                },0)
                            .span(1,'.sts-line-memo',`!${memo}`)
                                .on.click((e)=>{this.fn.pop(memo,'20s')},0)
                            .span(1,'.sts-line-time',`!...`)
                                .on.click((e)=>{this.fn.pop(time,'3s');},0)
                      }
                      htm.ok();
                    }else{
                      ds.setAttribute('data-ajs-clk','0');
                    }
                    
                  }else
                  if(has('sts-menu-memo')){
                    //$lg('2445::sts-menu-tsl')
                    let ds = Doc.api.query('.msg-box .msg-cont .sts-cont-box');
                    if( ds.classList.contains('hide')){
                      let inp1 = Doc.api.query('.sts-input-1');
                          inp1.rows = 6;
                      let tsl = Doc.api.query('.sts-cont-tsl');
                          tsl.rows = 3;
                      ds.classList.remove('hide');
                      [...ds.children].forEach( el =>{el.classList.remove('hide')})
                    
                    }else if( ds.classList.contains('hide') == false && Doc.api.query('.sts-input-2').value.length == 0  ){
                      return ds.classList.add('hide');
                      
                    }else{
                      let lidx = parseInt( ds.getAttribute('data-ajs-lidx') );
                      //let sts  =  ds.getAttribute('data-ajs-sts') ;
    
                      //let inp1 = Doc.api.query('.sts-input-1');
                          //inp1.rows = 6;
                      let tsl = Doc.api.query('.sts-cont-tsl');
                          //tsl.rows = 3;
                      //alert(tsl);
                      //this.fn.bg.flash( tsl );
                      
                      let rsp = await this.service.data.req('tableMemo.addSent',this.songId,lidx,tsl.value);
                      if( rsp.da.rst == false) {
                        this.fn.bg.red(tsl);
                        $lg('2685::rsp',JSON.stringify(rsp));
                      }
                      else this.fn.bg.green( tsl );
                    }
                  }else
                  if(has('sts-menu-phrase')){
                    //$lg('2446::sts-menu-phrase')
                  }else
                  if(has('sts-menu-deduce')){
                    //$lg('2446::sts-menu-phrase')
                    this.ui.wordTree.index(this.songId,lidx);
                  }else
                   if(has('sts-menu-tag')){
                    
                    let cbox = Doc.api.query('.sts-cont-box');
                    let okbox = Doc.api.query('.sts-ok-box');
                    let okbtn = Doc.api.query('.sts-ok-btn');
                    let lbox = Doc.api.query('.sts-list-box');
                    let inp2 = Doc.api.query('.sts-input-2');
                    if( cbox ) cbox.classList.remove('hide');
                    if( okbox ) okbox.classList.remove('hide');
                    if( lbox ) lbox.classList.remove('hide');
                    if( inp2 ) inp2.classList.remove('hide');
                    if( okbtn ) okbtn.setAttribute('data-task','addTag');
                    
                    let rsp = await this.service.data.req('tableTag.listTagsNotAboutSpeaker','sentence');
                    
                    //$lg('4336::rsp',JSON.stringify(rsp));
                    
                    if( rsp.da.rst == false  ) return;
                    if( rsp.da.dat.arr.length == 0  ) return;
                    
                    let showTags = (()=>{
                      let htm = new Html();
                          htm.dom('.sts-list-box')
                                .div('.sts-tags-box flex-row-4050 flex_wrap:wrap').as(1);
                      for( let arr of rsp.da.dat.arr ){
                        let tag = arr[0];
                        htm.button(1,'.btn',`!${tag}`);
                      }
                      htm.ok();
                    })()
                    
                  }else
                  if(has('sts-menu-append')){
                    this.ui.article.sentence.fn.appendNew(e);
                  }else
                  if(has('sts-menu-remove')){
                    this.ui.article.sentence.fn.remove(lidx);
                  }
                },0)
                
                .query(`.sts-ok-btn`).on.click(async (e)=>{
                    
                    this.ui.fn.highlight(e);;
                    let ds = e.target;
                    let task = ds.getAttribute('data-task');
                    
                    if( task == 'addTag' ){
                      let lidx = null;
                      let tags = null;
                      let cbox = Doc.api.query('.sts-cont-box');
                      let inp2 = Doc.api.query('.sts-input-2');
                      if( cbox ) lidx = cbox.getAttribute('data-ajs-lidx');
                      if( lidx ) lidx = parseInt( lidx );
                      if( inp2 ) tags = inp2.value.trim().split(' ');
                      if( lidx == null || tags == null ) {
                        cbox.classList.add('hide');
                      }
                      let rsp = await this.service.data.req('tableTag.addTagsForSentence',tags,this.songId,lidx,'sentence');
                      $log.lgg('4372:addTag',JSON.stringify(rsp));
                      if( rsp.da.rst == false ) this.fn.bg.red(ds);
                      else this.fn.bg.green(ds);
                      
                      
                    }else
                    if( task == 'append' ){
                      //return alert('append');
                      //let lidx = null;
                      let cont = null;
                      //let cbox = Doc.api.query('.sts-cont-box');
                      let inp2 = Doc.api.query('.sts-input-2');
                      //if( cbox ) lidx = cbox.getAttribute('data-ajs-lidx');
                      //if( lidx ) lidx = parseInt( lidx );
                      if( inp2 ) cont = inp2.value.trim();
                      if( cont == null ) {
                        cbox.classList.add('hide');
                        return;
                      }
                      
                      let lrc = this.obj.lrc(this);
                      
                      lrc.addText( cont );
                      
                      let maxLidx = await this.service.data.req('tableWord.getNumberOf.maxLineIdx',this.songId);
                      
                          maxLidx++;
                      $lg('4320::bgy',maxLidx);
                      let rsp = await this.dat.tableWord.batAdd(this.songId,lrc,maxLidx);
                      
                      $log.lgg('4217:append',JSON.stringify(rsp));
                      if( rsp.da.rst == false ) this.fn.bg.red(ds);
                      else this.fn.bg.green(ds);
                      
                    }
                },0)
                
                this.ui.msgbox.fn.show(htm.pack());
              
              })()
              
              
            },
            
            fn : {
              
              copy : (e)=>{
                
                $lg('2501::copy');
                
              },
              
              //translate
              tsl : (e)=>{
                
                $lg('2508::tsl');
                
              },
              
              phrase : (e)=>{
                
                $lg('2514::phrase');
                
              },
              
              appendNew : (e)=>{
                
                let cbox = Doc.api.query('.sts-cont-box');
                let okbox = Doc.api.query('.sts-ok-box');
                let okbtn = Doc.api.query('.sts-ok-btn');
                //let lbox = Doc.api.query('.sts-list-box');
                let inp2 = Doc.api.query('.sts-input-2');
                if( cbox ) cbox.classList.remove('hide');
                if( okbox ) okbox.classList.remove('hide');
                //if( lbox ) lbox.classList.remove('hide');
                if( inp2 ) inp2.classList.remove('hide');
                if( okbtn ) okbtn.setAttribute('data-task','append');
                    
                
              },
              
              remove : async (lidx)=>{
                
                let ans = window.confirm('确定删除此句?');
                
                if( ans == 1 ){
                  
                  let rsp = await this.service.data.req('tableWord.removeSentence',this.songId,lidx);
                  
                  if( rsp.da.rst == false ) alert( '删除失败')
                  else alert( '删除成功')
                  
                }
                    
                
              },
              
              writtingAssistant : async (e)=>{
                
                let ds = e.target;
                
                let m = /.+\s(\w+|[\u4e00-\u9faa]+)$/i.exec(ds.value);
                
                if( m == null ) return;
                
                let word = m[1];
                
                let tit = Doc.api.query('.msg-title .msg-tit');
                if( tit ) tit.innerText = word;
                
                //$lg('4289',word);
                let rsp = await this.dic.list(word,10,'word');
                
                //$log.lgg('4292::',JSON.stringify(rsp));
                
                if( rsp == null || rsp.arr.length == 0) return;
                
                //$lg('4296',rsp.arr.length);
                
                let lBox = Doc.api.query('.sts-list-box');
                if( lBox ) lBox.classList.remove('hide');
                let assBox = Doc.api.query('.sts-ass-box');
                if( assBox ) assBox.innerHTML = '';
                
                let htm = new Html();
                if( assBox == null ){
                    htm.dom('.sts-list-box')
                          .div('.sts-ass-box flex-row-4').top();
                }else{
                  htm.dom('.sts-ass-box');
                }
                for( let a of rsp.arr ){
                  htm.button('.spread-btn sts-ass-word',`!${a[0]}`);
                }
                htm.ok();
              },
              
              assWordClick : (e)=>{
                
                let ds = e.target;
                
                let wd = ds.innerText;
                
                //alert(wd);
                
                let inp2 = Doc.api.query('.sts-input-2');
                    inp2.rows = 6;
                if( inp2 == null ) return;
                
                let word = inp2.value;
                
                //alert(word);
            
                inp2.value = word.replace(/(.+\s)(\w+|[\u4e00-\u9faa]+)$/,`$1`+wd);
                
                inp2.focus();
                
              },
              
              // 列出所有备注（翻译）
              listMemoAll : async (sid)=>{
                
                let rsp = await this.service.data.req('tableMemo.listStsAll',this.songId);
                
                //$log.lgg('5044',JSON.stringify(rsp));
                
                if( rsp.da.rst == false ) {
                  return;
                }
                
                
                let htm = new Html();
                let i = rsp.da.dat.arr.length;
                //$lg('2730::i::bgb',i);
                for( let item of rsp.da.dat.arr ){
                  
                  i -= 1;
                  
                  let [id,sid,lidx,memo,time] = [...item];
                  
                  //let str = `.art-line-box .memo-box[data-lidx='${lidx}']`;
                  //$lg('5059::bgb',str);
                  
                  htm.dom(`.memo-box[data-lidx='${lidx}']`);
    
                  htm.span('.memo',`!${memo}`);

                  htm.ok();
                  
                }
                
                
                
              }
              
            }
            
          },
          
          words : {
            
            menu : (e)=>{
              
              alert('word editor menu');
              
            }
            
          }
          
          
        },
        
        tabMenu    : {
            
            into : (anyStr)=>{
              
              this.ui.tabMenu.css.all()
                             .index(anyStr);
                             //.eventSetup();
              return this.ui.tabMenu;
              
            },
            
            css : {
                
                box  : ()=>{
                  
                  let cs = new Css();
                      cs.style(['cssAjs','cssUi','cssTabMenu','css_tab-box'])
                          .slt('.tab-menu-box')
                              .f.fs('4vmin').ds()
                              .a.marg.top('100px')
                                .mar('16px').pad('10px')
                                .wh('97%')
                                .bor('2px solid white')
                                .bg(cs.rgba.white(1,0.9))
                                .bord.rad('20px')
                                .ds()
                          .slt('.cont-head-box,.cont-body-box')
                              .f.rel().ds()
                              .a.mar('10px')
                                .pad('10px').w('95.6%')
                                .bor('2px solid black')
                                .bg(cs.rgba.white(6,0.9))
                                .ds()
                          .slt('.cont-head-box')
                              .a.wh('96%','100px')
                                //.marg.bot('10px')
                                //.padd.bot('10px')
                                .bord.top.rad.both('20px')
                                .bord.bot.rad.both('0px')
                                
                                .ovfl.x.scl()
                                .ds()
                          .slt('.cont-body-box')
                              .a.marg.top('0px')
                                .padd.top('0px')
                                .bord.top.rad.both('0px')
                                .bord.bot.rad.both('20px')
                                .ds()
                                
                          .slt('.right-box')
                                .flex.col.p(9)
                                .f.rel().ds()
                                .a.wh('96%','auto')
                                  .tr('0px','0px')
                                  .marpad('10px')
                                  .bor('0px solid black')
                              .ds()
                          .ok();
                  return this.ui.tabMenu.css;
                  
                },
                
                btns : ()=>{
                  
                  let cs = new Css();
                      cs.style(['cssAjs','cssUi','cssTabMenu','css_tab-btns'])
                          .slt('.head-tab,.body-panel')
                              .f.fs('4vmin').ds()
                              .a.bor('0px solid red')
                                .mar('20px').pad('20px')
                                .bord.rad('10px')
                                .ds()
                          .slt('.head-tab')
                              .a.bor('0px solid white')
                                .bord.rad('10px')
                                .mar('10px')
                                .pad('10px')
                                //.bord.bot.rad.both('0px')
                                //.bord.bot.val('0px')
                                .wh('auto')
                              .ds()
                          .slt('.body-panel')
                              .a.marg.top('0px')
                                .padd.top('20px')
                                .bord.top.rad.both('0px')
                                .bord.top.val('0px')
                                .wh('91.3%','1150px')
                                .ds()
                          .slt('.panel-bar,.panel-cont')
                              .a.mar('10px').pad('10px')
                              .ds()
                          
                            
                          .ok();
                  return this.ui.tabMenu.css;
                  
                },
                
                item : ()=>{ 
                  
                  let cs = new Css();
                      cs.style(['cssAjs','cssUi','cssTabMenu','css_panel-item'])
                          .slt('.panel-item')
                              //.flex.row.p(4)
                              .border('0px solid black')
                              .border_bottom('4px solid black')
                              .margin_bottom('10px solid black')
                              .f.rel().ds()
                              .a.mar('0px').pad('10px')
                                //.bord.rad('10px')
                                .wh('99%','100px')
                                //.bg(cs.rgba.white(1,0.96))
                                .bgd.tsp()
                                .ds()
                          .slt('.panel-item>*')
                              .z_index(1)
                              .f.rel().fs('4.6vmin').ds()
                              .a.bg(cs.rgba.white(3,0.6))
                                .clr(cs.rgba.white(12,0.96))
                                .bor('1px solid '+cs.rgba.white(12,0.96))
                                .mar('10px').pad('10px')
                                .bord.rad('10px')
                                //.bor('0px solid white')
                                .h('auto')
                                
                                .ds()
                          .slt('.panel-item>button')
                              .a.bor('opx solid white')
                                .ds()
                          .slt('.song-add-ok')
                              .a.w('96%').ds()
                          .slt('.song-name')
                              .white_space('wrap')
                              .a.w('90%')
                                //.ovf.scl()
                                //.txt.ovfl.elli()
                                .ds()
                          .slt('.btn-song-play')
                              .a.tsf(cs.fn.rot('45deg'))
                                .bor('0px solid black')
                                .bgd.tsp()
                                .ds()
                          .slt('.input-file, input')
                              .f.fs('3vmin').ds()
                              .a.wh('60%','auto')
                                .bg('white')
                                .bord.rad('10px')
                                .pad('10px')
                                .ds()
                        .ok();
                  return this.ui.tabMenu.css;
                },
                
                panel : ()=>{
                  
                  let cs = new Css();
                      cs.style(['cssAjs','cssUi','cssTabMenu','css_panel-menu'])
                          .slt('.panel-menu,.panel-cont,.panel-move')
                              .background(cs.rgba.white(10,0.96))
                              .flex.row.p(5)
                              .f.rel().ds()
                              .a.mar('6px').pad('6px')
                                .bord.rad('10px')
                                .bor('0px solid '+cs.rgba.white(12,0.96))
                                .wh('auto')
                                .bgd.tsp()
                                .ds()
                          .slt('.panel-cont')
                              .a.ovfl.y.scl()
                                .wh('100%','93%')
                                .ds();
                              
                      cs.ok();
                  return this.ui.tabMenu.css;
                },
                
                lrc : ()=>{
                  
                  let cs = new Css();
                      cs.style(['cssAjs','cssUi','cssTabMenu','css_mp3_lrc'])
                          .slt('.lrc-cont')
                              .f.rel().fs('3vmin').ds()
                              .background('white')
                              .a.mar('10px').pad('10px')
                                .bord.rad('10px')
                                .bor('3px solid black')
                                .wh('99%','360px')
                                //.bgd.tsp()
                                .ovfl.y.scl()
                                .ds()
                              .white_space('pre')
                          .slt('.mp3-name')
                              .f.fs('3vmin').ds()
                              .a.wh('auto','90%')
                                .clr('black')
                              .ds()
                          .slt('.song-add-rst')
                              .a.marpad('10px')
                                .bg('grey')
                                .ds()
                          .ok();
                  return this.ui.tabMenu.css;
                },
                
                ext : ()=>{
                  
                  let cs = new Css();
                  
                  new Css('.ext-tool',{
                    min_width   : '65px',
                    height      : '65px',
                    font_size   : '30px',
                  })
                  
                  new Css('.ext-tool-box',{
                    position       : 'absolute',
                    right          : '20px',
                    bottom         : '20px',
                    width          : '100px',
                    height         : '86%',
                    z_index        : 30,
                    background     : cs.rgba.white(6,0.6),
                    border         : '3px solid black',
                    border_radius  : '10px',
                  })//.ext-tool-box
                  
                },
                
                all  : ()=>{
                  
                  Ajs.runAll(this.ui.tabMenu.css);
                  return this.ui.tabMenu;
                  
                },
            },
            
            index : (anyStr)=>{
              new Css('.body-panel',{
                position        : 'relative',
                display         : 'none',
              })
              let h = new Html();
              h.dom(anyStr)
                .div('.tab-menu-box flex-col-4').top()
                    .div('.cont-head-box flex-row-4').as(1)
                        .button('.head-tab status-btn yelack tab-song','!文章',1)
                        .button('.head-tab status-btn tab-cata','!目录',1)
                        .button('.head-tab status-btn tab-dict','!词典',1)
                        .button('.head-tab status-btn tab-book','!book',1)
                        .button('.head-tab status-btn tab-test','!测试',1)
                        .button('.head-tab status-btn tab-info','!统计',1)
                    .div('.cont-body-box flex-col-8').as(1)
                        .div('.body-panel flex-col-8',1).as(0)
                            .div('.panel-menu flex-row-5',0)
                            .div('.panel-cont flex-col-8',0)
                        .clone(0,4);
                    let i = -1;
                    let cl = ['panel-song','panel-cata','panel-dict','panel-test','panel-info'];
                    for(let obj of (h.queryAll('.body-panel').result)){
                      i++;
                      obj.classList.add(cl[i]);
                    }

                   
                h.ok();
              return this.ui.tabMenu;
              
            },

            tabs : {
              
              song : {
                
                data : {
                  
                  url : null,
                  
                },
                
                topMenu : {
                  
                  build : ()=>{
                    this.ui.tabMenu.tabs.song.topMenu.clean();
                    let h = new Html();
                    h.dom('.panel-song .panel-menu')
                        .button('.btn status-btn add','!add')
                        .button('.btn status-btn create-article','!create')
                        .button('.btn status-btn','!003')
                        .button('.btn status-btn list','!list');
                    h.ok();
                    
                    $all('.panel-menu>button').on.click((e)=>{
                      let ds = e.target;
                      let $tabMenu = this.ui.tabMenu;
                      //$lg('1272::build');
                      $tabMenu.fn.cleanPanel();
                      if(ds.classList.contains('add')){
                        $tabMenu.tabs.song.add.htm();
                      }else 
                      if(ds.classList.contains('create-article')){
                        $tabMenu.tabs.song.create.index();
                      }else 
                      if(ds.classList.contains('list')){
                        $tabMenu.tabs.song.list();
                      }
                    },0)
                    
                    //h.ok();
                      
                    return this.ui.tabMenu.tabs.song.topMenu;
                    
                  },
                  
                  clean : ()=>{
                    
                    Doc.api.query('.panel-menu').innerText = '';
                    
                    return this.ui.tabMenu.tabs.song.topMenu;
                    
                  },
                  
                },
                
                add  : {
                  
                  dat : {
                      
                      name     : null,
                      mp3_part : null,
                      mp3_pid  : null,
                      text_name  : null,
                      text_ext   : null,
                      
                  },
                    
                  htm : ()=>{
                    
                    let css = (()=>{
                      
                      new Css('.pg',{
                        width           : '96%',
                        height          : '70%',
                        top             : '0px',
                        //margin          : '6px',
                        //padding         : '6px',
                        
                      })//.pg
                      new Css('.pv',{
                        height          : '96%',
                        border_radius   : '10px',
                        background      : 'lightgreen',
                      })//.pv
                      new Css('.pc',{
                        display         : 'block',
                        position        : 'absolute',
                        top             : '20px',
                        left            : '40%',
                        height          : 'auto',
                        min_width       : '100px',
                        border_radius   : '10px',
                        background      : 'white',
                        color           : 'black',
                        z_index         : 10,
                        font_size       : '4vmin',
                      })//.pc
                      
                    })()
                    
                    let htm = (()=>{
                      let thiz = this.ui.tabMenu.tabs.song.add;
                      let h = new Html();
                      h.dom('.panel-song .panel-cont')
                        .div('.panel-item').as(0)
                          .div(0,'.pg flex-row-4').as(1)
                              .span(1,'.pv')
                              .span(1,'.pc')
                        .div('.panel-item flex-row-5').as(0)
                            .button('.media-uploader width:96%',`!file upload`,0)
                            .input.file('.input-file input-mp3 dsp:none',0)
                                .on.input(thiz.fn.media_upload,0)
                        .div('.right-box mp3-info')
                        /*.div('.panel-item').as(0)
                            .span(`!txt`,0)
                            .input.file('.input-file input-txt',0)
                                .on.input(thiz.fn.lrc_show,0)*/
                        .div('.right-box lrc-info')
                        /*.div('.panel-item').as(0)
                            .button('.append-to',`!append to`,0)
                                .on.click(thiz.fn.appendTo,0)
                        .div('.right-box lrc-append-to')*/
                        .div('.panel-item').as(0)
                            .button(`.song-add-ok`,`!start`,0)
                              
                            //.span(`.song-add-rst`,0)
                        .ok();
                      })()
                      
                  },
                  
                  fn : {
                    
                    ok : async ()=>{
                      
                      let showResult = (rsp,msg=null)=>{
                        let h = new Html();
                        h.dom('.panel-cont');
                        if(rsp.da.rst == false ){
                          h.div('.panel-item').as(0)
                              .span(`!${rsp.da.rst}`,0)
                                  .at.style('backgroundColor','hsl(0,50%,50%)')
                          .div('.panel-item').as(1)
                              .span(`!${rsp.da.msg}`,1)
                                  .at.style('backgroundColor','hsl(38,100%,50%)');
                          $log.lgg('3774::err::bgo',JSON.stringify(rsp));
                        }else{
                          
                          h.div('.panel-item').as(0)
                              .span(`!${rsp.da.rst}`,0)
                                  .at.style('backgroundColor','hsl(60,50%,50%)');
                          
                        }
                        h.ok();
                      }
                      
                      let thiz = this.ui.tabMenu.tabs.song.add;
                      //thiz.fn.cleanContent();
                      //return;
      
                      let mp3_name = thiz.dat.mp3_name;
                      let mp3_part = thiz.dat.mp3_part;
                      let mp3_pid  = thiz.dat.mp3_pid;
                      let text_name = thiz.dat.text_name;
                      let text_ext  = thiz.dat.text_ext;
                      
                      let name = text_name;
                      if(name == null) name = mp3_name;
                      if(name == null) {
                        alert('2241::both textName and mp3Name are empty');
                        return;
                      }

                      let content = document.body.querySelector('.lrc-cont');
                      if( content ) {
                        content = content.value;
                      }else{
                        return alert('至少需要添加一个文本');
                      }  
                      //$lg('5450',content);
                      // 歌曲信息，歌手，标题等
                      let rst = await this.service.data.req('tableSong.add',name,mp3_part,mp3_pid);
                      if( rst.da.rst == false ) return alert('5420:tableSong.add fail\n'+rst.da.msg);
                      
                      //歌曲id
                      let sid = await this.service.data.req('tableSong.getLastId',);
                      if( sid == false ) return alert('5423:tableSong.getLastId fail');
                      
                      //objLrc处理
                      this.songId = sid;
                      this.objLrc = this.obj.lrc(this);
                      
                      
                      if(text_ext == 'json')
                            this.objLrc.addJson( sid, content );
                      else  this.objLrc.addText( content );
                      //let rspLrcAdd = await this.service.data.req('tableWord.batAdd',sid,lrc);
                      if(this.objLrc == null ) return alert('5503:objLrc.addText fail');
                      //处理后添加到word表
                      let rspLrcAdd = await this.dat.tableWord.batAdd(sid,this.objLrc);
                          //$lg('1593::rspLrcAdd',JSON.stringify(rspLrcAdd));
                          showResult(rspLrcAdd);
                          
                      //添加到mp3表
                      if( mp3_part && mp3_pid ){
                        
                          let rspMp3Add = await this.service.data.req('tableSong.lockMedia',sid, mp3_part, mp3_pid);
                          showResult(rspMp3Add);
                          
                      }
                        
                        
                    },
                    
                    read_mp3_data : (file)=>{
                      
                      return new Promise((ok)=>{
                        let reader = new FileReader();
                            //reader.readAsBinaryString(f1)
                            reader.readAsArrayBuffer(file)
                            reader.onload = (e)=>{
                              //$log.lgg('3612::text',f1.name,this.result);
                              //let m = /.+\.([a-zA-Z]{3,4})$/.match(f1.name);
                              ok(e.target.result);
                              
                            }
                      })

                      
                    },
                    
                    media_upload : async (e)=>{ 
                      const token = performance.now().toFixed(0);
                      $lg('this is media_upload',`token:${token}`);
                      let thiz = this.ui.tabMenu.tabs.song.add;
                      let ds = e.target;
                      let f1 = ds.files[0];
                      
                      /*let ppt = Reflect.getPrototypeOf(f1);
                      let keys = Reflect.ownKeys(ppt);
                      $lg('4976:file.ownKeys',...keys);*/
                      //$lg('4976:webkitRelativePath',f1.webkitRelativePath);
                      
                      /*if(/^.+\.(mp3|wav|jpeg|txt|json)$/i.test(f1.name) == false){
                          return alert('4982:mp3|wav was supported only');
                      }*/
                      
                      let ext = null;
                      let m = /^.+\.(\w+)$/i.exec(f1.name);
                      if( m ) ext = m[1];
                      else return alert(`4988:con't determine extended format:${ext}`);
                      ext = ext.toString().toLowerCase();
                      
                      if( ['txt','json'].includes(ext) ){
                        return thiz.fn.lrc_show(e);
                      }
                      
                      let data = await thiz.fn.read_mp3_data(f1);
                      //$lg('4977:read_mp3_data success');
                      
                      let pv = Doc.api.query('.pv');
                      let pc = Doc.api.query('.pc');
                      //$lg('4981',pv,pc);
                      //let ms = performance.now();
                      
                      let mp3_part_num = await this.fn.shouldBeFission('mp3');
                      if( mp3_part_num > -1 ) mp3_part_num = mp3_part_num.toString().padStart(4,'0');
                      else return alert('5000:mp3_part_num应该>=0, 实际是-1');
                      //ms = performance.now()-ms;
                      //$lg('4994:after:shouldBeFission::bgg',ms);
                      //return alert('mp3_part_num:'+mp3_part_num+'\nms:'+ms);
                      
                      document.addEventListener(`upload_pg_${token}`,(e)=>{
                          try{
                            /*let obj = JSON.parse(e.detail);
                            let op = obj.op;
                            let da = obj.da;*/
                            //$lg('4990:got_upload_pg::bgg');
                            let da = e.detail;
                            if(f1.size > 0){
                              let val = parseFloat(da/f1.size)*100;
                              //$lg('10354',`da:${da},fsize:${f1.size},pc:${val}`);
                              pv.style.width = val + '%';
                              pc.innerText = parseInt(val) + '%';
                            }
                          }catch(e){
                            $lg('4998:upload_pg:error::bgo',e.message)
                          }
                      })
                        
                      return new Promise((res)=>{
                        
                        document.addEventListener(`upload_done_${token}`,(e)=>{
                          $lg(`5044:upload_done_${token}`);
                          let op = 'data__save_as_blob';
                          let da = {
                            //file : '../app/dat/data.sqlite3',
                            file  : `../app/dat/mp3_${mp3_part_num}.sqlite3`,
                            media : f1.name,
                            title : f1.name,
                            ext   : ext,
                            token : token,
                          };
                          let obj = {op,da};
                          this.socket.send(JSON.stringify(obj));
                          
                          document.addEventListener(`save_as_blob_${token}`,(e)=>{
                            //$log.lgg(JSON.stringify(e.detail));
                            let da = e.detail;
                            let rst = da.rst;
                            let dat = da.dat;
                            let msg = da.msg;
                            if(rst == true){
                              thiz.dat.mp3_name  = f1.name;
                              thiz.dat.mp3_part  = parseInt(mp3_part_num);
                              thiz.dat.mp3_pid   = dat;
                              //let pc = Doc.api.query('.pc');
                              //pc.innerText = `库号:${mp3_part_num},id:${dat}`;
                              pc.innerText = 'success';
                              thiz.fn.mp3_show_info(f1.name,mp3_part_num,dat);
                              res(e.detail);
                            }else{
                              pc.innerText = `rst:${rst},msg:${msg}`;
                            }
                              
                          })
                          
                        })
                        
                        let upload_data = {
                          filename : f1.name,
                          token    : token,
                        }
                        this.socket.send(JSON.stringify({op:'upload',da:upload_data}));
                        this.socket.send(data);
                        $lg('5004:this.socket.send(data); done');
                      
                      });
                      
                      //thiz.fn.mp3AddInfo(f1);
                      //thiz.fn.mp3SetFile(f1);
                    },
                    /*
                    mp3AddMedia : ()=>{
                      let thiz = this.ui.tabMenu.tabs.song.add;
                      let f1 = thiz.dat.mp3file;
                      let addr = '../include/handler.php';
                      let path = '../app/mp3/'+thiz.dat.mp3Name;
                      let type = 'mp3';
                      let op = 'file__upload';
                      let da = {path:path,type:'mp3'};
                      let fmda = new FormData();
                          fmda.append("opda",JSON.stringify({op:op,da:da}));
                          fmda.append("mp3",f1);
                      return new Promise((ok,fail)=>{
                        let xhr = new Xhr(addr);
                        xhr.up(fmda);
                        xhr.rsp((rsp)=>{
                          $lg('1477::upload::dat',JSON.stringify(rsp));
                          ok(rsp);
                        },(rsp)=>{
                          $lg('1479::upload::err::bgo',JSON.stringify(rsp));
                          fail(rsp);
                        })
                      })
                    },
                    */
                    
                    mp3_show_info : (name, part, pid)=>{
                      let thiz = this.ui.tabMenu.tabs.song.add;
                          
                      //let name = (f1.name).toString().replace('.mp3','');
                      //thiz.dat.mp3Name = name;
                      let c = Doc.api.query('.mp3-info');
                        if(c){ c.innerHTML = ''; }
                      let h = new Html();
                      h.dom('.mp3-info')
                          .div('.line1 flex-row-4').as(1)
                              .button('.btn media-info-name',`!${name}`,1)
                              
                          .div('.line2 flex-row-4').as(2)
                              .button('.btn media-info-part',`!${part}`,2)
                              .button('.btn media-info-pid',`!${pid}`,2)
                        .ok();
                        
                      //thiz.dat.name = name;
                      
                    },
                    /*
                    /*
                    mp3SetFile : (f1)=>{
                      let thiz = this.ui.tabMenu.tabs.song.add;
                          thiz.dat.mp3file = f1;
                    },
                    mp3UploadFile : ()=>{
                      let thiz = this.ui.tabMenu.tabs.song.add;
                      let f1 = thiz.dat.mp3file;
                      let addr = '../include/handler.php';
                      let path = '../app/mp3/'+thiz.dat.mp3Name;
                      let type = 'mp3';
                      let op = 'file__upload';
                      let da = {path:path,type:'mp3'};
                      let fmda = new FormData();
                          fmda.append("opda",JSON.stringify({op:op,da:da}));
                          fmda.append("mp3",f1);
                      return new Promise((ok,fail)=>{
                        let xhr = new Xhr(addr);
                        xhr.up(fmda);
                        xhr.rsp((rsp)=>{
                          $lg('1477::upload::dat',JSON.stringify(rsp));
                          ok(rsp);
                        },(rsp)=>{
                          $lg('1479::upload::err::bgo',JSON.stringify(rsp));
                          fail(rsp);
                        })
                      })
                    },
                    */
                    
                    lrc_show : (e)=>{
                      let thiz = this.ui.tabMenu.tabs.song.add;
                      let ds = e.target;
                      //$lg('1313::className',ds.className);
                      //let ks= Reflect.ownKeys(ds.files[0]);
                      let f1 = ds.files[0];
                      //let ppt = Reflect.getPrototypeOf(f1);
                      //let ks = Reflect.ownKeys(ppt);
                      //$lg('1316::ks',...ks);
                      //$lg('1316::size,name,ext,cont',f1.size,f1.name,f1.extend,f1.toString());
                      if(/^.+\.(txt|json)$/i.test(f1.name)){
                        if(typeof FileReader == undefined) return;
                        let fder = new FileReader();
                            fder.readAsText(f1)
                            fder.onload = function(e){
                              //$log.lgg('3612::text',f1.name,this.result);
                              //let m = /.+\.([a-zA-Z]{3,4})$/.match(f1.name);
                              let m = f1.name.split('.');
                              
                              thiz.fn.lrc_show_text(f1.name,m[1],this.result);
                            }
                      }
                      
                    },
                    
                    lrc_show_text : (name,ext,lrc)=>{
                      //$lg('1347::lrcAddText');
                      let thiz = this.ui.tabMenu.tabs.song.add;
                          thiz.dat.text_name = name;
                          thiz.dat.text_ext  = ext;
                      let c = Doc.api.query('.lrc-cont');
                      if(c){
                        c.innerHTML = lrc;
                        return
                      }else{
                        let h = new Html();
                        h.dom('.lrc-info')
                            .textarea(`#lrc-cont`,'.lrc-cont',`!${lrc}`)
                          .ok();
                        //let textObj = document.getElementById('lrc-cont');
                        //$lg('5730::bgo','typeof textObj:',typeof textObj,textObj == null);
                      
                      }
                    },
                    
                    
                    
                    cleanContent : ()=>{
                      let chd = Doc.api.queryAll('.panel-cont>div:not(:first-child)');
                      [...chd].forEach((c)=>{
                        c.parentNode.removeChild(c);
                      })
                    },
                    
                    /*
                    appendTo : (e)=>{
                  
                      let ds = e.target;
                  
                      let pars = this.ui.tabMenu.tabs.cata.pars;
                      
                          pars.where = 'body .msg-box .msg-cont';
                      
                      let idx = this.ui.tabMenu.tabs.cata.index();
                      
                      this.ui.tabMenu.tabs.cata.css();
                      
                      this.ui.msgbox.fn.show( idx );
                  
                      this.ui.tabMenu.tabs.cata.folderBox.list( 0, pars.where );
                  
                    },
                    */
                    
                  },
                  
                },
                
                create  : {
                  
                  dat : {
                      
                      title   : null,
                      content : null,
                      singer  : 'me',
                      special : null,
                      
                  },
                    
                  fn : {
                    
                    ok : async ()=>{
                      
                      let showResult = (rsp,msg=null)=>{
                        let h = new Html();
                        h.dom('.panel-song .panel-cont');
                        if(rsp.da.rst == false ){
                          h.div('.panel-item').as(0)
                              .span(`!${rsp.da.rst}`,0)
                                  .at.style('backgroundColor','hsl(0,50%,50%)')
                          .div('.panel-item').as(1)
                              .span(`!${rsp.da.msg}`,1)
                                  .at.style('backgroundColor','hsl(38,100%,50%)');
                          $log.lgg('3774::err::bgo',JSON.stringify(rsp));
                        }else{
                          
                          h.div('.panel-item').as(0)
                              .span(`!${rsp.da.rst}`,0)
                                  .at.style('backgroundColor','hsl(60,50%,50%)');
                          
                        }
                        h.ok();
                      }
                      
                      let thiz = this.ui.tabMenu.tabs.song.create;
                      this.ui.tabMenu.fn.cleanContent('.panel-song .panel-cont');

                      
                      let title   = thiz.dat.title;
                      let content = thiz.dat.content;
                      let singer  = thiz.dat.singer;
                      let special = thiz.dat.special;
                      
                      if(title == null) title = 'no title';
                      if(content == null) {
                        alert('2241::need a content to add');
                        return;
                      }
                      
                      let rsp = await this.service.data.req('tableSong.add',title);
                      showResult(rsp);
                      if(rsp.da.rst == false) {
                        $lg('1357::add song fail::bgo',JSON.stringify(rsp));
                        return;
                      }
                      
                      let rid = await this.service.data.req('tableSong.getLastId',);
                      let rst = Doc.api.query('.song-add-rst');
                          showResult(rid);
                      if(rid.da.rst == false) {
                        $lg('1361::get songId fail::bgo',JSON.stringify(rid));
                        
                        return;
                      }
                      let sid = parseInt( ((rid.da.dat.arr)[0])[0] );

                      this.songId = sid;
                      this.objLrc = this.obj.lrc(this);
                      let lrc = this.objLrc;
                      lrc.addText(thiz.dat.content);
                      //let rspLrcAdd = await this.service.data.req('tableWord.batAdd',sid,lrc);
                      let rspLrcAdd = await this.dat.tableWord.batAdd(sid,lrc);
                          //$lg('1593::rspLrcAdd',JSON.stringify(rspLrcAdd));
                          showResult(rspLrcAdd);
                      
                    },

                    onInput : (e)=>{
                      
                      let ds = e.target;
                      
                      let thiz = this.ui.tabMenu.tabs.song.create;
                      
                      let has = (...args)=>{return ds.classList.contains(...args)}
                      
                      if( has( 'article-title' )){
                        
                        thiz.dat.title = ds.value;
                        
                      }else
                      
                      if( has( 'article-content' )){
                        
                        thiz.dat.content = ds.value;
                        
                      }
                      
                      
                    }

                  },
                  
                  index : ()=>{
                    let thiz = this.ui.tabMenu.tabs.song.create;
                    let h = new Html();
                    h.dom('.panel-song .panel-cont')
                      .div('.panel-item').as(0)
                          .span(`!title`,0)
                          .input.text('.input-title article-title',0)
                              .on.input(thiz.fn.onInput,0)
                      
                      .div('.right-box lrc-info').as(0)
                          .textarea('.lrc-cont input-content article-content fs:4vmin',0)
                              .on.input(thiz.fn.onInput,0)
                      .div('.panel-item').as(0)
                          .button(`.article-create-ok`,`!done`,0)
                              .on.click(thiz.fn.ok,0)
                      .ok();
                  },
                  
                },
                
                list : async ()=>{
                  
                    let css = (()=>{
                      
                      let cs = new Css();
                      
                      new Css('.list-left',{
                        width           : '99%',
                        height          : '96%',
                        z_index         : 1,
                        overflow        : 'hidden',
                      })//.list-left
                      new Css('.list-right',{
                        position        : 'absolute',
                        left            : '30px',
                        z_index         : 2,
                        width           : '70%',
                        height          : '86%',
                        //background      : cs.rgba.white(3,0.3),
                        background      : 'transparent',
                        border          : '1px solid black !important',
                      })//.list-right
                      new Css('.list-right *',{
                        z_index         : '10 !important',
                        opacity         : '1',
                      })//.list-right *
                      new Css('.list-desc',{
                        width           : '96%',
                        height          : '60px',
                        font_size       : '30px !important',
                        margin          : '10px',
                        padding         : '10px',
                      })//.list-desc
                      new Css('.list-cmd',{
                        width           : '96%',
                        height          : '60px',
                        font_size       : '30px !important',
                        margin_bottom   : '30px',
                      })//.list-cmd
                      new Css('.song-id',{
                        padding         : '6px',
                        margin          : '10px',
                        font_size       : '26px !important',
                        background      : 'lightpink',
                      })//.song-id
                      new Css('.song-name',{
                        width           : 'auto !important',
                        padding         : '6px',
                        margin          : '10px',
                        font_size       : '36px !important',
                        background      : cs.rgba.white(3,0.3),
                        color           : 'white',
                        border_radius   : '6px',
                        vertical_align  : 'top',
                        //filter          : 'drop-shadow(0 0 3px black)',
                        text_shadow     : '0px 0px 10px black',
                        //box_shadow        : '0px 0px 0 3px black',
                        //text_shadow     : '10px 1px 0 rgba(255,255,255,1),10px 10px 20px rgba(128,85,128,1)',
                      })//.song-name
                      new Css('img',{
                        width           : '99%',
                        height          : 'auto',
                      })//img
                      new Css('.list-cmd button',{
                        font_size       : '36px',
                        width           : '80px',
                        height          : '80px',
                        border          : '3px solid black',
                        border_radius   : '50%',
                        background      : 'white',
                        text_shadow     : '0px 0px 10px white',
                        //background      : cs.rgba.yellow(3,0.3),
                        margin          : '10px',
                        padding_bottom  : '4px',
                        
                        
                      })//.list-cmd button
                      new Css('.h450',{
                        
                        height          : '450px !important',
                        
                        
                      })//.panel-item
                      new Css('.minor-tool',{
                        background      : `${cs.rgba.white(1,0.3)} !`,
                        color           : `${cs.rgba.white(3,0.6)} !`,
                        border          : `1px solid ${cs.rgba.white(3,0.6)} !`,
                      })//.minor-tool
                      new Css('.list-counter',{
                        background      : `lightblue`,
                        opacity         : 0.6,
                        //background      : `transparent`,
                        border          : `0px solid ${cs.rgba.white(3,0.6)} !`,
                        border_radius   : `6px`,
                      })//.list-counter
                      new Css('.list-counter-item',{
                        background      : `${cs.rgba.white(6,0.6)}`,
                        border          : `1px solid black`,
                        border_radius   : `6px`,
                        margin          : '6px',
                        padding         : '6px',
                        font_size       : '30px',
                      })//.list-counter-item
                      new Css('.list-counter-friend',{
                        background      : `${cs.rgba.green(2,0.1)} !`,
                      })//.list-counter-friend
                      new Css('.list-counter-stranger',{
                        background      : `pink !`,
                      })//.list-counter-stranger
                      new Css('.list-counter-pc',{
                        background      : `${cs.rgba.yellow(6,0.6)} !`,
                      })//.list-counter-pc
                      
                    })()
                  
                    //let txt1 = 'select id,name from song order by id desc;';
                    //let rsp = await this.sql.que(txt1);
                    let rsp = await this.service.data.req('tableSong.list.all');
                    let ids = [];
                    let add = (async ()=>{
                      //$lg('5948::',JSON.stringify(rsp));
                      if(rsp.da.rst == false) return;
                      if(rsp.da.dat.arr.length == 0) return;
                      let h = new Html();
                      h.dom('.panel-song .panel-cont');
                      for(let arr of rsp.da.dat.arr){
                        let id   = arr[0];
                        let name = arr[1];
                        ids.push(id);
                        h.div('.panel-item h450 flex-row-4').as(0)
                                .data('sid',id)
                            .div('.list-left',0).as(6)
                                .img(`#img${id}`,'.img',6)
                            .div('.list-right flex-col-71',0).as(10)
                                .div('.list-desc flex-row-7',10).as(11)
                                    .span(`.song-id`,`!${id}`,11)
                                    .span(`.song-name`,`#song-id-${id}`,`!${name}`,11)
                                .div(`#list-counter-${id}`,'.list-counter flex-row-4',10)
                                .div(`#list-cmd-${id}`,'.list-cmd flex-row-46',10).as(12)
                                    //.button(`.btn-song-ext flash-btn`,`!\u2026`,12)
                                    .button(`.minor-tool btn-song-lock-media flash-btn`,`!\u26d3`,12)
                                    .button(`#enter${id}`,`.btn-song-enter flash-btn`,`!\u279c`,12)
                                
                            /*.button(`.btn-song-remove flash-btn`,`!\u2612`,0)
                                .data('sid',id)
                                .on.click((e)=>{return;},1);*/
                      }
                      h.ok();
                      
                      
                      let dat = [];
                      
                      let ext_class = '';
                      for(let sid of ids){
                        dat = [];
                        let h = new Html();
                            h.dom(`#list-counter-${sid}`);
                        
                        dat.push(  await this.service.data.req('tableWord.getNumberOf.friend',    sid));
                        dat.push(  await this.service.data.req('tableWord.getNumberOf.stranger',  sid));
                        dat.push(  await this.service.data.req('tableWord.getNumberOf.notMarked', sid));
                        dat.push(  await this.service.data.req('tableWord.getNumberOf.notRepeat', sid));
                        dat.push( (dat[0]/dat[3]*100).toFixed(2)+'%')
                        dat.push(  await this.service.data.req('tableWord.getNumberOf.thisArticle',   sid));
                        dat.push(  await this.service.data.req('tableWord.getNumberOf.maxLineIdx',sid));
                        
                        let i = -1;
                        for(let num of dat){
                          i++;
                          ext_class = '';
                          if( i == 0) ext_class = 'list-counter-friend';
                          if( i == 1) ext_class = 'list-counter-stranger';
                          if( i == 4) ext_class = 'list-counter-pc';
                          h.span(`.list-counter-item ${ext_class}`,`!${num}`);
                        }
                        h.ok();
                      }
                      
                      
                    })();
                    
                    [...Doc.api.queryAll('.list-left .img')].forEach(img=>{
                      let id = img.id.replace('img','').padStart(4,'0');
                      img.src = `../app/img/${id}.jpgx`;
                    })
                    //let img79 = Doc.api.gbid('img79');
                    //if( img79 ) img79.src = '../app/img/0079.jpg';
                },
                
                load : async (sid)=>{
                  
                  const $song = this.ui.tabMenu.tabs.song;
                  
                  $lg('5764::load::sid',sid);
                  
                  if(sid == null) return;
                      
                  this.songId = parseInt(sid);
                  
                  this.ui.spreadMenu.fn.disLrcTool();
                  
                  let obj = await this.service.data.req('tableSong.getPartPid',sid);
                  
                  //$lg('5774',JSON.stringify(obj));
                  
                  if( obj == null || obj.part == null ) return alert('没有找到mp3相关信息');
                  
                  const part = obj.part.toString().padStart(4,'0');
                  const file = `../app/dat/mp3_${part}.sqlite3`;  
                  const sql  = `select dat from mp3 where id = ${obj.pid}`;
                  const op   = 'data__stream_blob';
                  const da   = {file,sql};
                  const opda = {op,da};
                  //this.socket.send(JSON.stringify(opda));
                  const socket = new Socket('ws://127.0.0.1:8081');
                  
                  let result = true;
                  
                  socket.sendObj(opda);
                        
                  socket.on(op,(da)=>{
                    //$lg('5792',JSON.stringify(da));
                    if(da.rst == false){
                      result = false;
                      let msg = '加载音频失败:\n'+da.msg;
                      return alert(msg);
                    }
                  })
                  
                  if(result == false ) {
                    return alert('加载音频失败');
                  }
                  const data = await socket.gotObject();
                  
                  const mp3Blob = new Blob([data], { type: 'audio/mpeg' });  
                  
                  if( $song.data.url != null ){
                    URL.revokeObjectURL($song.data.url);      
                  }
                  
                  $song.data.url = URL.createObjectURL(mp3Blob);  
                  //$lg('5795:url',$song.data.url);
                  this.audio.load($song.data.url);
                  
                  

                  //await this.dat.fn.buildObjLrcAll(this.songId);
                  if(this.objLrc.ready)
                      this.ui.spreadMenu.fn.disLrcTool(false);
                  
                  return;
                },
                /*
                play : async (e)=>{
                  let ds = e.target;
                  let sid = ds.parentNode.getAttribute('data-ajs-sid');
                  
                  if(sid == null) return;
                      
                  this.songId = parseInt(sid);
                  
                  this.ui.spreadMenu.fn.disLrcTool();
                  
                  let rsp = await this.service.data.req('tableMp3.getPath',sid);
                  
                  if(rsp.da.rst == false) return this;
                  
                  $lg('1228::rsp',JSON.stringify(rsp));
                  let path = ((rsp.da.dat.arr)[0])[0];
                  //$lg('1230::path',path);
                  
                  if(path == null) return this;
                  
                  
                  await this.audio.load(path);
                  this.audio.play();
                  
                  Doc.api.query('.ajs-slider-close').click();

                  
                  await this.dat.fn.buildObjLrcAll(this.songId);
                  
                  this.ui.spreadMenu.fn.disLrcTool(false);
                  
                  
                },
                */
                enter : async (e)=>{
                  let ds = e.target;
                  //let sid = ds.parentNode.getAttribute('data-ajs-sid');
                  let sid = ds.id.replace('enter','');
                  
                  if(sid == null) return;
                      
                  this.songId = parseInt(sid);
                  
                  await this.ui.article.content.load( sid );
                  
                  
                  
                  this.service.data.req('tableActivity.add',sid);
              
                  
                  /*
                  this.ui.spreadMenu.fn.disLrcTool();
                  
                  let rsp = await this.service.data.req('tableMp3.getPath',sid);
                  
                  if(rsp.da.rst == false) return this;
                  
                  $lg('1228::rsp',JSON.stringify(rsp));
                  let path = ((rsp.da.dat.arr)[0])[0];
                  //$lg('1230::path',path);
                  
                  if(path == null) return this;
                  
                  
                  await this.audio.load(path);
                  this.audio.play();
                  
                  Doc.api.query('.ajs-slider-close').click();

                  
                  await this.dat.fn.buildObjLrcAll(this.songId);
                  
                  this.ui.spreadMenu.fn.disLrcTool(false);
                  */
                  
                },
                
                lock_media : async (e,ds)=>{
                  
                  //$lg('6149::bgb','lock_media');
                  
                  let sid = ds.parentElement.id.replace('list-cmd-','');
                  if( sid ) sid = parseInt( sid );
                  
                  //$lg('6149::bgb','sid',sid);
                  //alert(pid);
                  this.ui.mediaBinding.index( sid, async (sid,part,pid)=>{
                    //alert(`sid:${sid},part:${part},pid:${pid}`);
                    
                    let rsp = await this.service.data.req('tableSong.lockMedia',sid,part,pid);
                    
                    alert(rsp.da.rst);
                    
                  })
                  
                  
                },
                
                ext : async (e)=>{
                  //alert('song-ext');
                  let idx = (e)=>{
                    if(e == null) return "''";
                    return e.getAttribute('data-ajs-idx');
                  }
                  let ds = e.target;
                  let dp = ds.parentNode;
                  /*let dpn = dp.nextSibling;
                  let dpp = ds.parentNode.parentNode;
                  */
                  let sid = ds.id.replace('img','');
                  //$lg('1817::idx',`dp:${idx(dp)}`,`dpn:${idx(dpn)}`,`dpp:${idx(dpp)}`);
                  
                  let box = Doc.api.query('.ext-tool-box');
                  if( box )box.parentNode.removeChild(box);
                  
                  
                  if(ds.getAttribute('data-ext-menu') == '1'){
                    ds.setAttribute('data-ext-menu','0');
                    return;
                  }
                  
                  if(sid == null) return;
                  
                  let h = new Html();
                  h.dom()
                    .div('.panel-item ext-tool-box flex-col-8050').top()
                        .data('sid',sid)
                        .on.click( async (e)=>{
                          let ds = e.target;
                          let dp = e.target.parentNode;
                          let sid = dp.getAttribute('data-ajs-sid');
                          //$lg('2301::sid',sid);
                          if( sid ) sid = parseInt( sid );
                          this.songId = sid;
                          //$lg('1827',`sid:${sid}`,dp.className,ds.className);
                          let cts = (...args)=>{return ds.classList.contains(...args);}
                          if(cts('ext-info')){
                            $lg('6240::ext-info::bgb');
                            let num0 = await this.service.data.req('tableWord.getNumberOf.maxLineIdx',sid);
                            let num1 = await this.service.data.req('tableWord.getNumberOf.thisArticle',   sid);
                            let num2 = await this.service.data.req('tableWord.getNumberOf.notRepeat', sid);
                            let num3 = await this.service.data.req('tableWord.getNumberOf.friend',    sid);
                            let num4 = await this.service.data.req('tableWord.getNumberOf.stranger',  sid);
                            let num5 = await this.service.data.req('tableWord.getNumberOf.notMarked', sid);
                            let sum  = `当前文章统计\n`;
                                sum += `  句子数:${num0}\n`;
                                sum += `单词量\n`;
                                sum += `  全部:${num1}\n`
                                sum += `  不重复:${num2}\n`
                                sum += `  熟词:${num3}\n`
                                sum += `  生词:${num4}\n`
                                sum += `  未标注:${num5}\n`
                            alert(sum);
                          }else 
                          if(cts('ext-media')){
                            
                            this.ui.mediaBinding.index(sid,(pid)=>{
                              return new Promise((ok)=>{
                                alert(sid);
                                ok();
                              })
                            });

                          }else
                          if(cts('ext-article')){
                            $lg('3541::ext-article::sid::bgo',sid);
                            this.ui.article.content.load( sid );

                          }else
                          if(cts('ext-remove')){
                             let a = window.confirm('remove it ?');
                              if(a == true){
                                //let sid = ds.getAttribute('data-ajs-sid');
                                let sid = ds.parentNode.getAttribute('data-ajs-sid');
                                    sid = parseInt(sid);
                                    //$lg('1310::sid::bgg',sid);
                                this.ui.tabMenu.tabs.song.remove(sid);
                              }

                          }else
                          if(cts('ext-listen')){
                            await this.ui.sliderMenu.close();
                            this.ui.listen.index(sid);
                          }
                        },0)
                        .button('.ext-tool ext-remove',`!\u00d7`)  
                        .button('.ext-tool ext-media',`!\u266c`)  
                        .button('.ext-tool ext-info',`!\u26a0`)  
                        .button('.ext-tool ext-listen',`!\u260a`)  
                        //.button('.ext-tool ext-article',`!\u2637`);
                         
                    //.queryAll('.ext-tool').on.click((e)=>{return},1);
                  
                  let tool = h.pack();
                  
                  dp.appendChild(tool);
                  /*
                  if(dpn == null)dpp.appendChild(tool);
                  else {
                    //$lg('1842::dpn',dpn.innerHTML);
                    dpp.insertBefore(tool,dpn);
                  }*/
                  //$lg('1814::btn-ext');
                  ds.setAttribute('data-ext-menu','1');
                  return;
                },
                /*
                article : async (sid)=>{
                  if(this.ui.article.ds == null){
                    await this.ui.article.add();
                  }
                  
                  await this.dat.fn.buildObjLrcAll(sid);
                  this.ui.article.content.add();
                  
                  return this;
                  
                },*/
                
                remove : async (sid)=>{
                  let rsp0 = await this.service.data.req('tableSong.remove',sid);
                  let rsp1 = await this.service.data.req('tableWord.remove',sid);
                  let rsp2 = await this.service.data.req('tableMp3.remove',sid);
                  let rsp3 = await this.service.data.req('tableTag.remove',sid,'word');
                  this.ui.tabMenu.tabs.song.list();
                  //let rsp3 = await this.dat.tableAware.remove(sid);
                  //$lg('1577::remove song::bgo',rsp0.da.rst,rsp1.da.rst,rsp2.da.rst,)
                },
                
                
                
                
              },
              
              cata : {
                
                pars : {
                  
                  where : null,
                  
                },
                
                topMenu : {
                  
                  build : ()=>{
                    //this.ui.tabMenu.tabs.cata.topMenu.clean();
                    //$lg('3453::cata.topMenu.build::bgg');
                    if(Doc.api.query('.panel-cata .panel-menu button'))return;
                    
                    this.ui.tabMenu.tabs.cata.css();
                    
                    let h = new Html();
                    h.dom('.panel-cata .panel-menu')
                        .button('.btn status-btn list','!list')
                        .button('.btn status-btn delete','!delete')
                        .button('.btn status-btn edit','!edit')
                        //.button('.btn status-btn move','!move')
                        .button('.btn status-btn add','!add');
                    h.ok();
                    
                    $all('.panel-cata .panel-menu>button').on.click((e)=>{
                      let ds = e.target;
                      let $tabMenu = this.ui.tabMenu;
                      this.ui.fn.highlight(e);
                      //$lg('1272::build');
                      $tabMenu.fn.cleanPanel();
                      if(ds.classList.contains('add')){
                        $tabMenu.tabs.cata.folderBox.add.htm();
                      }else 
                      if(ds.classList.contains('list')){
                        $tabMenu.tabs.cata.folderBox.list();
                      }else
                      if(ds.classList.contains('edit')){
                        let tar = Doc.api.query(".folder-box .cata-item-name[class*='yelack']");
                        if( tar == null ) return;
                        let caid = tar.getAttribute('data-ajs-caid');
                        let fgm = $tabMenu.tabs.cata.subMenu.edit(caid);
                        this.ui.msgbox.fn.show( fgm );
                      }else
                      if(ds.classList.contains('delete')){
                        $tabMenu.tabs.cata.edit();
                      }
                      /*if(ds.classList.contains('move')){
                        $tabMenu.tabs.cata.move();
                      }*/
                    },0)
                    
                    //h.ok();
                    this.ui.tabMenu.tabs.cata.folderBox.list();
                    
                    return this.ui.tabMenu.tabs.cata.topMenu;
                    
                  },
                  
                },
                
                css : ()=>{
                  if( Doc.has(`style[class*='cata_item']`)) return;
                  let color = `hsla(30,20%,10%,0.3)`;
                  Css.root = 'Ajs/cata_item';
                  new Css('.elm-to-move',{
                    background      : 'orange',
                    color           : 'white',
                    font_size       : '4vmin',
                    border_radius   : '10px',
                    border          : '3px solid black',
                    padding         : '6px',
                    margin          : '6px',
                  })//elm-to-move
                  new Css('.cata-item',{
                    position        : 'relative',
                    height          : 'auto',
                    width           : '96%',
                    margin          : '6px',
                    margin_left     : '40px',
                    padding         : '2px',
                    font_size       : '4vmin',
                    background      : 'transparent',
                  })//.cata-item
                  new Css('.cata-item-line',{
                    position        : 'relative',
                    display         : 'flex',
                    flex_direction  : 'flex-row',
                    justify_content : 'flex-start',
                    align_items     : 'center',
                  })//.cata-item-line
                  new Css('.cata-item-menu',{
                    position        : 'relative',
                    //top             : '-6px',
                    left            : '50px',
                    padding         : '0px',
                    font_size       : '3vmin',
                    background      : `${color}`,
                    width           : '42px',
                    height          : '78%',
                    border          : `0px solid ${color}`,
                    border_right    : `16px solid ${color}`,
                    border_top_left_radius     : '6px',
                    border_bottom_left_radius  : '6px',
                    z_index         : 1,      
                  })//.cata-item-menu
                  new Css('.cata-item-name',{
                    position        : 'relative',
                    margin          : '2px',
                    padding         : '2px',
                    padding_left    : '56px',
                    padding_right   : '16px',
                    //background      : 'lightyellow',
                    white_space     : 'pre',
                    border_radius   : '10px',
                    border          : '3px solid black',
                  })//.cata-item-name
                  new Css('.cata-add-ok,.cata-add-input',{
                    width           : '96%',
                    margin          : '20px',
                    padding         : '10px',
                    font_size       : '4vmin',
                    background      : 'gray',
                  })//.cata-add-ok,.cata-add-input
                  new Css('.cata-add-input',{
                    background      : 'lightgrey',
                  })//.cata-add-input
                  new Css('.cata-item-menu:hover,.cata-item-menu:active',{
                    border       : `0px solid ${color}`,
                    padding      : '0px',
                    background   : `${color}`,
                  })//.cata-add-input
                  new Css('.panel-cata .panel-cont .folder-box>.cata-item',{
                    margin_left  : '-30px',
                  })//.panel-cata .panel-cont .folder-box>.cata-item
                  new Css('.cata-move-to',{
                    width        : 'auto !important',
                    white_space  : 'nowrap',
                  })//.cata-move-to
                  /*new Css(`.panel-cata .panel-cont .folder-box>.cata-item:nth-child(0)`,{
                    margin_top  : '100px',
                  })*///.panel-cata .panel-cont .folder-box>.cata-item:nth-child(1)
                  Css.root = 'Ajs/cata_menu';
                  new Css('.cata-menu-box',{
                    height            : 'auto',
                    width             : '96%',
                    display           : 'flex',
                    flex_direction    : 'row',
                    justify_content   : 'space-around',
                    align_items       : 'center',
                    border_radius     : '6px',
                    //background        : 'lightblue',
                    background        : 'gray',
                    padding           : '3px',
                    transition        : 'width 0.3s',
                  })//.cata-menu-box
                  new Css('.cata-submenu',{
                    position          : 'absolute',
                    top               : '-20px',
                    left              : '100px',
                    width             : 'auto !important',
                    z_index           : 100,
                    background        : 'grey',
                    padding           : '16px',
                    border            : '1px solid black',
                    border_radius     : '10px',
                    
                  })//.cata-submenu
                  
                  new Css('.cata-layer',{
                    position        : 'relative',
                    //display         : 'flex',
                    flex_direction  : 'column',
                    justify_content : 'flex-start',
                    align_items     : 'flex-start',
                    overflow        : 'scroll',
                    border          : '2px solid lightblue',
                    border_radius   : '10px',
                    margin          : '3px',
                    padding         : '3px',
                  })//.cata-layer
                  Css.root = 'Ajs/cata_list';
                  new Css('.list-line',{
                    padding           : '6px',
                    margin            : '6px',
                    padding           : '6px',
                    border_radius     : '10px',
                    border            : '3px solid grey',
                    width             : '93%',
                    background        : 'hsla(45,6%,30%,0.2)'
                  })//.list-line
                  new Css('.list-line-name',{
                    width             : 'auto',
                    overflow_x        : 'scroll',
                    white_space       : 'pre',
                  })//.list-line-name
                  new Css('.folder-top',{
                    transform         : 'rotateY(180deg)',
                  })//.folder-top
                  new Css('.list-line-check',{
                    width             : '50px',
                    height            : '50px',
                  })//.list-link-check
                  new Css('.cata-btn',{
                    position          : 'relative',
                    font_size         : '5vmin',
                    width             : 'auto',
                    min_width         : '100px',
                    height            : '96%',
                    margin            : '2px',
                    margin_left       : '4px',
                    margin_right      : '4px',
                    padding           : '2px',
                    padding_left      : '10px',
                    padding_right     : '10px',
                    border_radius     : '6px',
                    border            : '0px solid black',
                    flex_grow         : 1,
                    text_align        : 'center',
                    
                  })//.cata-menu
                  Css.root = 'Ajs';
                  
                  let showBoth = (()=>{
                    let cs = new Css()
                    .style('Ajs/cata-show-both')
                    .slt('.cata-box')
                        .flex.row.p(46)
                        .a.wh('96%').ds()
                    .slt('.cata-layer')
                        .a.wh('49%','96%')
                          .ds()
                    .ok();
                  })()
                  let showHalf = (()=>{
                    let cs = new Css()
                    .style('Ajs/cata-show-half')
                    .slt('.cata-box')
                        .flex.col.p(82)
                        .a.wh('96%').ds()
                    .slt('.cata-layer')
                        .a.wh('96%','96%')
                          .ds()
                    .slt('.folder-box')
                        .a.dsp.flx().ds()
                    .slt('.list-box')
                        .a.dsp.no().ds()
                    .ok();
                  })()
                  
                  Doc.api.query('.Ajs .cata-show-both').disabled = true;
                  Doc.api.query('.Ajs .cata-show-half').disabled = false;
                  
                  
                },
                
                subMenu : {
                  
                  htm : (e,id = 0)=>{
                    
                    let ds = e.target;
                    let dp = e.target.parentNode;
                    let has = (...args)=> ds.classList.contains(...args);
                    [...Doc.api.queryAll('.cata-submenu')].forEach(obj=>{
                      obj.parentNode.removeChild(obj);
                    })
                    let h = new Html();
                    h.dom( dp )
                        .div('.cata-submenu flex-row-5').top()
                          .data('id',id)
                          .button('.btn cata-btn close','!\u00ab')
                          .button('.btn cata-btn tool edit','!\u270e')
                          .button('.btn cata-btn tool up','!\u21d1')
                          .button('.btn cata-btn tool down','!\u21d3')
                          .button('.btn cata-btn tool top','!\u21f1')
                          .button('.btn cata-btn tool move','!\u21d5')
                          .button('.btn cata-btn tool delete','!\u2297')
                    .queryAll('.cata-btn').on.click( async (e)=>{
                      let ds = e.target;
                      let dp = e.target.parentNode;
                      let has = (...args)=> ds.classList.contains(...args);
                      if(has('move')){
                        [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                          obj.parentNode.removeChild(obj);
                        })
                        let fgm = this.ui.tabMenu.tabs.cata.subMenu.move();
                        dp.parentNode.appendChild( fgm );
                      }else
                      if(has('up')){

                      }else
                      if(has('down')){

                      }else
                      if(has('top')){
                        [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                          obj.parentNode.removeChild(obj);
                        })
                        
                        let id = dp.getAttribute('data-ajs-id');
                        let upid = 0;
                        let rsp = await this.service.data.req('tableCata.update.upid',id,upid);
                        if( rsp.da.rst == false ) return alert( rsp.da.msg );
                        Doc.api.query('.cata-submenu .close').click();
                        Doc.api.query('.panel-cata .panel-menu .list').click();
                     
                      }else
                      if(has('close')){
                        let elms = Doc.api.queryAll('.elm-to-move');
                        
                        [...elms].forEach( elm => elm.classList.remove('elm-to-move') );
                        
                        elms = Doc.api.queryAll('.cata-submenu');
                        [...elms].forEach(elm=>elm.parentNode.removeChild(elm));
                      }else 
                      if(has('delete')){
                        
                        let id = dp.getAttribute('data-ajs-id');
                        
                        [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                          obj.parentNode.removeChild(obj);
                        })
                        let fgm = this.ui.tabMenu.tabs.cata.subMenu.del(id);
                        dp.parentNode.appendChild( fgm );
                        
                        
                      }else
                      if(has('edit')){
                        
                        let id = dp.getAttribute('data-ajs-id');
                        $lg('3558::id',id);
                        [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                          obj.parentNode.removeChild(obj);
                        })
                        let fgm = this.ui.tabMenu.tabs.cata.subMenu.edit(id);
                        this.ui.msgbox.fn.show( fgm );
                        
                        
                      }
                    },0)
                    /*.query('.cata-submenu').on.click((e)=>{
                      
                    },0)*/
                    h.ok();
                  
                  },
                  
                  move : ()=>{
                  
                    let htm = new Html()
                    .dom()
                        .div('.cata-submenu flex-row-5').top()
                          //.span('.btn cata-move-label',`!move to:`)
                          .span('.cata-move-to',`!click target`)
                          //.button('.btn cata-move-close',`! X `)
                          .button('.btn cata-move-ok',`!ok`)
                      
                    .queryAll('.btn').on.click((e)=>{return;},1)
                    
                    .query('.panel-move').on.click( async(e)=>{
                      let ds = e.target;
                      this.ui.fn.highlight(e);
                      let has = (a)=>{ return ds.classList.contains(a)};
                      /*if( has('cata-move-close') ){
                        ds.parentNode.parentNode.removeChild(ds.parentNode);
                      }else*/
                      if( has('cata-move-ok') ){
                        $lg('3556::dp.className',ds.parentNode.className,ds.parentNode.parentNode.parentNode.className);
                        let dppp = ds.parentNode.parentNode.parentNode;
                        let caid = dppp.getAttribute('data-ajs-caid');
                        let upid = ds.getAttribute('data-upid');
                        let rsp = await this.service.data.req('tableCata.update.upid',caid,upid);
                        if( rsp.da.rst == false ) return alert( rsp.da.msg );
                        $lg('3892::rsp',JSON.stringify(rsp));
                        Doc.api.query('.cata-submenu .close').click();
                        Doc.api.query('.panel-cata .panel-menu .list').click();
                      }
                    },0);
                    
                    return htm.pack();
                    
                  },
                  
                  del  : (id)=>{
                  
                    let htm = new Html()
                    .dom()
                        .div('.cata-submenu submenu-del flex-row-5').top()
                          .data('id',id)
                          .span('.btn cata-del-alert',`!del ?`)
 
                          .button('.btn cata-del-yes',`!yes`)
                          .button('.btn cata-del-no',`!no`)
                      
                    .queryAll('.btn').on.click((e)=>{return;},1)
                    
                    .query('.submenu-del').on.click( async(e)=>{
                      let ds = e.target;
                      this.ui.fn.highlight(e);
                      let has = (a)=>{ return ds.classList.contains(a)};
                      /*if( has('cata-move-close') ){
                        ds.parentNode.parentNode.removeChild(ds.parentNode);
                      }else*/
                      if( has('cata-del-yes') ){
                        //$lg('3556::dp.className',ds.parentNode.className,ds.parentNode.parentNode.className);
                        let dp = ds.parentNode;
                        let id = dp.getAttribute('data-ajs-id');
                        
                        let rsp = await this.service.data.req('tableCata.del',id);
                        if( rsp.da.rst == false ) return alert( rsp.da.msg );
                        Doc.api.query('.cata-submenu .close').click();
                        Doc.api.query('.panel-cata .panel-menu .list').click();
                      }else 
                      if( has('cata-del-no') ){
                        //$lg('3556::dp.className',ds.parentNode.className,ds.parentNode.parentNode.className);
                        
                        Doc.api.query('.cata-submenu .close').click();
                        
                      }
                    },0);
                    
                    return htm.pack();
                    
                  },
                  
                  edit : (caid)=>{
                    
                    let htm = new Html().dom()
                    .div('.pan cata-edit-box flex-col-5').top()
                      .data('temp',caid)
                      .input.text('.btn cata-edit-input')
                      .button('.btn cata-edit-ok',`!ok`)
                        .on.click(async (e)=>{
                          
                          let ds = e.target;
                          let dp = e.target.parentNode;
                          
                          let name = dp.firstChild.value.trim();
                          
                          let id = dp.getAttribute('data-ajs-temp');
                          
                          if( name == null || name.length == 0 ) return;
                          
                          let rsp = await this.service.data.req('tableCata.update.name',id,name);
                          
                          if( rsp.da.rst == false ){ return  alert( rsp.da.msg ) };
                          
                          this.ui.msgbox.fn.hide();
                          Doc.api.query('.panel-cata .panel-menu .list').click();
                          
                        },0);
                    
                    return htm.pack();
                    
                  },
                  
                },
                
                
                index : ( box = null )=>{
                  
                  //$lg('3772::htm::box::bgo',box);
                  
                  if(Doc.has(`${box} .folder-box`)) return;

                  let htm = new Html();
                  htm.dom(box)
                      .div('.cata-box').top()
                        .div('.cata-layer folder-box').as(1)
                          .div(1,'.cata-menu-box folder-menu').as(0)
                              .button(0,'.cata-btn',`!A`)
                              .button(0,'.cata-btn',`!B`)
                              .button(0,'.cata-btn folder-both',`!\u25e7`)
                              .button(0,'.cata-btn folder-top',`!\u21f1`)
                        .div('.cata-layer list-box').as(2)
                          .div(2,'.cata-menu-box list-menu').as(0)
                              .button(0,'.cata-btn list-save',`!\u272a`)
                              .button(0,'.cata-btn list-table',`!\u26d7`)
                              .button(0,'.cata-btn list-unlink',`!\u2260`)
                                  .disable(true)
                              .button(0,'.cata-btn folder-both',`!\u25e7`)
                              .button(0,'.cata-btn list-top',`!\u21f1`)
                              .button(0,'.cata-btn list-chk',`!\u25a2`)
                  
                      .queryAll('.folder-menu button').on.click((e)=>{
                        let ds = e.target;
                        let has = (...a)=>{return ds.classList.contains(...a)}
                        if(has('folder-top')){
                          Doc.api.query('.Ajs .cata-show-both').disabled = true ;
                          Doc.api.query('.Ajs .cata-show-half').disabled = false ;
                          
                          //Doc.api.query('.folder-box').style.zIndex = 0;
                          Doc.api.query('.folder-box').style.display = 'flex';
                          //Doc.api.query('.list-box').style.zIndex = 1;
                          Doc.api.query('.list-box').style.display = 'none';
                        }else
                        if(has('folder-both')){
                          Doc.api.query('.Ajs .cata-show-both').disabled = false ;
                          Doc.api.query('.Ajs .cata-show-half').disabled = true ;
                          Doc.api.query('.folder-box').style.display = 'flex';
                          Doc.api.query('.list-box').style.display = 'flex';
                        
                            
                        }
                      },0)
                      
                      .queryAll('.list-menu button').on.click( async (e)=>{
                        let pars = this.ui.tabMenu.tabs.cata.pars;
                        let where = pars.where;
                        let ds = e.target;
                        let has = (...a)=>{return ds.classList.contains(...a)}
                        if(has('list-top')){
                          
                          Doc.api.query('.Ajs .cata-show-both').disabled = true ;
                          Doc.api.query('.Ajs .cata-show-half').disabled = false ;
                          
                          
                          //Doc.api.query('.folder-box').style.zIndex = 1;
                          Doc.api.query('.folder-box').style.display = 'none';
                          
                          //Doc.api.query('.list-box').style.zIndex = 0;
                          Doc.api.query('.list-box').style.display = 'flex';
                        
                        }else
                        if(has('folder-both')){
                          Doc.api.query('.Ajs .cata-show-both').disabled = false ;
                          Doc.api.query('.Ajs .cata-show-half').disabled = true ;
                          Doc.api.query('.folder-box').style.display = 'flex';
                          Doc.api.query('.list-box').style.display = 'flex';
                        
                            
                        }else
                        if(has('list-table')){
                          
                          /*
                          let rsp = await this.service.data.req('tableSong.list.all',);
                          this.ui.tabMenu.tabs.cata.listBox.listTableData(rsp,box);
                          */
                          
                          let rsp = await this.service.data.req('tableTbl.listAll',);
                          //$lg('4048::listTableName',JSON.stringify(rsp));
                          this.ui.tabMenu.tabs.cata.listBox.listTable(rsp,box);
                          
                          
                        }else
                        if(has('list-unlink')){
                          
                          $lg('4385::unlink');  
                          
                        }else
                        if(has('list-save')){
                          
                          ds.style.color = 'black';
                          //$lg('4054::list-save');
                          /*
                          let rsp = await this.service.data.req('tableSong.list.all',);
                          this.ui.tabMenu.tabs.cata.listBox.listTableData(rsp,box);
                          */
                          let [tag,caid,tableId] = [null,null,null];
                          
                          let fld = Doc.api.query(`${where} .folder-box .cata-item .yelack`)
                          $lg('4063::fld == null',fld == null,where == null,`${where} .folder-box .cata-item .yelack`);
                          if( fld ){ 
                            caid = fld.getAttribute('data-ajs-caid');
                          }
                          let arr = [];
                          let chks = Doc.api.queryAll(`${where} .list-box input:checked`);
                          $lg('4069::bgb',chks==null,chks.length,`${where} .list-box .list-line-check[checked=true]`)
                          if( chks.length > 0 ){ 
                            let i = -1;
                            for( let chk of [...chks] ){
                              i++;
                              $lg('4074::bgg',chk.getAttribute('data-ajs-idx'));
                              let rowId = chk.getAttribute('data-ajs-rowId');
                              if( rowId ) arr.push( rowId );
                              if( i == 0 ) tableName = chk.getAttribute('data-ajs-tableName');
                            }
                          }
                          
                          $lg('4078::arr.length',arr.length,JSON.stringify(arr));
                          $lg('4079::tag,caid,tableName',`'${tag}','${caid}','${tableName}'`)
                          
                          let rsp = await this.service.data.req('tableTag.add',tag,caid,arr,tableName);
                          if( rsp.da.rst == true ) {
                            ds.style.color = 'green';
                          }else{
                            ds.style.color = 'red';
                            alert( rsp.da.msg );
                          }
                          //this.ui.tabMenu.tabs.cata.listBox.listTable(rsp,box);
                          
                          
                        }
                        
                        Doc.api.query('.list-unlink').disabled = true;
                        
                      },0);
                  
                      /*.query('.folder-menu').on.click((e)=>{
                        let ds = e.target;
                        alert(ds.innerText);
                      },0);*/
                  
                  if( box ) {
                    //$lg('3832::bgg');
                    htm.ok();
                  }
                  else return htm.pack();
                  
                },
                
                folderBox : {
                
                  list : async (upid = 0, where = null)=>{
                    
                    //$lg('3834::cata::list')
                    
                    let $cata = this.ui.tabMenu.tabs.cata;
                    
                    let rsp = await this.service.data.req('tableCata.list',upid);
                    
                    //$lg('3509::rsp',JSON.stringify(rsp));
                    
                    if(rsp.da.rst == false){ return alert(rsp.da.msg); }
                    
                    if( rsp.da.dat.arr.length == 0 ){
                      return //alert( 'found nothing from back storage' );
                    }
                    
                    if( upid == 0 ) {
                      //this.ui.tabMenu.fn.cleanBodyPanel('.panel-cata .panel-cont ');
                      [...Doc.api.queryAll('.cata-item')].forEach(elm=>elm.parentNode.removeChild(elm))
                    }
                    $cata.folderBox.add.items(rsp.da.dat.arr, where);
                    
                  },
                  
                  add : {
              
                    htm : ()=>{
                      
                      let htm = new Html().dom()
                      .div('.pan cata-add-box flex-col-5').top()
                        .input.text('.btn cata-add-input')
                        .button('.btn cata-add-ok',`!ok`)
                          .on.click(async (e)=>{
                            
                            const ds = e.target;
                            
                            let upid = 0;
                            
                            let name = e.target.parentNode.firstChild.value.trim();
                            
                            //$lg('3532::name',`'${name}'`);
                            
                            if( name == null || name.length == 0 ) return;
                            
                            let obj = Doc.api.query('.panel-cata .panel-cont .yelack');
                            //$lg('4467::obj.idx',obj.getAttribute('data-ajs-idx'));
                            if( obj != null ) upid = obj.parentNode.parentNode.getAttribute('data-ajs-caid');
                            
                            //this.fn.bg.flash(ds);
                            
                            let rsp = await this.service.data.req('tableCata.add', upid, name );
                            
                            if( rsp.da.rst == false ){ return  alert( rsp.da.msg ) };
                            
                            this.fn.bg.green(ds);
                            
                            this.ui.msgbox.fn.hide();
                            
                            this.ui.tabMenu.tabs.cata.folderBox.list();
                            
                            //$lg('3535::rsp::bgb',JSON.stringify(rsp));
                            
                          },0)
                      
                      this.ui.msgbox.fn.show( htm.pack() );
                      
                    },
              
                    items : ( arr,where = null )=>{
                        
                      //$lg('3554::add::items::arr',JSON.stringify(arr));
                      
                      if( arr.length == 0 ) return;
                      
                      
                      let htm = new Html();
                      
                    
                      for( let item of arr ){
                        
                        let   id = item[0];
                        let upid = item[1];
                        let name = item[2];
                        
                        //$lg('3566::id,upid,name::bgy',id,upid,name);
                        if( where == null ){
                          where = '.panel-cata .panel-cont';
                        }
                        
                        this.ui.tabMenu.tabs.cata.pars.where = where;
                        
                        let top = `${where} .folder-box`;
                        
                        if( upid > 0 ){
                          
                          top = `${where} .folder-box .cata-item[data-ajs-caid='${upid}'`;
                          
                        }
                    
                        
                        htm.dom( top );
    
                        htm.div(`.cata-item flex-col-4`).top()
                          .data('caid',id)
                          .data('upid',upid)
                          .div(`.cata-item-line`).as(1)
                              .button(1,`.cata-item-menu`)
                                  .on.click((e)=>{
                                  let ds = e.target;
                                  let dp = ds.parentNode;
                                  let caid = dp.parentNode.getAttribute('data-ajs-caid');
                                  //$lg('3796::id',id,dp.parentNode.getAttribute('data-ajs-idx'));
                                  this.ui.tabMenu.tabs.cata.subMenu.htm(e,caid);
                                  
                                },0)
                              .span(1,`.cata-item-name`,`!${name}`)
                                  .data('caid',id)
                                  .on.click(async (e)=>{
                                    let ds = e.target;
                                    let item = ds.parentNode.parentNode;
                                    //$lg('3614::item.idx',item.getAttribute('data-ajs-idx'));
                                    [...Doc.api.queryAll('.cata-item .yelack')].forEach((elm)=>{
                                      elm.classList.remove('yelack');
                                    })
                                    ///////////////////////////////////////
                                    let to = Doc.api.query('.cata-move-to')
                                    if( to ){
                                      let elms = Doc.api.queryAll('.elm-to-move');
                                      [...elms].forEach( elm => elm.classList.remove('elm-to-move') );
                          
                                      ds.classList.add('elm-to-move');
                                      to.classList.add('elm-to-move');
                                      to.innerText = ds.innerText;
                                      Doc.api.query('.cata-submenu .close').innerHTML = '\u00bb';
                                      let btnOk = Doc.api.query('.cata-move-ok');
                                          btnOk.setAttribute('data-upid',item.getAttribute('data-ajs-caid'));
                          
                                      return;
                                    }
                                    ///////////////////////////////////////
                                    ds.classList.add('yelack');
                                    let st = item.getAttribute('data-ajs-status');
                                    if( st == null || st == '0'){
                                      //download item
                                      item.setAttribute('data-ajs-status','1');
                                      let caid = item.getAttribute('data-ajs-caid');
                                      let where = this.ui.tabMenu.tabs.cata.pars.where;
                                      $lg(`caid:'${caid}',where:'${where}'`);
                                      this.ui.tabMenu.tabs.cata.folderBox.list(caid,where);
                                      let rsp = await this.service.data.req('tableTag.listCaid',parseInt(caid) );
                                      if( rsp.da.rst == false ) {
                                        return;// alert( '4254::'+ rsp.da.msg );
                                      }
                                      this.ui.tabMenu.tabs.cata.listBox.showTag( rsp );
                                    }else{
                                      //delete sub items
                                      item.setAttribute('data-ajs-status','0');
                                      let child = item.children;
                                      if( child.length > 0 ){
                                        for(let chd of [...child]){
                                          let cidx = chd.getAttribute('data-ajs-idx');
                                          //$lg('3629::chd.idx',cidx);
                                          if(chd.className.indexOf('cata-item-line') == -1 )
                                            { chd.parentNode.removeChild(chd); }
                                        }
                                      }
                                    }
                                  },0);
                          
                      }
                      
                      htm.ok();
                      
                    },
                    /*
                    item : (upid,id,name)=>{
                        
                    let top = Doc.ali.query(`.panel-cata .panel-cont .cata-item[data-ajs-id='${upid}'`);
                    
                    if(upid == null){
                      
                      top = Doc.ali.query(`.panel-cata .panel-cont`);
                      
                    }
                    
                    let htm = new Html();
                        htm.dom( top );
  
                        htm.div(`.cata-item flex-row-4`)
                          .data('id',id)
                          .data('upid',upid)
                          .span(`.cata-item-name`,`!${name}`)
                          .button(`.cata-item-menu`,`!*`)
                        .ok();
                    
                  },
                    */
                  },
                
                  edit : ()=>{
                    
                    
                    
                  },
                  
                  del : ()=>{
                    
                    
                    
                  },
                  
                },
                
                listBox : {
                  
                  listTableData : ( tableName, rsp, box )=>{
                    
                    //$lg('4367::rsp::bgo',JSON.stringify(rsp));
                    
                    if( rsp.da.rst == false ) return alert( rsp.da.msg );
                          
                    if( rsp.da.dat.arr.length == 0 ) return;
                    //$lg('4279::bgo',`${box} .list-line`);
                    
                    if( box == null ) box = '.panel-cata .panel-cont'
                    
                    this.ui.tabMenu.tabs.cata.pars.where = box;

                    [...Doc.api.queryAll( `${box} .list-line` )].forEach(e=>e.parentNode.removeChild(e));
                    
                    let htm = new Html();
                    htm.dom( `${box} .list-box` )
                    for( let item of rsp.da.dat.arr ){
                      let id   = item[0];
                      let name = item[1];
                      htm.div('.list-line flex-row-46').as(1)
                          .data('name',name)
                          .span(1,'.list-line-name',`!${name}`)
                              .data('rowid',id)
                              .data('tblName',tableName)
                              .on.click((e)=>{
                                let ds = e.target;
                                let rowid = ds.getAttribute( 'data-ajs-rowid' );
                                let tblName = ds.getAttribute( 'data-ajs-tblName' );
                                let map = this.ui.tabMenu.tabs.cata.listBox.getTblNameMap();
                                let name = map.get( parseInt(tblName) );
                                //$lg('4396::name',`name:${name},rowid:${rowid},tblName:${tblName}`);
                                if( name == 'song' )this.ui.article.content.load( rowid );
                              })
                          .input.checkbox(1,'.list-line-check')
                              .data('rowId',id)
                              .data('tableName',tableName)
                          
                      
                    }
                    
                    if( box ) htm.ok();
                    else return htm.pack()
                    
                  },
                  
                  listTable : ( rsp, box )=>{
                    
                    if( rsp.da.rst == false ) {
                      return alert( `4327::`+rsp.da.msg );
                    }
                    if( rsp.da.dat.arr.length == 0 ) return;
                    
                    [...Doc.api.queryAll( `${box} .list-line` )].forEach(e=>e.parentNode.removeChild(e));
                    
                    
                    let htm = new Html();
                    htm.dom( `${box} .list-box` )
                    let i = -1;
                    for( let item of rsp.da.dat.arr ){
                      //let id   = item[0];
                      i++;
                      let id   = item[0];
                      let name = item[1];
                      if( ['cata'].indexOf( name ) > -1 ) continue;
                      htm.div('.list-line flex-row-5').as(1)
                          .data('tableName',id)
                          .data('tableName',name)
                          .data('box',box)
                          .span(1,'.list-line-name',`!${name}`)
                              .on.click( async (e)=>{
                                let ds = e.target;
                                let dp = e.target.parentNode;
                                let tableId = dp.getAttribute('data-ajs-tableId');
                                let box  = dp.getAttribute('data-ajs-box');
                                //$lg('4317::type,box::bgg',tableId,box);
                                if( tableId != undefined ){
                                  let tableName = dp.getAttribute('data-ajs-tableName');
                                  //let rsp = await this.dat.fn.getTableData( name );
                                  let afterId = -1;
                                  let num = 100;
                                  //song
                                  let sqlText = ` select id,name from ${tableName} order by id asc limit ${num} offset ${afterId}`;
                                  if( name == 'word' ) { sqlText = ` select id,word from ${tableName} order by id asc limit ${num} offset ${afterId}`; }
                                  let rsp = await this.sql.que(sqlText)
                                  //$lg('4322::rsp',JSON.stringify(rsp));
                                  this.ui.tabMenu.tabs.cata.listBox.listTableData(tableId,rsp,box);
                          
                                }
                              },0)
                          
                      
                    }
                    
                    if( box ) htm.ok();
                    else return htm.pack()
                    
                  },
                  
                  showTag : async ( rsp )=>{
                    
                    $lg('4400::showTag',JSON.stringify(rsp));
                    //tag,caid,rowid,tableid
                    if( rsp.da.dat.arr.length == 0 ) return;
                    
                    let map = this.ui.tabMenu.tabs.cata.listBox.getTblNameMap();
                    
                    let sqlText = null;
                    let tblId = null;
                    let tblName = null;
                    let idArr = [];
                    for( let arr of rsp.da.dat.arr ){
                      
                      let tag     = arr[0];
                      let caid    = arr[1];
                      let rowid   = arr[2];
                      let tableid = arr[3];
                      tblName = arr[3];
                      idArr.push( rowid );
                      if( tblName == null ) tblName = map.get( tableid );
                    }
                    
                    if( tblName == 'song' ){;l
                      sqlText = `select id,name from ${tblName} where id in (${idArr.join(',')})`;
                    }
                      
                    $lg('4471::sqlText',sqlText);
                    
                    let rsp2 = await this.sql.que( sqlText );
                    
                    if( rsp2.da.rst == false ) return alert( '4475:'+rsp2.da.msg );
                    
                    this.ui.tabMenu.tabs.cata.listBox.listTableData( tblName, rsp2 );
                    
                    Doc.api.query('.list-unlink').disabled = false;
                    
                  },
                  
                  getTblNameMap : ( id )=>{
                    
                    let map = new Map();
                    let i = 0;
                    let arr = this.dat.tableTbl.names;
                        arr.sort();
                        arr.forEach(name => {
                          i += 10;
                          map.set(i,name);
                        })
                    return map;
                    
                  }
                  
                },
                
                fn : {
                
                }
                
              },
              
              dict : {
                
                htm : ()=>{
                  //$lg('3498::dict::htm::bgg');
                  if(Doc.has('#sliderMenu .dict-input-box'))return this;
                  this.dic.root = '#sliderMenu .panel-dict .panel-cont';
                  this.dic.ui.run();
                  
                  
                },
                
              },
              
              info : {
                
                data : {
                  
                  menu : {
                    menu1 : [
                    
                      {id:'',clazz:'info-menu-glance',text:'总览'},
                      {id:'',clazz:'',text:'词汇量'},
                      {id:'',clazz:'',text:'听力'},
                      {id:'',clazz:'',text:'0004'},
                      {id:'',clazz:'',text:'0005'},
                      
                    ],
                  }
                  
                },
                
                index : ()=>{
                  
                  let css = (()=>{
                  
                    if( Doc.has(`style[class*='info-menu-box']`)) return;
                  
                    let cs = new Css();
                    
                    Css.root = 'Ajs/tabs/tab-info';
                    
                    new Css('.info-menu',{
                      width        : '900px',
                      background   : 'lightyellow',
                    })//.info-menu
                    
                    new Css('.info-menu-box',{
                      
                      width        : '90%',
                      margin       : '10px',
                      padding      : '6px',
                      overflow_x   : 'scroll',
                      flex_wrap    : 'nowrap',
                      background   : cs.rgba.white(9,1),
                      border_radius   : '10px',
                      
                    })//.menu-box
                    new Css('.info-menu-box > button',{
                      
                      font_size       : '36px',
                      width           : '100px',
                      margin          : '10px',
                      padding         : '6px',
                      flex_shrink     : 0,
                      border          : '0px solid black',
                      border_radius   : '10px',
                      
                    })//.menu-box > button
                  
                    Css.root = 'Ajs';
                  
                  })()
                  
                  let htm = (async ()=>{
                    
                    let imenu = Doc.api.query('.panel-info .panel-menu');
                    if( imenu ) imenu.innerHTML = '';
                    
                    const $info = this.ui.tabMenu.tabs.info;
                    
                    let len = $info.data.menu.menu1.length - 1;
                    
                    let html = new Html();
                    html.dom('.panel-info .panel-menu')
                        .div('.spread-line info-menu flex-col-8').as(1)
                            .div(1,'.spread-line info-menu-box info-menu-box1 flex-row-4').as(2)
                                .button(2,'.spread-btn info-menu-btn',`!001`)
                                .clone( len )
                            .div(1,'.info-menu-box info-menu-box2')
                          
                        .ok();
                        
                    let btns = Doc.api.queryAll('body .panel-info .panel-menu .info-menu-btn');
                    
                    let i = -1;
                    let $menu;
                    for(let btn of btns){
                      
                      i++;
                      $menu = $info.data.menu.menu1[i];
                      if($menu.clazz)
                        btn.classList.add($menu.clazz);
                      btn.innerText = $menu.text;
                      
                    }
                        
                    
                  })()
                
                },
              
                event : {
                  
                },
              
                fn : {
                  
                  detail : async (e)=>{
                    
                    let ds = e.target;
                    let dp = ds.parentNode;
                    
                    [...dp.querySelectorAll('.info-item-name')].forEach( async (el) =>{
                      if( el.innerText == '不认识的单词数'){
                        //alert('list不认识的单词数');
                        let rsp = await this.service.data.req('tableAware.listAllUnknowWords');
                        $log.lgg(JSON.stringify(rsp));
                        if( rsp.da.rst == false ) return;
                        
                        let tar = Doc.api.query('.panel-info .panel-cont #allWordUnknow');
                        if( tar ) tar.parentNode.removeChild( tar );
                        
                        let ui = new Ui();
                        let tbl = new ui.table();
                            tbl.conf.id( 'allWordUnknow' )
                                    //.cellClass('info-item-name','info-item-num','info-item-detail')
                                    .col( rsp.da.dat.col )
                                    .dat( rsp.da.dat.arr );
                            tbl.done('.panel-info .panel-cont');
                        
                      }
                    })
                    
                  },
                  
                  //拆解了多少单词
                  
                  
                },
              
              },
              
              test : {
                
                index : ()=>{
                  
                    this.ui.tabMenu.tabs.test.fn.cleanCont();
                    
                    let css = (()=>{
                      if(Doc.has(`.Ajs style[class*='test-listening'`)) return;
                      let cs = new Css();
                      new Css('.test-menu-box',{
                        width         : '60%',
                        padding       : '6px',
                        border        : '0px solid white',
                        border_radius : '16px',
                        margin        : '20px',
                        background    : cs.rgba.white(9,1),
                      })//.test-menu-box
                      new Css('.test-menu-btn',{
                        font_size     : '6vmin',
                        width         : '96%',
                        margin        : '10px',
                        border        : '0px solid white',
                        padding       : '6px',
                        background    : cs.rgba.white(3,1),
                        color         : 'black',
                        border_radius : '16px',
                      })//.test-menu-btn
                      new Css('.panel-test .panel-cont',{
                        border        : '2px solid black !important',
                        background    : 'white !important',
                      })//.panel-test .panel-cont
                      
                    })()
                    
                    let htm = (()=>{
                      new Html()
                      .dom( '.panel-test .panel-cont' )
                          .div('.test-menu-box flex-col-5').as(1)
                              .button(1,'.test-menu-btn test-btn-listening','!listening')
                      .ok();
                      
                    })()
                    
                    
                },
                
                
                listening : {
                  
                  index : ()=>{
                  
                    this.ui.tabMenu.tabs.test.fn.cleanCont();
                    
                    /*
                    let css = (()=>{
                      if(Doc.has(`.Ajs style[class*='test-listening'`)) return;
                      let cs = new Css();
                      new Css('.test-menu-box',{
                        width         : '60%',
                        padding       : '6px',
                        border        : '0px solid white',
                        border_radius : '16px',
                        margin        : '20px',
                        background    : cs.rgba.white(9,1),
                      })//.test-menu-box
                      new Css('.test-menu-btn',{
                        font_size     : '6vmin',
                        width         : '96%',
                        margin        : '10px',
                        border        : '0px solid white',
                        padding       : '6px',
                        background    : cs.rgba.white(3,1),
                        color         : 'black',
                        border_radius : '16px',
                      })//.test-menu-btn
                      
                    })()
                    */
                    let htm = (()=>{
                      new Html()
                      .dom( '.panel-test .panel-cont' )
                          .div('.spread-line').as(1)
                              .button(1,'.spread-btn','!1')
                              .button(1,'.spread-btn','!2')
                              .button(1,'.spread-btn','!3')
                              .button(1,'.spread-btn','!4')
                              .button(1,'.spread-btn','!5')
                      .ok();
                      
                    })()
                    
                    
                },
                  
                },
                
                fn : {
                  
                  cleanCont : ()=>{
                    
                    let cont = Doc.api.query('.panel-test .panel-cont');
                    if( cont ) cont.innerHTML = '';
                    
                  },
                  
                  cleanMenu : ()=>{
                    
                    let cont = Doc.api.query('.panel-test .panel-menu');
                    if( cont ) cont.innerHTML = '';
                    
                  },
                  
                }
                
                
              },
              
            },
          
            fn : {
              
              switchPanel : (e)=>{
                this.ui.fn.highlight(e);
                let $tabMenu = this.ui.tabMenu;
                $tabMenu.fn.hideBodyPanel();
                //$tabMenu.fn.cleanPanel();
              },
              
              cleanPanel : ()=>{
                
                // $lg('4052::cleanPanel')
                
                Doc.api.query('#sliderMenu .cont-body-box .panel-cont')
                  .innerText = '';
                  
                return this.ui.tabMenu;
                
              },
              
              hideBodyPanel : ()=>{
                
                [...Doc.api.queryAll('#sliderMenu .body-panel')].forEach((e)=>{
                  e.style.display = 'none';
                })
                
                  
                return this.ui.tabMenu;
                
              },
              
              showBodyPanel : (clazz)=>{
                
                [...Doc.api.queryAll(`#sliderMenu ${clazz}`)].forEach((e)=>{
                  e.style.display = 'flex';
                })
                
                  
                return this.ui.tabMenu;
                
              },
              
              cleanBodyPanel : (clazz)=>{
                
                [...Doc.api.queryAll(`#sliderMenu ${clazz}`)].forEach((e)=>{
                  e.innerHTML = '';
                })
                
                  
                return this.ui.tabMenu;
                
              },
              
              cleanContent : (clazz)=>{
                
                [...Doc.api.queryAll(`#sliderMenu ${clazz}`)].forEach((e)=>{
                  e.innerHTML = '';
                })
                
                  
                return this.ui.tabMenu;
                
              },
              
              cleanTopMenu : ()=>{
                Doc.api.query('#sliderMenu .panel-menu').innerText = '';
                    
              },
              
              getObjectURL : (file)=>{

                  var url = null;
                
                  if (window.createObjcectURL != undefined) {
                
                    url = window.createOjcectURL(file);
                
                  } else if (window.URL != undefined) {
                
                    url = window.URL.createObjectURL(file);
                
                  } else if (window.webkitURL != undefined) {
                
                    url = window.webkitURL.createObjectURL(file);
                
                  }
                  return url;
              },
              
            }
            
        },
        
        range      : {
            ds     : null,
            id     : 'myRange',
            addto  : (anyStr)=>{
                let ui    = new Ui();
                let range = new ui.range();
                    range.into(anyStr)
                          .id(this.ui.range.id)
                          .bg('white')
                          .done();
                this.ui.range.ds = range;
                
                return this;
            },
            event  : {
              input : (e)=>{
                //$lg('710::bgo','range.oninput');
                try{
                  
                  let ds = e.target;
                  
                  let aud = this.myAudio;
                  
                  if(aud == undefined) return this;
                  if(aud.currentTime == undefined) return this;
                  aud.pause();
                  if(aud.paused == false) return this;
                  //$lg('723::val,max,dur::bgo',ds.value,ds.max,this.dur);
                  let val  = ds.value/ds.max * this.dur;
                  //$lg('725::val::bgg',val);
                  aud.currentTime = val;
                  aud.play();
                }catch(e){
                  
                }
              },
              setup : ()=>{
                this.ui.range.ds = Doc.api.gbid(this.ui.range.id);
                let rg = this.ui.range.ds;
                    rg.addEventListener('input',this.ui.range.event.input,false);
              },
            },
            
            
        },
        
        volume     : {
            ds     : null,
            id     : 'adj-volume',
            addto  : (anyStr)=>{
                let ui    = new Ui();
                let range = new ui.range();
                    range.into(anyStr)
                          .id(this.ui.volume.id)
                          .bg('white')
                          .done();
                
                return this;
            },
            event  : {
              input : (e)=>{
                //$lg('710::bgo','range.oninput');
                try{
                  
                  let ds = e.target;
                  
                  let aud = this.myAudio;
                  
                  if(aud == undefined) return this;
                  if(aud.volume == undefined) return this;
                
                  
                  //$lg('723::val,max,dur::bgo',ds.value,ds.max,this.dur);
                  let val  = ds.value/ds.max;
                  //$lg('725::val::bgg',val);
                  aud.volume = val;
                  
                }catch(e){
                  
                }
              },
              setup : ()=>{
                let spd = Doc.api.gbid(this.ui.volume.id);;
                    spd.addEventListener('input',this.ui.volume.event.input,false);
              },
            },
            
            
        },
        
        range2     : {
            ds     : null,
            id     : 'myRange2',
            addto  : (anyStr)=>{
                let ui    = new Ui();
                let range = new ui.range2();
                    range.into(anyStr)
                          .id(this.ui.range2.id)
                          .bg(new Css().rgba.white(3,0.9))
                          .callback.p1(null,this.ui.range2.touch.move,null)
                          .callback.p2(null,this.ui.range2.touch.move,null)
                          .callback.p1click(this.ui.range2.clickAB)
                          .callback.p2click(this.ui.range2.clickAB)
                          .done();
                this.ui.range2.ds = range;
                return this;
            },
            touch : {
              
              move : (ds,t,p,x)=>{
                //$lg('609::t,p,x',t,p,x);
                let gp = ds.parentNode.parentNode;
                let gpWidth = gp.clientWidth;
                let pc = x/gpWidth;
                if(pc !== NaN && this.dur > 0){
                    //$lg('614::type::bgo',typeof(x),typeof(gpWidth),x,gpWidth,`${pc}`);
                    let time = this.dur * pc;
                    let timeArr = this.fn.timeTsl(time);
                    let target = '.loop-time-a';
                    let idx = 0;
                    if(p == 'p2'){
                      target = '.loop-time-b';
                      idx = 1;
                    }
                    this.loopDur[idx] = time;
                    /*Doc.api.query(`${target} .dur-mm`).innerText = timeArr[0].toString().padStart(2,'0');
                    Doc.api.query(`${target} .dur-ss`).innerText = timeArr[1].toString().padStart(2,'0');
                    Doc.api.query(`${target} .dur-ms`).innerText = timeArr[2].toString().padStart(3,'0');*/
                    this.ui.loopAB.setText(time,String.fromCharCode(idx+97));
                    
                    this.ui.range2.clickAB(ds,t,p,x);
                }
              }
              
            },
            clickAB  : (ds,t,p,x)=>{
              //$lg('665::bgy','p',p);
              let pname = 'point1';
              if(p == 'p2')pname = 'point2';
              //$lg('668::bgo','class',ds.className);
              //ds.classList.remove(pname);
              
              [...Doc.api.queryAll('.point1,.point2')].forEach((elm)=>{
                elm.setAttribute('data-ajs-acp','0');
              })
              ds.setAttribute('data-ajs-acp','1');
              
              //ds.classList.add('point-sel');
              //ds.classList.toggle(pname);
              
              //$lg('670::bgo','class',ds.className);
              return this;
            },
            updatePos : (pc,target)=>{
              let ds = this.ui.range2.ds;
                  ds.event.updatePos(pc,target);
              return this;
            }
            
        },
        
        speed      : {
            ds     : null,
            id     : 'adj-speed',
            addto  : (anyStr)=>{
                let ui    = new Ui();
                this.ui.speed.ds = new ui.range2();
                
                this.ui.speed.ds.into(anyStr)
                          .id(this.ui.speed.id)
                          .fs1('4vmin')
                          .r1('6px')
                          //.w('70px')
                          .bgc1('yellow black')
                          .min1(0.2).max1(1.5).val1(1)
                          .bg(new Css().rgba.white(3,0.9))
                          .callback.p1(null,this.ui.speed.touch.move,null)
                          .single()
                          .done();
                 
                return this;
            },
            touch : {
              
              move : (ds,t,p,x)=>{
                //$lg('609::t,p,x',t,p,x);
                //$lg('988::ds.className',ds.className);
                let gp = ds.parentNode.parentNode;
                let gpWidth = gp.clientWidth;
                //$lg('991::ds.className',gpWidth);
                let pc = x/gpWidth;
                if(pc !== NaN){
                    //$lg('614::type::bgo',typeof(x),typeof(gpWidth),x,gpWidth,`${pc}`);
                    let dmax = ds.getAttribute('data-ajs-max1');
                        dmax = parseFloat(dmax);
                    $lg('993::dmax',dmax);
                    let pc1 = parseFloat(pc*dmax);
                    let ps1 = pc1.toString().slice(0,3);
                    $lg('996::pc1,ps1',pc1,ps1);
                    this.playbackRate = pc1;
                    let aud = this.myAudio;
                        aud.playbackRate = pc1;
                    ds.innerHTML = `${ps1}x`;
                }
              }
              
            },
            fn : {
              spSetPos : (rate)=>{
                //let sp = Doc.api.query(`#${this.ui.speed.id}`);
                let p1 = Doc.api.query(`#${this.ui.speed.id} .point1`);
                let max1 = parseFloat(p1.getAttribute('data-ajs-max1'));
                let pc = rate / max1;
                this.ui.speed.ds.event.updatePos(pc,1);
                return this;
              }
            }
            
        },
        
        ABList     : {
          
          addBtn : ()=>{
              let iconCode = 0x2780+parseInt(this.abList.length-1);
              let char = String.fromCharCode(iconCode);
              //$lg('1210::bgo',`${char}`);
              let h = new Html();
              h.dom('.AB-list-box')
                  .button('.spread-btn btn-AB-pick',`!${char}`)
                      .data('abidx',this.abList.length-1)
                      .on.click((e)=>{
                          let ds = e.target;
                          this.ui.fn.highlight(e);
                          let abidx = ds.getAttribute('data-ajs-abidx');
                              abidx = parseInt(abidx);
                          //$lg('1248::abidx',abidx);
                          let timeArr = this.abList[abidx];
                          //$lg('1251::timeArr',timeArr);
                          this.loopDur = this.abList[abidx];
                          this.ui.loopAB.replace(timeArr);
                          if(this.loopAB) {
                            this.audio.fn.setCurrTime(this.loopDur[0]);
                          }
                          //$lg('1275::all done::bgg');
                      },0)
                .ok();
              return this;
          },
          setItemVal : (idx,valArr)=>{
              this.abList[idx][0] = valArr[0];
              this.abList[idx][1] = valArr[1];
              return this;
          },
          
        },
        
        adjBtn     : {
          
          
          
          zoom_out : {
              
              touchmove : (e)=>{
                let ds = e.target;
                let dx = 0;//parseFloat(ds.style.left.replace('px',''));
                if(e.type == 'touchmove') dx = e.touches[0].clientX;
                let dir = dx-this.adjBtnPos[1]>0 ? 1 : 0;
                $lg('723::dx,ldx,dir',dx,this.adjBtnPos[1],dir);
                
                this.adjBtnPos[1] = dx;
                let obj = Doc.api.query(`div[data-ajs-acp='1']`);
                if(obj == null)return this;
                let x = parseFloat(obj.style.left.replace('px',''));
                //$lg('700::before:x::bgb',x);
                //x=x-0.06;
                if(dir == 1)x=x+0.06;
                else x=x-0.06;
                //$lg('702::before:x::bgg',x);
                obj.style.left = x+ 'px';
                
                
                this.ui.adjBtn.updateLoopDur(obj,x);
                
                //$lg('700::obj.style.left',obj.style.left);
              },
              
          },
          
          zoom_in : {
              
              mousedown : (e)=>{
                //$lg('728::mousedown::bgy',Log.now());
                let ds = e.target;
                
                /*let ppt = Reflect.getPrototypeOf(e);
                let ks = Reflect.ownKeys(ppt);
                $lg('732::keys::bgo',...ks);*/
                /*$lg('731::x::bgg',x,typeof(x));
                    x+=0.05;*/
                let obj = Doc.api.query(`div[data-ajs-acp='1']`);
                if(obj == null)return this;
                let x = parseFloat(obj.style.left.replace('px',''));
                    x += 0.06;
                obj.style.left = x+ 'px';
                this.ui.adjBtn.updateLoopDur(obj,x);
                
                let runEvent = (()=>{
                  let mse = document.createEvent("MouseEvent");
                      mse.initMouseEvent("mousedown", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                      ds.dispatchEvent(mse);
                      
                  let ppt = Reflect.getPrototypeOf(mse.initMouseEvent);
                  //let ks = Reflect.ownKeys(ppt);
                  let ks = Reflect.get(mse.initMouseEvent,'constructor');
                  //$lg('756::constructor:src::bgo',ks.toString());
                      
                  //$lg('742::runEvent done::bgg',Log.now());
                });
                
                //this.ui.range2.updatePos(60,2);
                
                
                return this;
                
              },
              
              touchmove : (e)=>{
                //$lg('719::right');
                let ds = e.target;
                let dx = 0;//parseFloat(ds.style.left.replace('px',''));
                if(e.type == 'touchmove') dx = e.touches[0].clientX;
                 
                let dir = dx-this.adjBtnPos[1]>0 ? 1 : 0;
                //$lg('723::dx,ldx,dir',dx,this.adjBtnPos[1],dir);
                
                this.adjBtnPos[1] = dx;
                let obj = Doc.api.query(`div[data-ajs-acp='1']`);
                if(obj == null)return this;
                let x = parseFloat(obj.style.left.replace('px',''));
                //$lg('700::before:x::bgb',x);
                if(dir == 1)x=x+0.06;
                else x=x-0.06;
                
                
                //$lg('702::before:x::bgg',x);
                obj.style.left = x+ 'px';
                
                this.ui.adjBtn.updateLoopDur(obj,x);
                
                //$lg('700::obj.style.left',obj.style.left);
              },
              
          },
          
          updateLoopDur : (obj,x)=>{
              //$lg('732::className',obj.className);
              let gp = obj.parentNode.parentNode;
              let gpWidth = gp.clientWidth;
              let pc = x/gpWidth;
              if(pc !== NaN && this.dur > 0){
                  let p = 'p1';
                  if(obj.classList.contains('point2')){
                    //$lg('739::point2',obj.className.indexOf('point2')>=0);
                    p='p2';
                  }
                  let time = this.dur * pc;
                  let timeArr = this.fn.timeTsl(time);
                  let target = '.loop-time-a';
                  let idx = 0;
                  if(p == 'p2'){
                    target = '.loop-time-b';
                    idx = 1;
                  }
                  this.loopDur[idx] = time;
                  /*Doc.api.query(`${target} .dur-mm`).innerText = timeArr[0].toString().padStart(2,'0');
                  Doc.api.query(`${target} .dur-ss`).innerText = timeArr[1].toString().padStart(2,'0');
                  Doc.api.query(`${target} .dur-ms`).innerText = timeArr[2].toString().padStart(3,'0');*/
                  this.ui.loopAB.setText(this.loopDur[idx],String.fromCharCode(idx+97));
              }
              //this.ui.range2.clickAB(ds,t,p,x);
          },
          
          
          eventSetup : ()=>{
            let L = Doc.api.query('.range2-adj-box .zoom-out');
                //L.addEventListener('touchmove',this.ui.adjBtn.left.touchmove,false);
                L.addEventListener('click',this.ui.adjBtn.zoom_out.touchmove,false);
                //L.addEventListener('mousedown',this.ui.adjBtn.left.touchmove,false);
            let R = Doc.api.query('.range2-adj-box .zoom-in');
                //R.addEventListener('touchmove',this.ui.adjBtn.right.touchmove,false);
                R.addEventListener('click',this.ui.adjBtn.zoom_in.mousedown,false);
                //R.addEventListener('mousedown',this.ui.adjBtn.right.touchmove,false);
          }
          
        },
        
        loopAB     : {
            
            rate : [0.025, 0.1, 0.25, 0.5],
          
            step : 0 ,
            
            setRate : (op = '+',event=null)=>{
              if(op == '+'){
                this.ui.loopAB.step++;
                if(this.ui.loopAB.step > this.ui.loopAB.rate.length-1)
                    this.ui.loopAB.step = 0;
              }else{
                this.ui.loopAB.step--;
                if(this.ui.loopAB.step == -1 )
                    this.ui.loopAB.step = this.ui.loopAB.rate.length-1;
              }
              if(event){
                //let ds = event.target;
                let objs = Doc.api.queryAll('.btn-rate-add,.btn-rate-mus');
                let s = 20*(this.ui.loopAB.step+1);
                let l = 100 - s*0.7;
                objs.forEach((ds)=>{
                  ds.style.backgroundColor = `hsl(60,60%,${l}%)`;
                  //ds.style.color = `black`;
                })
                
              }
              return this.ui.loopAB.rate[this.ui.loopAB.step];
            },
            
            getRate : ()=>{
                return parseFloat(this.ui.loopAB.rate[this.ui.loopAB.step]);
            },
            
            replace : (timeArr)=>{
                try{
                //$lg('1406::replace::bgg');
                //let time = aud.currentTime;
                
                for(let idx=0; idx<timeArr.length; idx++){
                    this.loopDur[idx] = timeArr[idx];
  
                    this.ui.loopAB.setText(timeArr[idx],String.fromCharCode(idx+97));
                    
                    //let pc = timeArr[idx] / this.dur;
                    
                    //this.ui.range2.updatePos(pc,idx+1);
                }
                }catch(e){
                  $lg('1477::err',err.message);
                }
            },
            
            
            setText : (time,tail)=>{
              try{
                //$lg('1422::setText,time,tail::bgb',time,tail);
                let timeArr = this.fn.timeTsl(time);
                //$lg('1424::timeArr::bgy',...timeArr,tail);
                Doc.api.query(`.loop-time-${tail} .dur-mm`).innerHTML = timeArr[0].toString().padStart(2,'0');
                Doc.api.query(`.loop-time-${tail} .dur-ss`).innerHTML = timeArr[1].toString().padStart(2,'0');
                Doc.api.query(`.loop-time-${tail} .dur-ms`).innerHTML = timeArr[2].toString().padStart(3,'0');
              }catch(e){
                $lg('1491::err',e.message);
              }
            },
            
          
        },
        
        lrcMisc    : {
          
          saveAll : async (ds)=>{
            //$lg('1503::btn-lrc-save-all');
            ds.classList.remove('flash-btn')
            ds.classList.add('flash-working')
            //$lg('2191::saveAll::start::bgg',Log.now())
            await this.objLrc.saveAll();
            //$lg('2193::saveAll::done::bgg',Log.now())
            ds.classList.remove('flash-working')
            ds.classList.add('flash-btn')
            return this;
          },
          
          saveOne : async (ds)=>{
            $lg('2200::btn-lrc-save-one');
            ds.classList.remove('flash-btn')
            ds.classList.add('flash-working')
            $lg('2203::saveOne::start::bgg',Log.now())
            await this.objLrc.saveOne();
            $lg('2205::saveOne::done::bgg',Log.now())
            ds.classList.remove('flash-working')
            ds.classList.add('flash-btn')
            return this;
          },
          
          test : async (e)=>{
            $lg('1509::ui.lrcMisc.test::bgy');
            //await this.dat.tableSong.add('the day you went away');
            //await this.dat.tableSong.add('as long as you love me');
            //this.dat.tableSong.getLastId().then((rst)=>{
            let txt1 = 'select id,name from song;';
            let txt2 = `select id,name from song where name like 'as%'`;
            let txt3 = `select id,lidx,idx,word from word order by sid,lidx,idx asc limit 1000`;
            let txt4 = `select count(id) as sum from word where sid = 2`;
            let fn1 = ()=>{
                this.sql.que(txt1).then((rst)=>{
                  $lg('1523::',JSON.stringify(rst));
                  new (new Ui()).table(rst.da.dat).into('#lgHtml');
                  //$lg(`1517::${Log.now()}::bgy`);
                })
            }
            let fn2 = ()=>{
              return new Promise((res)=>{
                this.sql.que(txt2).then((rst)=>{
                  $lg('1524::',JSON.stringify(rst));
                  //new (new Ui()).table(rst.da.dat).into('#lgHtml');
                  //$lg(`1521::${Log.now()}::bgo`);
                  let line = (rst.da.dat)[0];
                  let id = line.id;
                  res(id);
                })
              })
            }
            let fn6 = ()=>{
              let txt6 = `select id,lidx,idx,word,start,end from word where sid=${this.songId} and lidx=`;
              return new Promise((res)=>{
                let lidx = this.objLrc.lidx;
                this.sql.que(txt6+lidx).then((rsp)=>{
                  //$lg('1570::',JSON.stringify(rst));
                  if(rsp.da.rst == false) return;
                  Doc.api.gbid('box').innerHTML = '';
                  new (new Ui()).table(rsp.da.dat).into('#box');
                  res();
                })
              })
            }
            
            let wordAdd = (sid)=>{
          
                $lg('1528::id',sid);
                this.dat.tableWord.batAdd(sid,this.objLrc)
                    .then((obj)=>{
                        $lg('1531::res::',JSON.stringify(obj));
                        let rst = obj.da.rst;
                        if(rst == false)$lg('1533::false,msg::bgo',obj.da.msg);
                        else{
                          $lg('1535::res::',JSON.stringify(obj));
                          return;
                        }
                    })
                $lg('1530::batAdd done');
            
            }
            
            let wordList = ()=>{
            
                $lg('1547::txt3',txt3);
                this.sql.que(txt4).then((rsp)=>{
                    $lg('1549::rsp',JSON.stringify(rsp.da.dat));
                    
                    let ui = new Ui();
                    let tbl = new ui.table(rsp.da.dat);
                        tbl.into('#box');
                    //new (new Ui()).table(rsp.da.dat).into('#lgHtml');
                })
            }
            
            let mp3List = ()=>{
                $lg('1804::mp3List start',Log.now());
                let txt = 'select id,name,path from mp3';
                $lg('1547::txt3',txt3);
                this.sql.que(txt).then((rsp)=>{
                    $lg('1549::rsp',JSON.stringify(rsp.da.dat));
                    
                    let ui = new Ui();
                    let tbl = new ui.table(rsp.da.dat);
                        tbl.into('#lgHtml');
                    //new (new Ui()).table(rsp.da.dat).into('#lgHtml');
                })
            }
            
            let mp3Add = ()=>{
              $lg('1818::mp3Add',Log.now());
              fn2().then((sid)=>{
                $lg('1820::fn2 done',Log.now());
                let path = './mp3/as_long_as_you_love_me.mp3'
                this.dat.tableMp3.add(sid,'as long as you love me',path).then(()=>{
                  $lg('1823::mp3Add done',Log.now());
                  return;
                })
              })
            }
            
            let rgbToHsl = ()=>{
              let rgb1 = [80,85,107];
              let rgb2 = [237,142,76];
              let org = [255,165,0];
              let rgb3 = (new Css()).rgba.red(6,0.6);
              let hsl  = ( new Css ).rgbToHsl(...rgb1);
              let hsl2 = ( new Css ).rgbToHsl(...rgb2);
              let horg = ( new Css ).rgbToHsl(...org);
              /*$lg('1915::hsl:',`rgba(80,85,107,1)rgb(80,85,107)`,`hsl(${hsl[0]},${hsl[1]}%,${hsl[2]}%)hsl(${hsl[0]},${hsl[1]}%,${hsl[2]}%)`);
              $lg('1916::hsl:',`rgba(237,142,76,1)rgb(237,142,76)`,`hsl(${hsl2[0]},${hsl2[1]}%,${hsl2[2]}%)hsl(${hsl2[0]},${hsl2[1]}%,${hsl2[2]}%)`);
              $lg('1922::hsl:',`rgba(255,165,0,1)rgb(255,165,0)`,`hsl(${horg[0]},${horg[1]}%,${horg[2]}%)hsl(${horg[0]},${horg[1]}%,${horg[2]}%)`);
              */
              /*for(let i=0; i<10; i++){
                $lg('rgba:',(new Css()).rgba.green(i,0.6));
              }*/
            }
           
            let showMsgBox = ()=>{
              this.ui.msgbox.fn.show();
            }
           
            let dictListWords = async ()=>{
              let arr = await this.dic.list('key');
              $lg('4012::dic.list',Log.now(),JSON.stringify(arr));
              
            }
            
            //dictListWords();
            
            let getSpaceCharCode = ()=>{
              
              $lg('2914::bgy','space char code :' ,' '.charCodeAt(0));
            }
            //getSpaceCharCode();
            /*this.dat.fn.buildObjLrcAll(3).then((rsp)=>{
              alert('done');
            })*/
            
            let dictEditMeaning = async ()=>{
              $lg('3425::dictEditMeaning');
              let mn = `v. 加工,machine的ing形式;n. 制造；[机] 机械加工`;
              let rsp = await this.dic.edit.meaning(478853,mn);
              $lg('3427::dictEditMeaning::bgy',JSON.stringify(rsp));
            }
            //dictEditMeaning();
            let dictAddTableApart = async ()=>{
              $lg('3692::dictAddTableApart');
              
              let rsp = await this.dic.add.tableApart();
              $lg('3695::dictAddTableApart::bgy',JSON.stringify(rsp));
              
            }
            //dictAddTableApart();
            
            let dictTableApartAdd = async ()=>{
              //$lg('3700::dictAddTableApart');
              let wdid = 1235;
              let arr = ['con','tro','ver','sy'];
              //let rsp = await this.dic.tableApart.add(wdid,arr);
              //$lg('3703::dictTableApartAdd::bgy',JSON.stringify(rsp));
              let rsp = await this.dic.tableApart.getPart(wdid);
              $lg('3706::dictTableApartAdd::bgy',JSON.stringify(rsp));
              
            }
            //dictTableApartAdd();
            //dictAddTableApart();
            
            let cata = ()=>{
              
              new Css('.msg-cont',{
                height : 'auto',
                max_height : '96%',
                width  : 'auto',
                //background : 'hsla(0,90%,30%,1)',
                background : 'black',
              })
              
              let mbox = Doc.api.query('.msg-box');
                  mbox.style.height = '50%';
                  
              //mbox.style.backgroundColor = 'hsla(30,90%,30%,1)';
              let msg = Doc.api.query('.msg-cont');
                  //msg.style.backgroundColor = 'hsl(60,20%,60%)';
                  //msg.style.maxHeight = '56%';
              
              this.ui.tabMenu.tabs.cata.css();
              let fgm = this.ui.tabMenu.tabs.cata.htm();
              
              this.ui.msgbox.fn.show( fgm );
              
              this.ui.tabMenu.tabs.cata.folderBox.list(0,'.msg-cont');
              
            }
            //cata();
            
            let gm = async  ()=>{
              
              /*let t1 = '（'.charCodeAt(0);
              let c1 = t1.toString(16);
              $lg(t1,`'${c1}'`,'\uff09');
              return;*/
              
              await this.service.data.req('buildTable',);
              //return;
              /*let a = '('.charCodeAt(0);
              let b = ')'.charCodeAt(0);
              let c = ','.charCodeAt(0);
              let d = "'".charCodeAt(0);
              $log.lgg('5573::',a,b,c,d);
              alert('ok');
              return;*/
              let htm = new Html();
              
              
              htm.dom()
              .div('#pgm',`.w:96% m:30px p:20px`);
                //.div('#pgm',`.p:10px `,'!');
              
              this.ui.msgbox.fn.show( htm.pack() );
              
              let msg = (txt)=>{
                Doc.api.gbid('pgm').innerText = txt;
              }
              
              msg('getting book');
              let rsp = await this.fn.getData('../app/book/gm.txt');
              if( rsp.da.rst == false ) return alert( rsp.da.msg );
              let book = rsp.da.dat;
              //$lg('5542::len',book.length,Log.now());
              
              book = book.replace(/\n{1,}/,'\n');
              
              let sq = new Sqlike();
              book = sq.fn.esc( book );
              
              let lines = book.split('\n');
              
              const TYPE_UNIT  = 0;
              //const TYPE_MENU = 1;
              const TYPE_ITEM  = 1;
              const TYPE_POINT = 2;
              const TYPE_CONT  = 3;
              
              let units = [];
              let titles = [];
              
              let nps = [];
              let menu = [];
              let i = 0;
              let j = 0;
              let up = 0;
              let uidx = 0;
              let iidx = 0;
              let pidx = 0;
              let sqlText = ` INSERT INTO book(up,line,content,type) VALUES`;
              
            //$log.lgg('6490::sqlText',sqlText);
              let nearId = -1;
              let box = [];
              let as = ( n, id)=>{
                box[n] = id;
              }
              let use = ( n )=>{
                return box[n];
              }
              for( let line of lines){
                
                if(/^$/.test(line))continue;
                if(/^\s+$/.test(line))continue;
                if(line.length == 0)continue;
                
                i++;
                j++;
                
                //line = sq.fn.esc( line );
                
                /*line = line.replace(/\(/g,'\u0040');
                line = line.replace(/\)/,'\u0041');
                line = line.replace(/\,/g,'\u0044');
                line = line.replace(/\'/g,'\u0027');*/
                
                //line = line.replace(")",'\u0044,');
                if( /^序$/.test( line )) {
                
                  sqlText += ','.repeat(i>1?1:0) + `( 0, ${j}, '${line}', ${TYPE_UNIT})`;
                  uidx = j;
                  nearId = -1;
                }else
                if( /第.{1,3}单元.*/.test( line )) {
                
                  sqlText += ','.repeat(i>1?1:0) + `( 0, ${j}, '${line}', ${TYPE_UNIT})`;
                  uidx = j;
                  nearId = -1;
                }else
                //cont
                if( /[I,Ⅰ-Ⅹ]+[\.\s]+[\u4e00-\u9faa]+/.test( line )){
                  sqlText += ','.repeat(i>1?1:0) + `( ${uidx}, ${j}, '${line}', ${TYPE_ITEM})`;
                  iidx = j;
                  nearId = -1;
                }else
                //np
                if( /^\s*\d{1,4}.+/.test(line)) {
                  
                  sqlText += ','.repeat(i>1?1:0) + `( ${iidx}, ${j}, '${line}', ${TYPE_POINT})`;
                  pidx = j;
                  nearId = -1;
                }else{
                  if( nearId < 0 ) nearId = i - 1;
                  sqlText += ','.repeat(i>1?1:0) + `( ${nearId}, ${j}, '${line}', ${TYPE_CONT})`;
                  
                }
                
                
                if( i == 400 || i == lines.length){
                  //sqlText = sqlText.replace(/_(?=u00)/g,'\u005c');
                  let rsp = await this.sql.run(sqlText,this.php.book);
                  if( rsp.da.rst == false ){
                    //$log.lgg(JSON.stringify(rsp.da.msg));
                    alert('error:'+rsp.da.msg);
                    return;
                  }
                  sqlText = `INSERT INTO book(up,line,content,type) VALUES`;
                  msg(`${j}/${lines.length}`);
                  i = 0;
                }
                
              }
              msg('done');
              //$lg('5555::units:',...menu);
              
              //$lg('np:',...nps);
              
              //$lg('nps.length:',nps.length);
              
              //$lg('lines:',lines.length,Log.now());
              //alert('done');
              
              
            };
            //gm();
            
            let roman = ()=>{
              
              //let txt = "Ⅰ,ⅩⅣ,Ⅶ,Ⅱ,ⅩⅤ,Ⅹ,Ⅲ,ⅩⅥ,Ⅻ,ⅣⅢ,ⅩⅦ,ⅩⅩⅩ,Ⅴ,ⅩⅧ,Ⅵ,ⅩⅨ,ⅡC,ⅩⅩ,C,Ⅷ,ⅩⅩⅠ,CC,Ⅸ,ⅩⅩⅧ,D,DCCC,Ⅺ,ⅩⅩⅩⅥ,M,V,ⅩⅢ";
              let txt = "Ⅰ,ⅩⅣ,Ⅶ,Ⅱ,ⅩⅤ,Ⅹ,Ⅲ,ⅩⅥ,Ⅻ,ⅣⅢ,ⅩⅦ,ⅩⅩⅩ,Ⅴ,ⅩⅧ,Ⅵ,ⅩⅨ,ⅡC,ⅩⅩ,CⅩ,CC,Ⅸ,ⅩⅩⅧ,D,DCCC,Ⅺ,ⅩⅩⅩⅥ,M,V,ⅩⅢ";

              let arr = [ ...new Set( [...txt.split(',')] )];
              //$log.lgg('5647::txt',txt,arr.join(','));
              
              arr.sort();
              $lg('5592',arr.length,...arr);
              $log.lgg(arr.join(','));
            }
            //roman();
            
            let bookAddLine = async ()=>{
              let rsp = await this.service.data.req('tableBook.addLine',0,0,'a',0);
              $lg('5591::bookAddLine',JSON.stringify(rsp));
            }
            //bookAddLine();
            
            let datetime18 = ()=>{
              let name = '';
              let d = new Date();
              let fn = ['FullYear','Month','Day','Hours','Minutes','Seconds','getSeconds'];
                  for( let s of fn ){
                    name  += (Reflect.get( d, `get${s}`, d ))();
                    //if(ppt)name += Reflect.apply( ppt,d,null);
                  };
              $lg('5786::datetime18',name);
            }
            //datetime18();
            
            let getJson = async ()=>{
              
              let alpgo = ()=>{
                return new Promise((ok)=>{
                  let fname = '../app/json/alpha_go.json';
                  let xhr = new Xhr(this.php.addr);
                  xhr.ask('file__open',{filename:fname});
                  xhr.rsp((rsp)=>{
                    //$log.lgg(rsp);
                    let obj = JSON.parse(rsp);
                    ok(obj.da);
                  },(rsp)=>{
                    $lg('5814::err::bgo',JSON.stringify(rsp));
                  })
                })
              }
              
              let da = await alpgo();
              
              $log.lgg(da.dat);
              
              //let dat = JSON.parse(da.dat);
              
              //$log.lgg(JSON.stringify(dat));
              
              
              alert('done');
              
            }
            //getJson();
            
            let jsDate = ()=>{
              let d = new Date();
              let s = d.toUTCString();
              $lg('5838::',s);
              
              let d2 = new Date();
              let s2 = d2.toString('YYYY-MM-DD HH:MM:SS');
              $lg('5838::',s2);
              
              
            }
            //jsDate();
            
            let recRsp = ()=>{
              let str = `{"rst":true,"dat":{"path":"../app/voice/2023/08/25","name":"20230825-212152-0686-16-6.mp3","mkdir":1},"msg":null}`;
              let rsp = JSON.parse(str);
              let date = rsp.path.match(/\.+\/app\/voice\/(\d{4})\/(\d{2})\/(\d{2})$/);
              let time = rsp.name.match(/(\d{8})\-(\d{6})\-(\d{4})\-(\d{1,})\-(\d{1,})\.mp3$/);
              
            }
            //recRsp();
            
            let wordTree = (()=>{
              
              //this.ui.wordTree.index(17,0);
              this.ui.wordTree.index(17,6);
              //this.ui.wordTree.index(17,19);
              
            })()
            //wordTree();
            
            let feishu = ()=>{

                ////////////////////////////////
                
                let upload = (obj)=>{
                  return new Promise((ok, fail)=>{
                  
                    let da = {
                      name : `../learning/html/bootdata.json`,
                      cont : JSON.stringify(obj),
                    }
                    
                    let op = 'file__save';
                    
                    //let addr = '../../include/handler.php';
                    let addr = 'http://127.0.0.1:8080/project/include/handler.php';
                    
                    
                    let pack = (op,da)=>{
                  
                      let key   = 'opda';
                      let value = {
                          op      : op,
                          da      : da
                      };
                      let gift = encodeURIComponent( key ) + "=" + encodeURIComponent( JSON.stringify(value) );
                    
                      return gift;
                      
                    }
                    
                    let opda = pack(op,da);
                    $log.lgg('6535::opda',opda);
                    let xhr = new XMLHttpRequest();
                    xhr.timeout = 1000 * 20;
                    //let opda = task_build_request(user, op, da);
                    xhr.open('post', addr,true);
                    xhr.setRequestHeader("Content-Type",'application/x-www-form-urlencoded; charset=UTF-8');
                    xhr.onreadystatechange = function(){
                      if (this.readyState !== 4) {
                        return;
                      }
                      if (this.status === 200) {
                        ok(this.response);
                      } else {
                        fail(new Error(this.statusText));
                      }
                    }
                    
                    xhr.responseType = 'text';
                    xhr.send( opda );    
                  })
                }
                ////////////////////////////////
                document.addEventListener('click',async (e)=>{
                  let rsp = await upload({qq:'99397897'});
                  
                  alert(JSON.stringify(rsp));
                },0)
                ////////////////////////////////
              
              
            }
            //feishu();
            
            let upload = (fname,obj)=>{
                return new Promise((ok, fail)=>{
                
                  let da = {
                    name : `../learning/html/${fname}.json`,
                    cont : JSON.stringify(obj),
                  }
                  
                  let op = 'file__save';
                  
                  //let addr = '../../include/handler.php';
                  let addr = 'http://127.0.0.1:8080/project/include/handler.php';
                  
                  
                  let pack = (op,da)=>{
                
                    let key   = 'opda';
                    let value = {
                        op      : op,
                        da      : da
                    };
                    let gift = encodeURIComponent( key ) + "=" + encodeURIComponent( JSON.stringify(value) );
                  
                    return gift;
                    
                  }
                  
                  let opda = pack(op,da);
                
                  let xhr = new XMLHttpRequest();
                  xhr.timeout = 1000 * 20;
                  //let opda = task_build_request(user, op, da);
                  xhr.open('post', addr,true);
                  xhr.setRequestHeader("Content-Type",'application/x-www-form-urlencoded; charset=UTF-8');
                  xhr.onreadystatechange = function(){
                    if (this.readyState !== 4) {
                      return;
                    }
                    if (this.status === 200) {
                      ok(this.response);
                    } else {
                      fail(new Error(this.statusText));
                    }
                  }
                  
                  xhr.responseType = 'text';
                  xhr.send( opda );    
                })
            }
            //upload('001test',{txt:'test'})
            
            let voiceReg = (()=>{
              
              
              let htm = (()=>{
                let htm = new Html().dom()
                .textarea('#rtxx','.w:96% h:200px ovfl:scroll');
                this.ui.msgbox.fn.show(htm.pack());
              })()
              
              let txt = Doc.api.gbid('#rtxt');
              
              navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;  
  
              
              navigator.mediaDevices.getUserMedia({ audio: true })
              .then(function(stream) {
                
                const audioContext = new AudioContext();
                const mediaStreamSource = audioContext.createMediaStreamSource(stream);
                
                // 进行滤波处理
                const biquadFilter = audioContext.createBiquadFilter();
                biquadFilter.type = "lowpass";
                biquadFilter.frequency.value = 3000;
                mediaStreamSource.connect(biquadFilter);
                
                // 增加音量
                const gainNode = audioContext.createGain();
                gainNode.gain.value = 10;
                biquadFilter.connect(gainNode);
                

                gainNode.connect(audioContext.destination);
                
                            
                
                const recognition = new webkitSpeechRecognition(); // 创建语音识别对象
            
                if(typeof recognition == undefined) {
                  alert('not suoported');
                  return;
                }
            
                recognition.lang = 'en-US'; // 设置识别语言为英文
                recognition.continuous = true; // 设置连续识别模式
            
                recognition.onresult = function(event) {
                  const result = event.results[event.results.length - 1][0].transcript; // 获取最后一个识别结果
                  $lg('6768',result); // 输出识别结果
                  // 在这里可以根据识别结果进行相应的处理
                  txt.value = restlt + '\n';
                };
            
                recognition.start(); // 开始识别
              })
              .catch(function(error) {
                $lg('6775::获取麦克风权限失败：', error);
              });
              
            })
            
            let updateTable = ( async ()=>{
              alert('click ok to start update table');
              await this.service.data.req('buildTable');
              
              alert('done');
            })
            
            let toggleLine = (()=>{
              $lg('6957::toggleLine');
              [...Doc.api.queryAll('.art-line-box .line')].forEach( el =>{
                if( el.classList.contains('hide-line') == false ) {
                  el.classList.add('hide-line');
                }else{
                  el.classList.remove('hide-line');
                }
                $lg(el.className);
              })
            })
          
            let pythonHelloWorld = (()=>{
              let addr = '../python/req.py';
              
              let baseUrl =window.location.href;
              let absoluteUrl = new URL(addr, baseUrl);
              // 获取绝对路径字符串
              let absolutePath = absoluteUrl.href;
              $lg('7910::bgg','pythonHelloWorld',absolutePath);
    
              try{
              let xhr = new Xhr( addr );
                  xhr.port(8090);
                  xhr.ask('op_hello','da_data');
                  xhr.rsp((data)=>{
                    $lg('7922::bgb',JSON.stringify(data));
                  },(err)=>{
                    $lg('7924::bgo',err,err.message,JSON.stringify(err));
                  })
              }catch(e){
                $lg('7928::bgo',e.message);
              }
            })
          
            let aiCoach = (()=>{
              
              this.ui.aiCoach.index();
              
            })
          
            let buildWave = (async ()=>{
              
              await this.service.data.req('tableWave.build');
              
            })
            
            let tableOption_UpdateAll = (async ()=>{
              
              await this.service.data.req('tableOption.testUpdateAll');
              
              $lg('tableOption_UpdateAll');
              
            })
            
            let testWavAddToDatabase = (async ()=>{
              
              let rsp = await this.mp3Enc.test();
              
              $log.log('7991',JSON.stringify(rsp)); 
              
            })
          
            let outputSomeoneVoice =(async ()=>{
              
                let rsp = await this.service.data.req('tableTag.listSpeakerSentence',38,5);
                if( rsp.da.rst == false ) return alert('false');
                //$log.lgg(JSON.stringify(rsp));
                //return;
                let ds = [];
                for(let arr of rsp.da.dat.arr){
                  ds.push( arr[1] )
                }
                //$log.lgg(JSON.stringify(ds));
                
                
                let sqlText = `
                  SELECT lidx,MIN(start) AS start, MAX(end) AS end  
                  FROM word  
                  WHERE sid = 38 AND lidx IN (${ds.join(',')})  
                  GROUP BY lidx;
                `
                rsp = await this.sql.que(sqlText);
                let da = {
                  input     : '~/pj/app/mp3/人类来到人工智能时代的十字路口.mp3',
                  output    : `~/pj/app/mp3/001`,
                  dat       : rsp.da.dat.arr,
                }
                //$log.lgg(JSON.stringify(da));
                //return;
              return new Promise((ok,fail)=>{
                let xhr = new Xhr('../../python/handler.py');
                    xhr.json(1);
                    xhr.port(8090);
                    xhr.ask('audio__outputWaveFileBat',da);
                    xhr.rsp((jsonObj)=>{
                      $log.lgg('7858',JSON.stringify(jsonObj));
                      alert('done');
                      ok(jsonObj)
                    },(err)=>{
                      alert('fail');
                      fail(err)
                    })
              })
            })
          
            let fission = (async ()=>{
              
              let rsp = await this.service.data.req('fission','mp3',0);
              alert(JSON.stringify(rsp));
              
            })
          
            let save_mp3_to_sqlite = (()=>{
              let sql = `
                insert into mp3 blob()
              `;
              let op = 'data__save_as_blob';
              let da = {
                 path : '../app/dat/',
                 name : 'mp3_0000.sqlite3',
                 file : file,
                 sql  : sql,
                 act  : act,
              }
              
            })
          
            let optionUpdateKeyValue = (async ()=>{
              let rsp = await this.service.data.req('tableOption.update','fission','mp3','0');
              let rsp2 = await this.service.data.req('tableOption.update','fission','img','0');
              //let rsp = await this.service.data.req('tableOption.update','fission','mp3','0');
              alert(JSON.stringify(rsp));
              alert(JSON.stringify(rsp2));
            })
          
            let getFileSizeTesting = (async ()=>{
              
              //let path = '../app/mp3/AlphaGo.mp3';
              let path = '../app/dat/mp3_0000.sqlite3';
              let rsp = await this.fn.getFileSize(path,'MB');
              
              alert(rsp);
              
            })
            
            let attach_database = (async ()=>{
              
              let sqlText = ` attach database '../app/dat/mp3_0000.sqlite3' as 'mp3a';
                              select title 
                              from mp3a.mp3 
              `;
              
              let sqlText1 = ` 
                  select path
                  from mp3 
                  where id = 51
              `;
              
              
              
              
              let rsp = await this.sql.que(sqlText);
              
              alert(JSON.stringify(rsp));
              
              
            })
            
            let shouldBeFission = (()=>{
              this.fn.shouldBeFission('mp3',0);
              this.fn.shouldBeFission('voice',0);
              this.fn.shouldBeFission('img',0);
            })
          
            let mp3PartGlance = (async ()=>{
              
              let rsp = await this.service.data.req('tablePart.glance','mp3',0);
              
              if( rsp.da.rst == false ) return alert(rsp.da.dat.msg);
              
              $lg('8192::rsp::bgb',...rsp.da.dat.arr)
              
            })
          
            let mediaBinding = (()=>{
              this.ui.mediaBinding.index()
            })
            
            let baseLangTest = (()=>{
              
              alert('baseLangTest start');
              
              let fn = (...arr)=>{
                $lg('8409::bgb',...arr);
                return 1;
              }
              let done = ()=>{
                $lg('8413::done::bgg')
              }
              if(fn(0)){
                
              }else
              if(fn(1)){
                
              }else
              if(fn(2)) 
              
              alert('done');
              
            })
            
            let listUnknowBySid = (async ()=>{
              let t1 = performance.now();
              let rsp = await this.service.data.req('tableAware.listUnknowBySid',37);
              let t2 = performance.now();
              //if(rsp.da.rst == false)
              
              $lg('8433',(t2-t1),rsp.da.msg);
              //$lg('8433',JSON.stringify(rsp));
              $lg('8434',rsp.da.dat.arr.length);
              $lg('8435',...rsp.da.dat.arr);
              
              
              
            })
          
            let buildTableListen = (async ()=>{
              
                alert('buildTableListen');
                
                let rsp = await this.service.data.req('buildTable');
                
                alert(JSON.stringify(rsp));
                
            })
            
            let mp3_load = (()=>{
              
              $lg('8620:test:mp3_load');
              this.ui.tabMenu.tabs.song.load(77);
              
            })
            
            let dict_build_table_cut = ( async ()=>{
              
              let rsp = await this.dic.webman.request('tableCut.build');
              
              alert(JSON.stringify(rsp));
              
            })
            
            let dict_word_cut = ( async ()=>{
              
              $lg('8758:dict_word_cut');
              
              let rsp = await this.dic.webman.request('tableCut.addword',['de','vast','ation']);
              
              alert(JSON.stringify(rsp))
              
            })
            
            let dict_cut_getPart = ( async ()=>{
              
              let rsp = await this.dic.webman.request('tableCut.getPart','devastation');
              
              alert(JSON.stringify(rsp));
              
            })
            
            let buildTable = (async ()=>{
              
              
              let rsp = await this.service.data.req('buildTable',);
              /*
              
              await this.service.data.req('tableOption.update','fission','img',0);
              await this.service.data.req('tableOption.update','fission','mp3',0);
              await this.service.data.req('tableOption.update','fission','voice',0);
              
              await this.fn.shouldBeFission('img');
              await this.fn.shouldBeFission('mp3');
              await this.fn.shouldBeFission('voice');
              
              */
              alert('all done');
              
            })
          
            let listNumByDate = (async ()=>{
              
              //let rsp = await this.dic.webman.request('tableCut.getNumByDate',);
              //let rsp = await this.dic.webman.request('tableCut.listDetailNumByYear',);
              let rsp = await this.dic.webman.request('tableCut.listDetailByYear',);
              
              alert(JSON.stringify(rsp));
              
            })
            
            let listenProgress = (async ()=>{
              
              let sid = 8;
              let action = 201;
              let item = 2;
              //let rsp = await this.service.data.req('tableTag.listenProgress.save',sid,action,item);;
              let rsp = await this.service.data.req('tableTag.listenProgress.getLastItem',sid,action);;
              
              
              alert(JSON.stringify(rsp));
              
            })
            
            
          
            /*
            await this.service.data.req('buildTable',);
            $lg('6164::tableMp3 rebuilded');
            */
            /*
            await this.service.data.req('buildTable',);
            $lg('6164::tableMp3 rebuilded');
            */
            //showMsgBox();
            //fn6();
            //rgbToHsl();
            //fn6();
            
            //wordList();
            //await mp3Add();
            //mp3List();
            //$lg('1834::this.songId',this.songId);
            
            //$lg(`2401::abList.length:${this.abList.length}::bgo`);
            
            //$lg(`2402::abList::bgg`,this.abList[0][0],this.abList[0][1]);
            
            return this;
          },
          
          event : {
              setup : ()=>{
                let misc = Doc.api.query('.line-lrc-misc');
                    misc.addEventListener('click',(e)=>{
                      let ds = e.target;
                      if(ds.classList.contains('btn-lrc-save-all')){
                          return this.ui.lrcMisc.saveAll(ds);
                      }else 
                      if(ds.classList.contains('btn-lrc-save-one')){
                          return this.ui.lrcMisc.saveOne(ds);
                      }else 
                      if(ds.classList.contains('btn-lrc-test')){
                          return this.ui.lrcMisc.test(e);
                      }
                      return;
                    },0);
                let btns = Doc.api.queryAll('.line-lrc-misc>button');
                    for(let btn of btns){
                      btn.addEventListener('click',(e)=>{return;},true);
                    }
              },
          },
          
        },
        
        lrcBox     : {
          
          htm   : (lrcText)=>{
            
            let h = new Html();
                h.dom().div('.lrc-box flex-col-71').top();
            let lines = lrcText.split('\n');
            for(let line of lines){
              h.div('.lrc-line flex-row-4').as(0);
              let words = line.split(' ');
              //$lg('1412::bgg',line);
              //$lg('1413::bgg',...words);
              for(let word of words){
                h.div('.lrc-word',`!${word}`,0);
                
              }
            }
            let fgmLrc = h.pack();
            let menu = Doc.api.query('#spmenu');
            if(menu)menu.appendChild(fgmLrc);
            return this;
            
            
          },
          
          css   : ()=>{
            
            let cs = new Css();
            let step = new cs.hsl().inc(15).step;
            cs.style(['cssAjs','cssUi','cssLrcBox','css_lrcBox'])
              .slt('.lrc-box')
                  .f.rel().ds()
                  .a.flx.wrap.yes()
                    .h('auto')
                    .max.h('400px')
                    .ovfl.y.scl()
                    .bg(cs.rgba.white( 7, 1 ))
                    //.bor('6px solid black')
                    .ds()
              .slt('.lrc-line')
                  .f.rel().ds()
                  .a.flx.wrap.yes()
                    .bord.rad('6px')
                    //.bg(cs.rgba.white(6,0.6))
                    .ds()
              .slt('.lrc-set-time')
                  .flex.col.p(82)
                  .a.bor('1px solid white')
                    .mar('6px')
                    .bg(cs.rgba.white(1))
                    .bord.rad('6px')
                    .ds()
              .slt('.lrc-time-info')
                  .flex.row.p(5)
              .slt('.lrc-time-start,.lrc-time-end')
                  .a.pad('3px').mar('6px')
                    .bor('1px solid black')
                    .w('45%')
                    .flx.grow(1)
                    .bord.rad('6px')
                    .ds()
              .slt('.lrc-word')
                  .f.rel().tac().fs('5vmin').ds()
                  .a.mar('6px').pad('6px')
                    //.w('86%')
                    .bor('0px solid black')
                    .bord.rad('6px')
                    .bg(cs.rgba.green(3,0.4))
                    .clr(cs.rgba.white(0,1))
                    .padd.lef('10px').rig('10px')
                    .ds()
              
              .ok();
            return this;
            
          },
          
          event : {
            /*
            btnSetTime :  ()=>{
                let clk = async (e)=>{
                      //return new Promise((res,rej)=>{
                          //this.ui.fn.highlight(e);
                          if(this.songId == null) return;
                          let sid = this.songId;
                          let lidx = this.objLrc.lidx;
                          let objLine = this.objLrc.lines[lidx];
                          let words = objLine.words;
                          for(let objWord of words ){
                              let widx = objWord.idx;
                              let start = objWord.start;
                              let end = objWord.end;
                              await this.service.data.req('tableWord.setTime',sid,lidx,widx,start,end);
                          }
                }
                let btn = Doc.api.gbcl('btn-lrc-set-time');
                    btn[0].addEventListener('click',clk,false);
            },*/
            
            btnNextWord : ()=>{
                let btnNext = Doc.api.gbcl('btn-lrc-nextword');
                    btnNext[0].addEventListener('click',(e)=>{
                          
                      return new Promise((res,rej)=>{
                          /*let add = (lidx)=>{
                              let obj = {
                                id : 'btn-next',
                                fn : ()=>{
                                  if(Doc.api.query(`div[data-ajs-lidx='${lidx}']`)){
                                    $lg(`1268::found lidx:'${lidx}'::bgg`,Log.now());
                                    res();
                                  }
                                },
                                args : null,
                              }
                              window.compEveArr.push(obj.fn);
                          }*/
                          
                          this.ui.fn.highlight(e);
                          let lidx = this.objLrc.lidx;
                          if(lidx == -1){
                            this.objLrc.nextLine();
                            lidx = this.objLrc.lidx;
                          }
                          let idx = this.objLrc.widx+1;
                          
                          if(idx > this.objLrc.currLine().words.length-1){
                            Doc.api.query('.btn-lrc-nextline').click();
                            return;
                          }
                          let word = Doc.api.query(`.lrc-box div[data-ajs-widx='${idx}']`);
                          if(word)word.click();
                          
                          res();
                      })
                    },false);
            },
            
            btnNext : ()=>{
                let btnNext = Doc.api.gbcl('btn-lrc-nextline');
                    btnNext[0].addEventListener('click',(e)=>{
                          
                      return new Promise((res,rej)=>{
                          /*let add = (lidx)=>{
                              let obj = {
                                id : 'btn-next',
                                fn : ()=>{
                                  if(Doc.api.query(`div[data-ajs-lidx='${lidx}']`)){
                                    $lg(`1268::found lidx:'${lidx}'::bgg`,Log.now());
                                    res();
                                  }
                                },
                                args : null,
                              }
                              window.compEveArr.push(obj.fn);
                          }*/
                          
                          this.ui.fn.highlight(e);
                          //let box = Doc.api.query('div .lrc-box');
                              //box.innerHTML = '';
                          let fgm = this.objLrc.nextLine().outHtm();
                          let lidx = this.objLrc.lidx;
                          //add(lidx);
                          //$lg('1287',window.compEveArr.toString());
                          //$lg('1282::apn fgm start ::bgb',Log.now());
                          //$lg('1285::document.readyState',document.readyState,Log.now());
                           
                              //box.appendChild(fgm);
                          /*if(Doc.api.query(`div[data-ajs-lidx='${lidx}']`)){
                            $lg(`1268::found lidx:'${lidx}'::bgg`,Log.now());
                            res();
                          }else{
                            $lg(`1293::not found lidx:${lidx}`)
                            //return;
                          }*/
                          //$lg('1288::document.readyState',document.readyState,Log.now());
                          this.ui.lrcBox.fn.showLrc(fgm);
                          this.ui.lrcBox.fn.showIdx(this.objLrc.lidx);
                          //$lg(`mp3::1266,btnNext done,${Log.now()}::bgg`);
                          res();
                      })
                    },false);
            },
            
            btnPre : ()=>{
                let btnPre = Doc.api.gbcl('btn-lrc-preline');
                    btnPre[0].addEventListener('click',(e)=>{
                      this.ui.fn.highlight(e);
                      let box = Doc.api.query('div .lrc-box');
                          box.innerHTML = '';
                          box.appendChild(this.objLrc.preLine().outHtm());
                      this.ui.lrcBox.fn.showIdx(this.objLrc.lidx);
                    },false);
            },
            
            btnFirst : ()=>{
                let btnFirst = Doc.api.gbcl('btn-lrc-firstline');
                    btnFirst[0].addEventListener('click',(e)=>{
                      this.ui.fn.highlight(e);
                      let box = Doc.api.query('div .lrc-box');
                          box.innerHTML = '';
                          box.appendChild(this.objLrc.firstLine().outHtm());
                          this.ui.lrcBox.fn.showIdx(0);
                    },false);
            },
            
            btnLast : ()=>{
                let btnLast = Doc.api.gbcl('btn-lrc-lastline');
                    btnLast[0].addEventListener('click',(e)=>{
                      this.ui.fn.highlight(e);
                      let box = Doc.api.query('div .lrc-box');
                          box.innerHTML = '';
                          box.appendChild(this.objLrc.lastLine().outHtm());
                          this.ui.lrcBox.fn.showIdx(this.objLrc.lines.length-1);
                    },false);
            },

            all : ()=>{
              
                Ajs.runAll(this.ui.lrcBox.event,['all']);
                return this;
              
            }
            
          },
          
          fn : {
            
            showIdx : (idx)=>{
              //btn-lrc-lineidx
              let btnIdx = Doc.api.gbcl('btn-lrc-lineidx');
                  btnIdx[0].innerHTML = idx.toString();
                  //btnIdx[0].value = idx.toString();
            },
            
            addLabel : (pos=0,widx)=>{
              
              let pars = [
                  ['start','\u25e3'],
                  ['end','\u25e5']
                ];
              let arrow = Doc.api.celm('span','',`lrc-lbl-${pars[pos][0]}`,pars[pos][1]);
              let owd = Doc.api.query(`.lrc-word[data-ajs-widx='${widx}']`);
              if( owd.querySelector(`.lrc-lbl-${pars[pos][0]}`) == null ) owd.appendChild(arrow);
              
              return this;
            },
            
            showLrc : (fgm)=>{
              let box = Doc.api.query('.lrc-box');
                  box.innerHTML = '';
                  box.appendChild(fgm);
                  //this.ui.lrcBox.fn.showIdx(0);
              return this;
            },
            
          }
          
          
        },
        
        aiCoach : {
          
          wave : {
            
            standard : null,
            
            customer : null,
            
          },
          
          index : (lidx,widx)=>{
            
            let css = (()=>{
              
              if(Doc.has( '.Ajs style[class*="ai-coach"]')) return;
              
              Css.root = 'Ajs/ai-coach';
              
              let cs = new Css();
              
              new Css('.ai-coach',{
                width         : '96%',
                height        : '96%',
              })//.ai-coach
              
              new Css('.ai-coach div,.ai-coach button',{
                border        : '0px solid black',
                border_radius : '10px',
                font_size     : '4vmin',
                grow          : 1,
              })//.ai-coach div,.ai-coach button
              
              new Css('.ai-coach div',{
                width         : '96%',
                height        : 'auto',
                margin        : '6px',
                //padding       : '10px',
                background    : cs.rgba.white(9,1),
                border        : '1px solid black !important',
              })//.ai-coach div
              
              new Css('.ai-coach button',{
                margin        : '6px',
                padding       : '10px',
                grow          : 1,
                background    : cs.rgba.white(3,1),
                min_width     : '100px',
              })//.ai-coach button
              
              new Css('.coach-wave-tool',{
                position      : 'relative',
                //display       : 'inline-block',
                width         : '96%',
              })//.coach-wave-tool
              new Css('.standard-tool',{
                //top        : '-50px',
                border     : '1px solid red !important',
              })//.standard-tool
              new Css('.customer-tool',{
                //top        : '-50px',
                border     : '1px solid green !important',
                
              })//.customer-tool
              new Css('.coach-info-label',{
                //top        : '-50px',
                //grow       : 1,
                height     : '30px !important',
                background : 'orange',
                
              })//.coach-info-label
              new Css('.ai-coach-info',{
                //top        : '-50px',
                //grow       : 1,
                width      : '96%',
                height     : '60px',
              
                
              })//.ai-coach-info
              new Css('.coach-canvas',{
                //top        : '-50px',
                //grow       : 1,
                width      : '96%',
                height     : '200px',
              
                
              })//.coach-canvas
              
              Css.root = 'Ajs';
              
            })()
            
            let htm = (()=>{
              
              let htm = new Html();
              
              htm.dom()
              .div('.ai-coach flex-col-8').top()
                  .data('lidx',lidx)
                  .data('widx',widx)
                  .on.click( this.ui.aiCoach.event.center,0)
                  .div('.ai-coach-info flex-row-5').as(6)
                      .span(6,'.coach-info-label','#cpu-info-vol0')
                      .span(6,'.coach-info-label','#cpu-info-vol1')
                  .div('.ai-coach-wave').as(1)
                      .div(1,'.coach-wave-box standard-voice').as(11)
                      .div(1,'.coach-wave-tool standard-tool flex-row-6').as(12)
                          .button(12,'.coach-play-command coach-standard-time','!3.020')
                          .button(12,'.coach-play-command coach-cmd-play-standard','!play')
                  .div('.ai-coach-wave').as(2)
                      .div(2,'.coach-wave-box customer-voice').as(13)
                      .div(2,'.coach-wave-tool customer-tool flex-row-6').as(14)
                          .button(14,'.coach-play-command coach-customer-time','!3.020')
                          .button(14,'.coach-play-command coach-cmd-zoom-customer','+')
                          .button(14,'.coach-play-command coach-cmd-play-customer','!play')
                  .div('.ai-coach-canvas').as(7)
                      .canvas(7,'.coach-canvas')
                  .div('.ai-coach-result').as(3)
                  .div('.ai-coach-command flex-row-5').as(4)
                      .button(4,'.coach-command coach-cmd-load','!load')
                      .button(4,'.coach-command coach-cmd-start-training','!training');
              
              this.ui.msgbox.fn.show( htm.pack() );
              
            })()
            
            
            
            
          },
          
          event : {
            
            center : (e)=>{
              
              let type = e.type;
              
              let ds = e.target;
              let dp = ds.parentNode;
              let dpp = ds.parentNode.parentNode;
              
              let parent = (...args)=>{ return dp.classList.contains(...args); }
              let clazz = (...args)=>{ return ds.classList.contains(...args); }
              
              if( type == 'click' ){
                
                if( clazz( 'coach-cmd-load' )){
                  
                  this.ui.aiCoach.fn.load(e);
                  this.ui.aiCoach.fn.load2();
                  
                }else
                if( clazz( 'coach-cmd-play-standard' )){
                  //alert('coach-cmd-play-standard');
                  this.ui.aiCoach.fn.playStandard();
                  
                }
                if( clazz( 'coach-cmd-play-customer' )){
                  //alert('coach-cmd-play-standard');
                  this.ui.aiCoach.fn.playCustomer();
                  
                }
                if( clazz( 'coach-cmd-zoom-customer' )){
                  //alert('coach-cmd-play-standard');
                  this.ui.aiCoach.customer.zoom();
                  
                }
                if( clazz( 'coach-cmd-start-training' )){
                  //alert('coach-cmd-play-standard');
                  this.ui.aiCoach.customer.training(e);
                  
                }
                
                
              }
              
              
              
            },
            
            
            
          },
          
          customer : {
            
            zoom : ()=>{
              
              if( this.ui.aiCoach.wave.customer !== null ){
                
                let zoomBtn = Doc.api.query('.coach-cmd-zoom-customer');
                let p = zoomBtn.getAttribute('data-zoom');
                if( p == null || p == '100'){
                  
                  zoomBtn.setAttribute('data-zoom','200');
                  zoomBtn.innerText = '200';
                  this.ui.aiCoach.wave.customer.zoom(p);
                }else{
                  p = parseInt( p );
                  p+=100;
                  if( p > 1000 ) p = 100;
                  zoomBtn.setAttribute('data-zoom',p);
                  zoomBtn.innerText = p;
                  this.ui.aiCoach.wave.customer.zoom(p);
                }
              }else{
                alert('this.ui.aiCoach.wave.customer == null')
              }
              
            },
            
            training : async (e)=>{
              
              let trBtn = e.target;
              let p = trBtn.getAttribute('data-start');
              if( p == null || p == '0'){
                let eve = trBtn.getAttribute('data-event');
                if( eve == null || eve == '0'){
                  //document.addEventListener('speakingOver',(e)=>{
                  this.mp3Enc.sharedEvent.on('speakingOver', (data) => {
                    let info = Doc.api.query('.ai-coach-info');
                    let label = Doc.api.queryAll('.coach-info-label');
                    if( label ) { [...label].forEach((elm)=>{elm.classList.add('hide') })};
                    if( info )  { this.fn.bg.green( info ) }
                    
                  })
                  
                  this.mp3Enc.sharedEvent.on('silenceStart', (time) => {
                    $lg('8388::silenceStart',time)
                  })
                  this.mp3Enc.sharedEvent.on('buildBlobFileDone', (url) => {
                    this.ui.aiCoach.fn.load2( url );
                  })
                  
                  
                  /*
                  document.addEventListener('buildBlobFileDone',(e)=>{
                    
                    let url = e.detail.val;
                    
                    $lg('8364::buildBlobDone',url);
                    
                    this.ui.aiCoach.fn.load2( url );
                    
                  })
                  */
                  //document.addEventListener('cpuWorking',(e)=>{
                  let objVol0 = Doc.api.gbid('cpu-info-vol0');
                  let objVol1 = Doc.api.gbid('cpu-info-vol1');
                  
                  let showOnce = 0;
                  this.mp3Enc.sharedEvent.on('cpuWorking', (data) => {
                    try{
                    let vol = data;
                    $lg('8379::silenceValue',data);
                    return;
                    if( showOnce == 0 ){
                      let label = Doc.api.queryAll('.coach-info-label');
                      if( label ) { 
                        [...label].forEach((elm)=>{
                          elm.classList.remove('hide') 
                        })
                        showOnce = 1;
                      }
                    }
                    let pc = Math.abs( vol ) / 0.2 * 100;
                    //$lg('8404::pc',pc);
                    if( pc > 96 ) pc = 96;
                    //$lg('2198',vol,pc,Log.now());
                    if( vol > 0 ){
                      objVol1.style.width = pc + '%';
                      objVol0.style.width = '0';
                    }else{
                      objVol0.style.width = pc + '%';
                      objVol1.style.width = '0';
                    }
                    }catch(e){
                      $lg('8420',e.message);
                    }
                    //this.volArr.push(Math.abs( vol ));
                  })
              
                }
                trBtn.setAttribute('data-start','1');
                trBtn.innerText = 'stop';
                
                let canvas = Doc.api.query('.coach-canvas');
                let canvasCtx = canvas.getContext('2d');

                
                this.mp3Enc.startTraining(canvasCtx);
                
              }else{
                
                trBtn.setAttribute('data-start','0');
                trBtn.innerText = 'training';
                this.mp3Enc.stopTraining();
                //$lg('8396::rsp',JSON.stringify(rsp),rsp);
                //this.ui.aiCoach.fn.load2( rsp );
              }
              
              
              
              
            },
            
          },
          
          
          fn : {
            
            load : async (e)=>{
              
              let ds = e.target;
              
              let dpp = ds.parentElement.parentElement;
              
              let lidx = dpp.getAttribute('data-ajs-lidx');
              let widx = dpp.getAttribute('data-ajs-widx');
              
              //$lg('8438::lidx,widx',lidx,widx);
              
              if( lidx ) lidx = parseInt( lidx );
              if( widx ) widx = parseInt( widx );
              
              if( typeof lidx !== 'number' || typeof widx !== 'number') return alert('lidx,widx wrong');
              
              let objWord = this.objLrc.getObjWord(lidx,widx);
              let word = objWord.word;
              let st = objWord.start * 1000;
              let ed = objWord.end * 1000;
              
              let cutWord = async ()=>{
                
                let rsp = await this.service.data.req('tableMp3.getPath',this.songId);
                if( rsp.da.rst == false ) return alert('getPath fail');
                let path = ((rsp.da.dat.arr)[0])[0];
                if( path == null ) return this;
                
                let da = {
                  input     : '~/pj/app'+path.replace('.',''),
                  output    : `~/pj/app/wav/${word}.wav`,
                  start     : st,
                  end       : ed,
                  silence   : -10,
                }
                
                //$log.lgg('8450:da',JSON.stringify(da));
                //return;
                return new Promise((ok,fail)=>{
                  let xhr = new Xhr('../../python/handler.py');
                      xhr.json(1);
                      xhr.port(8090);
                      xhr.ask('audio__outputWaveFile',da);
                      xhr.rsp((jsonObj)=>{
                        $log.lgg('8472',JSON.stringify(jsonObj));
                        ok(jsonObj)
                      },(err)=>{
                        fail(err)
                      })
                })
              }
              
              let loadWave = ()=>{
                //let wavesurfer = this.ui.aiCoach.wave.standard;
                 this.ui.aiCoach.wave.standard = WaveSurfer.create({
                  container: Doc.api.query('.standard-voice'),
                  waveColor: 'rgb(200, 0, 200)',
                  progressColor: 'orange',
                  url: `./wav/${word}.wav`,
                })
                
                this.ui.aiCoach.wave.standard.once('interaction', () => {
                  this.ui.aiCoach.wave.standard.play()
                })
                
                
                
              }
              
              
              this.fn.bg.flash('.standard-tool');
              let cutRsp = await cutWord();
              
              if( cutRsp.da.rst == 0 ) return alert('8497::fail');
              
              Doc.api.query('.standard-tool').classList.remove('bg-flash');
              
              loadWave();
              
            },
            
            load2 : (url)=>{
                $lg('8491::load2',url,url == undefined);
                if(url == undefined ) return;
                const audio = new Audio();
                audio.src = url.toString().replace('blob:', '');
                audio.play();
              
                let loadWave = (url)=>{
                //let wavesurfer = this.ui.aiCoach.wave.standard;
                  this.ui.aiCoach.wave.customer = WaveSurfer.create({
                    container: Doc.api.query('.customer-voice'),
                    waveColor: 'rgb(100, 0, 100)',
                    progressColor: 'rgb(100, 0, 100)',
                    //url: './voice/2023/09/21/20230921-220300-0355-38.mp3',
                    //url: './voice/2023/09/25/20230925-213842-0660-55.mp3',
                    url: url,
                    hideScrollbar: false,
                    autoScroll: true,
                    autoCenter: true,
                    audioRate: 0.5,
                  })
                }
                
                //URL.revokeObjectURL( url );
                
                loadWave(url);
                
                this.ui.aiCoach.wave.customer.once('interaction', () => {
                  this.ui.aiCoach.wave.customer.play()
                })
                
                this.ui.aiCoach.wave.customer.on('timeupdate', (currentTime) => {
                  //console.log('Time', currentTime + 's')
                  URL.revokeObjectURL( url );
                  let time = Doc.api.query('.coach-customer-time');
                      time.innerText = currentTime.toFixed(2);
                })
                
                
              
              
            },
            
            playStandard : ()=>{
              
              //alert('playStandard');
              
              if( this.ui.aiCoach.wave.standard !== null ){
                this.ui.aiCoach.wave.standard.play();
              }else{
                alert('this.ui.aiCoach.wave.standard == null')
              }
            },
            
            playCustomer : ()=>{
              
              //alert('playStandard');
              
              if( this.ui.aiCoach.wave.customer !== null ){
                
                let playBtn = Doc.api.query('.coach-cmd-play-customer');
                let p = playBtn.getAttribute('data-play');
                if( p == null || p == '0'){
                  playBtn.setAttribute('data-play','1');
                  this.ui.aiCoach.wave.customer.playbackRate = 0.5;
                  this.ui.aiCoach.wave.customer.play();
                }else{
                  playBtn.setAttribute('data-play','0');
                  this.ui.aiCoach.wave.customer.pause();
                }
              }else{
                alert('this.ui.aiCoach.wave.customer == null')
              }
            },
            
            
            
          },
          
          
          
          
        },
        
        book : {
          
          index : ()=>{
            
            this.ui.sliderMenu.close();
            
            let css = (()=>{
              if(Doc.api.query('.book-content-box')) return;
              Css.root = 'Ajs/book';

              new Css('.book-content-box',{
                width           : '96%',
                height          : '96%',
                top             : 0,
                left            : 0,
                backgroundColor : 'white',
                padding         : '20px',
                z_index         : 1,
              })//.book-content-box
              new Css('.book-line',{
                position        : 'relative',  
                width           : '96%',
                height          : 'auto',
                
                backgroundColor : 'transparent',
                padding         : '6px',
                margin          : '10px',
                
              })//.book-line
              new Css('.book-cont',{
                position        : 'relative',  
                font_size       : '4vmin',
                color           : 'black',
                
              })//.book-cont
              new Css('.pink',{
                color           : 'black !important',
                background      : 'pink !important',
              })//.pink
              
              /*new Css('.book-menu-box .cata-line-name',{
                text_overflow   : 'ellipsis',
              })*/
              new Css('.book-menu-box>.cata-item',{
                margin_left     : '0px',
                padding_left    : '0px',
              })//.book-menu-box>.cata-item'
              new Css('.book-menu-box',{
                width           : '96%',
                height          : '90%',
                
                overflow_y      : 'scroll',
                left            : 0,
                padding         : '6px',
                background      : `hsla(60,60%,20%,0.6)`,
                z_index         : 10,
              })//.book-menu-box
              new Css('.book-menu-cmd-box',{
                width           : '90%',
                height          : '70px',
                padding         : '6px',
                margin          : '6px',
                background      : `lightgrey`,
                //border          : `6px solid black`,
                //color           : `black`,
                //border_radius   : '16px',
                //text_align      : 'center',
                //font_size       : '5vmin',
              })//.book-menu-cmd-box
              new Css('.book-menu-cmd',{
                min_width       : '70px',
                width           : 'auto',
                min_width       : '70px',
                height          : '70px',
                padding         : '6px',
                margin          : '16px',
                background      : `lightgrey`,
                border          : `1px solid black`,
                color           : `black`,
                border_radius   : '6px',
                text_align      : 'center',
                font_size       : '5vmin',
              })//.book-menu-cmd

              new Css('.book',{
                display         : 'none',
                position        : 'absolute',
                top             : 0,
                left            : 0,
                width           : '94%',
                height          : '96%',
                font_size       : '5vmin',
                padding         : '10px',
                margin          : '10px',
                border          : 'black',
                border_radius   : '10px',
                border          : '6px solid hsla(60,60%,10%,1)',
                background      : 'hsla(60,90%,90%,1)',
                color           : 'hsla(60,60%,10%,1)',
                //filter          : 'drop-shadow 0 0 3px white',
                overflow_y      : 'scroll',
                z_index         : 0,
              })//.book
              new Css('.book-cmd',{
                position      : 'relative',
                
                width         : '70px',
                height        : '70px',
                font_size     : '5vmin',
                background    : 'gray',
                margin        : '10px',
                text_align    : 'center',
                clock         : 'black',
                top           : '30px',
                right         : '20px',
                z_index       : 101,
              })//book-btn-close
              new Css('.book-cmd-box',{
                position      : 'fixed',
                
                width         : '90%',
                height        : '70px',
                top           : '30px',
                right         : '20px',
                z_index       : 101,
              })//book-cmd
            
              Css.root = 'Ajs';
              
            })()
            
            let bookContent = (()=>{
              if(Doc.has('#book')) {
                  /*let book = Doc.api.query('.book');
                      book.classList.remove('hide');
                      book.style.zIndex = 100;*/
                  return;
              }
              
              let htm = (()=>{
                //$lg('6576::book::htm::bgb');
                let htm = new Html();
                    htm.dom( 'body' )
                    .div('#book','.book flex-col-71').as(1)
                        .div(1,'.book-cmd-box flex-row-6').as(10)
                            //.button(10,'.book-cmd book-btn-set focus-btn','!set')
                                
                            .button(10,'.book-cmd book-btn-hide','!--')
                                .on.click((e)=>{
                                  //$lg('6590::book::close::bgo');
                                  this.ui.book.hide();
                                  this.ui.msgbox.fn.show();
                                })
                            .button(10,'.book-cmd book-btn-close','!x')
                                .on.click((e)=>{
                                  //$lg('6590::book::close::bgo');
                                  this.ui.book.hide();
                                })
                        .div(1,'.book-content-box flex-col-71')
                    .ok();
              })()
              
            })()
            
            let bookMenu = (async ()=>{
              //shared some css
              this.ui.tabMenu.tabs.cata.css();
              
              let fgm = new Html()
              .dom()
              .div('.book-menu-cmd-box flex-row-4050').as(1)
                  .button(1,'.book-menu-cmd book-menu-set focus-btn','!set')
                  .button(1,`.book-menu-cmd book-menu-close`,'!close')
                    .on.click((e)=>{
                      this.ui.msgbox.fn.hide();
                      this.ui.book.show();
                    },0)
              .div(`.book-menu-box flex-col-71`);
              
              this.ui.msgbox.fn.show( fgm.pack() );
              
              let rsp = await this.service.data.req('tableBook.listMenu', 0 );
              
              this.ui.book.addItems( rsp.da.dat.arr );
              
              //$lg('6082::rsp',JSON.stringify(rsp));
              
            })()
            
            
            Doc.api.query('.msg-box').style.top = '50px';
            Doc.api.query('.msg-box').style.width = '96%';
            Doc.api.query('.msg-box').style.height = '96%';
            
          },
          
          addItems : ( arr )=>{
                        
            //$lg('6095::add::items::arr',JSON.stringify(arr));
            
            if( arr.length == 0 ) return;
            
            
            let htm = new Html();
          
            for( let item of arr ){
              
              let upid = item[0];
              let   id = item[1];
              let name = item[2];
              
              //$lg(upid,id,name);

              let top = `.book-menu-box`;
              
              if( upid > 0 ){
                
                top = `.book-menu-box .cata-item[data-ajs-bookid='${upid}'`;
                
              }
          
              
              htm.dom( top );

              htm.div(`.cata-item flex-col-4`).top()
                .data('bookid',id)
                .data('upid',upid)
                .div(`.cata-item-line`).as(1)
                    .button(1,`.cata-item-menu`)
                        .on.click(this.ui.book.menuClick,0)
                    .span(1,`.cata-item-name`,`!${name}`)
                        .data('bookid',id)
                        .on.click(this.ui.book.itemClick,0)
                .ok();
              
            }
            
          },
            
          itemClick : async (e)=>{
            
            let ds = e.target;
            let item = ds.parentNode.parentNode;
            
            /*
            let target = Doc.api.query('.book-menu-set');
            if( target ){
              
              if( target.classList.contains('yelack')){
                  //
                  let bookid = item.getAttribute('data-ajs-bookid');
                  let rsp = await this.service.data.req('tableBook.selfAddType', parseInt(bookid) );
                  if( rsp.da.rst == false ) return;// alert( '6153::'+ rsp.da.msg );
                  ds.classList.add('pink');
                  return;
                  
              }
              
            }
            */
          
            
            
            //$lg('3614::item.idx',item.getAttribute('data-ajs-idx'));
            [...Doc.api.queryAll('.book-menu-box .cata-item .yelack')].forEach((elm)=>{
              elm.classList.remove('yelack');
            })
            ///////////////////////////////////////
            
            ///////////////////////////////////////
            ds.classList.add('yelack');
            let st = item.getAttribute('data-ajs-status');
            if( st == null || st == '0'){
              //download item
              item.setAttribute('data-ajs-status','1');
              let bookid = item.getAttribute('data-ajs-bookid');
              let where = '.book-content-box';
              //this.ui.book.list(bookid,where);
              let rsp = await this.service.data.req('tableBook.listMenu', parseInt(bookid) );
              if( rsp.da.rst == false ) return alert( '6153::'+ rsp.da.msg );
              this.ui.book.addItems( rsp.da.dat.arr );
              
              //this.ui.book.showCont( rsp );
              
            }else{
              //delete sub items
              item.setAttribute('data-ajs-status','0');
              let child = item.children;
              if( child.length > 0 ){
                for(let chd of [...child]){
                  let cidx = chd.getAttribute('data-ajs-idx');
                  //$lg('3629::chd.idx',cidx);
                  if(chd.className.indexOf('cata-item-line') == -1 )
                    { chd.parentNode.removeChild(chd); }
                }
              }
            }
          },
          
          showCont : async ()=>{
            
            let actItem = Doc.api.query('.book-menu-box .yelack');
            if( actItem ){
              
              let bookid = actItem.getAttribute('data-ajs-bookid');
              if( bookid ) bookid = parseInt( bookid );
              
              let rsp = await this.service.data.req('tableBook.listCont', bookid );
              
              if( rsp.da.rst == null ) return;
              
              let book = Doc.api.query('#book .book-content-box');
              if ( book ) book.innerHTML = '';
              
              let htm = new Html();
              htm.dom('#book .book-content-box');
              
              for( let item of rsp.da.dat.arr ){
                //id,up,line,content
                htm.div('.book-line flex-row-4')
                      .span('.book-cont',`!${item[3]}`)
                      .data('bookid',item[0]);
              }
              
              htm.ok();
              
            }
            
          },
          
          hide : ()=>{
            
            $lg('6761::ui::book::hide::bgb');
            let book = Doc.api.gbid('book');
            if( book ){
                book.style.display = 'none';
                book.style.zIndex = 0;
            }
          },
          
          show : ()=>{
            $lg('6769::ui::book::show::bgg');
            let book = Doc.api.gbid('book');
            if( book ){
                book.style.display = 'flex';
                book.style.zIndex = 100;
              this.ui.book.showCont();
            }
          },
          
          subMenu : {
            
            index : (e,id = 0)=>{
              
              let ds = e.target;
              let dp = e.target.parentNode;
              let has = (...args)=> ds.classList.contains(...args);
              [...Doc.api.queryAll('.cata-submenu')].forEach(obj=>{
                obj.parentNode.removeChild(obj);
              })
              let h = new Html();
              h.dom( dp )
                  .div('.cata-submenu flex-row-5').top()
                    .data('id',id)
                    .button('.btn cata-btn close','!\u00ab')
                    .button('.btn cata-btn tool delete','!\u2297')
                    .button('.btn cata-btn tool edit','!\u270e')
                    .button('.btn cata-btn tool top','!\u21f1')
                    .button('.btn cata-btn tool move','!\u21d5')
              .queryAll('.cata-btn').on.click( async (e)=>{
                let ds = e.target;
                let dp = e.target.parentNode;
                let has = (...args)=> ds.classList.contains(...args);
                if(has('move')){
                  [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                    obj.parentNode.removeChild(obj);
                  })
                  let fgm = this.ui.book.subMenu.move();
                  dp.parentNode.appendChild( fgm );
                }else
                if(has('top')){
                  [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                    obj.parentNode.removeChild(obj);
                  })
                  
                  let id = dp.getAttribute('data-ajs-id');
                  let upid = 0;
                  let rsp = await this.service.data.req('tableCata.update.upid',id,upid);
                  if( rsp.da.rst == false ) return alert( rsp.da.msg );
                  Doc.api.query('.cata-submenu .close').click();
                  Doc.api.query('.panel-cata .panel-menu .list').click();
               
                }else
                if(has('close')){
                  let elms = Doc.api.queryAll('.elm-to-move');
                  
                  [...elms].forEach( elm => elm.classList.remove('elm-to-move') );
                  
                  elms = Doc.api.queryAll('.cata-submenu');
                  [...elms].forEach(elm=>elm.parentNode.removeChild(elm));
                }else 
                if(has('delete')){
                  
                  let id = dp.getAttribute('data-ajs-id');
                  
                  [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                    obj.parentNode.removeChild(obj);
                  })
                  let fgm = this.ui.book.subMenu.del(id);
                  dp.parentNode.appendChild( fgm );
                  
                  
                }else
                if(has('edit')){
                  
                  let id = dp.getAttribute('data-ajs-id');
                  $lg('3558::id',id);
                  [...Doc.api.queryAll('.cata-submenu .tool')].forEach(obj=>{
                    obj.parentNode.removeChild(obj);
                  })
                  let fgm = this.ui.book.subMenu.edit(id);
                  this.ui.msgbox.fn.show( fgm );
                  
                  
                }
              },0)
              /*.query('.cata-submenu').on.click((e)=>{
                
              },0)*/
              h.ok();
            
            },
            
            move : ()=>{
            
              let htm = new Html()
              .dom()
                  .div('.cata-submenu flex-row-5').top()
                    //.span('.btn cata-move-label',`!move to:`)
                    .span('.cata-move-to',`!click target`)
                    //.button('.btn cata-move-close',`! X `)
                    .button('.btn cata-move-ok',`!ok`)
                
              //.queryAll('.btn').on.click((e)=>{return;},1)
              
              .query('.panel-move').on.click( async(e)=>{
                let ds = e.target;
                this.ui.fn.highlight(e);
                let has = (a)=>{ return ds.classList.contains(a)};
                /*if( has('cata-move-close') ){
                  ds.parentNode.parentNode.removeChild(ds.parentNode);
                }else*/
                if( has('cata-move-ok') ){
                  $lg('3556::dp.className',ds.parentNode.className,ds.parentNode.parentNode.parentNode.className);
                  let dppp = ds.parentNode.parentNode.parentNode;
                  let caid = dppp.getAttribute('data-ajs-caid');
                  let upid = ds.getAttribute('data-upid');
                  let rsp = await this.service.data.req('tableBook.update.up',caid,upid);
                  if( rsp.da.rst == false ) return alert( rsp.da.msg );
                  $lg('3892::rsp',JSON.stringify(rsp));
                  Doc.api.query('.cata-submenu .close').click();
                  Doc.api.query('.panel-cata .panel-menu .list').click();
                }
              },0);
              
              return htm.pack();
              
            },
            
            del  : (id)=>{
            
              let htm = new Html()
              .dom()
                  .div('.cata-submenu submenu-del flex-row-5').top()
                    .data('id',id)
                    .span('.btn cata-del-alert',`!del ?`)

                    .button('.btn cata-del-yes',`!yes`)
                    .button('.btn cata-del-no',`!no`)
                
              .queryAll('.btn').on.click((e)=>{return;},1)
              
              .query('.submenu-del').on.click( async(e)=>{
                let ds = e.target;
                this.ui.fn.highlight(e);
                let has = (a)=>{ return ds.classList.contains(a)};
                /*if( has('cata-move-close') ){
                  ds.parentNode.parentNode.removeChild(ds.parentNode);
                }else*/
                if( has('cata-del-yes') ){
                  //$lg('3556::dp.className',ds.parentNode.className,ds.parentNode.parentNode.className);
                  let dp = ds.parentNode;
                  let id = dp.getAttribute('data-ajs-id');
                  
                  let rsp = await this.service.data.req('tableCata.del',id);
                  if( rsp.da.rst == false ) return alert( rsp.da.msg );
                  Doc.api.query('.cata-submenu .close').click();
                  Doc.api.query('.panel-cata .panel-menu .list').click();
                }else 
                if( has('cata-del-no') ){
                  //$lg('3556::dp.className',ds.parentNode.className,ds.parentNode.parentNode.className);
                  
                  Doc.api.query('.cata-submenu .close').click();
                  
                }
              },0);
              
              return htm.pack();
              
            },
            
            edit : (caid)=>{
              
              let htm = new Html().dom()
              .div('.pan cata-edit-box flex-col-5').top()
                .data('temp',caid)
                .input.text('.btn cata-edit-input')
                .button('.btn cata-edit-ok',`!ok`)
                  .on.click(async (e)=>{
                    
                    let ds = e.target;
                    let dp = e.target.parentNode;
                    
                    let name = dp.firstChild.value.trim();
                    
                    let id = dp.getAttribute('data-ajs-temp');
                    
                    if( name == null || name.length == 0 ) return;
                    
                    let rsp = await this.service.data.req('tableCata.update.name',id,name);
                    
                    if( rsp.da.rst == false ){ return  alert( rsp.da.msg ) };
                    
                    this.ui.msgbox.fn.hide();
                    Doc.api.query('.panel-cata .panel-menu .list').click();
                    
                  },0);
              
              return htm.pack();
              
            },
            
          },
          
          menuClick : (e)=>{
            let ds = e.target;
            let dp = ds.parentNode;
            let caid = dp.parentNode.getAttribute('data-ajs-caid');
            //$lg('3796::id',id,dp.parentNode.getAttribute('data-ajs-idx'));
            this.ui.book.subMenu.index(e,caid);
          },
        
        },
        
        wordTree : {
          
          data  : {
            
            tree : null,
            
          },
          
          index : (sid,lidx)=>{
            
            //this.service.data.req('buildTable',);
            const $tree = this.ui.wordTree;
            
            let css = (()=>{
              
              if( Doc.has(`style.Ajs [class*='word-house']`)) return;
              //let color = `hsla(30,20%,10%,0.3)`;
              
              let cs = new Css();
              
              let color = 'gray';
              Css.root = ('Ajs/wordTree')
              
              new Css('.word-tree-box',{
                display           : 'flex',
                /*
                font_size         : '6vmin',
                border            : '0px solid white',
                margin            : '2px',
                padding           : '2px',
                */
                border_radius     : '10px',
                background        : cs.rgba.white(6,1),
                
              })//.word-house,.word-floor,.word-room
              new Css('.word-tree-box',{
                flex_direction    : 'column',
                justify_content   : 'flex-start',
                align_items       : 'flex-start',
                flex_wrap         : 'nowrap',
                width             : '800px',
                height            : '800px',
                overflow          : 'scroll !',
              })//.word-tree-box
              new Css('.word-floor',{
                flex_direction    : 'row',
                justify_content   : 'flex-start',
                align_items       : 'flex-start',
                border            : '1px solid black !important',
                border_radius     : '10px  !important',
                height          : 'auto',
                width           : 'auto',
                margin          : '6px',
                margin_left     : '40px',
                padding         : '2px',
                font_size       : '4vmin',
                background      : 'transparent',
              })//.word-floor
              new Css('.word-tree-box > .word-floor',{
                
                margin_left     : '10px !important',
                
              })//.word-tree-box > .word-floor
              new Css('.word-house',{
                flex_direction    : 'column',
                justify_content   : 'flex-start',
                align_items       : 'flex-start',
                //border            : '0px solid red !important',
                //margin_left       : '20px !important',
                height          : 'auto',
                width           : 'auto',
                margin          : '6px',
                margin_left     : '40px !important',
                padding         : '2px',
                font_size       : '4vmin',
                background      : 'transparent',
              })//.word-house
              new Css('.word-room',{
                flex_direction    : 'row',
                align_item        : 'center',
                border            : '0px solid green !important',
                width             : 'auto',
                margin_left       : '20px',
              })//.word-room
              new Css('.word-guest-room-1,word-guest-room-3',{
                justify_content   : 'flex-end',
              })//.word-guest-room-1
              new Css('.word-guest-room-2,.word-guest-room-4',{
                justify_content   : 'flex-start',
              })//.word-guest-room-2
              new Css('.word-host-room',{
                justify_content   : 'flex-start',
                //padding_left      : '6px',
                //padding_right     : '6px',
                min_width         : '70px',
                //border            : '1px solid red !important',
                margin          : '2px',
                padding         : '2px',
                padding_left    : '56px',
                padding_right   : '16px',
                //background      : 'lightyellow',
                white_space     : 'pre',
                border_radius   : '10px',
                border          : '3px solid black',
              })//.word-host-room
              /*new Css('.host-show-menu',{
                background        : 'transparent',
                margin            : '6px',
                margin_left       : '20px',
                width             : '0px',
                height            : '0px',
                height            : '0px',
                border_left       : '20px solid lightgrey',
                border_right      : '20px solid transparent',
                border_top        : '20px solid transparent',
                border_bottom     : '20px solid transparent',
              })//.host-show-menu*/
              new Css('.castle-close',{
                width             : '100px !important',
              })//.castle-close
              
              /*
              new Css('.cata-item',{
                    position        : 'relative',
                    height          : 'auto',
                    width           : '96%',
                    margin          : '6px',
                    margin_left     : '40px',
                    padding         : '2px',
                    font_size       : '4vmin',
                    background      : 'transparent',
                  })//.cata-item
              new Css('.cata-item-line',{
                position        : 'relative',
                display         : 'flex',
                flex_direction  : 'row',
                justify_content : 'flex-start',
                align_items     : 'center',
              })//.cata-item-line*/
              new Css('.host-show-menu',{
                position        : 'relative',
                //top             : '-6px',
                left            : '50px',
                padding         : '0px',
                font_size       : '3vmin',
                background      : `${color}`,
                width           : '42px !important',
                height          : '70px',
                border          : `0px solid ${color}`,
                border_right    : `16px solid ${color}`,
                border_top_left_radius     : '6px',
                border_bottom_left_radius  : '6px',
                z_index         : 1,      
              })//.host-show-menu
              /*new Css('.cata-item-name',{
                position        : 'relative',
                margin          : '2px',
                padding         : '2px',
                padding_left    : '56px',
                padding_right   : '16px',
                //background      : 'lightyellow',
                white_space     : 'pre',
                border_radius   : '10px',
                border          : '3px solid black',
              })//.cata-item-name
              */
              /*
              new Css('.word-floor-2',{
                display           : 'inline !important',
              })//.word-floor-2
              */
              
              new Css('.word-guest-room-3',{
                width             : '50%',
                padding           : '2px',
              })//.word-guest-room3
              new Css('.word-guest-room-4',{
                padding           : '2px',
                width             : '50%',
              })//.word-guest-room4
              new Css('.word-tree-box .word-room:not(.word-host-room)',{
                display           : 'none',
              })//.word-guest-room-2
              
              Css.root = 'Ajs';
              
              let cssCheckIn = (()=>{
                if(Doc.has( '.Ajs .wordCheckIn' )) return;
                new Css().style('Ajs/wordCheckIn')
                .slt('.word-tree-box .word-room:not(.word-host-room)')
                    .display('flex !important')
                    .border('2px solid black !important')
                    .margin('10px !important')
                .ok()
                let obj = Doc.api.query('.Ajs .wordCheckIn');
                if( obj ) obj.disabled = true;
              })()
              
            })()
            
            let htm = (()=>{
              
              let htm = new Html();
                htm.dom()
                .div('.spread-line word-tree-menu flex-row-5').as(1)
                    .on.click(this.ui.wordTree.event.handler,0)
                    .button(1,'.btn','!保存')
                    .button(1,'.btn','!还原')
                    .button(1,'.btn word-tree-folder','\u25ac')
                    .button(1,'.btn word-tree-row','\u22ef')
                    .button(1,'.btn word-tree-col','\u22ee')
                    .button(1,'.btn word-tree-debug','!debug')
                    
                .div('.word-tree-box');
                    //.on.click(this.ui.wordTree.event.handler,0);
              
              this.ui.msgbox.fn.show( htm.pack() );
              

            })()
            
            let data = ( async ()=>{
              
              //$lg('9400::sid,lidx',sid,lidx);
              let rsp = await this.service.data.req('tableWordTree.list',sid,lidx);
              //$lg('9402::wordTree.index',JSON.stringify(rsp),Log.now());
              
              
              if( rsp.da.dat.arr.length == 0 ){
                
                //$lg('9407','rsp.da.dat.arr.length == 0',rsp.da.dat.arr.length == 0);

                rsp = await this.service.data.req('tableWord.list',sid,lidx);
                //$lg('9409::tableWord.list',sid,lidx,JSON.stringify(rsp.da.dat.arr),Log.now());
              
                $log.lgg('10758',JSON.stringify(rsp));
              
              
              }
              
              let od_sum = 0;
              for( let item of rsp.da.dat.arr){
                od_sum += item[2];
              }
              
              let arr = [];
              let i = -1;
              for( let item of rsp.da.dat.arr){
                i++;
                arr.push({
                  id    : item[0],
                  up    : item[1],
                  od    : od_sum == 0 ? i : item[2],
                  hide  : item[3],
                  text  : item[4],
                  type  : item[5],// == '.' ? 1 : item[5],
                  dir   : item[6],
                  flex  : item[7],
                  fold  : item[8],
                })
              }
              
              //$lg('7000::wordTree.index',sid,lidx,JSON.stringify(rsp.da.dat.arr),Log.now());
              this.ui.wordTree.data = {};
              let ui = new Ui();
              this.ui.wordTree.data.tree = new ui.tree();
              const tree = this.ui.wordTree.data.tree;
              tree.conf.root('.word-tree-box');
            
              tree.conf.onExpand((id)=>{
                //$lg('10797:tree.conf.onExpand::bgg',id)
              });
                
              
              tree.index();
              tree.item.add(arr);

            })()

          },
          
          event : {
            
            handler : (e)=>{
              
                let type = e.type;
                  
                let ds = e.target;
                if( ds == null ) return;
                
                let dp = ds.parentElement;
                let dpp = dp == null ? null : dp.parentElement;
                
                let had = (...args)=>{ return ds.classList.contains(...args); }
                let not = (...args)=>{ return ds.classList.contains(...args) == false; }
                
                let $event = this.ui.wordTree.event;
                
                if( type == 'click' ){
                
                  if( had( 'word-tree-debug') ){
                  
                    this.ui.wordTree.event.clickPrint();
                    
                  }else
                  
                  if( had( 'word-tree-folder') ){
                  
                    this.ui.wordTree.event.clickAddFolder();
                    
                  }
                  
                  
                  
                }
            
            },
            
            clickPrint : ()=>{
              
              let tree = this.ui.wordTree.data.tree;
              
              let arr = [];
              for(let item of tree.data.arr){
                arr.push(JSON.stringify(item));
              }
              
              $lg('10874::bgy',...arr);
              
            },
            
            clickAddFolder : ()=>{
              
              //alert('clickAddFolder');
              
              const $tree = this.ui.wordTree.data.tree;
              
              let arr = [];
              let i = -1;
              
              let cs = new Css();
              
              let item = { 
                id    : $tree.fn.getMaxId()+1,
                up    : -1,
                od    : $tree.fn.getMaxOrder()+1,
                hide  : 0,
                text  : '000',
                type  : 1,
                dir   : 0,
                flex  : 7,
                fold  : 0,
              };
              $tree.data.arr.push(item);
              $tree.item.add([item]);
              
            }
            
          },
          
          tree : {
            
            event : {
              
              onMoveOk : ()=>{
                
                alert('moveOk');
                
              },
              
              onClickText : ()=>{
                
                alert('clickText');
                
              },
              
              onExpand : (id)=>{
                
                alert('onExpand:'+id);
                
              },
              
            }
            
          }
          
        },
        
        mediaBinding : {
          
          data : {
            part    : null,
            pid      : null,
            sid      : null,
            callback : null,
            reset    : ()=>{
              this.ui.mediaBinding.data.num = null;
              this.ui.mediaBinding.data.pid = null;
              this.ui.mediaBinding.data.sid = null;
              this.ui.mediaBinding.data.callback = null;
            }
          },
          // 将文本与多媒体文件绑定
          // sid      : 文本id
          // callback : 将part和pid代入回调执行
          index : async (sid = null, callback = null )=>{
            
            let num = await this.service.data.req('tableOption.getFissionVal','mp3');
            if( num == -1 ) return alert('10316:num == -1');
            
            const css = (()=>{
              
              if(Doc.has(`style[class*='media-binding'`)) return;
              
              Css.root = 'Ajs/media-binding';
              
              new Css('.media-binding',{
                overflow_y   : 'scroll',
                max_height   : '800px',
                width        : '100%',
                margin_top   : '30px',
              })
              new Css('.media-binding *',{
                font_size    : '36px',
                z_index      : 1,
                margin       : '6px',
                margin_left  : '10px',
                margin_right : '10px',
              })//.media-binding *
              new Css('.media-item',{
                border        : '1px solid black',
                border_radius : '10px',
                width         : '96%',
              })//.media-item
              new Css('.media-ok',{
                font_size    : '6vmin',
                padding      : '10px',
              })//.media-ok
              new Css('.media-label',{
                width        : '25%',
                white_space  : 'pre'
              })//.media-label
              new Css('.media-current',{
                width           : '50% !',
                height          : '70px',
              })//.media-current
              new Css('.media-select-ext',{
                width           : '15% !',
              })//.media-select-ext
              new Css('.media-select-box',{
                width           : '95%',
                flex_wrap       : 'nowrap',
                max_height      : '260px',
                overflow_y      : 'scroll',
                border          : '6px solid gray'
              })//.media-select-box
              new Css('.media-select',{
                width           : '96%',
                height          : '70px',
              })//.media-select
              new Css('.media-list-box',{
                width           : '95%',
                flex_wrap       : 'nowrap',
                max_height      : '360px',
                overflow_y      : 'scroll',
                border          : '6px solid gray'
              })//.media-list-box
              new Css('.media-id',{
                width           : '8%',
                text_align      : 'right',
              })//.media-id
              new Css('.media-title',{
                //max_width       : '80%',
                width           : '70%',
                
              })//.media-title
              new Css('.media-size',{
                width           : '20%',
                text_align      : 'right',
                
              })//.media-size
              
              Css.root = 'Ajs';
              
            })()
            
            const htm = (async ()=>{
              
              let html = new Html();
                  html.dom();
                  html.div('.media-binding flex-col-7').as(1)
                        .div(1,'.spread-line media-item flex-row-4').as(0)
                            .span(0,'.spread-btn media-label',`!mp3库`)
                            .button(0,'.spread-btn media-current',`!${num}`)
                            .button(0,'.spread-btn media-select-ext',`!\u25bd`)
                        .div(1,'.spread-line media-select-box flex-col-8 hide').as(2);
                        
              for(let i=0; i<=num; i++){
                  html.button(2,`#media-select-${i}`,'.spread-btn media-select',`!${i}`);
              }
              
              html.div(1,'.media-list-box flex-col-7')
                  .button(1,'.media-item media-ok','!ok');
              
              this.ui.msgbox.fn.show( html.pack() );

            })()
            
            this.ui.mediaBinding.fn.glance(num);
            
            this.ui.mediaBinding.data.num = num;
            
            if( sid )      this.ui.mediaBinding.data.sid = sid;
            if( callback ) this.ui.mediaBinding.data.callback = callback;
            
          },
          
          event : {
            
            click : {
              
              title : (e,ds,dp)=>{
                
                //alert('media-title:'+dp.className);
                
                let dpp = dp.parentElement;
                let act = dpp.querySelector('.yelack');
                if( act ) act.classList.remove('yelack');
                dp.classList.add('yelack');
                let id = ds.id.replace('pid','');
                    id = parseInt( id );
                this.ui.mediaBinding.data.pid = id;
              },
              
              ok : async (e,ds)=>{
                
                
                //alert('media-ok');
                let num      = null;
                let curObj = Doc.api.query('.media-current');
                if( curObj ) num = parseInt( curObj.innerText );
                $lg('11212:num',num,curObj);
                
                const sid      = this.ui.mediaBinding.data.sid;
                const pid      = this.ui.mediaBinding.data.pid;
                const callback = this.ui.mediaBinding.data.callback;
             
                $lg(`10439:pid:${pid},sid:${sid}`);
             
                if( sid && num !== null && pid && typeof callback === 'function' ) {
                  await callback(sid,num,pid);
                };
                
                this.ui.mediaBinding.data.reset();
                
                this.ui.msgbox.fn.hide();
                
              },
              
              ext : (e,ds)=>{
                
                let obj = Doc.api.query('.media-select-box');
                if( !obj ) return;
                
                if(  obj.classList.contains('hide'))
                     obj.classList.remove('hide');
                else obj.classList.add('hide');
                
              },
              
              select : (e,ds)=>{
                
                //alert('media click select');
                
                let id = ds.id.replace('media-select-','');
                
                Doc.api.query('.media-select-ext').click();
                Doc.api.query('.media-current').innerText = id;
                
                this.ui.mediaBinding.fn.glance(id);
                
                
              },
              
            
              
              
            }
            
          },
          
          fn : {
            
            clearAllItem : ()=>{
              
              let items = Doc.api.queryAll('.media-binding .media-pid-item');
              if( !items ) return;
              
              [...items].forEach(elm=>{
                elm.parentElement.removeChild(elm)
              })
              
            },
            
            glance : async (num)=>{
              
              //$lg('11230:glance::bgg');
              
              this.ui.mediaBinding.fn.clearAllItem(num);
              
              
              let rsp = await this.service.data.req('tablePart.glance','mp3',num);
              if( rsp.da.rst == false ) return alert('10319: tablePart.glance  fail');
              //id,title,ext,md5  
              //$log.lgg('11238:glance',JSON.stringify(rsp));
              
              let html = new Html();
                  html.dom('.msg-box .media-binding .media-list-box');
              
              for( let item of rsp.da.dat.arr){
                
                let id    = item[0];
                let title = item[1];
                let MB    = (item[2] / 1024 / 1024).toFixed(2);
                
                //$lg('11247',id,title);
                
                html.div(`#media-item-${id}`,'.media-item media-pid-item flex-row-46').as(0)
                      .span(0,'.media-id',`!${id}`)
                      .span(0,`#pid${id}`,'.media-title',`!${title}`)
                      .span(0,'.media-size',`!${MB}MB`);
                      //.button(0,'.btn','!set')
                
              }
              
              
              
              html.ok();
              
              
            },
            
            
          }
          
          
        },
        
        listen : {
          
          data  :  {
            
              list  : null,
            
              sid   : null,
            
              mp3   : null,
              
              title : null,
              
              num   : null,
              
              action : null,
              
              menu   : [
                [201, '单选', '听音频', '看句子', '选择', '中文', '含义',1], 
                [202, '单选', '听音频', '看句子', '选择', '英文', '拼写',1],
                [211, '单选', '听音频', '看句子', '选择', '英文', '词缀',1],
                [203, '单选', '听音频', '------', '选择', '中文', '含义',1],
                [204, '单选', '听音频', '------', '选择', '英文', '拼写',1],
                [212, '单选', '听音频', '------', '选择', '英文', '词缀',1],
                [205, '拼写', '听音频', '看句子', '补全', '单词', '',    2],
                [206, '拼写', '听音频', '看句子', '拼写', '单词', '',    4],
                [207, '听写', '听音频', '------', '听写', '单词', '',    8],
                [208, '听写', '听音频', '------', '听写', '句子', '',   40],
                [301, '口语', '听音频', '看句子', '复述', '单词', '',    4],
                [302, '口语', '听音频', '看句子', '复述', '句子', '',   12],
                [303, '口语', '听音频', '------', '复述', '单词', '',    4],
                [304, '口语', '听音频', '------', '复述', '句子', '',   20],
              ],
              
              stop   : 0,
              
              skip   : 0,
            
              time   : 0,
            
          },
          
          index : async (sid)=>{
            
            let $data = this.ui.listen.data;
            
            $data.sid = sid;
            
            await this.ui.listen.fn.prepareData(sid);
            
            let css = (()=>{
              
              if(Doc.has(`style[class*='listen-mod-bg']`)) return;
              
              new Css('.sg',{
                color         : `hsl(30,30%,30%)`,
              })//.sg
              new Css('.wr',{
                color         : `hsl(160,50%,30%)`,
              })//.wr
              new Css('.ls',{
                color         : `hsl(30,70%,50%)`,
              })//.ls
              new Css('.cp',{
                color         : `hsl(150,70%,30%)`,
              })//.cp
              new Css('.cn',{
                color         : `hsl(160,30%,50%)`,
              })//.cn
              new Css('.en',{
                color         : `hsl(80,70%,50%)`,
              })//.en
              new Css('.md',{
                color         : `hsl(60,30%,60%)`,
              })//.md
              new Css('.st',{
                color         : `hsl(30,60%,30%)`,
              })//.st
              new Css('.red',{
                color         : `red`,
              })//.red
              new Css('.listen-mod-bg',{
                //background    : `white`,
                background    : `transparent`,
                margin        : '0px',
                padding       : '6px',
                font_size     : '33px',
                //border_radius : '10px',
              })//.listen-mod-bg
              new Css('.listen-index-box',{
                width         : '100%',
                height        : '600px',
                overflow_y    : 'scroll',
              })//.listen-menu-box
              new Css('.listen-index-item',{
                width         : `99% !`,
                height        : `80px !`,
                flex_shrink   : 0,
                z_index       : 1,
                overflow_y    : 'hidden',
              })//.listen-menu-item
              new Css('.listen-mod',{
                text_align    : `left`,
                width         : '85%',
                //height        : '80px !',
              })//.listen-mod
              new Css('.listen-code',{
                text_align    : `center`,
                width         : '15%',
                //height        : '80px !',
              })//.listen-code
            })()
            
            let htm = (()=>{
              
              let $data = this.ui.listen.data;
              
              let codeList = [
                  ['单选',  'sg'],
                  ['拼写',  'wr'],
                  ['听写',  'ls'],
                  ['补全',  'cp'],
                  ['听音频','md'],
                  ['看句子','st'],
                  ['中文',  'cn'],
                  ['英文',  'en']
                ];
                
              let getClaxx = (chn)=>{
                
                for(let item of codeList){
                  if(chn == item[0]) return item[1];
                }
                
                return '';
                
              }
              
              let makeDescBtn = (item)=>{
                let html = '';
                for(let i=1; i<item.length; i++){
                  let a = item[i];
                  let claxx = getClaxx(a);
                  if(i == item.length-1) {
                    claxx = 'red';
                    a += '分';
                  }
                  html += `<span class='listen-mod-bg ${claxx}'>${a}</span>`;
                }
                return html;
              }
              
              let fgm = new Html();
                  fgm.dom();
                  fgm.div('.spread-box listen-index-box flex-col-8').as(1)
                  for(let item of $data.menu){  
                      let html = makeDescBtn(item);
                      //$lg(html);
                      fgm.div(1,'.spread-line listen-index-item flex-row-4').as(2)
                            .button(2,'.spread-btn listen-code',  `!${item[0]}`)
                            .button(2,`#listen-mod-${item[0]}`,'.spread-btn listen-mod',`!${html}`);
                            //.button(2,`#listion-action-${${item[0]}}`,'.spread-btn listen-mod',`!${item[2]}`);
                  }
                  
              this.ui.msgbox.fn.title('');
              this.ui.msgbox.fn.show( fgm.pack() );
                    
            })()
            
            
            Doc.api.query('.btn-time').click();
            
          },
          
          event : {
            
            closeIndex : ()=>{
              
              this.ui.msgbox.fn.hide();
              
            },
            
            clickMenu : (e,ds)=>{
              
              //alert('menu');
              this.ui.msgbox.fn.show();
              
            },
            
            clickItem : async (e,ds)=>{
              
              let $data = this.ui.listen.data;
              
                  $data.stop = 0;
                  $data.skip = 0;
              
              //alert('clickItem');
              this.ui.fn.highlight(e);
              ds.classList.add('yelack');
              
              let idx = ds.id.replace('listen','');
              if( idx ) idx = parseInt( idx );
              
              //let idx = this.ui.listen.fn.getCurrItemId();
              //$lg('10905::idx',idx);
              
              let pg = Doc.api.query('.listen-progress');
              if( pg ) pg.innerText = `${idx}/${this.ui.listen.data.list.length-1}`;
              
              const action = $data.action;
              //this.ui.listen.fn.showBox('.listen-sentence-box',1);
              this.ui.listen.fn.makeSentence( idx, action );
              
              this.ui.listen.fn.showBox('.listen-input-box',0);
              this.ui.listen.fn.showBox('.listen-option-box',0);
              this.ui.listen.fn.makeOption( idx,action );
              
              let mission = [
                'playExample',
                'playItem',
                'playItem',
                'playItem',
              ];
              
              for(let item of mission){
                
                $data.skip = 0;
                if($data.stop) break;
                if($data.skip) continue;
                
                let fn = Reflect.get(this.ui.listen.fn,item);
                if( fn ) await fn(idx);
                
                if($data.stop) break;
                if($data.skip) continue;
                
                
                await Tool.delay(1000);
                
              }
              
              if( [201,202,203,204].includes( action ) ){
                  this.ui.listen.fn.showBox('.listen-option-box',1);
              }else
              if( [205,206,207,208].includes( action ) ){
                  this.ui.listen.fn.showBox('.listen-input-box',1);
              }
              
              //计时，统计回答问题用时多少
              this.ui.listen.data.time = performance.now();
              
              //alert(idx);
              //alert(JSON.stringify(dat));

            },
            
            clickPre : (e,ds)=>{
              
              //alert('clickNext');
              let next = 0;
              let item = this.ui.listen.fn.getCurrItemId();
              if( item === null ) next = 0;
              else if(item === 0) next = this.ui.listen.data.length-1;
              else next -= 1;
              
              if( next < 0) next = this.ui.listen.data.length-1;
              
              let obj = Doc.api.query(`#listen${next}`);
              if( obj ) {
                  obj.click();
                //let next = Doc.api.query(`#listen${currentItem+1}`);
                //if( next ) this.ui.listen.currentItem++;
              }
              
              
            },
            
            clickNext : async (e,ds)=>{
              
              //alert('clickNext');
              
              let nextItem = this.ui.listen.fn.getCurrItemId();
              
              if( nextItem === null ) nextItem = 0;
              else if(nextItem === 0) nextItem++;
              else nextItem++;
              
              if( nextItem > this.ui.listen.data.length-1) nextItem = 0;
              
              let elm = Doc.api.query(`#listen${nextItem}`);
              if( elm ) {
                  elm.click();
                //let next = Doc.api.query(`#listen${currentItem+1}`);
                //if( next ) this.ui.listen.currentItem++;
              }
              
              
            },
            
            clickPlay : (e,ds)=>{
              
              //alert('clickPlay');
              let obj = Doc.api.query('.listen-item-box .yelack')
              if( obj == null ) return;
              let id = obj.id.replace('listen','');
              if( id === null ) return;
              id = parseInt(id);
              this.ui.listen.fn.playItem(id);
              
            },
            
            clickSkip : (e,ds)=>{
              
              //alert('stop');
              this.audio.pause();
              this.ui.listen.data.skip = 1;
              let event = new CustomEvent("playOneTimesDone", null);
              document.dispatchEvent(event);
              
            },
            
            clickStop : (e,ds)=>{
              
              //alert('stop');
              this.audio.pause();
              this.ui.listen.data.stop = 1;
              let event = new CustomEvent("playOneTimesDone", null);
              document.dispatchEvent(event);
              
            },
            
            clickPlayExample : (e,ds)=>{
              
              //alert('clickPlay');
              let obj = Doc.api.query('.listen-item-box .yelack')
              if( obj == null ) return;
              let id = obj.id.replace('listen','');
              if( id === null ) return;
              id = parseInt(id);
              
              
              this.ui.listen.fn.playExample(id);
              
            },
            
            clickFinish : (e,ds)=>{
              
              alert('inputFinish');
              
            },
            
            clickTitle : async (e,ds)=>{
              
              //alert('Progress');
              let $data = this.ui.listen.data;
              
              let bExt = Doc.api.query('.btn-ext');
              if( bExt ) bExt.click();
              
              //open article content
            
              let sid = $data.sid;
              $lg('11127:sid',sid);
              
              await this.ui.article.content.load(sid);
              
              let idx = this.ui.listen.fn.getCurrItemId();
              if( idx == null ) idx = 0;
              //return;
              let dat = $data.list[idx];
              $log.lgg('11122',idx,JSON.stringify(dat),Array.isArray(dat));
              let lidx = dat[1];
              
              this.ui.article.tool.fn.locateToLine(lidx);
              
              
              
            },
            
            clickProgress : (e,ds)=>{
              
              //alert('Progress');
              let ibox = Doc.api.query('.listen-item-box');
              
              if( ibox == null ) return;
              
              if( ibox.classList.contains('hide')){
                  //ibox.style.animation = 'item-box-spread 1s ease';
                  this.ui.listen.fn.showBox('.listen-item-box');
              }else{
                  //ibox.style.animation = 'item-box-shrink 1s ease';
                  this.ui.listen.fn.showBox('.listen-item-box',0);
              }
              
            },
            
            ClickAnswerOption : async (e,ds)=>{
              
              //alert(ds.className);
              //this.ui.fn.highlight(e);
              const $data = this.ui.listen.data;
              
              let has = (str)=>{ return ds.classList.contains(str) };
              
              let id = this.ui.listen.fn.getCurrItemId();
              let dat = this.ui.listen.data.list[id];
              
              let sid  = dat[0];
              let lidx = dat[1];
              let widx = dat[2];
              let word = dat[3];
              
              
              
              let dpp = ds.parentElement.parentElement;
              if( dpp ) {
                let obj =  dpp.querySelector('.yelack');
                if( obj ) obj.classList.remove('yelack');
              }
              
              let markVal = has('listen-right-answer');
              if(!markVal) ds.classList.add('listen-wrong-answer');
              this.ui.listen.fn.addMark( markVal );
              
              ds.classList.add('yelack');
              await Tool.delay(1000);
              this.ui.listen.fn.enableRightAnswerStyle(1);
              
              let memo = '听力-单词-单选题';
              let val = 1;
              
              if(has('listen-right-answer')){
                
              }else{
                
                await Tool.delay(500);
                
                val = -1;
                
              }
              
              this.ui.listen.fn.removeNotRightAnswer();
              this.ui.listen.fn.showRightAnswer(word);
              
              let ms = parseInt( performance.now() - this.ui.listen.data.time ) ;
              let action = this.ui.listen.data.action;
              await this.service.data.req('tableActivity.add',sid,lidx,widx,word,action,val,ms);
              
              this.ui.listen.fn.saveProgress(sid,action,id);
              
              await Tool.delay(3000);
            
              
              let next = Doc.api.query('.listen-next');
              if( next ) next.click();
            },
            
            ShowOption : (e,ds)=>{
              
              //alert('ShowOption');
              this.ui.listen.fn.showBox('.listen-option-box');
              
              
            },
            
            ShowItem : (e,ds)=>{
              
              //alert('ShowItem');
              this.ui.listen.fn.showBox('.listen-item-box');
              
            },
            
            ShowInput : (e,ds)=>{
              
              //alert('ShowInput');
              this.ui.listen.fn.showBox('.listen-input-box');
              
            },
            
            ShowRightAnswer : (e,ds)=>{
              
              //alert('ShowRightAnswer');
              this.ui.listen.fn.showRightAnswer();
              
            },
            
            
            MarkUnknow : async (e,ds)=>{
              
              //alert(ds.className);
              //this.ui.fn.highlight(e);
              let has = (str)=>{ return ds.classList.contains(str) };
              
              let id = this.ui.listen.fn.getCurrItemId();
              let dat = this.ui.listen.data.list[id];
              $lg('11097',...dat);
              let sid  = dat[0];
              let lidx = dat[1];
              let widx = dat[2];
              let word = dat[3];
              
              let pg = Doc.api.query('.listen-progress');
              if( pg ) pg.innerText = `${id}/${this.ui.listen.data.length}`;
        
              
              let dpp = ds.parentElement.parentElement;
              if( dpp ) {
                let obj =  dpp.querySelector('.yelack');
                if( obj ) obj.classList.remove('yelack');
              }
              
              //ds.classList.add('yelack');
              await Tool.delay(500);

              this.ui.listen.fn.showRightAnswer(word);
              this.ui.listen.fn.enableRightAnswerStyle(1);
              
              let memo = '完全听不懂';
              let val = 0;

              this.service.data.req('tableAware.add',sid,lidx,widx,word,val,memo);
              await Tool.delay(3000);

              let next = Doc.api.query('.listen-next');
              if( next ) next.click();
            },
            
            ShowInfo :  (e,ds)=>{
              

              let id  = this.ui.listen.fn.getCurrItemId();
              if( id == null ) id = 0;
              
              let dat = this.ui.listen.data.list[id];
              
              let sid  = dat[0];
              let lidx = dat[1];
              let widx = dat[2];
              let word = dat[3];
              
              let txt = `
                sid  : ${sid}
                lidx : ${lidx}
                widx : ${widx}
                word : ${word}
              `;
              
              alert(txt);
              
            },
            
          },
          
          mod : {

            index :  async (action)=>{
              //alert('id:'+id);;
              $lg('10720::listen.index.start::bgg',performance.now());
              let $data = this.ui.listen.data;
              
              $data.action = action;
              //let num = $data.list.length;
              //$lg('listen::bgy',...this.ui.listen.data);
            
              //await this.dat.fn.buildObjLrcAll(sid,null);
              //await this.ui.tabMenu.tabs.song.load(sid);
              let sid = $data.sid;
              let lastItem = await this.service.data.req('tableTag.listenProgress.getLastItem',sid,action);
              $lg('12097::listen:lastItem::bgy',lastItem);
              
              let partArr = [];
              
              if( action == 205 ){
                
                //partArr = await this.dic.webman.request('tableCut.getPart',) 
                
              }
            
              const panel = {
                sts : [201,202,205,206],
                inp : [205,206,207,208],
                opt : [201,202,203,204]
              }
            
              let removePart = (arr,...queryArr)=>{
                //$lg(11240,arr);
                if( !arr.includes(action) ){
                  for(let queryStr of  queryArr){
                    let obj = Doc.api.query(queryStr);
                    if( obj ) obj.parentElement.removeChild(obj);
                  }
                }
              }
            
              let css = (()=>{
                
                if(Doc.has(`style[class*='listen-control']`)) return;
                  
                Css.root = 'Ajs/listen';
                
                let cs = new Css();
                
                new Css('.listen-box',{
                  width              : '99%',
                  background         : cs.rgba.white(3,1),
                  border_radius      : '10px',
                })//.listen-box
                new Css('.listen-caption-box',{
                  //overflow_x         : 'scroll',
                
                  overflow           : 'visible !',
                  
                })//.listen-caption-box
                new Css('.listen-x-box',{
                  //overflow_x         : 'scroll',
                  margin             : '2px !',
                  padding            : '3px !',
                  
                  
                })//.listen-x-box
                new Css('.listen-title-box',{
                  //overflow_x         : 'scroll',
                  width              : '65%',
                  overflow_x         : 'scroll',
                  
                })//.listen-title-box
                new Css('.listen-pg-box',{
                  //overflow_x         : 'scroll',
                  width              : '15%',
                })//.listen-pg-box
                new Css('.listen-menu-box',{
                  //overflow_x         : 'scroll',
                  width              : '5%',
                })//.listen-menu-box
                new Css('.listen-title',{
                  //overflow_x         : 'scroll',
                  min_width            : '99%',
                  white_space          : 'nowrap',
                  background           : cs.rgba.white(3,1),
                  border_radius        : '10px',
                  font_size            : '30px !',
                  padding              : '10px',
                })//.listen-title
                new Css('.listen-progress',{
                  //overflow_x         : 'scroll',
                  width              : '99%',
                })//.listen-progress
                new Css('.listen-menu',{
                  //overflow_x         : 'scroll',
                  width              : '99%',
                })//.listen-menu
                new Css('.listen-close',{
                  width              : '70px !important',
                  border_radius      : '10px',
                  //font_size          : '4vmin',
                  //border             : '1px solid black'
                })//.listen-close
                new Css('.listen-item-box',{
                  
                  position           : 'absolute !',
                  z_index            : 10,
                  top                : '100px',
                  right              : '10px',
                  
                  max_height         : '260px',
                  flex_wrap          : 'wrap',
                  overflow_y         : 'scroll',
                  
                  background         : cs.rgba.white(6,1),
                  border             : '6px solid grey !',
                  border_radius      : '10px',
                  padding            : '16px',
                  filter             : 'drop-shadow 0 0 10px yellow',
                  
                })//.listen-item-box
                new Css('.listen-item',{
                  min_width          : '70px !important',
                  width              : '100px !important',
                  //border_radius      : '50%',
                  
                })//.listen-item
                new Css('.listen-control-box',{
                  width              : '15%',
                  flex_grow          : 1,
                })//.listen-control-box
                new Css('.listen-control',{
                  width              : '96% !important',
                  flex_grow          : 1,
                })//.listen-control
                new Css('.listen-input-answer',{
                  text_align         : 'left',
                  font_size          : '26px',
                  height             : '160px',
                  white_space        : 'pre-wrap',
                  padding            : '16px',
                })//.listen-input-answer
                new Css('.listen-next,.listen-pre',{
                  flex_grow          : '1.5 !important',
                })//.listen-next
                
                
                const ani = (()=>{
                  cs.style('Ajs/listen/animation')
                    .kf('item-box-spread')
                        .pc(  0).width('0px').height('0px')
                        .pc( 50).width('50%').height('auto')
                        .pc(100).width('99%').height('auto')
                    .kf('item-box-shrink')
                        .pc(  0).width('99%').height('auto')
                        .pc( 50).width('50%').height('auto')
                        .pc(100).width('0px').height('0px')
                    .ok();
                })()
                
                /*
                new Css('.listen-answer-word',{
                  background         : 'yellow',
                })//.listen-answer-word
                
                new Css('.listen-answer-a',{
                  order              : 1,
                })//.listen-answer-a
                new Css('.listen-answer-b',{
                  order              : 2,
                })//.listen-answer-b
                new Css('.listen-answer-c',{
                  order              : 3,
                })//.listen-answer-c
                new Css('.listen-answer-d',{
                  order              : 4,
                })//.listen-answer-d
                */
                Css.root = 'Ajs';
                
              })()
              
              let htm = (()=>{
                
                let lbox = Doc.api.query('.listen-box');
                if( lbox ) lbox.parentElement.removeChild(lbox);
                
                let menuIdx = action - 201;
                let op = $data.menu[menuIdx][4];
                let ob = $data.menu[menuIdx][5];
                let title = `${$data.title}-${action}-${op}-${ob}`;
                
                let html = new Html();
                html.dom('.spread-box')
                    .div('.listen-box  flex-col-8').as(1)
                        .div('.spread-line  listen-caption-box',1).as(2)
                            .div('.spread-line listen-x-box listen-title-box',2).as(0)
                                .span('.listen-title',`!${title}`,0)
                            .div('.spread-btn listen-x-box  listen-pg-box',2).as(0)
                                .button('.spread-btn listen-progress',`!${$data.list.length}`,0)
                                .div('.listen-item-box hide flex-row-7',0).as(3)
                            .div('.spread-btn listen-x-box listen-menu-box',2).as(0)
                                .button('.spread-btn listen-menu',`!\u2261`,0)
                        .div('.spread-line  listen-control listen-quick-menu flex-row-5',1).as(2)
                            .div('.spread-line  listen-control-box flex-row-5',2).as(4)
                                .button('.spread-btn listen-control listen-show-input',       `!\u25ad`,4)
                                //.button('.spread-btn listen-control listen-show-item',        `!\u2780`,4)
                                .button('.spread-btn listen-control listen-show-option',      `!\u2254`,4)
                                .button('.spread-btn listen-control listen-show-right-answer',`!\u2611`,4)
                                .button('.spread-btn listen-control listen-show-info',        `!\u2148`,4)
                                .button('.spread-btn listen-control listen-show-text',        `!\u26b6`,4)
                                .button('.spread-btn listen-control listen-mark-unknow',      `!\u2047`,4)
                        .div('.spread-line  listen-sentence-box flex-col-8',1).as(6)
                        .div('.spread-line  listen-control flex-row-5',1).as(2)
                            .div('.spread-line  listen-control-box flex-row-5',2).as(4)
                                .button('.spread-btn listen-control listen-pre',  `!\u2264`,4)
                                .button('.spread-btn listen-control listen-play', `!\u25b6`,4)
                                .button('.spread-btn listen-control listen-play-example',`!\u25b7`,4)
                                .button('.spread-btn listen-control listen-skip', `!\u00bb`,4)
                                .button('.spread-btn listen-control listen-stop', `!\u25fe`,4)
                                .button('.spread-btn listen-control listen-next',`!\u2265`,4)
                        .div('.spread-line  listen-input-box flex-row-7 hide',1).as(2)
                            .textarea('.spread-btn listen-input-answer',2)
                            .button('.spread-btn listen-input-finish',`!\u25e3`,2)
                        .div('.spread-line  listen-option-box flex-col-8 hide',1);
                let i = -1;
                for( let item of $data.list){
                  i++;
                  let ext_class = '';
                  if(i == lastItem) ext_class = 'yelack';
                  html.button(`#listen${i}`,`.spread-btn listen-item ${ext_class}`,`!${i}`,3);
                }
                html.ok();
                
                removePart(panel.sts,'.listen-sentence-box');
                removePart(panel.inp,'.listen-input-box','.listen-show-input');
                removePart(panel.opt,'.listen-option-box','.listen-show-option');
                
                this.ui.listen.fn.adjInputStyle( action );
                
                //$lg('10848::listen:index:done::bgg',performance.now());
                //this.ui.msgbox.fn.show( html.pack() );
                
              })()
              
              let extBtn = Doc.api.query('.btn-ext')
              if( extBtn && !extBtn.classList.contains('yelack')) {
                extBtn.click();
              }
            },

          },
          
          fn : {
            
            prepareData : async (sid)=>{
              
                document.addEventListener('buildObjLrcAllDone',(e)=>{
                  //$lg('10721::buildObjLrcAllDone::bgg',performance.now());
                },0)
                this.dat.fn.buildObjLrcAll(sid);
                /*
                const mp3 = await this.service.data.req('tableMp3.getPath',sid);
                //$log.lgg(JSON.stringify(mp3));
                if( mp3.da.rst == false || mp3.da.dat.arr.length == 0 ) return alert('10691::error:该文单没有音频文件 ');
                this.ui.listen.data.mp3 = mp3.da.dat.arr[0][0];
                await this.audio.load(this.ui.listen.data.mp3);
                */
                //$lg('10703:mp3::bgy',this.ui.listen.mp3,performance.now());
                
                this.ui.msgbox.fn.title('正在加载音频');
                this.ui.msgbox.fn.show();
                
                await this.ui.tabMenu.tabs.song.load(sid);
                
                
                const title = await this.service.data.req('tableSong.getName',sid);
                this.ui.listen.data.title = title;
                
                this.ui.msgbox.fn.title('正在加载单词数据');
                this.ui.msgbox.fn.show();
                //列出当前文章所有不认识的单词
                this.ui.listen.data.list = await this.service.data.req('tableActivity.listUnknowBySid',sid);
                let list = this.ui.listen.data.list;
                
                //$log.lgg('11792',JSON.stringify(list));
                
                if( list == null ) alert('10691::error:\n数据库没有列出陌生单词');
                if( list.length == 0 ) alert(`这篇文章《${title}》没有生词`);
                //sid,lidx,idx,word,start,end, did,meaning
                //$lg('11296',this.ui.listen.data.list.length);
                return;
                
              
            },
            
            makeOption : async ( id, action = 201 )=>{
              
              let t1 = performance.now();
              
              let dat = this.ui.listen.data.list[id];
              let [sid,lidx,idx,word,start,end,did,meaning] = dat;
              //$lg('11161',...dat);
              //let target = null;
              //if(sid == 52 && lidx == 246 && idx == 18) target = 1;
              //firstLetter
              let firstLetter = word.charAt(0);
              
              let wordProp = '';
              let m = /(adj|v|vt|n|adv|prep|conj)\..+/.exec(meaning);
              if( m ){
                //alert( m[1] );
                wordProp = m[1];
                
              }
              
              //生成随机id
              let rnd = (min,max)=>{
                let nums = [];
                for(let i=0; i<3; i++){
                  nums[i] = min + 1 + Math.floor(Math.random()*max);
                }
                return nums
              }
              
              
              //得到一个单词列表，从表中取以下两项作为结果输出
              // 最小id
              // 总量
              let sqlText1 = ()=>{
                return `
                  attach database '../mod/dict.sqlite.db' as 'dict';
                  select min(id) as start,count(*) as num
                  from (
                    select id,word,meaning
                    from wd
                    where score = 0 
                        and word like '${firstLetter}%' 
                        and id <> ${did} 
                    limit 1000
                  )
                  where meaning like '${wordProp}%'
                `;
              }
              //$log.lgg('11203',sqlText1());
              
              let rsp = await this.sql.que(sqlText1());
              let arr = rsp.da.dat.arr[0];
              //$lg(`10901:sqlText1::bgg`,performance.now()-t1);
              //if(target)
              //$lg('10862::bgb',...arr);

              //根据最小id和总量两个参数生成目标单词id
              let r = rnd(...arr);
              
              //依据随机单词id选择单词词义作为候选答案
              let sqlText2 = ()=>{
                return `
                  attach database '../mod/dict.sqlite.db' as 'dict';
                  select id,word,meaning 
                  from wd 
                  where id in(${r[0]},${r[1]},${r[2]})
                `
              };
              
              //if(target)$log.lgg('10897',sqlText2());
                  
              rsp = await this.sql.que(sqlText2());
              //if(target)
              //$lg('10862::bgy',did,word,meaning,...rsp.da.dat.arr);
              //alert(sqlText2());
              //$log.lgg('10848',word,meaning,sqlText2() );
              
              //0-3
              let rightAnswerIdx    =  0 + Math.floor(Math.random()*4);
              let rightAnswerLetter = String.fromCharCode(65+rightAnswerIdx);
              let answerArr    = [];
              
              let colIdx = 2;
              let colData = meaning;
              if( [201,203].includes(action) ) {
                colIdx = 2;
                colData = meaning;
              }else
              if( [202,204].includes(action) ) {
                colIdx = 1;//word
                colData = word;
              }
              
              for(let arr of rsp.da.dat.arr){
                let val = arr[colIdx].replace(/\(.+\)/ig,"");
                //$lg('11239',arr[2],mn);
                answerArr.push( val );
              }
              colData = colData.replace(/\(.+\)/ig,"");
              answerArr.push(colData);
              if( rightAnswerIdx !== 3 ){
                let temp = answerArr[rightAnswerIdx];
                answerArr[rightAnswerIdx] = colData;
                answerArr[3] = temp;
              }
              
              //$lg(`10983:data ready:${performance.now()-t1}ms::bgb`);
              
              //$lg('10862:rightAnswerIdx::bgo',rightAnswerIdx);
              
              //return alert(rightAnswerLetter);
              
              let css = (()=>{
                
                if(Doc.has(`style[class*='listen-answer']`)) return;
                
                Css.root = 'Ajs/listen';
                
                let cs = new Css();
                
                new Css('.listen-answer-idx',{
                  width            : '6% !important',
                })//.listen-answer-idx
                new Css('.listen-answer',{
                  width            : '90% !important',
                  text_overflow    : 'ellipsis',
                  white_space      : 'nowrap',
                  font_size        : '36px !',
                })//.listen-answer
                new Css('.listen-right-answer',{
                  color            : 'white !important',
                  background       : 'lightgreen !important',
                  
                })//.listen-right-answer
                new Css('.listen-wrong-answer',{
                  color            : 'white !important',
                  background       : 'lightpink !important',
                  
                })//.listen-wrong-answer
                new Css('.listen-answer-unknow',{
                  color            : 'white !important',
                  background       : `${cs.rgba.white(9,1)} !important`,
                  
                })//.listen-answer-unknow
                
                Css.root = 'Ajs';
                
              })()
              
              this.ui.listen.fn.enableRightAnswerStyle(0);
              
              
              //生成候选答案按钮
              let htm = (()=>{
                
                //let rightClass = `listen-right-answer`;
                
                [...Doc.api.queryAll('.listen-answer-item')].forEach(elm=>{
                  elm.parentElement.removeChild(elm)
                })
                
                let html = new Html();
                html.dom('.listen-option-box');
                      //.div(`.spread-line listen-answer-item flex-row-4`).as(1);
                          //.span(`.spread-btn listen-answer-idx`,1)
                          //.button(`.spread-btn listen-answer listen-answer-unknow`,`!完全听不懂`,1);
                          
                for( let i = 0; i < answerArr.length; i++){
                    let lowerLetter = String.fromCharCode(97+i);
                    let upperLetter = String.fromCharCode(65+i);
                    let claxx = i == rightAnswerIdx ? `listen-right-answer` : '';
                    html.div(`.spread-line listen-answer-item flex-row-4`).as(1)
                        .span(`.spread-btn listen-answer-idx`,`!${upperLetter}`,1)
                        .button(`.spread-btn listen-answer listen-answer-${lowerLetter} ${claxx} `,`!${answerArr[i]}`,1)
                }
                html.ok();
              })()
              
              return 1;
              //$lg('10983:ms::bgo',performance.now()-t1);
              
            },
            
            saveProgress :  (sid,action,item)=>{
              
              return this.service.data.req('tableTag.listenProgress.save',sid,action,item);
              
            },
            
            makeSentence : async (id, action = 201)=>{
              
              let t1 = performance.now();
              
              //let id  = this.ui.listen.fn.getCurrItemId();
              //if( id == null ) id = 0;
              let item = this.ui.listen.data.list[id];
              let [sid,lidx,idx,word,start,end,did,meaning] = item;
              //$lg('11161',...dat);
              let wordArr = this.objLrc.lines[lidx].words;
              
              
              let css = (()=>{
                
                if(!Doc.has(`style[class*='listen-word']`)){;
                
                  Css.root = 'Ajs/listen';
                  
                  let cs = new Css();
                  
                  
                  new Css('.listen-sentence',{
                    flex_wrap        : 'wrap',
                    overflow_y       : 'scroll',
                    margin           : '6px',
                    padding          : '6px',
                    max_height       : '160px !',
                  })//.listen-sentence
                  new Css('.listen-word',{
                    color            : 'black',
                    background       : `transparent`,
                    border           : '0px solid black',
                    font_size        : '30px',
                    margin_left      : '10px',
                    padding          : '3px',
                  })//.listen-word
                  
                }
                
                this.ui.listen.fn.changeHotWordStyle(action);
                
                Css.root = 'Ajs';
                
              })()

          
              let htm = (()=>{
                
                //let rightClass = `listen-right-answer`;
           
                [...Doc.api.queryAll('.listen-sentence')].forEach(elm=>{
                  elm.parentElement.removeChild(elm)
                })
                
                let html = new Html();
                html.dom('.listen-sentence-box')
                      .div(`.listen-sentence flex-row-4`).as(1);
                      //.div(`.spread-line listen-answer-item flex-row-4`).as(1);
                          //.span(`.spread-btn listen-answer-idx`,1)
                          //.button(`.spread-btn listen-answer listen-answer-unknow`,`!完全听不懂`,1);
                          
                for( let i = 0; i < wordArr.length; i++){
                    let obj  = wordArr[i];
                    let word = obj.word;
                    let target = i == idx ? 'listen-hot-word' : '';
                    let num = 2;
                    if( i == idx && [205].includes(action) ){
                      word = word.substr(0,word.length-num) + '--';
                    }else
                    if( i == idx && [206].includes(action) ){
                      word = '-'.repeat(word.length);
                      num = word.length;
                    }
                    html.span(`.listen-word ${target}`,`!${word}`,1);
                    if( i == idx && [205,206].includes(action) ){
                      html.span(`.listen-word-length ${target}`,`!${num}`,1);

                    }
                    
                        
                }
                html.ok();
              })()
              
              //let sbox = Doc.api.query('.listen-sentence-box');
              //if( sbox ) sbox.classList.remove('hide');
              //$lg('10983:ms::bgo',performance.now()-t1);
              
              return;
              
            },
          
            addMark : ( val = 1 )=>{
              
              let css = (()=>{
                
                if(Doc.has(`style[class*='listen-mark']`)) return;
                
                new Css('.listen-mark',{
                  
                  font_size     : '10vmin',
                  position      : 'absolute',
                  top           : '-30px',
                  right         : '60px',
                  background    : 'transparent',
                  color         : 'orange',
                  
                })
                
              })()
              
              let htm = (()=>{
                
                let str = '.listen-wrong-answer';
                let clazz = 'listen-mark listen-wrong-mark';
                let text  = '\u2716';
                
                if( val ) {
                  str = '.listen-right-answer';
                  clazz = 'listen-mark listen-right-mark';
                  text  = '\u2714';
                }
                let obj = Doc.api.query(str);
                
                if( !obj ) return;
                
                let tar = obj.parentElement;
                
                let html = new Html();
                html.dom(tar)
                      .span(`.${clazz}`,`!${text}`)
                    .ok();
              })()
              
            },
          
            showBox : (queryStr, val = null)=>{
              
              let obj = Doc.api.query(queryStr);
              if( obj ){
                if( val === null ){
                  if(obj.classList.contains('hide')){
                    obj.classList.remove('hide');
                    if(queryStr == '.listen-input-box'){
                      Doc.api.query('.listen-input-answer').focus();
                    }
                  }else{
                    obj.classList.add('hide')
                  }
                }else
                if( val === 1){
                  obj.classList.remove('hide')
                  if(queryStr == '.listen-input-box'){
                    Doc.api.query('.listen-input-answer').focus();
                  }
                }else
                if( val === 0){
                  obj.classList.add('hide')
                }
              }
              
            },
            
            showRightAnswer : (word)=>{
              
              if(word == undefined ){
                
                let id = this.ui.listen.fn.getCurrItemId();
                let dat = this.ui.listen.data.list[id];
                //$lg('11097',...dat);
                /*let sid  = dat[0];
                let lidx = dat[1];
                let widx = dat[2];*/
                word = dat[3];
                
              }
              
              //$lg('11342',word);
              let obj =  document.querySelector('.listen-option-box .yelack');
              if( obj ) obj.classList.remove('yelack');
              
                  obj =  document.querySelector('.listen-option-box .listen-right-answer');
              if( obj ) {
                obj.classList.remove('yelack');
                let html = new Html();
                html.dom(obj.parentElement).before()
                      .div(`.spread-line listen-answer-item flex-row-5`).as(1)
                          .span(`.spread-btn listen-answer-idx`,1)
                          .button(`.spread-btn listen-answer yelack`,`!${word}`,1)
                      .ok();
              }
              
              this.ui.listen.fn.enableRightAnswerStyle(1);
              
              
              
            },
            
            showText  : ()=>{
              
              let id  = this.ui.listen.fn.getCurrItemId();
              if( id == null ) id = 0;
              let dat = this.ui.listen.data.list[id];
              let lidx = dat[1];
              alert(this.objLrc.getLineText(lidx));
              
            },
            
            removeNotRightAnswer : ()=>{
              
              let elms =  document.querySelectorAll('.listen-option-box .listen-answer');
              if( elms ) {
                for( let elm of elms){
                  if(!elm.classList.contains('listen-right-answer')){
                    elm.parentElement.parentElement.removeChild(elm.parentElement);
                  }
                }
              }
            },
            
            enableRightAnswerStyle : (val)=>{
              
              let styleElm = Doc.api.query(`style[class*='listen-right-answer']`);
              if( styleElm ) {
                
                if( val == 1) styleElm.disabled = false;
                else styleElm.disabled = true;
                
              }
              
            },
            
            playItem : (idx)=>{
              
              return new Promise((ok)=>{
                
                document.addEventListener('playOneTimesDone',()=>{
                  ok();
                },0)
                try{
                  let dat = this.ui.listen.data.list[idx];
                  
                  let timeArr = [dat[4]/1000,dat[5]/1000];
                  //$lg('11398',...timeArr);
                  this.loopDur = timeArr;
                  //thiz.ui.loopAB.replace(timeArr);
                  //Doc.api.query('.audio').currentTime = timeArr[0];
                  this.myAudio.currentTime = timeArr[0];
                  this.flag_RepeatOnlyOneTimes = 1;
                  if(this.myAudio.paused) this.audio.play();
                }catch(e){
                  
                  $lg('11406::error::bgo',e.message())
                }
              });
              
            },
            
            playExample : (idx)=>{
              
              return new Promise((ok)=>{
                
                document.addEventListener('playOneTimesDone',()=>{
                  ok();
                },0)
                
                let dat = this.ui.listen.data.list[idx];
                
                let lidx = dat[1];
                
                let timeArr = this.objLrc.getStsTime(lidx);
                this.loopDur = timeArr;
                //thiz.ui.loopAB.replace(timeArr);
                //Doc.api.query('.audio').currentTime = timeArr[0];
                this.myAudio.currentTime = timeArr[0];
                this.flag_RepeatOnlyOneTimes = 1;
                if(this.myAudio.paused) this.audio.play();
              });
              
            },
            
            getCurrItemId : ()=>{
              
              let obj = Doc.api.query('.listen-item-box .yelack');
              if( obj ){
                
                let id = obj.id.replace('listen','');
                if( id ) {
                  id = parseInt(id);
                  //$lg('11433::getCurrItemId::id::bgy',id);
                  return id;
                }
                
              }
              
              return null;
              
            },
            
            changeHotWordStyle : ( action )=>{
              
                if(Doc.has(`style[class*='listen-hot-word']`)){
                  let targetStyle = Doc.api.query(`style[class*='listen-hot-word']`);
                  //$lg(11697,'targetStyle:',typeof targetStyle);
                  if( targetStyle ) targetStyle.parentElement.removeChild(targetStyle);
                }
                
                let hotWordColor = 'black !';
                
                if( [201,203].includes(action) ){
                  hotWordColor = 'black !';
                }else
                if( [202,204].includes(action) ){
                  hotWordColor = 'yellow !';
                }
                
                
                Css.root = 'Ajs/listen';
                
                new Css('.listen-hot-word',{
                  color            : hotWordColor,
                  background       : `yellow !`,
                  border           : '2px solid black !',
                  border_radius    : '6px !',
                  font_size        : '36px',
                  min_height       : '40px !',
                  padding_left     : '10px !',
                  padding_right    : '10px !',
                  
                })//.listen-hot-word
                
                Css.root = 'Ajs';
              
            },
            
            adjInputStyle : ( action )=>{
              
              let inp = Doc.api.query('.listen-input-answer');
              if( !inp ) return;
              
              if([205,206,207].includes(action)){
                // 单词
                //inp.style.height = '60px';
                inp.style.textAlign = 'center';
              }else
              if([208].includes(action)){
                // 句子
                //inp.style.height = '160px';
                inp.style.textAlign = 'left';
              }
              
            }
            
          },
          
        },
        
        msgbox : {
          
          htm : ()=>{
            let hide = (e)=>{
              this.ui.msgbox.fn.hide();
              return;
            }
            let minify = (e)=>{
              //this.ui.msgbox.fn.minify();
              return;
            }
            let h = new Html();
            h.dom('body')
              .div('.msg-box hide').top()
                  .div('.msg-title').as(1).on.click(hide,0)
                      .div('.msg-tit',1)
                      //.div('.msg-btn msg-btn-hide',`!--`,1).on.click(hide,0)
                      .div('.msg-btn msg-btn-close',`!x`,1).on.click(hide,0)
                  .div('.msg-cont')
              .ok()
          
            return this.ui.msgbox;
          },
          
          css : ()=>{
            if(Doc.api.query('.cssMsgBox'))return this.ui.msgbox;
            let cs = new Css();
            cs.style('cssMsgBox')
            .slt('.msg-box')
                .flex.col.p(8050)
                .f.abs().ds()
                .a.wh('90%','auto')
                  .max.h('1450px')
                  .pad('10px')
                  .bor('6px solid black')
                  .bord.rad('16px')
                  .ovfl.y.scl()
                  .bg(cs.rgba.white(3,1))
                  .ds()
            .slt('.msg-cont')
                .f.rel().fs('4vmin').ds()
                .a.wh('96%','90%')
                  //.max.h('750px')
                  .marg.bot('20px')
                  .ovfl.y.scl()
                  .bg( cs.rgba.white(3,1) )
                .ds()
            .slt('.msg-title')
                .margin_bottom('20px')
                .flex.row.p(46)
                .f.rel().fs('5vmin').ds()
                .a.wh('93%','70px')
                  .tr('10px','20px')
                  
                  //.bg(cs.rgba.white(6,0.9))
                .ds()
            .slt('.msg-tit')
                .f.rel().fs('5vmin').ds()
                .padding_bottom('20px')
            .slt('.msg-btn')
                .f.rel().fs('5vmin').tac().ds()
                .a.wh('70px','99%')
                  .bg(cs.rgba.white(10,0.9))
                  .clr('black')
                  .ds()
            .slt('.hide')
                .a.dsp.no().ds()
            .slt('.show')
                .a.dsp.flx().ds()
            .ok();
            return this.ui.msgbox;
          },
          
          fn : {
            
            show : (...args)=>{
              let t = undefined;
              if(args) t = typeof(args[0]);
              if( t == 'object'){
                this.ui.msgbox.fn.clean();
                let cont = Doc.api.query('.msg-cont');
                    cont.innerHTML = '';
                    cont.appendChild(args[0]);
              }
              let box = Doc.api.query('.msg-box');
                  box.classList.remove('hide');
                  box.classList.add('show');
                  box.style.zIndex = 100;
              return this.ui.msgbox;
            },
            
            title : (str)=>{
              
              let obj = Doc.api.query('.msg-tit');
              if( obj ){
                
                obj.innerHTML = str;
                
              }
              
            },
            
            hide : ()=>{
              let box = Doc.api.query('.msg-box');
                  box.classList.remove('show');
                  box.classList.add('hide');
                  box.style.zIndex = 0;
                  box.style.top = 'auto';
                  box.style.height = 'auto';
                  box.style.width = '90%';
                  
              return this.ui.msgbox;
            },
            
            clean : ()=>{
              let box = Doc.api.query('.msg-cont');
                  box.innerHTML = '';
                  
              return this.ui.msgbox;
            },
            
            
            
          }
          
        },
        
        fn : {
          
            /*addAB : (timeArr)=>{
                
                //let time = aud.currentTime;
                for(let idx=0; idx<timeArr.length; idx++){
                    this.loopDur[idx] = timeArr[idx];
  
                    this.ui.loopAB.setText(timeArr[idx],String.fromCharCode(idx+97));
                    
                    let pc = timeArr[idx] / this.dur;
                    
                    this.ui.range2.updatePos(pc,idx+1);
                }
                
            },*/
            
            highlight : (e)=>{
                
              let ds = e.target;
              
              [...ds.parentElement.children].forEach((elm)=>{
                elm.classList.remove('yelack');
              })
              
              if( ds.classList.contains('yelack') ) 
                  ds.classList.remove(yelack);
              else 
                  ds.classList.add('yelack');
          

            },
            
            turn   : (anyStr)=>{
              //$lg('ajs::2352::dsp');
              let objs = Doc.api.queryAll(anyStr);
              if(objs == null) return;
              objs.forEach((obj)=>{
                //if(obj.className.indexOf('AB-list-box')>-1)$lg('269::className::bgo',obj.className);
                if(obj.classList.contains(`line-hide`))obj.classList.remove(`line-hide`);
                else obj.classList.add(`line-hide`);
              })
          },
          
            obj    : ( anyStr, show = 1, hide = 1 )=>{
              //$lg('ajs::2352::dsp');
              let objs = Doc.api.queryAll(anyStr);
              if(objs == null) return;
              objs.forEach((obj)=>{
                //if(obj.className.indexOf('AB-list-box')>-1)$lg('269::className::bgo',obj.className);
                if(obj.classList.contains(`line-hide`)){
                  if(show)obj.classList.remove(`line-hide`);
                }else{ 
                  if(hide)obj.classList.add(`line-hide`);
                }
              })
          },
            
        }
    
    }
  
    php = {
        addr : '../include/handler.php',
        file : '../app/dat/data.sqlite3',
        book : '../app/dat/gmbook.sqlite3',
    }
  
    dat = {

        socket : {
          
          handler : (event)=>{
            try{
              $lg('12320::bgb','this.socket.binaryType',this.socket.binaryType,typeof event.data);
              
              const type = typeof event.data;
              if( type == 'string'){
                let obj = JSON.parse(event.data);
                let op = obj.op;
                let da = obj.da;
                //$lg('10403','socket.handler',event.data);
                let eve = new CustomEvent(op, {detail: da});
                document.dispatchEvent(eve);
              }else
              if( type == 'object' ){
                $lg('12344::bgo','object');
                let eve2 = new CustomEvent('socketGotObject', {detail: event.data});
                document.dispatchEvent(eve2);
                /*const mp3Blob = new Blob([event.data], { type: 'audio/mpeg' });  
                let url = URL.createObjectURL(mp3Blob);  
                $lg('12348:url',url);
                this.audio.load(url);*/
                //this.audio.src = url;
                // 使用MSE API将Blob数据进行处理和播放  
                /*
                let mediaSource = new MediaSource();  
                let sourceBuffer;  
              
                this.audio.src = URL.createObjectURL(mp3Blob);  
                mediaSource.addEventListener('sourceopen', () => {  
                  sourceBuffer = mediaSource.addSourceBuffer('audio/mpeg');  
                });  
                const chunk = event.data;  
                if (sourceBuffer.updating) {  
                  return;  
                }  
                sourceBuffer.appendBuffer(chunk);  
                */
              }else
              if( type == 'arraybuffer' ){
                
              }
              /*if( op == 'pg'){
                if(fsize > 0){
                  val = parseFloat(da/fsize)*100;
                  $lg('10354',`da:${da},fsize:${fsize},pc:${val}`);
                  pv.style.width = val + '%';
                  pc.innerText = parseInt(val) + '%';
                
              }else{
                $lg('10359',event.data);
              }*/
            }catch(e){
              //$lg('12337::bgy','socket typeof event.data',typeof event.data,typeof event.data == 'string' ? event.data : null);
              //$lg('12338::bgg','this.socket.binaryType',this.socket.binaryType);
              $log.lgg(event.data);
              $lg('12378::bgo',e.message);
            }
            
            
          }
          
        },

        tableWord : {
          
          batAdd : async (sid,lrc,startLidx = 0)=>{
            //$lg('1860::batAdd');
            let sqlText = `INSERT INTO word(sid,lidx,idx,word,type,start,end) VALUES`;
            let i = 0;
            /*let L = 0;
            let arr = [];
            let fail = [];*/
            //$lg('2590:lines.len',lrc.lines.length);
            
            for(let objLine of lrc.lines){
                if(objLine == null){continue;}
                //L++;
                let lidx = startLidx + objLine.idx;
                //$lg('1866::lidx',lidx);
                for(let objWord of objLine.words){
                    if(objWord == null){continue;}
                    const idx   = objWord.idx;
                    //let word = objWord.word;
                    const word  = objWord.word.replace(/'/g,'\u2032');
                    const type  = objWord.type;
                    const start = objWord.start;
                    const end   = objWord.end;
                    //const md5   = SparkMD5.hash(`${sid}-${lidx}-${idx}-${word}`);
                    //const datetime = "datetime('YYYY-MM-DD HH:MM:SS.SSS','localtime')";
                    //const time = "strftime('%Y-%m-%d %H:%M:%f','now')";
            
                    /*if((new RegExp(md5)).test(sqlText)){
                      $lg('2961::bgo',md5,`${sid}-${lidx}-${idx}-${word}`);
                    }*/
                    sqlText += ','.repeat(i)+`\n(${sid},${lidx},${idx},'${word}',${type},${start},${end})`;
                    i=1;
                }
                /*if(L == Math.floor(lrc.lines.length/2)){
                  arr.push(sqlText);
                  sqlText = 'INSERT INTO word(sid,lidx,idx,word,start,end,md5) VALUES';
                  i=0;
                }*/
                //sqlText += ';';
            }
            //$log.lgg('9118::sqlText',sqlText);
            //$lg('9118::sqlText',sqlText.length);
            //return;
            await this.sql.run(sqlText);
            
            return this.service.data.req('tableWord.updateLen',sid);
            
            /*for(sqlText of arr){
              let r = await sql.run(sqlText);
              if(r.da.rst == false)fail.push(r);
            }
            
            if(fail.length == undefined) return true;
            return false;*/
            
        },
        
          
        },

        fn : {
          /*
          buildObjLrc : async (sid,queryAnyStr=null)=>{
            
            let msg = Doc.api.query(queryAnyStr);
            
            this.objLrc = this.obj.lrc(this);
            
            let maxLineIdx = await this.service.data.req('tableWord.getNumberOf.maxLineIdx',sid);
            $lg('2900::maxLineIdx::bgg',JSON.stringify(maxLineIdx));
                maxLineIdx = parseInt(maxLineIdx);
            
            
            for(let lidx =0; lidx <= maxLineIdx; lidx++ ){
              
              if(msg)msg.innerText = `${lidx}/${maxLineIdx}`;
              
              let rsp = await this.service.data.req('tableWord.getWordsByLine',sid,lidx);
              //$lg('2902::rsp::bgg',JSON.stringify(rsp.da.dat));
              if(rsp.da.rst == false)continue;
              
              let objLine = this.obj.line(lidx);
              for(let oo of rsp.da.dat.arr){
                  //$lg('3021::oo::bgb',JSON.stringify(rsp.da.dat.col));
                  //idx","word","type","start","end"
                  let objWord = this.obj.word(oo[1], oo[2], oo[0], oo[3], oo[4]);
                  //$lg(`3694::bgb`,`${lidx}:${oo.idx}:${oo.word}:${oo.type}`);
                  objLine.addWord(objWord);
              }
              this.objLrc.addLine(objLine);
            
            }
            this.objLrc.ready = true;
            //$lg('2926::this.objLrc.ready',this.objLrc.ready);
            return this.objLrc;
          },
          */
          buildObjLrcAll : async (sid,sq=null)=>{
            
            
            /*let sqlText = `
                select lidx,idx,word,type,start,end 
                from word 
                where sid = ${sid} 
                order by lidx asc,idx asc 
            `;*/
            //$lg('4473::start::bgg',Log.now());
            //let rsp = await this.sql.que(sqlText);
            let rsp = await this.service.data.req('tableWord.getWord',sid);
            //$log.lgg('10929:rsp',JSON.stringify(rsp));
            //let msg = Doc.api.query(queryAnyStr);
            if(rsp.da.dat.arr.length == 0) return alert('12942:arr是空集');
            this.objLrc = this.obj.lrc(this);
            /*
            let maxLineIdx = await this.dat.tableWord.maxLineIdx(sid);
                maxLineIdx = parseInt(maxLineIdx);
            */
              //if(rsp.da.rst == false)continue;
            //$lg('2900::maxLineIdx::bgg',maxLineIdx);
            let maxLineIdx = rsp.da.dat.arr[rsp.da.dat.arr.length-1][0];
            //for(let lidx =0; lidx <= maxLineIdx; lidx++ ){
              
              
              //let rsp = await this.dat.tableWord.getWordsByLine(sid,lidx);
              //$log.lgg('2902::rsp::bgg',JSON.stringify(rsp.da.dat));
            let lastLidx = -1;
            let thisTime = 0;
            let nextTime = -1;
            for(let arr of rsp.da.dat.arr){
              //for(let arr of item){
                //["lidx","idx","word","type","start","end"]
                //   0      1      2      3      4      5
                let lidx = arr[0];
                if(lidx > lastLidx){
                  this.objLrc.addLine(this.obj.line(lidx));
                  //$lg(`${lidx}/${maxLineIdx}::${Log.now()}`);
                  
                }
                let st = typeof arr[4] == 'number' ? arr[4]/1000 : null ;
                let ed = typeof arr[5] == 'number' ? arr[5]/1000 : null ;
                //$lg('3021::oo::bgb',JSON.stringify(rsp.da.dat.col));
                //lidx,idx","word","type","start","end"
                let objWord = this.obj.word(arr[2], arr[3], arr[1], st, ed);
                //                          word,type,idx,start,end,this
                //$lg(`3694::bgb`,`${lidx}:${arr[1]}:${arr[2]}:${arr[3]}`);
                
                this.objLrc.getLine(lidx).addWord(objWord);
              //}
                
                //setTimeout(function() {
                  if(lidx > lastLidx){
                    if(thisTime > nextTime){
                        if(sq){
                            sq.msg(`${lidx}/${maxLineIdx}`);
                        }
                        nextTime += 100;
                        //$lg(`${nextTime},${Log.now()}`);
                    }
                  }
                //}, 0);
                
                thisTime = lidx;
                lastLidx = lidx;
                
            }
            
            
            this.objLrc.ready = true;
            //$lg('2926::this.objLrc.ready',this.objLrc.ready);
            let event = new CustomEvent("buildObjLrcAllDone", null);
            document.dispatchEvent(event);
            
            return this.objLrc;
          },
          
          listTableName : ()=>{
            
            let sqlText = ` select name from sqlite_sequence order by name asc`;
            return this.sql.que(sqlText)
            
          },
          
          getTableData : ( name, afterId = -1, num = 100 )=>{
            
            let sqlText = ` select * 
                            from ${name} 
                            order by id asc 
                            limit ${num} offset ${afterId}`;
            return this.sql.que(sqlText)
            
          },
          
          ajaxUpload : (ad, op, da, file, okCallBack, failCallBack)=>{
    
            let opda = {
                op: op,
                da: da
            };
        
            let lists = new FormData();
                lists.append("opda", JSON.stringify(opda));
                lists.append("file", file);
            
            $.ajax({
                url: ad, //上传地址
                async: true, //异步
                type: 'post', //post方式
                data: lists, //FormData数据
                processData: false, //不处理数据流 !important
                contentType: false, //不设置http头 !important
        
                success: okCallBack,
                error: failCallBack
        
            })
        },
      
          fileUpload : ( da, file )=>{
            
            return new Promise((ok,fail)=>{
              let addr = php.addr;
              let ope = 'file__upload';
              /*let dat = {
                path : da.path,
                name : da.name,
                mkdir: da.mkdir,
              };*/
              //$lg('mp3::842::fileUpload',JSON.stringify(da));
              ajaxUpload(addr,ope,da,file,(rsp)=>{
                
                rsp = JSON.parse(rsp);
                //$lg('Mp3.module.js::687::ok::bgg',JSON.stringify(rsp));
                ok(rsp);
                
              },(rsp)=>{
                $lg('Mp3.module.js::691::error::bgo',JSON.stringify(rsp));
                fail(rsp);
              })
            })
          }
          
          
        }
        
    }
    
    fn  = {
      
      getData : (filename)=>{
        return new Promise((res,rej)=>{
            let op = 'file__open';
            let da = { filename };
            let xhr = new Xhr(this.php.addr);
            xhr.ask(op,da);
            xhr.rsp((data)=>{
              $lg('7765',data,'::lgg');
              /*let obj = JSON.parse(data);
              let dat = obj.da.dat;
              $lg('7768::bgg',dat);*/
              res(JSON.parse(data));
            },(err)=>{
              $lg('7071::bgo',err);
              rej();
            })
        })
      },
      
      timeTsl : (time)=>{
          //$lg('3077::time',time);
          let mm = Math.floor(time / 60);
          //$lg('3079::mm',mm);
          let ss = Math.floor(time - mm * 60);
          //$lg('3081::ss',ss);
          
          let ms = (time - Math.floor(time))*1000;
              ms = Math.floor(ms);
              //$lg('3081::mm,ss,ms',mm,ss,ms);
              
          return [mm,ss,ms];
      },
      
      statusBtn : ()=>{
        
      },
      
      showLrc : ()=>{
        
        let btnLrc = Doc.api.query('.btn-lrc');
        if(btnLrc.classList.contains('yelack') == false) return;
    
        
        return this;
        
      },
      
      activeFlashBtn : ()=>{
        
        new Html();
        
        $all(`.flash-btn`).on.aniEnd((e)=>{
                        
            let ds = e.target;
            
            //$lg('280::aniEnd::className',ds.className,Log.now());
            if(ds.classList.contains('flash')){
              ds.classList.remove('flash');
              //ds.classList.toggle('flash');
            }
            //$lg('284::aniEnd::className',ds.className,Log.now());
        },0);
        
        
        $all(`.flash-btn`).on.mouseDown((e)=>{
            
            let ds = e.target;
            
            //$lg('280::mouseDown::className',ds.className,Log.now());
            if(ds.classList.contains('flash') == false){
              ds.classList.add('flash');
              //ds.classList.toggle('flash');
            }else{
              ds.classList.toggle('flash');
            }

        },0);
        
        
      },
      
      clipboard : {
        
          copyText : async (text)=>{
              let ks = Reflect.ownKeys(navigator);
              $lg('6800::bgb',...ks);
              return;
              const permission = await navigator.permissions.query({ name: 'clipboard-write' });
              if (permission.state === 'denied') {
                  return $lg('6806::bgg',"no permissions to clipboard-write")
              }
              try {
                  await navigator.clipboard.writeText(text) // 写入文本
                  $lg('6806::bgg',"clipboard writeText done!")
              } catch (e) {
                  $lg("6808::bgo","clipboard writeText Error")
                  
              }

          },
          
          pasteImage : async ()=>{
            let destinationImage = document.getElementById("myImage")
            const permission = await navigator.permissions.query({ name: 'clipboard-read' });
            if (permission.state === 'denied') {
                throw new Error('Not allowed to read clipboard.');
            }
            const clipboardContents = await navigator.clipboard.read();
            for (const item of clipboardContents) {
                if (!item.types.includes('image/png')) {
                    throw new Error('Clipboard contains non-image data.');
                }
                const blob = await item.getType('image/png');
                destinationImage.src = URL.createObjectURL(blob);
            }
          },
        
      },
      
      bg : {
        
        flash : (obj)=>{
            if( typeof obj == 'null' ) return;
          //return new Promise((ok)=>{
            if( typeof obj === 'string'){
              obj = Doc.api.query(obj);
            }
            
            obj.addEventListener('animationend',(e)=>{
              obj.classList.remove('bg-flash');
              //ok();
            },{once:1})
            obj.classList.add('bg-flash');
          //})
        },
        
        green : (obj)=>{
          if( typeof obj == 'null' ) return;
          //return new Promise((ok)=>{
          if( typeof obj === 'string'){
            obj = Doc.api.query(obj);
          }
          obj.addEventListener('animationend',(e)=>{
              obj.classList.remove('bg-green');
              obj.classList.remove('bg-flash');
              //ok();
            },{once:1})
          obj.classList.remove('bg-flash');
          obj.classList.add('bg-green');
          //})
        },
        
        red : (obj)=>{
            if( typeof obj == 'null' ) return;
          //return new Promise((ok)=>{
            if( typeof obj === 'string'){
              obj = Doc.api.query(obj);
            }
            obj.addEventListener('animationend',(e)=>{
              obj.classList.remove('bg-red');
              obj.classList.remove('bg-flash');
              //ok();
            },{once:1})
            obj.classList.remove('bg-flash');
            obj.classList.add('bg-red');
          //})
          
        }
        
      },
      
      pop : (content,wh = null, sec = null )=>{
        $lg('7043::fn.pop::bgy');
        if(Doc.has('.pop')) {
          let pop = Doc.api.query('body>.pop');
              pop.innerHTML = content;
              pop.classList.remove('hide');
              pop.classList.add('show');
              if( sec > 0 ){
                pop.classList.add('pop-show');
                pop.style.animationDuration = sec + 's';
              }
              if( typeof wh == 'string' ){
                let fn = ((w,h = w)=>{
                  pop.style.width = w;
                  pop.style.heigh = h;
                })([...(wh.split(','))])
              }
          return;
        };
        
        let cs = new Css();
        
        let css = (()=>{
          $lg('7053::fn.pop::css::bgb');
          let cs = new Css();
              cs.style('Ajs/kf')
                .kf('ani-pop-show')
                  .pc(  0).a.dsp.blk().ds()
                  .pc(100).a.dsp.no().ds()
                .ok();
          new Css('.pop',{
            //display         : 'none',
            position        : 'absolute',
            top             : 'auto',
            left            : 'auto',
            width           : '80%',
            font_size       : '5vmin',
            padding         : '30px',
            margin          : '50px',
            //border          : '3px solid black',
            border_radius   : '16px',
            border          : '6px solid hsla(60,60%,10%,1)',
            background      : cs.rgba.white(3,6),//'hsla(60,90%,90%,1)',
            color           : 'hsla(60,60%,10%,1)',
            //filter          : 'drop-shadow 0 0 3px white',
            animation       : 'ani-pop-show forwards',
            overflow        : 'scroll',
            z_index         : 100,
          })//.pop
          new Css('.pop-show',{
            animation       : 'ani-pop-show 600s backwards',
          })//.pop-show
        })()
        
        let htm = (()=>{
          $lg('7081::fn.pop::htm::bgb');
          let htm = new Html();
              htm.dom( 'body' )
              .div('.pop',`!${content}`)
                  .on.click((e)=>{
                    let ds = e.target;
                    if( ds.classList.contains('pop') == false) return;
                    /*ds.classList.remove('show');
                    ds.classList.add('hide');
                    */
                    ds.parentNode.removeChild( ds );
                    //ds.style.display = 'none';
                  },0)
                  /*.on.aniEnd((e)=>{
                    $lg('7086::fn.pop::aniEnd::bgb',Log.now());
                    let ds = e.target;
                        ds.classList.remove('pop-show');
                        ds.classList.add('hide');
                        
                  },0)*/
                  /*.on.aniStart((e)=>{
                    $lg('7122::fn.pop::aniStart::bgb',Log.now());
                    let ds = e.target;
                      ds.classList.remove('hide');
                  },0)*/
              .ok();
        })()
        
        
      },
      
      getFileSize : async ( fpath, unit = 'MB' )=>{
        let pms = ()=>{ return new Promise((ok,fail)=>{
          let op = 'file__size';
          let da = { fpath, unit };
          let xhr = new Xhr(this.php.addr);
              xhr.ask(op,da);
              xhr.rsp((data)=>{
                $log.lgg(data);
                ok(JSON.parse(data))
              },(err)=>{
                $lg('error::bgo',err.message)
              })
        })};
        
        let rsp = await pms();
        //return alert(rsp);
        if( rsp.da.rst == false ) return -1
        return rsp.da.dat;
      },
      
      shouldBeFission : async (which,num = null)=>{
        
        if(!['img','mp3','voice'].includes(which)) return alert('只能是"img,mp3,vouce"');
        
        if( num === null ){
          // 分库版本
          num = await this.service.data.req('tableOption.getFissionVal',which);
        }
        if( num === -1 )return alert('nun == -1,return');
        
        //当前数据文件大小
        let snum = num.toString().padStart(4,'0');
        let path = `../app/dat/${which}_${snum}.sqlite3`;
        let size = await this.fn.getFileSize(path,'MB');
        //return alert('size:'+size);
        //size超过100MB或文件不存在(-1)，执行分库
        if( size > 100 || size == -1){
          //超过100MB执行分库
          if( size > 100 )num ++;
          let rsp = await this.service.data.req('fission',which,num);
          if(rsp.da.rst == false ) return alert(`10999:fission ${which} fail`);
          if( size > 100 ){
            //更新当前版本
            rsp = await this.service.data.req('tableOption.selfAdd','fission',which);
            if(rsp.da.rst == false) return alert(`11001:'tableOption.selfAdd,fission,${which}' fail`);
          }
        }
        return num;
        
      },
      
    }
    
    sql = {
        
        run   : (sqlText,dbFile = null)=>{
            return new Promise((ok,fail)=>{

                let act   = 'run';
                let sql   = sqlText;
                let file  = dbFile == null ? this.php.file : dbFile;
                let addr  = this.php.addr;
                let op    = 'data__run_cmd';
                let da    = { sql,act,file };
                let sqlike = new Sqlike(addr);
                try{
                  sqlike.run(op,da).then((dat)=>{
                      ok(dat);
                  },(err)=>{
                      $lg('1887::bgo',err);
                      fail(err);
                  })
                }catch(err){
                  $lg('4711::bgo',err.message);
                }
            });
        },
        
        que   : (sqlText,dbFile = null)=>{
            return new Promise((ok,fail)=>{

                let act   = 'que';
                let sql   = sqlText;
                let file  = dbFile == null ? this.php.file : dbFile;
                let addr  = this.php.addr;
                let op    = 'data__run_cmd';
                let da    = { sql,act,file };
                let sqlike = new Sqlike(addr);
                try{
                  sqlike.run(op,da).then((dat)=>{
                      //$lg('4464::bgb',JSON.stringify(dat));
                      ok(dat);
                  },(err)=>{
                      $lg('4467::bgo',err);
                      fail(err);
                  })
                }catch(err){
                  $lg('4740::bgo',err.message);
                }
            });
        },
        
        getData : (sqlText,arr)=>{
            let act   = 'dat';
            let sql   = sqlText;
            let file  = this.php.file;
            let addr  = this.php.addr;
            let op    = 'data__run_cmd';
            let da    = { sql,arr,act,file };
            let sqlike = new Sqlike(addr);
            return sqlike.run(op,da);
        },
        
        getResult : (sqlText,arr)=>{
            let act   = 'rst';
            let sql   = sqlText;
            let file  = this.php.file;
            let addr  = this.php.addr;
            let op    = 'data__run_cmd';
            let da    = { sql,arr,act,file };
            let sqlike = new Sqlike(addr);
            sqlike.run(op,da).then((dat)=>{
                ok(dat);
            },(err)=>{
                $lg('1920::bgo',err);
                rej(err);
            })
        },
        
      }
    
    obj = {
      
      lrc  : (ds=this)=>{
          return {
              lidx           : -1,
              widx           : -1,
              lines          : [],
              thjs           : ds,
              ready          : false,
              saveAll        : async function(){
                  //$lg('3203::saveAll::start::bgy',Log.now());
                  let thiz = (this.thjs);
                  for(let line of this.lines){
                    let lidx = line.idx;
                    for(let word of line.words){
                      let widx = word.idx;
                      let st   = parseInt( word.start*1000 );
                      let ed   = parseInt( word.end*1000 );
                      if(st && ed)
                          await thiz.service.data.req('tableWord.setTime',thiz.songId,lidx,widx,st,ed);
                    }
                  }
                  //$lg('3215::saveAll::done::bgy',Log.now());
                  return this;
              },
              saveOne        : async function(idx){
                  //return new Promise((res,rej)=>{
                  //this.ui.fn.highlight(e);
                  let thiz = (this.thjs);
                  $lg('3250::saveOne::bgb');
                  $lg('3251::thjs.songId::bgo',thiz.songId);
                  
                  if(thiz.songId == null) return;
                  if(idx == null )idx = this.lidx;
                  let sid = thiz.songId;
                  let lidx = idx;
                  //$lg('3256::lidx::bgb',lidx);
                  if(lidx == -1) return;
                  let objLine = this.lines[lidx];
                  let words = objLine.words;
                  for(let objWord of words ){
                      let widx = objWord.idx;
                      let start = parseInt(objWord.start*1000);
                      let end = parseInt(objWord.end*1000);
                      await thiz.service.data.req('tableWord.setTime',sid,lidx,widx,start,end);
                  }
              },
              
              addText        : function(text){
                  
                  
                  let lines = [];
                  
                  text = text.replace(/('|"|\[|\{|\<|\()([a-zA-Z]+)('|"|\]|\}|\>|\))/g,' $1 $2 $3 ');
                  
                  text = text.replace(/([^a-z]*)([a-z]+)([^a-z]*)/ig,'$1 $2 $3');
                  
                  text = text.replace(/(\,(?!\d+)|\(|\)|\[|\]|\/(?!\d+)|\>|\<|\+|\-|\—|\*|\%)/g,' $1 ');
                  
                  text = text.replace(/\u0020{1,}/g,' ');
                  //$log.lgg('4051::\n',text);
                  text = text.replace(/\n{1,}/g,'\n');
                  
                  //$log.lgg('4053::\n',text);
                  text = text.replace(/([a-zA-Z]+)('[a-z]{1,2})/ig,'$1 $2');
                  //$log.lgg('4055::\n',text);
                  
                  
                  
                  text = text.replace(/(\w+)([\?\:\!\;])/ig,'$1 $2');
                  
                  
                  text = text.replace(/(\.)(\s|\,)/ig,'$1 $2');
                  
                  
                  //for SQlite
                  text = text.replace(/\(/g, '\uff08' ) ;
                  text = text.replace(/\)/g, '\uff09' ) ;
                  text = text.replace(/\,/g, '\u201a' ) ;
                  text = text.replace(/\'/g, '\u2032' ) ;
                  text = text.replace(/\"/g, '\u2033' ) ;
                  text = text.replace(/\`/g, '\u2035' ) ;
          
                  
                  //text = text.replace(/([\.\?\:\!])\s/ig,'$1 \u2704');//剪刀
    
                  //$log.lgg('4551::text',text);
                  
                  let parts = text.split('\n');
                  
                      parts.forEach((str)=>{
                        if(/^\s*$/.test(str))return;
                        //if(/(e\.g\.\s*)\u2704/.test(str)){ str = str.replace(/(e\.g\.\s*)\u2704/g,'$1');}
                        //str = str.replace(/(\w+)([\.\?\:\!])\s\u2704/ig,'$1 $2\u2704');
                        //let arr = str.toString().split(/\u2704/g);
                        let lang = /[\u4e00-\u9fa5]/.test(str);
                        //gpt-3.5 generated
                        let arr = [];
                        if(lang){
                          arr = text.split(/[。？；！.!?]+/);
                        }else{
                          arr = ajString.splitSentences(str);
                        }
                        lines.push(...arr);
                        
                      })
                  
                  let lidx = -1;
                  let thix = (this.thjs);
                  
                  let bug = (lidx,widx,rxp,word)=>{
                    if(lidx > 0) return;
                    $lg('4565::bgb',widx,rxp.toString(),word,rxp.test(word));
                  }
                  
                  const rxp = [];
                      rxp[100] = /^[\s\n]*$/;
                      rxp[0] = /^[a-zA-Z]+$/;
                      rxp[1] = /^[，。？！\,\.\:\!\?\(\)\[\]\<\>\/\*\%\+\-\=\|\$\#\@\!\&]$/;
                      rxp[2] = /\'[a-zA-Z]{1,2}/;
                      //rxp[3] = /^(\d+\.\d+)|(\d+(\,\d{3})*)$/;
                      rxp[3] = /^(\d+((\,|\.|\/)\d{1,3})*)$/;
                      rxp[31] = /\d+(st|nd|th|%)/;//1st,2nd,3th,17th,17%
                      
                      rxp[4] = /[\u4e00-\u9faa\s]/;
                  for(let line of lines){
                    if(rxp[100].test( line )) continue;
                    //if(/^(\.|\?)\s*$/.test(line)) continue;
                    lidx++;
                    this.addLine(thix.obj.line(lidx,thix));
                    //h.div('.lrc-line flex-row-4').as(0);
                    
                    
                    let words = [];
                    if(rxp[4].test( line )){
                      words = line.split('');
                    }else{
                      words = line.split(/\s+/);
                    }
                    
                    //$lg('1413::bgg',...words);
                    let widx = -1;
                    for(let word of words){
                      if(rxp[100].test(word))continue;
                      //word = word.replace(/^(\w+)[\,\.\?\:\!\s]*$/i,'$1');
                      word = word.trim();
                      let type = 0;
                      if( rxp[0].test(word) )  {
                        type = 0;
                        
                      }else if( rxp[1].test(word) )  {
                        type = 1;
                        //bug(lidx,widx,rxp[1],word);
                      }else if( rxp[2].test(word) ){ 
                        type = 2;
                        //bug(lidx,widx,rxp[2],word);
                      }else if( rxp[3].test(word) || rxp[31].test(word) ){  
                        type = 3;
                      }else{
                        type = 4;
                      
                        //bug(lidx,widx,rxp[3],word);
                      }
                      widx++;
                      this.lastLine().addWord(thix.obj.word(word,type,widx));
                    }
                  }
              },
              
              addChineseText : function(text){
                  
                  
                  let lines = [];
                  
                  text = text.replace(/('|"|\[|\{|\<|\()([a-zA-Z]+)('|"|\]|\}|\>|\))/g,' $1 $2 $3 ');
                  
                  text = text.replace(/([^a-z]*)([a-z]+)([^a-z]*)/ig,'$1 $2 $3');
                  
                  text = text.replace(/(\,(?!\d+)|\(|\)|\[|\]|\/(?!\d+)|\>|\<|\+|\-|\—|\*|\%)/g,' $1 ');
                  
                  text = text.replace(/\u0020{1,}/g,' ');
                  //$log.lgg('4051::\n',text);
                  text = text.replace(/\n{1,}/g,'\n');
                  
                  //$log.lgg('4053::\n',text);
                  text = text.replace(/([a-zA-Z]+)('[a-z]{1,2})/ig,'$1 $2');
                  //$log.lgg('4055::\n',text);
                  
                  
                  
                  text = text.replace(/(\w+)([\?\:\!\;])/ig,'$1 $2');
                  
                  
                  text = text.replace(/(\.)(\s|\,)/ig,'$1 $2');
                  
                  
                  //for SQlite
                  text = text.replace(/\(/g, '\uff08' ) ;
                  text = text.replace(/\)/g, '\uff09' ) ;
                  text = text.replace(/\,/g, '\u201a' ) ;
                  text = text.replace(/\'/g, '\u2032' ) ;
                  text = text.replace(/\"/g, '\u2033' ) ;
                  text = text.replace(/\`/g, '\u2035' ) ;
          
                  
                  //text = text.replace(/([\.\?\:\!])\s/ig,'$1 \u2704');//剪刀
    
                  //$log.lgg('4551::text',text);
                  
                  let parts = text.split('\n');
                  
                      parts.forEach((str)=>{
                        if(/^\s*$/.test(str))return;
                        //if(/(e\.g\.\s*)\u2704/.test(str)){ str = str.replace(/(e\.g\.\s*)\u2704/g,'$1');}
                        //str = str.replace(/(\w+)([\.\?\:\!])\s\u2704/ig,'$1 $2\u2704');
                        //let arr = str.toString().split(/\u2704/g);
                        
                        //gpt-3.5 generated
                        let arr = ajString.splitSentences(str);
                        
                        lines.push(...arr);
                        
                      })
                  
                  let lidx = -1;
                  let thix = (this.thjs);
                  
                  let bug = (lidx,widx,rxp,word)=>{
                    if(lidx > 0) return;
                    $lg('4565::bgb',widx,rxp.toString(),word,rxp.test(word));
                  }
                  
                  const rxp = [];
                      rxp[100] = /^[\s\n]*$/;
                      rxp[0] = /^[a-zA-Z]+$/;
                      rxp[1] = /^[\,\.\:\!\?\(\)\[\]\<\>\/\*\%\+\-\=\|\$\#\@\!\&]$/;
                      rxp[2] = /\'[a-zA-Z]{1,2}/;
                      //rxp[3] = /^(\d+\.\d+)|(\d+(\,\d{3})*)$/;
                      rxp[3] = /^(\d+((\,|\.|\/)\d{1,3})*)$/;
                      rxp[31] = /\d+(st|nd|th|%)/;//1st,2nd,3th,17th,17%
                      
                      rxp[4] = /^[\u4e00-\u9faa\s]+$/;
                  for(let line of lines){
                    if(rxp[100].test( line )) continue;
                    if(rxp[4].test( line )) continue;
                    //if(/^(\.|\?)\s*$/.test(line)) continue;
                    lidx++;
                    this.addLine(thix.obj.line(lidx,thix));
                    //h.div('.lrc-line flex-row-4').as(0);
                    let words = line.split(/\s+/);
                    //$lg('1412::bgg',line);
                    //$lg('1413::bgg',...words);
                    let widx = -1;
                    for(let word of words){
                      if(rxp[100].test(word))continue;
                      //word = word.replace(/^(\w+)[\,\.\?\:\!\s]*$/i,'$1');
                      word = word.trim();
                      let type = 0;
                      if( rxp[0].test(word) )  {
                        type = 0;
                        
                      }else if( rxp[1].test(word) )  {
                        type = 1;
                        //bug(lidx,widx,rxp[1],word);
                      }else if( rxp[2].test(word) ){ 
                        type = 2;
                        //bug(lidx,widx,rxp[2],word);
                      }else if( rxp[3].test(word) || rxp[31].test(word) ){  
                        type = 3;
                      }else{
                        type = 4;
                      
                        //bug(lidx,widx,rxp[3],word);
                      }
                      widx++;
                      this.lastLine().addWord(thix.obj.word(word,type,widx));
                    }
                  }
              },
              
              outText        : function(){
                
                let txt = '';
                for(let line of this.lines){
                  txt += line.outText() + '\n';
                }
                
                return txt;
                
              },
              
              getLineText    : function(lidx){
                
                let txt = '';
                let line = this.lines[lidx]
                txt += line.outText() + '\n';
              
                return txt;

              },
              
              addJson        : async function(sid,jsonStr,mark=0){
                  
                  let rsp = null;
                  let nickNum = 0;
                  
                  let thix = (this.thjs);
                  let rxp = [];
                      rxp[0] = /^[\s\n]*$/;
                      rxp[1] = /^([a-zA-Z]+)([\,\.\!\?\!\:\(\)\[\]\<\>\/\*\%\+\-\=\|\$\#\@\!\&])$/;
                      rxp[2] = /^([a-zA-Z]+)(\'[a-zA-Z]{1,2})/;
                      //rxp[3] = /^(\d+\.\d+)|(\d+(\,\d{3})*)$/;
                      rxp[3] = /^(\d+((\,|\.|\/)\d{1,3})*)$/;
                      rxp[31] = /\d+(st|nd|th|%)/;//1st,2nd,3th,17th,17%
                      
                      rxp[4] = /^([a-zA-Z\']+)([\.\!\?\!])$/;
                      rxp[5] = /^[\.\!\?]$/;
                      rxp[6] = /^[\,]$/;
                      
                  let pgs = JSON.parse(jsonStr);
                  
                  let arr  = [];
                  let lidx = -1;
                  for( let pg of pgs ){
                    let nick = pg.nick;
                    if( nick ) nickNum ++;
                    let sts  = pg.sts;
                    //tag,sid,lidx
                    //let rsp = await this.dat.tableTag.add(nick, sid, lidx);
                    for( let sentence of sts ){
                      
                      lidx++;
                      this.addLine(thix.obj.line(lidx,thix));
                      arr.push([nick,lidx]);
                      
                      let words = sentence.words;
                      let widx = -1;
                      for( let item of words ){

                        let wd = item[0].trim();
                        let st = item[1];
                        let ed = item[2];
                        
                        if(rxp[0].test(wd))continue;
                        //word = word.replace(/^(\w+)[\,\.\?\:\!\s]*$/i,'$1');
                        
                        let type = 0;
                        wd = wd.trim();
                        
                        //将标点符号拆开 ok. => ok .
                        if( rxp[1].test(wd) ){
                          let m = rxp[1].exec(wd);
                          wd = m[1];
                          
                          widx++;
                          this.lastLine().addWord(thix.obj.word(wd,type,widx,st,ed));
                          //next word is punc
                          wd = m[2];
                          st = ed+10;
                          ed = ed+20;
                          type = 1;
                          
                        }else 
                        if( rxp[2].test(wd) ){ 
                          //you're => you 're
                          let m = rxp[2].exec(wd);
                          wd = m[1];
                          
                          widx++;
                          this.lastLine().addWord(thix.obj.word(wd,type,widx,st,ed));
                          //next word is punc
                          wd = m[2];
                          st = ed+10;
                          ed = ed+10
                          type = 2;
                          //bug(lidx,widx,rxp[2],word);
                        }else 
                        if( rxp[3].test(wd) || rxp[31].test(wd)){  
                          //各种数字 
                          // 100 | 100,000,000 | 100.03 | 0.03 
                          // 1st | 2nd | 3th | 17% 
                          type = 3;
                          //bug(lidx,widx,rxp[3],word);
                        }
                        
                        widx++;
                        this.lastLine().addWord(thix.obj.word(wd,type,widx,st,ed));

                      }
                    }
                    
                  }
                
                  rsp = {
                    da : {
                      rst : true,
                      dat : null,
                      msg : null
                    }
                  }
                  
                  if( mark == 0 ){
                    if( nickNum > 2) mark = 1;
                  }
                  
                  if( mark == 1 ){
                    rsp =  await thix.service.data.req('tableTag.batMarkSentence',sid,arr);
                  }
                      //$lg('10001::rsp',JSON.stringify( rsp ));
                  return rsp;
                
              },
              
              addLine        : function(objLine){
                //this.lines.push(objLine);
                this.lines[objLine.idx] = objLine ;
                //this.lidx++;
                //$lg('1351::lines.length::bgb',this.lines.length);
                return this;
              },
              
              updateLine     : async function(lidx){
                let thix = (this.thjs);
                let rsp = await thix.dat.tableWord.getWordsByLine( thix.songId, lidx );
                
                if( rsp.da.rst == false ) return;
                
                //this.objLrc
                thix.objLrc.lines[ lidx ] = thix.obj.line(lidx,thix);
                
                for( let a of rsp.da.dat.arr ){
                  //idx,  word, type, start,  end
                  //a[0], a[1], a[2], a[3],   a[4]
                  (thix.objLrc.lines[lidx]).addWord(thix.obj.word( a[1], a[2], a[0], a[3], a[4] ));
                  
                }

              },
              
              currLine       : function(){
                if(this.lidx == -1)return null;
                return this.lines[this.lidx];
              },
              firstLine      : function(){
                this.lidx = 0;
                this.widx = 0;
                return this.lines[0];
              },
              lastLine       : function(){
                this.lidx = this.lines.length-1;
                return this.lines[this.lines.length-1];
              },
              preLine        : function(){
                  this.lidx--;
                  
                  if(this.lidx < 0) this.lidx = this.lines.length-1;
                  return this.lines[this.lidx];
              },
              nextLine       : function(){
                  this.lidx++;
                  this.widx = -1;
                  if(this.lidx > this.lines.length-1) this.lidx = 0;
                  return this.lines[this.lidx];
              },
              getLine        : function(idx){
                  
                  return this.lines[idx];
              },
              
              getTime        : function(){
                  let lidx = this.lidx;
                  let widx = this.widx;
                  return this.getItemTime(lidx,widx);
              },
              setTime        : function(floatSecondStart,floatSecondEnd=null){
                  let lidx = this.lidx;
                  let widx = this.widx;
                  return this.setItemTime(lidx,widx,floatSecondStart,floatSecondEnd);
              },
              
              setItemTime    : function(lidx,widx,floatSecondStart,floatSecondEnd=null){
                let objLine = this.lines[lidx];
                let objWord = (objLine.words)[widx];
                if(objWord == undefined)return this;
                if(floatSecondStart)
                    objWord.start = parseFloat(parseFloat(floatSecondStart).toFixed(3));
                if(floatSecondEnd)
                    objWord.end = parseFloat(parseFloat(floatSecondEnd).toFixed(3));
                return this;
              },
              setItemTimeEnd : function(lidx,widx,floatSecondEnd=null){
                let objLine = this.lines[lidx];
                let objWord = objLine.words[widx];
                    /*objWord.start = floatSecondStart;*/
                    objWord.end = parseFloat(parseFloat(floatSecondEnd).toFixed(3));
                return this;
              },
              getItemTime    : function(lidx,widx){
                //$lg('3289::getItemTime',lidx,widx,typeof(lidx),typeof(widx))
                let objLine = this.lines[lidx];
                let objWord = objLine.words[widx];
                    /*objWord.start = floatSecondStart;*/
                let st = objWord == undefined ? null : objWord.start;
                let ed = objWord == undefined ? null : objWord.end;
                if(st == null) st = 0;
                if(ed == null) ed = st+0.16;
                //$lg('3293::typeof(st)',st,typeof(st));
                //$lg('3294::typeof(ed)',ed,typeof(ed));
                return [st,ed];
                
              },
              getStsTime     : function(lidx){
                //$lg('3289::getItemTime',lidx,widx,typeof(lidx),typeof(widx))
                let objLine = this.lines[lidx];
                let st = null;
                let ed = null;
                
                for (let objWord of objLine.words){

                    const idx  = objWord.idx;
                    //const word = objWord.word;
                    //const type = objWord.type;
                    const start = objWord.start;
                    const end = objWord.end;
                    //$lg('1346::objWord::bgb',`${L}:${idx}`,`word:${word}`,`start:${start}`,`end:${end}`);
                    
                    if( idx == 0 ){
                      st = start;
                    }else 
                    if( idx == objLine.words.length - 1 ){
                      ed = end == null ? objLine.words[objLine.words.length - 2].end : end ;
                    
                      //$lg('1514::bgy',`'${sts_start}'`,`'${sts_end}'`);
                    }
                
                }
                
                if(st == null) st = 0;
                if(ed == null) ed = st+0.16;

                return [st,ed];
                
              },
              
              getObjWord     : function(lidx,widx){
                //$lg('3289::getObjWord',lidx,widx,typeof(lidx),typeof(widx))
                let objLine = this.lines[lidx];
                let objWord = objLine.words[widx];
                return objWord;
              },
          }
      },
      
      line : (idx=-1,ds=this)=>{
          return {
              idx   : idx,
              words : [],
              thjs  : ds,
              //thiz  : ds,
              addWord     : function(objWord){
                  this.words.push(objWord);
                  
                  //$lg('1368::length:',this.words.length);
                  return this;
              },
              outHtm      : function(){
                  //$lg(`mp3::1627,outHtm start,${Log.now()}::bgb`);
                  let h = new Html();
                      h.dom('.lrc-box')
                          //.div('.lrc-line flex-row-4').top()
                                .on.click((e)=>{
                                    //$lg('1433::text::bgg',e.target.innerText);
                                    let ds = e.target;
                                    
                                    if( ds.className.indexOf('lrc-lbl-') >= 0 ) return;
                                    
                                    let widx = ds.getAttribute('data-ajs-widx');
                                    
                                    if( widx == null ) return;
                                    
                                        widx = parseInt(widx);
                                    let lrc = (this.thjs).objLrc;
                                    let thiz = this.thjs;
                                    //let pt = Reflect.getPrototypeOf(this);
                                    //let ks = Reflect.ownKeys(this.thjs);
                                    //$lg('1443::ks::bgo',...ks,this.thjs.name);
                                    lrc.widx = widx;
                                    [...ds.parentNode.children].forEach((elm)=>{
                                        elm.classList.remove('yelack');
                                    })
                                    ds.classList.add('yelack');
                                    let lidx = lrc.lidx;
                                    if(thiz.setTimePoint && thiz.autoSetTime){
                                        let aud = thiz.myAudio;
                                        //if(aud.paused) return this;
                                        if(widx > 0){
                                          lrc.setItemTimeEnd(lidx,widx-1,parseFloat((aud.currentTime-0.07).toFixed(3)));
                                          thiz.ui.lrcBox.fn.addLabel(1,widx-1);
                                        }else{
                                          //set last word of pre line 
                                          if(lrc.lidx > 0){
                                              let pline = lrc.lines[lidx-1];
                                              let pidx = pline.words.length-1;
                                              if(aud.currentTime)lrc.setItemTimeEnd(lidx-1,pidx,aud.currentTime-0.07);
                                          }
                                        }
                                        if(aud.currentTime)lrc.setItemTime(lidx,widx,parseFloat(aud.currentTime.toFixed(3)));
                                        thiz.ui.lrcBox.fn.addLabel(0,widx);
                                    }else{
                                        // 取出
                                        let timeArr = lrc.getItemTime(lidx,widx);
                                        //$lg('2466::timeArr',...timeArr);
                                        thiz.loopAB = 1;
                                        thiz.loopDur = timeArr;
                                        thiz.ui.loopAB.replace(timeArr);
                                        //Doc.api.query('.audio').currentTime = timeArr[0];
                                        thiz.myAudio.currentTime = timeArr[0];
                                        if(thiz.myAudio.paused) thiz.audio.play();
                                    }
                                    
                                    return this;
                                },0);
                      if(this.idx) h.data('lidx',this.idx);
                      //$lg(`1372::line:${this.idx}::bgb`);
                      for(let obj of this.words){
                        //$lg(`1374::obj:${obj.idx},${obj.word},${obj.start},${obj.end}`);
                        /*h.div('.lrc-set-time').as(0)
                            .div('.lrc-time-info',0).as(1)
                                .span('.lrc-time-start','!00:00',1)
                                .span('.lrc-time-end','!00:00',1)*/
                          h.div('.lrc-word',`!${obj.word}`).as(1)
                                .data('widx',obj.idx)
                                .on.click((e)=>{
                                  //$lg('1438::widx::bgb',e.target.getAttribute('data-ajs-widx'));
                                    return this;
                                },true);
                          if( obj.start != null) { 
                          h.span(1,`.lrc-lbl-start`);} //,'!\u25e3'
                          if( obj.end   != null) { 
                          h.span(1,`.lrc-lbl-end `);} //,'!\u25e5'
                      }
                  //$lg(`mp3::1654,outHtm done,${Log.now()}::bgb`);
                  return h.pack();
              },
              outText     : function(){
                let txt = '';
                let i = 0;
                let j = -1;
                let last = this.words.length - 1;
                for(let obj of this.words){
                  j++;
                  txt += ' '.repeat(i) + obj.word;
                  i = 1;
                  if(j == last){
                    //if(/.+(^[\.\?\!\,\;\:])$/.test(obj.word) == false )
                      //txt += '.';
                  }
                }
                return txt;
              },
              getTimeArr  : function(){
                let st = (this.words[0]).start;
                let ed = (this.words[this.words.length-1]).end;
                return [st,ed];
              }
          }
      },
      
      word : (strWord,ty=0,idx=null,st=null,ed=null,ds=this)=>{
          return {
              idx   : idx,
              start : st,
              end   : ed,
              type  : ty,
              word  : strWord,
              thjs  : ds,
              setStart : function(fSecond){
                  this.start = fSecond;
                  return this;
              },
              setEnd : function(fSecond){
                  this.end = fSecond;
                  return this;
              },
          }
      },
      
    }
    
    mod = {
    
      dict : {
        
        init : async ()=>{
          
          let addr    = 'http://127.0.0.1:8080/project/include/handler.php';
          let dicfile = '../mod/dict.sqlite.db';
          await this.dic.init(addr,dicfile);
          
          return this;
          
        },
        
        event : {
          
          clickCancle : (e,ds)=>{
            let ebox = Doc.api.query('.dic-edit-box');
            if( !ebox ) return;
            ebox.classList.add('hide');
          },
          
          clickEnter : async (e,ds)=>{
            //alert('clickEnter');

            let inp = Doc.api.query('.dic-meaning-input');
            if( inp == null ) return;
            
            let elm = Doc.api.query('.word-detail-wd');
            if( elm == null ) return;
            
            let id = elm.id.replace('dict-word-id-','');
            //alert(id);
            let mn = inp.value;
            //return alert(mn);
            document.addEventListener('editMeaningDone',(e)=>{
              alert(e.detail.dat)
            },0)
            
            this.dic.webman.req.edit.meaning(id,mn);
              
            
              
          },
            
          showInputBox : (val = 1)=>{
            
            let ebox = Doc.api.query('.dic-edit-box');
            if( !ebox ) return;
            
            if( val == 1 ){
              
              let obj = Doc.api.query('.word-detail-mn');
              let inp = Doc.api.query('.dic-meaning-input');
              if( obj && inp ){
                
                inp.value = obj.innerText;
                
              }
              ebox.classList.remove('hide');
            }else{
              ebox.classList.add('hide');
            }
            
          },
            
        },
          
          
      },
        
      
      
      mp3Encoder : {
        
        init : async ()=>{
          
          let addr    = 'http://127.0.0.1:8080/project/include/handler.php';
          
          await this.mp3Enc.init(addr);
          
          return this;
          
        },
        
      },
      
    }
    
    audio = {
    
      busy : false,
    
      paused : true,
      
      load  : (mp3path)=>{
        return new Promise((ok,fail)=>{
          let aud = this.myAudio;
        
          //let aud = Doc.api.query('.audio');
              aud.setAttribute('src',mp3path);
              aud.setAttribute('preload','auto');
          this.audio.event.setup();
          aud.addEventListener('durationchange',(e)=>{
            if(aud.duration > 0){ 
              ok();
              
              //this.myAudio = aud;
            }else{ 
              fail();
            }
          },0)
        })
      },
      
      play : ()=>{
          //let ds = e.target;
      
          let btnPlay = Doc.api.query('.spread-menu .btn-play');
        
          //let aud = Doc.api.query('.audio');
          let aud = this.myAudio;
          
          let time = aud.currentTime;
          
          if(this.loopAB == 1) time = this.loopDur[0];
          
          let ms = parseInt( ( this.loopDur[1] - this.loopDur[0] )*1000 ) ;
          //$lg('12812:audio.play:ms::bgg',ms);
          this.service.time.req.start(ms,aud.playbackRate);
          aud.play();
          this.audio.paused = false;
          
          btnPlay.innerText = String.fromCharCode(0x2759).repeat(2);
          
      },
      
      pause : ()=>{
          //let ds = e.target;
      
          let btnPlay = Doc.api.query('.spread-menu .btn-play');
        
          //let aud = Doc.api.query('.audio');
          let aud = this.myAudio;
          
          let time = aud.currentTime;
          
          if(this.loopAB) time = this.loopDur[0];
          
          
          this.service.time.req.pause();
          //$lg('588::bgy',(time-this.lastTime).toString());
          this.lastTime = time;
          aud.pause();
          this.audio.paused = true;
          
          btnPlay.innerText = String.fromCharCode(0x25b6);

      },
      
      speed050 : (e)=>{
          this.playbackRate = this.playbackRate - 1 == 0 ? 1 : this.playbackRate - 1;
          
          let aud = this.myAudio;
              aud.playbackRate = this.playbackRate * 0.1;
          e.target.innerHTML = `${aud.playbackRate.toString().slice(0,3)}x`;
      },
      
      speed100 : (e)=>{
          this.playbackRate += 1;
          //let aud = Doc.api.query('.audio');
          let aud = this.myAudio;
              aud.playbackRate = this.playbackRate * 0.1;
          e.target.innerHTML = `${aud.playbackRate.toString().slice(0,3)}x`;
      },
      
      event : {
        
          updateFast : ()=>{
            
              let ds   = this.myAudio;
              //$lg(ds.currentTime);
              let time = ds.currentTime;
               
            
              if(this.loopAB){
                //if(time >= (this.loopDur[1]-0.01)){
                  //$lg('10325::myAudio::break::bgg',time,this.loopDur[1]);
                  ds.currentTime = parseFloat( this.loopDur[0] );
                //}
              }
              
              //let btnPao = Doc.api.query('.btn-play-AB-one');

              if( this.flag_RepeatOnlyOneTimes == 1 ){
                //if(time >= this.loopDur[1]){
                  ds.pause();
                  this.service.time.req.pause();
                  ds.currentTime = this.loopDur[1];
                  Doc.api.query('.btn-play').innerText = String.fromCharCode(0x25b6);
                  let event = new CustomEvent("playOneTimesDone", null);
                  document.dispatchEvent(event);
                //}
              }
            
          },
        
          updateSlowly : ()=>{
            
              let ds   = this.myAudio;
              //$lg(ds.currentTime);
              let time = parseFloat(ds.currentTime.toFixed(3));

              
              if(this.showLrc > 1){
                  
                  let cLine   = this.objLrc.currLine();
                  let timeArr = cLine == null ? [0,0] : cLine.getTimeArr();
                  //$lg('3559::timeArr',...timeArr);
                  if(time > timeArr[1] && this.objLrc.lidx<this.objLrc.lines.length-1){
                    cLine = this.objLrc.nextLine();
                    timeArr = cLine.getTimeArr();
                    this.ui.lrcBox.fn.showLrc(cLine.outHtm());
                    this.ui.lrcBox.fn.showIdx(this.objLrc.lidx);
                  }
                  
              }
              
              
              let pc = parseFloat( time / this.dur ).toFixed(3);
                  pc = parseFloat(pc);
              Doc.api.query('#myRange').value = Math.floor(pc*100);
              let timeArr = this.fn.timeTsl(time);
              //$lg('597::bgg',time);
              if(time == NaN) return; 
              let mm = timeArr[0];
                  mm = mm.toString().padStart(2,'0');
              let ss = timeArr[1];
                  ss = ss.toString().padStart(2,'0');

              Doc.api.query('.btn-time-now').innerHTML = `${mm}:${ss}`;
              
              return this.audio;
            
          },
        
          timeupdate : (e)=>{
              //if(this.ui.range.oninput == 1) return this;
            //this.audio.event.updateFast();
            this.audio.event.updateSlowly();
          },
          
          timeupdate2 : ()=>{
            //$lg('this.audio.timeupdate2::bgb',Log.now());
            this.audio.event.updateFast();
          },
          
          durationchange : (e)=>{
              let ds = this.myAudio;
              let dur = parseFloat( ds.duration ).toFixed(3);
                  dur = parseFloat( dur );
              if(dur == NaN) return; 
              this.dur = dur;
              let mm = Math.floor(dur / 60);
              let ss = Math.floor(dur - mm * 60);
              Doc.api.query('.btn-time-dur').innerHTML = `${mm}:${ss}`;
              
              //speed set 1.0x 
              this.ui.speed.fn.spSetPos(1.0);
              ds.playbackRate = 1.0;
              return this.audio;
          },
          
          ratechange : (e)=>{
              
              let ds = this.myAudio;
              
              if( this.service.time.paused == 0 ){
                this.service.time.req.setRate( ds.playbackRate );
              }
              
              let rate = ds.playbackRate;
                  rate = rate.toString().slice(0,3);
              
              let frate = parseFloat(rate);
              
              let trs = Doc.api.query('.top-rate-show');
                  trs.innerHTML = `${frate}x`;
              
              //speed set 1.0x 
              this.ui.speed.fn.spSetPos(frate);
              this.playbackRate = frate;
              return this.audio;
          },
          
          canplaythrough : (e)=>{
              let ds = this.myAudio;
              return this.audio;
          },
          
          canplay : (e)=>{
              let ds = this.myAudio;
              Doc.api.query('.btn-play').style.color = 'green';
              return this.audio;
          },
          
          ended : (e)=>{
              let aud = this.myAudio;
              let btnPlay = Doc.api.query('.spread-menu .btn-play');
              if(aud.loop == true){
                  btnPlay.click();
              }else{
                  btnPlay.innerText = String.fromCharCode(0x25b6);
              }
          },
          
          setup   : ()=>{
              
              //let aud = Doc.api.query('.audio');
              let aud = this.myAudio;
                  aud.addEventListener('canplay',this.audio.event.canplay,false);
                  aud.addEventListener('canplaythrough',this.audio.event.canplaythrough,false);
                  aud.addEventListener('durationchange',this.audio.event.durationchange,false);
                  aud.addEventListener('ratechange',this.audio.event.ratechange,false);
                  aud.addEventListener('timeupdate',this.audio.event.timeupdate,false);
                  aud.addEventListener('timeupdate2',this.audio.event.timeupdate2,false);
                  aud.addEventListener('ended',this.audio.event.ended,false);
              /*let btnPlay = Doc.api.query('.spread-menu .btn-play');
                  btnPlay.addEventListener('click',this.audio.play,false);*/
              /*let btnSpeed050 = Doc.api.query('.spread-menu .btn-speed050');
                  btnSpeed050.addEventListener('click',this.audio.speed050,false);
              let btnSpeed100 = Doc.api.query('.spread-menu .btn-speed100');
                  btnSpeed100.addEventListener('click',this.audio.speed100,false);
               */
              return this.audio;
              
          },
      },
      
      fn  : {
        
        setCurrTime : (fSecond)=>{
          let ds = this.myAudio;
              ds.currentTime = parseFloat(fSecond);
          return this.audio;
        },
        
      }
      
    }
    
    service = {
      
      time : {
          
        script : ()=>{
        
          importScripts('http://127.0.0.1:8080/project/import/module/ajs_worker.js')
          
          function $lg(...anyStr){
            let op = 'lg';
            let da = [...anyStr];
            self.postMessage({op,da});
            return this;
          }
          
          class Handler{
          
              constructor(msgObj){
                this.map = new Map();
                this.add(msgObj);
                this.listen();
              }
              
              listen(){
                self.addEventListener('message',  (e)=>{
                  //$lg('1392::msg from host',JSON.stringify(e.data));
                  let data = e.data;
                  let op = data.op;
                  let da = data.da;
                  this.handle(op,da);
                
                })
              }
              
              handle(op,da){
                let fn = this.map.get(op);
                if(fn){
                  fn(op,da);
                }
              }
              
              add = (fnObj)=>{
                let keys = Object.keys( fnObj );
                keys.forEach((key)=>{
                  let fn = fnObj[key];
                  if(fn)this.map.set(key,fn);
                })
                return this;
              }
              
              post(...args){
                self.postMessage(...args);
              }
              
          }
          
          class timeService{
            
            constructor(ms=20){
              
              this.iid = null;
              
              this.timeElapse = 0;
              
              this.paused = 0;
              
              this.inc  = ms;
              
              this.ms   = ms;
              
              this.rate = 1;
              
            }
            
            start( ms,rate,event ){
              this.stop();
              //$lg('10812::timeserver.start',`event:'${event}'`);
              this.ms = parseInt( ms * 0.99 );
              let t1 = performance.now();
              //$lg('13211::timeserver.start::bgg',`ms:'${ms}'`);
              //$lg('13211::timeserver.start::bgg',`ms:'${this.ms}'`);
              
              this.paused = 0;  
  
              if( rate )this.rate = rate;
  
              this.timeElapse = 0;
              
              this.iid = self.setInterval(()=>{
                
                if( this.paused ) return;
                
                //this.timeElapse +=  this.inc/1000 * (1/this.rate);
                
                self.postMessage({op:'report',da:{event:event}});
                //$lg('timeup::bgb',parseInt(performance.now()-t1));
                //$lg('this.rate::bgb',this.rate);
                t1 = performance.now();
              }, this.ms * (1/this.rate))
              
            }
            
            restart(){
              
              //$lg('10812::timeserver.start',`event:'${event}'`);
              //this.ms = parseInt( ms * 0.95 );
              //let t1 = performance.now();
              //$lg('13211::timeserver.restart::bgo',`ms:'${ms}'`);
              //$lg('13211::timeserver.rrstart::bgo',`ms:'${this.ms}'`);
              
              this.paused = 0;  
  
              //if( rate )this.rate = rate;
  
              this.timeElapse = 0;
              
              this.iid = self.setInterval(()=>{
                
                if( this.paused ) return;
                
                //this.timeElapse +=  this.inc/1000 * (1/this.rate);
                
                self.postMessage({op:'report',da:{event:event}});
                //$lg('timeup::bgb',parseInt(performance.now()-t1));
                //t1 = performance.now();
              }, this.ms * (1/this.rate))
              
            }
            
            pause(){
              
              this.paused = 1;
              self.clearInterval(this.iid);
              
            }
            
            stop(){
              
              self.clearInterval(this.iid);
              
            }
            
            setRate( rate ){
              
              this.rate = rate;
              //this.stop();
              //this.restart();
              //let t1 = performance.now();
              self.clearInterval(this.iid);
              
              this.iid = self.setInterval(()=>{
                
                if( this.paused ) return;
                
                //this.timeElapse +=  this.inc/1000 * (1/this.rate);
                
                self.postMessage({op:'report',da:{event:event}});
                //$lg('setRate-timeup::bgo',parseInt(performance.now()-t1));
                t1 = performance.now();
              }, this.ms * (1/this.rate))
              
              
            }
            
            getTimeElapse(){
              
              return this.timeElapse;
              
            }
            
          }
  
          let messageFromHost = {
            
            start   : (op,da)=>{
              timer.start(da.ms,da.rate,da.event);
              //self.postMessage({op:op,da:{msg:'started'}});
              
            },
            
            pause   : (op,da)=>{
              timer.pause();
              
            },
            
            stop    : (op,da)=>{
              
              timer.stop();
          
            },
  
            setRate : (op,da)=>{
              
              let rate = da.rate;
              
              timer.setRate( rate );
              //self.postMessage({op:op,msg:'adjTime done',dat:da});
  
            },
            
          }
          
          ///////////////////////////////
          new Handler( messageFromHost )
          
          let timer = new timeService();
          
          //$lg('script is running');
          
        },
        
        messageFromWorker  : (event)=>{
            let data = event.data;
            let op  = data.op;
            let da  = data.da;
            
            let fn = Reflect.get(this.service.time.rsp,op);
            if(fn)fn(op,da);
        },
        
        errorFromWorker    : (e)=>{
            $lg('156::err:',e.message);
        },
        
        init   : async ()=>{
            //$lg('1380::webman.start',Log.now());
            this.timeSvr.script = this.service.time.script;
            this.timeSvr.onmessage = this.service.time.messageFromWorker;
            this.timeSvr.onerror = this.service.time.errorFromWorker;
            await this.timeSvr.start();
            //$lg('timeService init done');
        },
        
        pars   : {
            addr : '../include/handler.php',
            file : '../app/dat/data.sqlite3',
        },
    
        req    : {
    
          start : (ms,rate,event='timeupdate2')=>{
            //$lg('10928::req,start',rate,event);
            this.timeSvr.post({op:'start',da:{ms:ms,rate:rate,event:event}});
          },
          
          pause : ()=>{
            this.timeSvr.post({op:'pause',da:null});
          },
          
          setRate : ( rate )=>{
            this.timeSvr.post({op:'setRate',da:{rate}});
          },
          
      
          stop   : ()=>{ 
              this.timeSvr.stop();
          },
        
        },
        
        rsp    : {
          
          report : (op,da)=>{
            //$lg('10949::this.service.time.report::bgb',`${da.event}`,Log.now());
            
            let event = new CustomEvent( da.event );
            if( da.event == 'timeupdate2' ) this.myAudio.dispatchEvent(event);
            else document.dispatchEvent(event);
            return this;
          },
          
          start : (op,da)=>{
            
            return this;
          },
          
          lg : (op,da)=>{
            $lg(...da);
            return this;
          },
          
        },
        
        post   : (...args)=>{
            this.timeSvr.post(...args);
        },
        
      },
      
      data : {
          
        worker : ()=>{
        
          //importScripts('http://127.0.0.1:8080/project/import/module/ajs_worker.js')
          
          function $lg(...anyStr){
            let op = 'lg';
            let da = [...anyStr];
            self.postMessage({op,da});
            return this;
          }
          function $lgg(...anyStr){
            let op = 'lgg';
            let da = [...anyStr];
            self.postMessage({op,da});
            return this;
          }
          
          class Xhr{
            constructor(addr,type='json',key='opda'){
              this.addr = addr;
              //$lg('6193::xhr::addr',addr);
              this.opda = '';//this.pack(op,da);
              this.key = key;
              this.header = this.headers.app;
              //this.rsp(rsp,err);
              this.type = type;
              
              //$lg('6329::this.header',this.header);
              
            }
            
            headers = {
              
                app       : "application/x-www-form-urlencoded; charset=UTF-8",
                
                es        : "text/event-source",
                
                html      : "text/html",
                
                fmdata    : ()=>{
                  let s = Math.random();
                      s = encodeURIComponent(s);
                      //$lg('6341::xhr::s',s);
                  let h = `multipart/form-data; boundary=----<${s}>----`;
                  $lg('6343::xhr::h',h);
                  
                  return h;
                },
            }
            
            setHeader(s){
              let h = Reflect.get(this.headers,s);
              let t = typeof(h);
              if( t == 'string' )   this.header = h;else 
              if( t == 'function')  this.header = h();else 
              if( t == 'undefined') this.header = s;
              return this;
            }
            
            key(k){
              this.key = k;
              return this;
            }
            
            pack(op,da) {
          
              let key   = this.key;
              let value = {
                  op      : op,
                  da      : da
              };
              let gift = encodeURIComponent( key ) + "=" + encodeURIComponent( JSON.stringify(value) );
              //let opda = properEncodeURIComponent( key ) + "=" + properEncodeURIComponent( JSON.stringify(value) );
              return gift;
              
            }
            
            req = (addr,opda)=>{
              //$lg('Xhr::req:2993:',addr,opda);
              let promise = new Promise((resolve, reject)=>{
                let type    = this.type;//json
                //let header  = "application/x-www-form-urlencoded; charset=UTF-8";
                let header  = this.header;
                //let header  = "text/event-source";
                let handler = function(){
                    if (this.readyState !== 4) {
                      return;
                    }
                    if (this.status === 200) {
                      resolve(this.response);
                    } else {
                      reject(new Error(this.statusText));
                    }
                };
              
                let http = new XMLHttpRequest();
                     //alert('Log::2999:this.pget:'+this.pget);
                      
                  //$lg('Ajs::Xhr:req:3012');
                  http.timeout = 1000 * 20;
                  //let opda = task_build_request(user, op, da);
                  http.open('post', addr,true);
                  http.setRequestHeader("Content-Type",header);
                  http.onreadystatechange = handler;
                  //http.setRequestHeader("Connection","Keep-Alive");
                  //http.setRequestHeader("Keep-Alive","timeout=50, max=100");
                  http.responseType = type;
                  http.send(opda);    
                      
              });
              return promise;
            }
            
            ask(op,da=null){
              this.opda = this.pack(op,da);
              return this;
            }
            
            
            up(formdata){
              this.setHeader('fmdata')
              $lg('6420::this.header',this.header);
              this.opda = formdata;
              return this;
            }
            
            upload(...args){
              return this.up(...args);
            }
            
            /**
             * rsp  : respone
             * suc  : callback function
             * err  : callback function
             **/ 
            rsp(suc,err){
              this.req(this.addr,this.opda)
                  .then(function(data) {
                      suc(data);
                      //$lg('11717::Contents: ' + data);
                  }, function(error) {
                      err(error);
                      $lg('出错了', error);
                  });
            }
            
          }
          
          class Sqlike{
  
              constructor(addr){
                  //$lg('8288::Sqlike::constructor');
                  this.pars = {
                    
                      tables  : [],
                    
                  },
                  
                  this.addr = addr;
                
              }
              
              run = (op,da)=>{
               // $lg('sqlike::11659::addr,op,da::bgg',this.addr,op,JSON.stringify(da));
                return new Promise((res,rej)=>{
                    new Xhr(this.addr)
                    .ask(op,da)
                    .rsp((data)=>{
                        //$lg('ajs_worker.js::8978::data::bgg',data);
                        /*
                        if(/<b>Warning<\/b>/i.test(data)){
                          if(/near/i.test(data)){
                            if(/syntax error/i.test(data)){
                              rej(data);
                            }
                          }
                        }
                        */
                        //let obj = JSON.parse(data);
                        /*let da  = obj.da;
                        let dat = da.dat;
                        $lg('8300::dat::bgy',dat);
                        */
                        res(data);
                        /*
                        let ui = new Ui();
                        let tbl = new ui.table(dat);
                            tbl.done();*/
                        //$lg('100::dat',dat.id,dat.word,dat.pronun,dat.meaning,dat.english);
                    },(err)=>{
                        $lg('8304::err::bgo',err);
                        rej(err);
                    })
                })
              }
              
              tableWriter = (tableName,colArr)=>{
                  let tsl = (str)=>{
                    if(str == '') return '';
                    let arr = str.split(',');
                    let rst = '';
                    for(let ss of arr){ 
                      let s = ss.toLowerCase();
                      if(s == 'pri')  {rst += ' PRIMARY KEY'}else
                      if(s == 'auto') {rst += ' AUTOINCREMENT'}else
                      if(s == 'uni')  {rst += ' UNIQUE'}else
                      if(s == 'not')  {rst += ' NOT NULL'}else
                      if(s == 'def')  {rst += ' DEFAULT'}
                      else{rst += ` ${ss}`}
                    }
                    return rst;
                  }    
                  let cmds = [];
                      cmds.push(`DROP TABLE IF EXISTS ${tableName};\n`);
                      cmds.push(`CREATE TABLE IF NOT EXISTS ${tableName}(\n`);
                  let i = -1;
                  for( let dat of colArr){
                      i++;
                      let col  = dat[0];
                      let type = dat[1];
                      let cons = dat[2] == null ? '' : dat[2];
                          cons = tsl(cons);
                      if(col == 'id' && cons == '')cons  = ' PRIMARY KEY AUTOINCREMENT';
                      let tail = i == colArr.length-1 ? '\n);' : ',\n';
                      let line = `  ${col.padEnd(10,' ')} ${type.padEnd(12,' ')} ${cons}${tail}`;
                      cmds.push(line);
                  }
                  let sql = cmds.join('');
                  //$lg('9191::sql::bgy',sql);
                  return sql;
        
              }
              
              indexWriter = (tableName,colArr)=>{
        
                  let cmds = [];
                  
                  for( let dat of colArr){
                      
                      let col  = dat[0];
                      let type = dat[1] == undefined ? 'INDEX' : dat[1];
                      
                      let line = `CREATE ${type} IF NOT EXISTS ${tableName}_${col} ON ${tableName}(${col});\n`;
                      cmds.push(line);
                  }
                
                  return cmds.join('');
        
              }
              
              conf  =   {
                
                  table : (name,colsArr)=>{
                      
                      return this;
                      
                  },
                  
                  index : ()=>{
                      
                      return this;
                      
                  },
                  
              }
              
              done  = ()=>{
                  
                  return this;
                  
              }
              
          }
          
          class Handler{
          
              constructor(msgObj){
                this.map = new Map();
                this.add(msgObj);
                this.listen();
              }
              
              listen(){
                self.addEventListener('message',  (e)=>{
                  //$lg('1392::msg from host',JSON.stringify(e.data));
                  let data = e.data;
                  let op = data.op;
                  let da = data.da;
                  this.handle(op,da);
                
                })
              }
              
              handle(op,da){
                let fn = this.map.get(op);
                if(fn){
                  fn(op,da);
                }
              }
              
              add = (fnObj)=>{
                let keys = Object.keys( fnObj );
                keys.forEach((key)=>{
                  let fn = fnObj[key];
                  if(fn)this.map.set(key,fn);
                })
                return this;
              }
              
              post(...args){
                self.postMessage(...args);
              }
              
          }
          
          let reflectPolyfill = ()=>{
            
            if (!Reflect) {
              Reflect = {
                get(target, propertyKey, receiver) {
                  return target[propertyKey];
                },
                set(target, propertyKey, value, receiver) {
                  target[propertyKey] = value;
                  return true;
                },
                deleteProperty(target, propertyKey) {
                  delete target[propertyKey];
                  return true;
                }
                // 其他 Reflect 方法的 Polyfill 实现
              };
            }
            
          }
          
          let php = {
              addr : 'http://127.0.0.1:8080/project/include/handler.php',
              file : '../app/dat/data.sqlite3',
              book : '../app/dat/gmbook.sqlite3',
          }
          
          let sql = {
        
            run   : (sqlText,dbFile = null)=>{
                
                let act   = 'run';
                let sql   = sqlText;
                let file  = dbFile == null ? php.file : dbFile;
                let addr  = php.addr;
                let op    = 'data__run_cmd';
                let da    = { sql,act,file };
                let sqlike = new Sqlike(addr);
                
                return  sqlike.run(op,da);
                
            },
            
            que   : (sqlText,dbFile = null)=>{
                //$lg('11679::sql.que::bgb')
                let act   = 'que';
                let sql   = sqlText;
                let file  = dbFile == null ? php.file : dbFile;
                
                let addr  = php.addr;
                let op    = 'data__run_cmd';
                let da    = { sql,act,file };
                
                //$lg('11679::sql.que::bgb',addr,file);
                
                let sqlike = new Sqlike(addr);
                  
                return sqlike.run(op,da)
                
            },
            
            getData : (sqlText,arr)=>{
                let act   = 'dat';
                let sql   = sqlText;
                let file  = this.php.file;
                let addr  = this.php.addr;
                let op    = 'data__run_cmd';
                let da    = { sql,arr,act,file };
                let sqlike = new Sqlike(addr);
                sqlike.run(op,da).then((dat)=>{
                    ok(dat);
                },(err)=>{
                    $lg('1906::bgo',err);
                    rej(err);
                })
            },
            
            getResult : (sqlText,arr)=>{
                let act   = 'rst';
                let sql   = sqlText;
                let file  = this.php.file;
                let addr  = this.php.addr;
                let op    = 'data__run_cmd';
                let da    = { sql,arr,act,file };
                let sqlike = new Sqlike(addr);
                sqlike.run(op,da).then((dat)=>{
                    ok(dat);
                },(err)=>{
                    $lg('1920::bgo',err);
                    rej(err);
                })
            },
            
          }
          
          let dat = {

              buildTable : async ()=>{
                  $lg('6339::buildTable::bgy');
                  //return;
                try{
                  let songCol = [
                    ['id',      'INTEGER'],
                    ['caid',    'INTEGER'],
                    ['name',    'varchar', 'uni'],
                    ['part',    'smallint'],
                    ['pid',     'smallint'],
                    ['lang',    'tinyint', 'def,0'],
                    ['time',    'DATETIME']
                  ];
                  
                  let songIdx = [
                    ['name'],
                    ['singer'],
                    ['special'],
                    ['lang']
                    
                  ];
                  
                  /*
                  type
                    0 单词
                    1 标点符号 , . : ! ?
                    2 缩写 's 'll 've 't
                    3 数字 0-9
                    
                  */
                  let wordCol = [
                    ['id',         'INTEGER'],
                    ['sid',        'INTEGER',     'nn'],
                    ['lidx',       'INT',         'nn'],
                    ['idx',        'INT',         'nn'],
                    ['word',       'varchar',     'nn'],
                    ['type',       'tinyint',        'def,0'],
                    ['len',        'tinyint',        'def,0'],
                    ['lang',       'tinyint','def,0'],// language
                  //['upidx',      'INT8',        'def,-1'],
                  //['uppos',      'INT8',        'def,0'],
                    ['start',      'MEDIUMINT UNSIGNED INT'],//4小时mp3,240MB
                    ['end',        'MEDIUMINT UNSIGNED INT'],
                    ['dur',        'SMALLINT UNSIGNED INT']
                  
                    //['md5',        'varchar(32)', 'uni,nn'],
                    //['time',       'DATETIME']
                  ];
                  
                  let wordIdx = [
                    ['lidx'],
                    ['sid'],
                    ['idx'],
                    ['word']
                  ];
                  
                  let mp3Col  = [
                    ['id',      'INTEGER'],
                    ['sid',     'INTEGER',  'def,-1'],
                    ['part',    'smallint', 'def,-1'],
                    ['pid',     'smallint', 'def,-1'],
                    ['name',    'varchar',  'uni,nn'],
                    ['time',    'DATETIME']
                  ];
                
                  let awareCol = [
                    ['id',         'INTEGER'],
                    ['sid',        'INTEGER'      ],
                    ['lidx',       'INT'          ],
                    ['idx',        'INT'          ],
                    ['word',       'varchar', 'nn' ],
                    ['val',        'INT2',      , 'nn' ],
                    ['memo',       'varchar' ],
                    ['time',       'DATETIME']
                    
                  ];
                  
                  let awareIdx = [
                    ['lidx'],
                    ['sid'],
                    ['idx'],
                    ['word']
                  ];
                
                  let memoCol = [
                    ['id',         'INTEGER'],
                    ['sid',        'INTEGER'      ],
                    ['lidx',       'INT'          ],
                    ['widx',       'INT'          ],
                    ['memo',       'text' ],
                    ['type',       'int8'  ],
                    ['time',       'DATETIME']
                    
                  ];
                  
                  let cataCol = [
                    ['id',         'INTEGER'],
                    ['upid',       'INTEGER' , 'nn,def,0' ],
                    ['od',         'INT' , 'def,0' ],
                    ['name',       'varchar' ,'nn' ],
                    ['time',       'DATETIME']
                  ];
                  
                  let wordTreeCol = [
                    ['id',         'INTEGER'],
                    ['sid',        'INTEGER'],
                    ['lidx',       'smallint'],
                    ['widx',       'smallint'],
                    ['up',         'smallint',  'def,-1' ],//widx
                    ['od',         'smallint',  'def,0' ],//order
                    ['pos',        'tinyint' ,  'def,0' ],
                    ['hide',       'tinyint' ,  'def,0' ],
                    ['word',       'varchar',   'nn' ],
                    ['type',       'tinyint',   'def,0' ],
                    ['dir',        'boolen',    'def,0' ],
                    ['flex',       'smallint',  'def,7' ],
                    ['fold',       'boolen',    'def,1' ],
                  ];
                  
                  let tagCol = [
                    ['id',         'INTEGER'],
                    ['tag',        'varchar(32)' ],
                    ['caid',       'INTEGER', 'def,-1' ],//cata id
                    ['num1',       'INTEGER', 'def,-1' ],//relative id  : sid
                    ['num2',       'INTEGER', 'def,-1' ],//relative id  : lidx
                    ['num3',       'INTEGER', 'def,-1' ],//relative id  : widx
                    ['text1',      'varchar', 'def,null' ],//tableName : 'word'
                    ['text2',      'varchar', 'def,null' ],//key       : 'speaker'
                    ['text3',      'varchar', 'def,null' ],//descript  : 'sid,lidx'
                    ['time',       'DATETIME']
                  ];
                  
                  let voiceCol = [
                    ['id',         'INTEGER'],
                    
                    ['sid',       'INTEGER' ,'nn' ],
                    ['lidx',      'INTEGER'  ],
                    ['memoid',    'INTEGER'  ],
                    ['start',     'REAL' ,'nn' ],
                    ['end',       'REAL' ,'nn' ],
                    
                  ];
                  
                  let bookCol = [
                    ['id',         'INTEGER'],
                    ['up',         'INTEGER','def,0'  ],
                    ['line',       'INTEGER'  ],
                    ['content',    'text'  ],
                    ['type',       'int8'  ]
                  ];
                  
                  let optionsCol = [
                    ['id',         'INTEGER'],
                    ['tag',        'varchar(16)'  ],
                    ['key',        'varchar(32)'  ],
                    ['val',        'text'  ]
                  ];
                  
                  let activityCol = [
                    ['id',         'INTEGER'],
                    ['sid',        'INTEGER'  ],
                    ['lidx',       'smallint'  ],
                    ['widx',       'smallint'  ],
                    ['word',       'varchar'  ],
                    ['type',       'tinyint'  ],
                    ['action',     'smallint'  ],
                    ['value',      'tinyint'  ],
                    ['ms',         'INTEGER'  ],
                    ['time',       'datetime'  ]
                    
                  ];
                  
                  let sqlike  = new Sqlike(php.addr);
                  let tbl = sqlike.tableWriter;
                  let idx = sqlike.indexWriter;
                  
                  //let addr  = this.php.addr;
                  let file  = php.file;
                  let book  = php.book;
                  let act   = 'run';
                  
                  
                  let op    = 'data__run_cmd';
                  let da    = [];
                      da[0] = {file,act,sql:tbl('song',   songCol )};
                      //da[1] = {file,act,sql:idx('song',   songIdx )};
                      da[2] = {file,act,sql:tbl('word',   wordCol )};
                      //da[3] = {file,act,sql:idx('word',   wordIdx )};
                      //da[4] = {file,act,sql:tbl('mp3',    mp3Col  )};
                      //da[5] = {file,act,sql:tbl('aware',  awareCol )};
                      //da[6] = {file,act,sql:idx('aware',  awareIdx )};
                      da[7] = {file,act,sql:tbl('memo',   memoCol  )};
                      da[8] = {file,act,sql:tbl('cata',   cataCol  )};
                      da[9] = {file,act,sql:tbl('tag',    tagCol  )};
                    
                      //da[11] = {file,act,sql:tbl('voice',    voiceCol  )};
                      //da[12] = {file:book,act,sql:tbl('book',    bookCol  )};
                      da[13] = {file,act,sql:tbl('wordTree',    wordTreeCol  )};
                      da[14] = {file,act,sql:tbl('option',    optionsCol  )};
                      
                      da[16] = {file,act,sql:tbl('activity',    activityCol  )};
                  let exe = [];
                      exe.push(13);
                  //$lg('12505::exe',exe);
                  let rst = 0;
                  for(let i=0; i<17; i++ ){
                      //$lg('12508::e',e);
                      //$lg('12509',JSON.stringify(da[e]));
                      //if( da[e] == null ) continue;
                      //let rsp = await sqlike.run(op,da[e])
                      if( !exe.includes(i) ) continue;
                      if( da[i] == undefined ) continue;
                      let rsp = await sqlike.run(op,da[i])
                      
                      if( rsp.da.rst == false ) alert( `6562::${rsp.da.msg}` );
                      else rst++;
                      $lg('6565::rsp',JSON.stringify(rsp));
                  }
                  
                  
                }catch(e){
                  alert(e.message);
                }
                  
                return {success : rst};
                  
              },
              
              fission : async (name, num)=>{
                  $lg('12491','fission');

                  if(/^(mp3|img|voice)$/.test(name) == false ) return null;

                  const number = num.toString().padStart(4,'0');

                  const fname = `../app/dat/${name}_${number}.sqlite3`;

                  let map = new Map();
                      map.set('img', 0);
                      map.set('mp3', 1);
                      map.set('voice',  2);
                  
                  let which = map.get(name);
                  
                  let imgCol = [
                    ['id',         'INTEGER'],
                    ['title',      'varchar'],
                    ['ext',        'varchar'],
                    ['md5',        'varchar','uni'],
                    ['dat',        'BLOB'  ],
                  ];
                  
                  let mp3Col = [
                    ['id',         'INTEGER'],
                    ['title',      'varchar'],
                    ['ext',        'varchar'],
                    ['md5',        'varchar','uni'],
                    ['dat',        'BLOB'  ],
                  ];
                  
                  let wordCol = [
                    ['id',         'INTEGER'],
                    ['sid',        'INTEGER',     'nn'],
                    ['lidx',       'INT',         'nn'],
                    ['idx',        'INT',         'nn'],
                    ['word',       'varchar(36)', 'nn'],
                    ['type',       'INT8',        'def,0'],
                    ['len',        'INT8',        'def,0'],
                    ['start',      'MEDIUMINT UNSIGNED INT'],//4小时mp3,240MB
                    ['end',        'MEDIUMINT UNSIGNED INT'],
                  
                  ];
                  
                  let sqlike  = new Sqlike(php.addr);
                  let tbl = sqlike.tableWriter;
                  let idx = sqlike.indexWriter;
                  
                  //let addr  = this.php.addr;
                  let file  = fname;
                  
                  let act   = 'run';
                  
                  let op    = 'data__run_cmd';
                  let da    = [];
                      da[0] = {file,act,sql:tbl('img',   imgCol )};
                      da[1] = {file,act,sql:tbl('mp3',   mp3Col )};
                      da[2] = {file,act,sql:tbl('voice', mp3Col )};
                      
                  return sqlike.run(op,da[ which ]);

              },
              
              incTable : {
                
                aware : async ()=>{
                  //$lg('1750','buildTable');
      
                  let awareCol = [
                    ['id',         'INTEGER'],
                    ['sid',        'INTEGER'      ],
                    ['lidx',       'INT'          ],
                    ['idx',        'INT'          ],
                    ['word',       'varchar(36)', 'nn' ],
                    ['val',        'INT2',      , 'nn' ],
                    ['time',       'DATETIME']
                    
                  ];
                  
                  let awareIdx = [
                    ['lidx'],
                    ['sid'],
                    ['idx'],
                    ['word']
                  ];
                  
      
                  let sqlike  = new Sqlike(php.addr);
                  let tbl = sqlike.tableWriter;
                  let idx = sqlike.indexWriter;
                  
                  //let addr  = php.addr;
                  let file  = php.file;
                  let act   = 'run';
                  
                  
                  let op    = 'data__run_cmd';
                  let da    = [];
                      da[0] = {file,act,sql:tbl('aware',awareCol)};
                      da[1] = {file,act,sql:idx('aware',awareIdx)};
                      
                  
                  for(let di of da){
                      await sqlike.run(op,di)
                  }
                },
                
              },
              
              tableWord : {
                
                  split  : async (song_id,text)=>{
                      
                      text = text.toString();
                      
                      //split to lines
                      let lines = text.split('\.');
                      
                      //for of lines
                      let L = -1;
                      for(let line of lines){
                          L++;
                          //split to words
                          let words = line.split(' ');
                          await dat.words.add(song_id,L,words);
                      }
                      
                  },
                  
                  batAdd : async (sid,lrc)=>{
                      $lg('1860::batAdd');
                      let sqlText = `INSERT INTO word(sid,lidx,idx,word,type,start,end) VALUES`;
                      let i = 0;
                      /*let L = 0;
                      let arr = [];
                      let fail = [];*/
                      $lg('2590:lines.len',lrc.lines.length);
                      
                      for(let objLine of lrc.lines){
                          if(objLine == null){continue;}
                          //L++;
                          let lidx = objLine.idx;
                          //$lg('1866::lidx',lidx);
                          for(let objWord of objLine.words){
                              if(objWord == null){continue;}
                              const idx   = objWord.idx;
                              //let word = objWord.word;
                              const word  = objWord.word.replace("'",'\u2032');
                              const type  = objWord.type;
                              const start = objWord.start;
                              const end   = objWord.end;
                              //const md5   = SparkMD5.hash(`${sid}-${lidx}-${idx}-${word}`);
                              //const datetime = "datetime('YYYY-MM-DD HH:MM:SS.SSS','localtime')";
                              //const time = "strftime('%Y-%m-%d %H:%M:%f','now')";
                      
                              /*if((new RegExp(md5)).test(sqlText)){
                                $lg('2961::bgo',md5,`${sid}-${lidx}-${idx}-${word}`);
                              }*/
                              sqlText += ','.repeat(i)+`\n(${sid},${lidx},${idx},'${word}',${type},${start},${end})`;
                              i=1;
                          }
                          /*if(L == Math.floor(lrc.lines.length/2)){
                            arr.push(sqlText);
                            sqlText = 'INSERT INTO word(sid,lidx,idx,word,start,end,md5) VALUES';
                            i=0;
                          }*/
                          //sqlText += ';';
                      }
                      //$lgg('1875::sqlText',sqlText);
                      $lg('15610::sqlText.length',sqlText.length);
                      await sql.run(sqlText);
                      
                      return dat.tableWord.updateLen(sid);
                      
                      /*for(sqlText of arr){
                        let r = await sql.run(sqlText);
                        if(r.da.rst == false)fail.push(r);
                      }
                      
                      if(fail.length == undefined) return true;
                      return false;*/
                      
                  },
                  
                  getWord : ( sid )=>{
                    
                    let sqlText = `
                        select lidx,idx,word,type,start,end 
                        from word 
                        where sid = ${sid} 
                        order by lidx asc,idx asc 
                    `;
                    //$lg('4473::start::bgg',Log.now());
                    return sql.que(sqlText);

                  },
                  
                  remove : (sid)=>{
                      
                          //$lg('2620::remove');
                          let sqlText = `
                            Delete 
                            From word 
                            WHERE sid = ${sid}
                          `;
                          
                          //$lg('2625::sqlText',sqlText);
                          return sql.run(sqlText)
                      
                  },
                  
                  removeOne : (sid,lidx,widx)=>{
                       
                      //$lg('2620::remove');
                      let sqlText = `Delete 
                                     From word 
                                     WHERE sid = ${sid} AND lidx = ${lidx} AND idx = ${widx}`;
                      
                      $log.lgg('2625::sqlText',sqlText);
                     return sql.run(sqlText);
                    
                  },
                  
                  removeSentence : (sid,lidx)=>{
                       
                      //$lg('2620::remove');
                      let sqlText = `Delete 
                                     From word 
                                     WHERE sid = ${sid} AND lidx = ${lidx}`;
                      
                      //$log.lgg('2625::sqlText',sqlText);
                     return sql.run(sqlText);
                    
                  },
                  
                  update : (sid,lidx,idx,word)=>{
                          word = word.replace("'",'\u2032');
                          //$lg('2620::remove');
                          let sqlText = `UPDATE word
                                         SET word = '${word}'
                                         WHERE sid = ${sid} AND lidx = ${lidx} AND idx = ${idx}`;
                          
                          //$lg('2625::sqlText',sqlText);
                          return sql.run(sqlText);
                      
                  },
                  
                  copyReplace : (sid,lidx,copyIdx,idx,word)=>{
                          word = word.replace("'",'\u2032');
                          //$lg('2620::remove');
                          let sqlText = ` insert into word(sid,lidx,idx,word,type,start,end) 
                                          select sid,lidx,${idx},'${word}',type,start,end
                                          from word 
                                          WHERE sid = ${sid} AND lidx = ${lidx} AND idx = ${copyIdx}`;
                          
                          //$lgg('11329::sqlText',sqlText);
                          return sql.run(sqlText);
                      
                  },
                  
                  setTime : (sid,lidx,idx,start,end)=>{
                      
                          //$lg('1993::setTime');
                          let sqlText = `UPDATE word 
                                         SET start = ${start} , end = ${end}   
                                         WHERE sid = ${sid} AND lidx = ${lidx} AND idx = ${idx}`;
                          
                          //$lg('1998::sqlText',sqlText);
                          return sql.run(sqlText);
                    
                  },
                  
                  setType  : (sid,lidx,idx,val)=>{
                      return new Promise((res,rej)=>{
                          //$lg('2707::remove');
                          let sqlText  = `UPDATE word 
                                          SET type = ${val} 
                                          WHERE sid = ${sid} AND lidx = ${lidx} AND idx = ${idx}`;
                              
                          //$lg('2712::sqlText',sqlText);
                          sql.run(sqlText).then((rsp)=>{
                              if(rsp.da.rst == 1) {
                                //$lg('2715::res::bgg',JSON.stringify(rsp));
                                res(rsp);
                              }
                              else {
                                $lg('2719::rej::bgo',JSON.stringify(rsp));
                                rej(rsp);
                              }
                          })
                      })
                  },
                  
                  updateLen  : (sid)=>{
                    
                    //$lg('2707::remove');
                    let sqlText  = `UPDATE word 
                                    SET len = length(word) 
                                    WHERE sid = ${sid}`;
                        
                    //$lg('2712::sqlText',sqlText);
                    return sql.run(sqlText)
                    
                    
                  },
                  
                  
                  getWordsByLine : async (sid,lidx)=>{
                    
                      let sqlText = ` SELECT idx,word,type,start,end
                                      FROM word 
                                      WHERE sid = ${sid} AND lidx = ${lidx}
                                      order by idx asc`;
      
                      let rsp = await sql.que(sqlText);
                      if(rsp.da.rst == true){
                        let obj = (rsp.da.dat.arr)[0];
                        let num = obj[0];
                        //alert('newWordNum:'+num);
                        return num;
                      }else{
                        $lg('1855::errot::bgo',rsp.da.msg);
                        return false;
                      }
                  
                  },
                  
                  getNumberOf : {
                    
                    //排队标点和数字,全部词，包括重复
                    allArticle : async ()=>{
                      
                      //$lg('15872:tableWord.getNumberOf.allArticle');
                      
                      let sqlText = ` 
                        select count(word) as num
                        from word 
                        where  sid = ${sid}
                      `;
                      let rsp = await sql.que(sqlText);
                      
                      //$lg('15882:rsp',JSON.stringify(rsp));
                      
                      if(rsp.da.rst == false) return 0;
                      if(rsp.da.dat.arr.length == 0) return 0;
                      
                      return rsp.da.dat.arr[0][0];
                      
                    },
                    
                    //排队标点和数字,全部词，包括重复
                    thisArticle : async (sid)=>{
                      
                      //$lg('15872:tableWord.getNumberOf.thisArticle');
                      
                      let sqlText = ` 
                        select count(word) as num
                        from word 
                        where  sid = ${sid}
                      `;
                      let rsp = await sql.que(sqlText);
                      
                      //$lg('15882:rsp',JSON.stringify(rsp));
                      
                      if(rsp.da.rst == false) return 0;
                      if(rsp.da.dat.arr.length == 0) return 0;
                      
                      return rsp.da.dat.arr[0][0];
                      
                    },
                    
                    //不重复
                    notRepeat : async (sid)=>{
                      
                      let sqlText = ` select count(distinct word) as num
                                      from word 
                                      where type=0 and sid = ${sid};`;
                      let rsp = await sql.que(sqlText);
                      
                      if(rsp.da.rst == false) return 0;
                      if(rsp.da.dat.arr.length == 0) return 0;
                      
                      return rsp.da.dat.arr[0][0];
                    },
                    
                    //熟悉词
                    friend : async (sid)=>{
                      //aware表中val==1为认识的单词，所有认识的单词作为参考
                      //与target目标表中单词inner join 或者 进行子查询
                      /*let sqlText = ` SELECT COUNT( target.word ) AS num 
                                      FROM (  SELECT word 
                                              FROM word 
                                              WHERE sid = ${sid} AND type=0  
                                              GROUP BY word ) AS target 
                                      INNER JOIN (  
                                              SELECT word  
                                              FROM aware 
                                              WHERE val=1 
                                              GROUP BY word ) AS ref  
                                      ON target.word = ref.word
                                      `;*/
                      let sqlText = ` 
                        SELECT COUNT( target.word ) AS num 
                        FROM (  SELECT distinct word 
                                FROM word 
                                WHERE sid = ${sid} AND type=0  
                        ) AS target 
                        where target.word in(
                          SELECT word
                          FROM activity
                          GROUP BY word 
                          having max(time) and value > 0
                        )
                      `;
                      
                      let rsp = await sql.que(sqlText);
                      
                      //$lg(JSON.stringify(rsp));
                      
                      if(rsp.da.rst == false) return 0;
                      if(rsp.da.dat.arr.length == 0) return 0;
                      
                      return rsp.da.dat.arr[0][0];
                      
                    },
                    
                    //陌生词
                    stranger : async (sid)=>{
                      // 某篇文章实时统计出的陌生词
                      let sqlText = ` 
                        SELECT COUNT( target.word ) AS num 
                        FROM (  SELECT distinct word 
                                FROM word 
                                WHERE sid = ${sid} AND type=0  
                        ) AS target 
                        where word in(
                          SELECT word
                          FROM activity
                          GROUP BY word 
                          having max(time) and value < 0
                        )
                      `;
                      
                      let rsp = await sql.que(sqlText);
                      
                      if(rsp.da.rst == false) return 0;
                      if(rsp.da.dat.arr.length == 0) return 0;
                      
                      return rsp.da.dat.arr[0][0];
                    },
                    
                    //未标注
                    notMarked : async (sid)=>{
                      //aware表中val==1为认识的单词，所有认识的单词作为参考
                      //与target目标表中单词inner join 或者 进行子查询
                      /*let sqlText = ` SELECT COUNT( target.word ) AS num 
                                      FROM (  SELECT word 
                                              FROM word 
                                              WHERE sid = ${sid} AND type=0  
                                              GROUP BY word ) AS target 
                                      INNER JOIN (  
                                              SELECT word  
                                              FROM aware 
                                              WHERE val=1 
                                              GROUP BY word ) AS ref  
                                      ON target.word = ref.word
                                      `;*/
                      let sqlText = ` SELECT COUNT( target.word ) AS num 
                                      FROM (  SELECT distinct word 
                                              FROM word 
                                              WHERE sid = ${sid} AND type=0  
                                      ) AS target 
                                      where word not in(
                                        SELECT word
                                        FROM activity
                                        GROUP BY word 
                                        
                                      )
                                      `;
                      
                      let rsp = await sql.que(sqlText);
                      
                      if(rsp.da.rst == false) return 0;
                      if(rsp.da.dat.arr.length == 0) return 0;
                      
                      return rsp.da.dat.arr[0][0];
                      
                    },
                    
                    maxLineIdx : async (sid)=>{
                      if(sid) sid = parseInt( sid );
                      //$lg('12155::tableWord.getNumberOf.maxLineIdx',sid);
                      
                        let sqlText = ` 
                          SELECT max(lidx) as lidx
                          FROM word 
                          WHERE sid = ${sid}
                        `;
        
                        let rsp = await sql.que(sqlText);
                        
                        if(rsp.da.rst == false) return 0;
                        
                        if(rsp.da.dat.arr.length == 0) return 0;
                        
                        return rsp.da.dat.arr[0][0];
                    },
                    
                    //总单词数
                    wordCount : async ()=>{
                      
                      //$lg('12155::tableWord.getNumberOf.maxLineIdx',sid);
                      
                        let sqlText = ` 
                          SELECT count(distinct word) as num
                          FROM word 
                          where type = 0
                        `;
        
                        let rsp = await sql.que(sqlText);
                        
                        if(rsp.da.rst == false) return 0;
                        
                        if(rsp.da.dat.arr.length == 0) return 0;
                        
                        return rsp.da.dat.arr;
                    },
                    
                    //单词长度统计
                    wordLength : async ()=>{
                      
                      //$lg('12155::tableWord.getNumberOf.maxLineIdx',sid);
                      
                        let sqlText = ` 
                          select  a.num,
                                  a.len,
                                  round(num * 1.0 /total*100,2)||'%' as pc
                          from(
                             select count(distinct word) as num,len
                             from word
                             where len > 2
                             group by len
                             order by len asc
                          ) as a
                          join(
                             select count(*) as total
                             from word
                             where len > 2
                          ) as b on b.total > 0
                        `;
        
                        let rsp = await sql.que(sqlText);
                        
                        if(rsp.da.rst == false) return 0;
                        
                        if(rsp.da.dat.arr.length == 0) return 0;
                        
                        return rsp.da.dat.arr;
                    },
                    
                  },
                  
                  
                  //for wordTree
                  list    : (sid,lidx)=>{
                      //$lg('7743::tableWord::sid,lidx',sid,lidx);
                      let sqlText = `
                         SELECT idx   AS id,
                                 -1   AS up,
                                  0   as od,
                                  0   as hide,
                               word   as text,
                                  0   as type,
                                  0   as dir,
                                  7   as flex,
                                  1   as fold
                         FROM word
                         WHERE sid = ${sid} AND lidx = ${lidx} 
                         ORDER BY id ASC
                      `;
                      //$log.lgg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  adjIdx : (sid, lidx, where = '>', widx, n = '+1')=>{
                    
                    let sqlText = ` update word 
                                    set idx = idx ${n}
                                    where sid = ${sid} and lidx = ${lidx} and idx ${where} ${widx}`;
                    //$lgg('11545::sqlText',sqlText);
                    return sql.run(sqlText);
                  },
                  
                  insert : (sid,lidx,arr)=>{
                      //$lg('8011::tablewordTree::batAdd');
                      let sqlText = `INSERT INTO word(sid,lidx,widx,upidx,pos,word) VALUES`;
                      let i = 0;
                      for(let a of arr){
      
                        const widx  = a[0];
                        const upidx = a[1];
                        const pos   = a[2];
                        const word  = a[3].replace("'",'\u2032');
      
                        sqlText += ','.repeat(i)+`\n(${sid},${lidx},${widx},${upidx},${pos},'${word}')`;
                        i = 1;
                        
                      }
                      $lg('8025::sqlText',sqlText);
                      return sql.run(sqlText);
                      
                  },
                  
                  //for findword,with time infomation,
                  //so that the word can be sounded
                  listWordsWithTime : (word)=>{
                    if( word ) word = word.toLowerCase()
                    let sqlText = `
                        select a.sid,a.lidx,a.idx,a.word,a.start,a.end,mp3.path
                        from word as a
                        inner join mp3 on mp3.sid = a.sid
                        where a.word like '${word}' and
                              a.type = 0 and
                              a.start > 0 and a.end > 0
                    `;
                    //$lg('4473::start::bgg',Log.now());
                    return sql.que(sqlText);
                  },
                  
                  
                  
                  
              },
              
              tableSong : {
                
                  add     : (name,part=null,pid=null)=>{
                      const time = "strftime('%Y-%m-%d %H:%M:%S','now','localtime')";
                      
                      let sqlText = `INSERT INTO song(name,part,pid,time) 
                                     VALUES('${name}',${part},${pid},${time});`;
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  remove  : (sid)=>{
                      
                          //$lg('2654::remove');
                          let sqlText = `
                            Delete 
                            From song 
                            WHERE id = ${sid}
                          `;
                          
                          //$lg('2659::sqlText',sqlText);
                          return sql.run(sqlText)
                              
                      
                  },
                  
                  getLastId : async ()=>{
                      let sqlText = ` SELECT max(id) 
                                      FROM song 
                                      `;
                      let rsp = await sql.que(sqlText);
                      
                      if(rsp.da.rst == false ) return null;
                      if(rsp.da.dat.arr.length == 0 ) return null;
                      
                      return rsp.da.dat.arr[0][0];
                      
                  },
                  
                  getSongId : async (name)=>{
                    
                      let sqlText = ` SELECT id 
                                      FROM song 
                                      WHERE name = '${name}' 
                                      ORDER BY id DESC 
                                      LIMIT 1;`;
                      let rsp = await sql.run(sqlText);
                      
                      if(rsp.da.rst == 0) return null;
                      if(rsp.da.dat.arr.length == 0) return null;
                      
                      return rsp.da.dat.arr[0][0];

                  },
                  
                  getName : async (id)=>{
                    
                      let sqlText = ` 
                        SELECT name
                        FROM song 
                        WHERE id = ${id}
                      `;
                      let rsp = await sql.que(sqlText);
                      
                      if(rsp.da.rst == false ) return null;
                      if(rsp.da.dat.arr.length == 0 ) return null;
                      
                      return rsp.da.dat.arr[0][0]
                      
                    
                  },
                  
                  list : {
                    
                    all : ()=>{
                    
                      let sqlText = ` select s.id,s.name,a.time
                                      from song as s
                                      left join(
                                        select sid,time
                                        from activity
                                        group by sid
                                        having max(time)
                                      ) as a on a.sid = s.id
                                      group by s.id
                                      order by a.time desc`;
                      return sql.que(sqlText)
                    
                  },
                    
                    
                  },
                  
                  lockMedia   : (sid,part,pid)=>{
                      
                      let sqlText = `
                        update song
                        set part  = ${part},
                            pid   = ${pid}
                        where id = ${sid}
                      `;
                      
                      $lg('7401::bgy',sqlText);
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  getPartPid : async (sid)=>{
                    
                      //$lg('15579:getPartPid');
                      
                      let sqlText = `
                        SELECT  part,pid 
                        FROM song 
                        WHERE id = ${sid}
                      `;
                      
                      let rsp = await sql.que(sqlText);
                      
                      //$lg('15590',JSON.stringify(rsp));
                      
                      if( rsp.da.rst == false ) return null;
                      if( rsp.da.dat.arr.length == 0 ) return null;
                      
                      return {
                        part : rsp.da.dat.arr[0][0],
                        pid  : rsp.da.dat.arr[0][1],
                      }
                      
                      
                  },
                  
              },
              
              tablePart : {
                
                glance : (partName,num)=>{
                    let pad = num.toString().padStart(4,'0');
                    let file = `../app/dat/${partName}_${pad}.sqlite3`;
                    let sqlText = `
                      select id,title,length(dat) as byte,ext,md5 
                      from mp3
                    `
                    return sql.que(sqlText,file);
                    
                  },
                  
              },
              
              tableMp3  : {
                
                  add     : (sid,name,part,pid)=>{

                      let date = "strftime('%Y-%m-%d %H:%M:%S','now','localtime')";
                      
                      let sqlText = `INSERT INTO mp3(sid,name,part,pid,time) VALUES(${sid},'${name}',${part},${pid},${date});`;
                      
                      //$log.lgg('7401',sqlText);
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  lockMedia   : (sid,part,pid)=>{
                      
                      let sqlText = `
                        update mp3
                        set part  = ${part},
                            pid   = ${pid}
                        where sid = ${sid}
                      `;
                      
                      //$log.lgg('7401',sqlText);
                      
                      return sql.run(sqlText);
                      
                  },
                
                  check : (path)=>{
                      
                      let sqlText = `SELECT  id,sid
                                     FROM mp3 
                                     WHERE path = '${path}'`;
                      
                      return sql.que(sqlText);
                      
                  },
                
                
                  remove  : (sid)=>{
                      
                          //$lg('2707::remove');
                          let sqlText = `Delete 
                                         From mp3 
                                         WHERE sid = ${sid}`;
                          
                          //$lg('2712::sqlText',sqlText);
                          return sql.run(sqlText);
                      
                  },
                  
                  //old
                  getPath : (sid)=>{
                      
                      let sqlText = `SELECT  path 
                                     FROM mp3 
                                     WHERE sid = ${sid}`;
                      
                      return sql.que(sqlText);
                      
                  },
                
                  getPartPid : async (sid)=>{
                    
                      //$lg('15579:getPartPid');
                      
                      let sqlText = `
                        SELECT  part,pid 
                        FROM mp3 
                        WHERE sid = ${sid}
                      `;
                      
                      let rsp = await sql.que(sqlText);
                      
                      //$lg('15590',JSON.stringify(rsp));
                      
                      if( rsp.da.rst == false ) return null;
                      if( rsp.da.dat.arr.length == 0 ) return null;
                      
                      return {
                        part : rsp.da.dat.arr[0][0],
                        pid  : rsp.da.dat.arr[0][1],
                      }
                      
                      
                  },
                  
                  listByLine : (sid,lidx)=>{
                      
                      let sqlText = `SELECT  id,name,path,time 
                                     FROM mp3 
                                     WHERE sid = ${sid} AND lidx = ${lidx} AND widx = -1 AND artist = 'me'
                                     ORDER BY id DESC`;
                      
                      return sql.que(sqlText);
                      
                  },
                  
                  
                
              },
        
              tableAware  : {
                  
                  //////////////////////////////////////////////////////////////
                  //  action 代码
                  //////////////////////////////////////////////////////////////
                  //  101   查字典
                  //  201   听力 单选题 听音频 看句子 选出1个单词 中文含义  
                  //  202   听力 单选题 听音频 看句子 选出1个单词 英文拼写
                  //  203   听力 单选题 听音频 ------ 选出1个单词 中文含义
                  //  204   听力 单选题 听音频 ------ 选出1个单词 英文拼写
                  //  205   听力 拼写题 听音频 看句子 补全1单词英文部分拼写
                  //  206   听力 拼写题 听音频 看句子 补全1单词英文全部拼写
                  //  207   听力 听写题 听音频 ------ 写出1个单词拼写
                  //  208   听力 听写题 听音频 ------ 写出1个句子拼写
                  //////////////////////////////////////////////////////////////
                  
                  
                  add     : (sid,lidx,widx,word,val,memo=null)=>{
                      
                      let datetime = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')";
      
                      let sqlText = `INSERT INTO aware(sid,lidx,idx,word,val,memo,time) VALUES(${sid},${lidx},${widx},'${word}',${val},'${memo}',${datetime});`;
                      
                      return sql.run(sqlText);
                      
                  },
                
                  judge   : (arr)=>{
                      let chainText = arr.join(',');
                      let sqlText = `SELECT  word,val 
                                     FROM (select word,val from aware order by datetime desc group by word) 
                                     WHERE word IN '${chainText}'`;
                      
                      return sql.que(sqlText);
                      
                  },
                
                  remove : (sid)=>{
                      return new Promise((res,rej)=>{
                          //$lg('1993::setTime');
                          let sqlText = `DELETE FROM aware
                                         WHERE sid = ${sid}`;
                          
                          //$lg('1998::sqlText',sqlText);
                          sql.run(sqlText).then((rsp)=>{
                              if(rsp.da.rst == 1) {
                                //$lg('2051::res::bgg',JSON.stringify(rsp));
                                res();
                              }
                              else {
                                $lg('3892::rej::bgo',JSON.stringify(rsp));
                                rej();
                              }
                          })
                      })
                  },
                  
                
                  getList : (sid,val,memo=undefined)=>{
                      let memoCont = '';
                      if(memo != undefined){
                        memoCont = ` AND memo = ${memo} `;
                      }
                      let sqlText = `SELECT  word,val 
                                     FROM aware 
                                     WHERE val = ${val} ${memoCont}
                                     GROUP BY word 
                                     ORDER BY word ASC ,time DESC`;
                      //$lg('4223::sql',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  getListAll : ()=>{
                    
                      let sqlText = `SELECT word,val 
                                     FROM aware
                                     GROUP BY word 
                                     having max(time)
                                     ORDER BY time desc`;
                      //$lg('4223::sql',sqlText);
                      return sql.que(sqlText);
                  },
                  
                  listUnknowBySid : async (sid)=>{
                      //
                      let sqlText1 = `
                        attach database '../mod/dict.sqlite.db' as 'dict';
                        select w.sid,w.lidx,w.idx,w.word,w.start,w.end,wd.id as did,wd.meaning
                        from(
                            select w.sid,w.lidx,w.idx,w.word,w.start,w.end
                            from (
                               SELECT word,sid,lidx,idx,start,end
                               FROM word
                               WHERE sid=${sid} and type=0 and len>3
                               GROUP BY word 
                            ) as w
                            where w.word in (
                               SELECT word
                               FROM aware
                               GROUP BY word 
                               having max(time) and val=0
                               ORDER BY time desc
                            )
                        ) as w
                        inner join dict.wd on wd.word = w.word
                        where wd.id is not null
                        group by wd.word
                      `;
                      // 曾经val=0，长度>3
                      let sqlText2 = `
                        attach database '../mod/dict.sqlite.db' as 'dict';
                        select w.sid,w.lidx,w.idx,w.word,w.start,w.end,wd.id as did,wd.meaning
                        from(
                            select w.sid,w.lidx,w.idx,w.word,w.start,w.end
                            from (
                               SELECT word,sid,lidx,idx,start,end
                               FROM word
                               WHERE sid=${sid} and type=0 and len>3
                               GROUP BY word 
                            ) as w
                            where w.word in (
                               SELECT word
                               FROM aware
                               where length(word) > 3
                               GROUP BY word 
                               having val=0
                               ORDER BY time desc
                            )
                        ) as w
                        inner join dict.wd on wd.word = w.word
                        where wd.id is not null
                        group by wd.word
                      `;
                      //$lgg('4223::sql',sqlText1);
                      let rsp = await sql.que(sqlText2);
                      if( rsp.da.rst == false ) return null;
                      
                      return rsp.da.dat.arr;
                      
                  },
                  
                  getWord : (word)=>{
                    return new Promise((res,rej)=>{
                      let sqlText = ` SELECT word,val 
                                      FROM aware 
                                      WHERE word = '${word}' 
                                      ORDER BY id DESC 
                                      LIMIT 1`;
                                     //ORDER BY val DESC ,id DESC`;
                      //$lg('4223::sql',sqlText);
                      sql.que(sqlText).then((rsp)=>{
                        if(rsp.da.rst == true)res(rsp);
                        else rej(rsp);
                      })
                    })
                  },
                  
                  getTotalNum : ()=>{
                    
                    let sqlText = `SELECT '认识的单词数' as 词汇量, COUNT(*) as 数量, '...' as 详情
                                      FROM (
                                          SELECT word, MAX(time) as latest_time 
                                          FROM aware 
                                          WHERE val = 1 
                                          GROUP BY word
                                      ) as latest_known 
                                      LEFT JOIN (
                                          SELECT word, MAX(time) as latest_time 
                                          FROM aware
                                          WHERE val = 0 
                                          GROUP BY word
                                      ) as latest_not_known 
                                      ON latest_not_known.word = latest_known.word 
                                      WHERE latest_known.latest_time >= IFNULL(latest_not_known.latest_time, '1970-01-01')
                                    
                                    union
                                    
                                      SELECT '不认识的单词数' as 词汇量, COUNT(*) as 数量, '...' as 详情
                                      FROM (
                                          SELECT word, MAX(time) as latest_time 
                                          FROM aware 
                                          WHERE val = 0 
                                          GROUP BY word
                                      ) as latest_not_known 
                                      LEFT JOIN (
                                          SELECT word, MAX(time) as latest_time 
                                          FROM aware
                                          WHERE val = 1 
                                          GROUP BY word
                                      ) as latest_known 
                                      ON latest_not_known.word = latest_known.word 
                                      WHERE latest_not_known.latest_time >= IFNULL(latest_known.latest_time, '1970-01-01');
                                    `;
                    
                    return sql.que(sqlText);
                    
                  },
                  
                  listAllUnknowWords : ()=>{
                    //$lg('11691::listAllUnknowWords');
                    let sqlText = ` select id,sid,lidx,idx,word,val
                                    from aware
                                    group by word
                                    having max(time) and val=0
                                    
                                  `;
                                     //ORDER BY val DESC ,id DESC`;
                    //$lg('11700::sql',sqlText);
                    return sql.que(sqlText);
                    
                  }
                
              },
              
              tableCata  : {
                
                  add     : (upid,name)=>{
                      
                      let time = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')";
      
                      let sqlText = `INSERT INTO cata(upid,name,time) VALUES(${upid},'${name}',${time});`;
                      
                      $lg('5425::sqlTest::bgy',sqlText);
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  list    : (upid=null)=>{
                      
                      let sqlText = `SELECT  id,upid,name,time 
                                     FROM cata 
                                     WHERE upid = ${upid} 
                                     ORDER BY time ASC`;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  update : {
                    
                    upid : (id,upid)=>{
                      
                        //$lg('1993::setTime');
                        let sqlText = `UPDATE cata 
                                       SET upid = ${upid} 
                                       WHERE id = ${id}`;
                        
                        $lg('5675::sqlText',sqlText);
                        return sql.run(sqlText)
      
                    },
                    
                    name : (id,name)=>{
                      
                        //$lg('1993::setTime');
                        let sqlText = `UPDATE cata 
                                       SET name = '${name}'
                                       WHERE id = ${id}`;
                        
                        $lg('1998::sqlText',sqlText);
                        return sql.run(sqlText)
      
                    },
                    
                  },
                  
                  del : (id)=>{
                      
                        //$lg('1993::setTime');
                        let sqlText = `DELETE FROM cata 
                                       WHERE id = ${id}`;
                        
                        //$lg('1998::sqlText',sqlText);
                        return sql.run(sqlText)
      
                    },
              },
              
              tableWordTree  : {
                
                  batAdd : (sid,lidx,arr)=>{
                      //$lg('8011::tablewordTree::batAdd');
                      let sqlText = `INSERT INTO wordTree(sid,lidx,widx,upidx,pos,word) VALUES`;
                      let i = 0;
                      for(let a of arr){
      
                        const widx  = a[0];
                        const upidx = a[1];
                        const pos   = a[2];
                        const word  = a[3].replace("'",'\u2032');
      
                        sqlText += ','.repeat(i)+`\n(${sid},${lidx},${widx},${upidx},${pos},'${word}')`;
                        i = 1;
                        
                      }
                      $lg('8025::sqlText',sqlText);
                      return sql.run(sqlText);
                      
                  },
      
                  list    : (sid,lidx)=>{
                      
                      let sqlText = `
                       SELECT widx as id,up,od,pos,hide,word
                       FROM wordTree
                       WHERE sid = ${sid} AND lidx = ${lidx} 
                       ORDER BY id ASC
                      `;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  update : (sid,lidx,widx,upidx,pos)=>{
                      
                        //$lg('1993::setTime');
                        let sqlText = `UPDATE wordTree
                                       SET upidx = ${upidx}, pos = ${pos}
                                       WHERE sid = ${sid} AND lidx = ${lidx}`;
                        
                        $lg('8062::sqlText',sqlText);
                        return sql.run(sqlText)
      
                    },
                  
                  del : (sid,lidx)=>{
                      
                      //$lg('1993::setTime');
                      let sqlText = `DELETE FROM wordTree
                                     WHERE sid = ${sid} AND lidx = ${lidx}`;
                      
                      //$lg('1998::sqlText',sqlText);
                      return sql.run(sqlText)
      
                  },
                  
              },
              
              tableTag  : {
                
                  addItem : (tag,caid,num1,num2,num3,text1,text2,text3)=>{
                      
                      $lg('16875:tableTag.addItem::bgb');
                      
                      let time = "strftime('%Y-%m-%d %H:%M:%S','now','localtime')";
                      
                      let sqlText  = `INSERT INTO tag(tag,caid,num1,num2,num3,text1,text2,text3,time) VALUES`;
                          sqlText += `('${tag}',${caid},${num1},${num2},${num3},'${text1}','${text2}','${text3}',${time})`;
                      
                      //$lgg(sqlText);
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  add     : (tag,caid,obj,text,key)=>{
                      
                      let rowId = null;
                      
                      let time = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')";
                      
                      let sqlText = `INSERT INTO tag(tag,caid,num,text1,text2,time) VALUES`;
                      
                      if( typeof(tag) == 'string' ){
                        tag = `'${tag}'`
                      }
                      
                      if( typeof(caid) == 'string' ){
                        caid = parseInt( caid );
                      }
                      
                      
                      if( Array.isArray( obj )){
                        let i = 0;
                        for( let rowid of obj ){
                          rowid = parseInt( rowid );
                          sqlText += ','.repeat(i) + `(${tag},${caid},${rowid},'${text}',${time})`;
                          i = 1 ;
                        }
                      }else if ( typeof(obj) == 'string' || typeof(obj) == 'number' ){
                        rowId = parseInt( obj );
                        sqlText = `INSERT INTO tag(tag,caid,num,text1,text2,time) VALUES('${tag}',${rowId},'${text1}','${text2}',${time});`;
                        
                      }else{
                        return alert('6362::rowId == null');
                      }
                      
      
                      
                      $lg('6367::sqlTest::bgy',sqlText);
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  batMarkSentence  : (sid,arr)=>{
                      
                      let time = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')";
                      
                      let sqlText = `INSERT INTO tag(tag,num1,num2,text1,text2,text3,time) VALUES`;
                      
                      let i = 0;
                      for( let a of arr ){
                        let tag   = a[0];
                        let lidx  = a[1];
                        
                        sqlText += ','.repeat(i) + `('${tag}',${sid},${lidx},'word','speaker','sid,lidx',${time})`;
                        i = 1 ;
                      }
                      
                      //$log.lgg('6367::sqlTest::bgy',sqlText);
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  
                  listCaid    : ( caid )=>{
                      
                      let sqlText = `SELECT  tag,caid,num1,text
                                     FROM tag 
                                     WHERE caid = ${caid} 
                                     ORDER BY num1 desc`;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  update : {
                    
                    upid : (id,upid)=>{
                      
                        //$lg('1993::setTime');
                        let sqlText = `UPDATE cata 
                                       SET upid = ${upid} 
                                       WHERE id = ${id}`;
                        
                        $lg('5675::sqlText',sqlText);
                        return sql.run(sqlText)
      
                    },
                    
                    name : (id,name)=>{
                      
                        //$lg('1993::setTime');
                        let sqlText = `UPDATE cata 
                                       SET name = '${name}'
                                       WHERE id = ${id}`;
                        
                        $lg('1998::sqlText',sqlText);
                        return sql.run(sqlText)
      
                    },
                    
                  },
                  
                  //num1:used to storage rowId
                  //text:used to storage tableName
                  remove  : (num1,text)=>{
                      
                      //$lg('2707::remove');
                      let sqlText = `Delete 
                                     From tag
                                     WHERE num1 = ${num1} AND text='${text}'`;
                      
                      //$lg('2712::sqlText',sqlText);
                      return sql.run(sqlText)
                  
                  },
                  
                  //speaker,sid
                  listSpeaker : ( sid )=>{
                      
                      let sqlText = `SELECT  tag AS speaker,num1 AS sid, count(tag) AS num
                                     FROM tag 
                                     WHERE  num1  = ${sid} AND
                                            text1 = 'word' AND
                                            text2 = 'speaker' 
                                     GROUP BY tag
                                     ORDER BY id asc`;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  listSpeakerSentence : ( sid,speaker )=>{
                      
                      let sqlText = `SELECT  num1 as sid,num2 as lidx,tag as speaker
                                     FROM tag 
                                     WHERE  tag  = '${speaker}' AND
                                            text1 = 'word' AND
                                            sid = ${sid}
                                    
                                     `;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  listTagsNotAboutSpeaker : ( about, sid = null, lidx = null )=>{
                      
                      let cdsSid = '';
                      if( sid !== null && typeof sid == 'number'){
                        cdsSid = ` num1 = ${sid} AND `;
                      }
                      
                      let cdsLidx = '';
                      if( lidx !== null && typeof lidx == 'number'){
                        cdsLidx = ` num2 = ${lidx} AND `;
                      }
                      
                      let sqlText = `SELECT  tag
                                     FROM tag 
                                     WHERE  ${cdsSid}
                                            ${cdsLidx}
                                            text1 = 'word' AND
                                            text2 = '${about}' 
                                     `;
                      //$lgg('12279::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  addTagsForSentence : ( tags, sid, lidx = null, about )=>{
                      
                      if( typeof tag == 'string'){
                        tags = [tags];
                      }
                      
                      let time = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')";
                      
                      let sqlText  = `INSERT INTO tag(tag,num1,num2,text1,text2,text3,time) VALUES`;
                      let i = 0;
                      for( let tag of tags ){
                          sqlText += ','.repeat(i) +`('${tag}',${sid},${lidx},'word','${about}','sid,lidx',${time})`;
                          i = 1;
                      }
                      $lgg('12081::sql::bgy',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  listenProgress : {
                    save :  async (sid,action,item)=>{
                      
                      //$lg('17060::bgy','listenProgress.save');
                      
                      let tag  = 'listen';
                      let caid = -1;
                      let [n1,n2,n3] = [sid,action,item];
                      let [t1,t2,t3] = ['progress','',''];
                      
                      let lastItem = await dat.tableTag.listenProgress.getLastItem(sid,action);
                      
                      if( lastItem >= 0 ) return dat.tableTag.listenProgress.update(sid,action,item);
                      
                      return dat.tableTag.addItem(tag,caid,n1,n2,n3,t1,t2,t3);
                    },
                    
                    getLastItem : async (sid,action)=>{
                      let sqlText = `
                        select num3
                        from tag
                        where tag = 'listen' 
                              and text1 = 'progress'
                              and num1 = ${sid}
                              and num2 = ${action}
                        group by num1
                        having max(time)
                      `;
                      //$lgg('17098:getLastItem',sqlText);
                      let rsp = await sql.que(sqlText);
                      //$lgg('17098:getLastItem',JSON.stringify(rsp));
                      
                      if( rsp.da.rst == false ) return -1;
                      if( rsp.da.dat.arr.length == 0 ) return -1;
                      
                      return rsp.da.dat.arr[0][0];
                      
                    },
                    
                    update : (sid,action,item)=>{
                      let sqlText = `
                        update tag
                        set num3 = ${item}
                        where tag = 'listen' 
                              and text1 = 'progress'
                              and num1 = ${sid}
                              and num2 = ${action}
                      `;
                      return sql.run(sqlText);
                    },
                    
                  }
                  
              },
              
              tableMemo  : {
                
                  add   : (sid,lidx,memo,type)=>{
                      
                      let time = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')";
      
                      let sqlText = `INSERT INTO memo(sid,lidx,memo,type,time) VALUES(${sid},${lidx},'${memo}',${type},${time});`;
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  drop   : (id)=>{
        
                      let sqlText = `DELETE FROM memo
                                     WHERE id = ${id}`;
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  addSent   : (sid,lidx,memo)=>{
                      
                      let type = 2;// this.MEMO_TYPE_SENTENTS;
                      
                      return dat.tableMemo.add(sid,lidx,memo,type);
                      
                  },
                  
                  listSTS    : (sid,lidx)=>{
                      
                      let sqlText = `SELECT  id,sid,lidx,memo,time 
                                     FROM memo 
                                     WHERE sid = ${sid} AND lidx = ${lidx}
                                     ORDER BY time ASC`;
                      //$lg('4223::sql',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  listStsAll    : (sid)=>{
                      
                      let sqlText = `
                         SELECT  id,sid,lidx,memo,time 
                         FROM memo 
                         WHERE sid = ${sid}
                         group by lidx
                         having max(time)
                         ORDER BY lidx ASC
                      `;
                      //$lg('4223::sql',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  
              },
              
              tableVoice  : {
                
                  add   : (sid,lidx,memoid,start,end)=>{
      
                      let sqlText = `INSERT INTO voice(sid,lidx,memoid,start,end) VALUES(${sid},${lidx},'${memoid}',${start},${end});`;
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  list    : (upid=null)=>{
                      
                      let sqlText = `SELECT  id,upid,name 
                                     FROM cata 
                                     WHERE upid = ${upid} 
                                     ORDER BY upid ASC ,name ASC,time ASC`;
                      //$lg('4223::sql',sqlText);
                      return sql.que(sqlText);
                      
                  },
                  
                  
              },
              
              tableActivity  : {
                
                  //////////////////////////////////////////////////////////////
                  //  action 代码
                  //////////////////////////////////////////////////////////////
                  //    1   打开文章                                         -1
                  //  101   查字典                                            -1
                  //  102   标记陌生词                                        -1
                  //  103   标记熟悉词                                        +1
                  //  160   翻译句子                                          +1
                  //  201   听力 单选题 听音频 看句子 选出1个单词 中文含义     1
                  //  202   听力 单选题 听音频 看句子 选出1个单词 英文拼写     1
                  //  203   听力 单选题 听音频 ------ 选出1个单词 中文含义     1
                  //  204   听力 单选题 听音频 ------ 选出1个单词 英文拼写     1
                  //  205   听力 拼写题 听音频 看句子 补全1单词英文部分拼写    2
                  //  206   听力 拼写题 听音频 看句子 补全1单词英文全部拼写    4
                  //  207   听力 听写题 听音频 ------ 写出1个单词拼写         10
                  //  208   听力 听写题 听音频 ------ 写出1个句子拼写         80
                  //  301   口语 听写题 听音频 看句子 复述单词
                  //  302   口语 听写题 听音频 看句子 复述句子
                  //  303   口语 听写题 听音频 ------ 复述单词
                  //  304   口语 听写题 听音频 ------ 复述句子
                  //
                  //////////////////////////////////////////////////////////////
                  //  type 代码
                  //////////////////////////////////////////////////////////////
                  //  0   单词                                         -1
                  //  1   词组                                            -1
                  //  2   句子                                            -1
                  //////////////////////////////////////////////////////////////
                
                  add   : (sid, lidx = 0, widx = 0, word = '',action = 1, value = 0, ms = 0)=>{
                      
                      //$lg('16779:tableActivity.add')
                      let type = 0;
                      if(/\s/.test(word)) type = 1;
                      
                      let time = "strftime('%Y-%m-%d %H:%M:%S','now','localtime')";
      
                      let sqlText = `
                          INSERT INTO activity(sid,lidx,widx,word,type,action,value,ms,time) 
                          VALUES(${sid},${lidx},${widx},'${word}',${type},${action},${value},${ms},${time});
                      `;
                      
                      return sql.run(sqlText);
                      
                  },
                  
                  // 列出陌生单词
                  listStrangerWord : ()=>{
                    
                      let sqlText = `
                        SELECT word,value
                        FROM activity
                        GROUP BY word 
                        having max(time)
                       `;
                      //$lg('4223::sql',sqlText);
                      return sql.que(sqlText);
                  },
                  
                  listUnknowBySid : async (sid)=>{
                      //
                      let sqlText1 = `
                        attach database '../mod/dict.sqlite.db' as 'dict';
                        select w.sid,w.lidx,w.idx,w.word,w.start,w.end,wd.id as did,wd.meaning
                        from(
                            select w.sid,w.lidx,w.idx,w.word,w.start,w.end
                            from (
                               SELECT word,sid,lidx,idx,start,end
                               FROM word
                               WHERE sid=${sid} and type=0 and len>3
                               GROUP BY word 
                            ) as w
                            where w.word in (
                               SELECT word
                               FROM activity
                               GROUP BY word 
                               having max(time) and value < 1
                               
                            )
                        ) as w
                        inner join dict.wd on wd.word = w.word
                        where wd.id is not null
                        group by wd.word
                      `;
                      // 曾经val=0，长度>3
                      let sqlText2 = `
                        attach database '../mod/dict.sqlite.db' as 'dict';
                        select w.sid,w.lidx,w.idx,w.word,w.start,w.end,wd.id as did,wd.meaning
                        from(
                            select w.sid,w.lidx,w.idx,w.word,w.start,w.end
                            from (
                               SELECT word,sid,lidx,idx,start,end
                               FROM word
                               WHERE sid=${sid} and type=0 and len>3
                               GROUP BY word 
                            ) as w
                            where w.word in (
                               SELECT word
                               FROM activity
                               where length(word) > 3
                               GROUP BY word 
                               having value < 1
                               
                            )
                        ) as w
                        inner join dict.wd on wd.word = w.word
                        where wd.id is not null
                        group by wd.word
                      `;
                      $lgg('4223::sql',sqlText2);
                      let rsp = await sql.que(sqlText2);
                      if( rsp.da.rst == false ) return null;
                      
                      return rsp.da.dat.arr;
                      
                  },
                  
                  //最新状态值
                  getWordValue : (word)=>{
                    
                      let sqlText = `
                        SELECT word,value
                        FROM activity
                        where word = '${word}'
                        GROUP BY word 
                        having max(time)
                       `;
                      //$lg('4223::sql',sqlText);
                      return sql.que(sqlText);
                  },
                  
                  
              },
              
              tableDict : {
                
                listCutNumByDay : async ( date )=>{
                      //
                      let sqlText1 = `
                        attach database '../mod/dict.sqlite.db' as 'dict';
                        select w.sid,w.lidx,w.idx,w.word,w.start,w.end,wd.id as did,wd.meaning
                        from(
                            select w.sid,w.lidx,w.idx,w.word,w.start,w.end
                            from (
                               SELECT word,sid,lidx,idx,start,end
                               FROM word
                               WHERE sid=${sid} and type=0 and len>3
                               GROUP BY word 
                            ) as w
                            where w.word in (
                               SELECT word
                               FROM activity
                               GROUP BY word 
                               having max(time) and value < 1
                               
                            )
                        ) as w
                        inner join dict.wd on wd.word = w.word
                        where wd.id is not null
                        group by wd.word
                      `;
                      // 曾经val=0，长度>3
                      let sqlText2 = `
                        attach database '../mod/dict.sqlite.db' as 'dict';
                        select w.sid,w.lidx,w.idx,w.word,w.start,w.end,wd.id as did,wd.meaning
                        from(
                            select w.sid,w.lidx,w.idx,w.word,w.start,w.end
                            from (
                               SELECT word,sid,lidx,idx,start,end
                               FROM word
                               WHERE sid=${sid} and type=0 and len>3
                               GROUP BY word 
                            ) as w
                            where w.word in (
                               SELECT word
                               FROM activity
                               where length(word) > 3
                               GROUP BY word 
                               having value < 1
                               
                            )
                        ) as w
                        inner join dict.wd on wd.word = w.word
                        where wd.id is not null
                        group by wd.word
                      `;
                      $lgg('4223::sql',sqlText2);
                      let rsp = await sql.que(sqlText2);
                      if( rsp.da.rst == false ) return null;
                      
                      return rsp.da.dat.arr;
                      
                  },
                  
              },
              
              tableBook : {
                
                addLine : ( up,line,content,type )=>{
                  
                  let sqlText = ` INSERT INTO book(up,line,content,type) VALUES(${up},'${line}','${content}',${type})`;
                      
                  //$log.lgg('6490::sqlText',sqlText);
                  return sql.run(sqlText,this.php.book);
                },
                
                list    : ( up )=>{
                      
                      let sqlText = `SELECT  up,line,content
                                     FROM book
                                     WHERE up = ${up} 
                                     ORDER BY id ASC`;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText,php.book);
                      
                  },
                  
                listCont  : ( bookid )=>{
                      
                      let sqlText = `SELECT  id,up,line,content
                                     FROM book
                                     WHERE id >= ${bookid} and id < ${bookid+100}
                                     ORDER BY id ASC`;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText,php.book);
                      
                },
                  
                listMenu  : ( up )=>{
                      
                      let sqlText = `SELECT  up,line,content
                                     FROM book
                                     WHERE up = ${up} And type < 3
                                     ORDER BY id ASC`;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText,php.book);
                      
                  },
                
                selfAddType : ( bookid )=>{
                      let sqlText = `update book
                                     set type = type+1
                                     WHERE id = ${bookid}
                                     `;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText,php.book);
                },
                
                update : {
                  
                  up : ( line,bookid )=>{
                      let sqlText = `update book
                                     set up = ${line}
                                     WHERE id = ${bookid}
                                     `;
                      //$lg('5435::sql::bgy',sqlText);
                      return sql.que(sqlText,php.book);
                  },
                
                },
              },
              
              tableOption : {
                
                update   : async (tag, key, val)=>{
                    
                    let sqlText0 = `select val from option where tag='${tag}' and key='${key}';`;
                    let sqlText1 = `INSERT INTO option(tag,key,val) VALUES('${tag}','${key}','${val}');`;
                    let sqlText2 = `update option 
                                    set val='${val}' 
                                    where key='${key}' and tag='${tag}';`;
                    let has = await sql.que(sqlText0);
                    if( has.da.dat.arr.length == 0){
                      return sql.run(sqlText1);
                    }else{
                      return sql.run(sqlText2);
                    }
                    
                },
                
                selfAdd   : async (tag, key)=>{
                    
                    let sqlText = `update option 
                                    set val=val+1 
                                    where tag='${tag}' and key='${key}';`;
                    
                    return sql.run(sqlText);
                    
                    
                },
                
                getVal    : (tag,key)=>{
                      
                    let sqlText = `SELECT  val
                                   FROM option
                                   WHERE tag='${tag} AND key = '${key}'`;
                    //$lg('5435::sql::bgy',sqlText);
                    return sql.que(sqlText);
                      
                },
                
                getFissionVal  : async (which)=>{
                    
                    if(!['img','mp3','voice'].includes(which)) return alert('16861:只能是"img","mp3","voice"');
                    
                    let sqlText = `SELECT  val
                                   FROM option
                                   WHERE tag = 'fission' AND key = '${which}'`;
                    //$lg('5435::sql::bgy',sqlText);
                    let rsp = await sql.que(sqlText);
                    if(rsp.da.rst == false ) return -1;
                    if(rsp.da.dat.arr.length == 0 ) return -1;
                    
                    return rsp.da.dat.arr[0][0]
                    
                },
                
                listAll    : ()=>{
                      
                    let sqlText = `SELECT  tag,key,val
                                   FROM option
                                   ORDER BY tag ASC,id ASC`;
                    //$lg('5435::sql::bgy',sqlText);
                    return sql.que(sqlText);
                      
                },
                
                updateAll    : (datArr)=>{
                      
                    let sqlText = `INSERT OR REPLACE  INTO option
                                   (tag,key,val) VALUES`;
                    
                    let i = 0;
                    for( let arr of datArr){
                      
                      sqlText += ','.repeat(i) + `(${arr[0]}, ${arr[1]}, ${arr[2]})`;
                      i = 1;

                    }            
                                   
                    $lgg('13352::tableOption.updateAll',sqlText);
                    return sql.que(sqlText);
                      
                },
                
                testUpdateAll : ()=>{
                  
                  let datArr = [
                      ['fore','hsl(20,20%,20%)','color'],
                      ['back','hsl(60,60%,60%)','color'],
                      ['highpass','1000','rec'],
                      ['lowpass','500','rec'],
                    ]
                  
                  return dat.tableOption.updateAll(datArr);
                }
                
              },
              
              fn : {
                
                
                listTableName : ()=>{
                  
                  let sqlText = ` select name from sqlite_sequence order by name asc`;
                  return sql.que(sqlText)
                  
                },
                
                getTableData : ( name, afterId = -1, num = 100 )=>{
                  
                  let sqlText = ` select * 
                                  from ${name} 
                                  order by id asc 
                                  limit ${num} offset ${afterId}`;
                  return sql.que(sqlText)
                  
                },
                
                comparePronunciation : (sid1,sid2,speakerTag,len=4)=>{
                  
                  let sqlText = `
                      select a.sid,a.lidx,a.idx,a.word,a.start,a.end,
                              b.start as st,b.end as ed 
                      from word as a
                      inner join ( 
                          select word,start,end 
                          from word 
                          where type=0 and len >= ${len} and sid = ${sid2} and 
                                lidx in (
                                      select num2 as lidx 
                                      from tag 
                                      where tag = '${speakerTag}' and text1 = 'word' and text2 = 'speaker' and num1 = ${sid2}
                                ) 
                          group by word
                      ) as b on b.word = a.word
                      where a.sid=${sid1}
                  `;
                  
                  return sql.que(sqlText);
                  
                },
                
                
              }
              
          }
  
          let messageFromHost = {
            
            getData     : async (op,da)=>{
              
              //$lg('13011::bgo','getData',op,JSON.stringify(da));
              
              let obj = `dat.${da.obj}`;
              
              if( da.obj == null ) obj = 'dat';
              
              let fn = da.fn;
              
              let args = da.args;
              
              const func = eval(`${obj}.${fn}`);
              
              //$lg('13281::func::bgo',obj,func.name,...args);
              
              // 在 obj 上调用函数
              const rsp = await (func.call(eval(obj),...args));
              
              //$lgg('13024::bgy',JSON.stringify(rsp));
              
              let rst = {
                str : `${obj}.${fn}`,
                rsp : rsp,
              }
              self.postMessage({op:op,da:rst});
              
            },

          }
          
          ///////////////////////////////
          
          reflectPolyfill();
          
          new Handler( messageFromHost )
          
          
          
          //$lg('service.data is running');
          
        },
        
        messageFromWorker  : (event)=>{
            let data = event.data;
            let op  = data.op;
            let da  = data.da;
            let fn = Reflect.get(this.service.data.rsp,op);
            //$lg('13866',fn,op);
            if(fn)fn(op,da);
            
        },
        
        errorFromWorker    : (e)=>{
            $lg('156::err:',e.message);
        },
        
        init   : async ()=>{
            //$lg('1380::webman.start',Log.now());
            this.dataSvr.script     = this.service.data.worker;
            this.dataSvr.onmessage  = this.service.data.messageFromWorker;
            this.dataSvr.onerror    = this.service.data.errorFromWorker;
            await this.dataSvr.start();
            //$lg('timeService init done');
        },
        /*
        pars   : {
            addr : '../include/handler.php',
            file : '../app/dat/data.sqlite3',
        },*/
    
        req    : ( funcString, ...args )=>{
          let op = 'getData';
          let da = null;
          let m = /^(.+)\.(.+)$/.exec(funcString);
          let n = /^([a-zA-Z]+)$/.exec(funcString);
          if(m){
            da = {
              obj  : m[1],
              fn   : m[2],
              args : args,
            }
          }else
          if(n){
            da = {
              obj  : null,
              fn   : n[1],
              args : args,
            }
          }
          //$lg('13083::data.req',funcString,op,JSON.stringify(da));
          
          let pms = new Promise((ok,fail)=>{
            document.addEventListener(`dat.${funcString}.done`,(e)=>{
              //$lg('13350::bgy',`dat.${funcString}.done`,JSON.stringify(e.detail));
              ok(e.detail);
            },0)
          })
          try{
            this.dataSvr.post({op,da});
          }catch(err){
            $lg('12259',err.message)
          }
          return pms;
          
        },
        
        rsp    : {
          
          getData : ( op, da )=>{
            
            let funcString  = da.str;
            let rsp         = da.rsp;
            //$lg('13367::bgy',`${funcString}.done`);
            let event = new CustomEvent(`${funcString}.done`,{detail:rsp});
            document.dispatchEvent( event );
            
          },
          
          
          lg : (op,da)=>{
            $lg(...da);
            return this;
          },
          
          lgg : (op,da)=>{
            $log.lgg(...da);
            return this;
          },
          
        },
        
        post   : (...args)=>{
              this.dataSvr.post(...args);
          },
  
      },

    }

}